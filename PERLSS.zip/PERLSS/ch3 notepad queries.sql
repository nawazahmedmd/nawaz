DELETE FROM legacy.T_CDE_DISENROLL_REASONS_CH3  
DELETE FROM legacy.T_RE_DISENROLL_REASONS_CH3  
DELETE FROM legacy.T_RE_ELIG_CH3  
DELETE FROM legacy.T_RE_BASE_CH3  
DELETE FROM legacy.T_PUB_HLTH_PGM_CH3  
DELETE FROM legacy.T_RE_CHOICES_TRACKING_CH3  
DELETE FROM legacy.T_RE_PAT_LIAB_CH3  
DELETE FROM legacy.T_RE_LIV_ARNG_CH3  
DELETE FROM legacy.T_RE_PMP_ASSIGN_CH3  
DELETE FROM legacy.T_PMP_SVC_LOC_CH3  
DELETE FROM legacy.T_PR_PROV_CH3 ;


SELECT *
FROM PERLSS.ENR_RQST
where last_modified_dt is NOT NULL
order by last_modified_dt DESC
WHERE TRACKING_CD ='C' 
--AND ENR_STATUS_CD='ENR'
 AND ENR_GRP_CD='CG3'
;

CREATE TABLE CV_CH3_RECON
(RID VARCHAR2(15),
NUM_SSN CHAR(9),
SAK_RECIP NUMBER(9,0),
DTE_EFFECTIVE NUMBER(8,0), 
DTE_END NUMBER(8,0),
DTE_ADD NUMBER(8,0),
LAST_UPDATE_DATE NUMBER(8,0)
);

SELECT distinct a.prsn_id ,a.pae_id as enrpaeid ,a.enr_id,a.enr_status_cd ,a.enr_grp_cd ,a.enr_start_dt ,a.enr_end_dt ,
c.pae_id as adjpaeid,c.adj_status_cd as adjstatus,c.pae_eff_dt,c.pae_end_dt,c.enr_grp_cd as adjgrpcd,
b.pae_id as paerqstpae_id ,
b.program_cd ,
b.status_cd as paestatus FROM perlss.enr_rqst a
join perlss.pae_rqst b on a.prsn_id =b.prsn_id and a.pae_id =b.pae_id
join perlss.adj_rqst c on a.prsn_id=c.prsn_id  and  b.pae_id =c.pae_id
--left join perlss.com_applcnt_access d on  a.prsn_id=d.prsn_id
WHERE a.enr_grp_cd ='CG3'  and a.tracking_cd ='C' and a.active_sw ='Y' and a.enr_status_cd in('ENR','DIS')
and c.active_sw ='Y' order by 1;

--check any disenroll record
select * from perlss.enr_rqst
where   (CREATED_BY LIKE 'CV_CH3_%' OR last_modified_by LIKE 'CV_CH3_%')
AND TRACKING_CD = 'C'
and enr_end_dt < now();


--any disenroll after conv date
--check any disenroll record
select * from perlss.enr_rqst
where   (CREATED_BY LIKE 'CV_CH3_%' OR last_modified_by LIKE 'CV_CH3_%')
AND TRACKING_CD = 'C'
and enr_end_dt > now() and enr_end_dt < '12/31/2299';


select count(1) from lt_cnv_src_mmis.T_CDE_DISENROLL_REASONS union all
select count(1) from lt_cnv_src_mmis.T_RE_DISENROLL_REASONS union all
select count(1) from lt_cnv_src_mmis.T_RE_ELIG union all
select count(1) from lt_cnv_src_mmis.T_RE_BASE union all
select count(1) from lt_cnv_src_mmis.T_PUB_HLTH_PGM union all
select count(1) from lt_cnv_src_mmis.T_RE_CHOICES_TRACKING union all
select count(1) from lt_cnv_src_mmis.T_RE_PAT_LIAB union all
select count(1) from lt_cnv_src_mmis.T_RE_LIV_ARNG UNION ALL
select count(1) from lt_cnv_src_mmis.T_PR_PROV UNION ALL
SELECT COUNT(1) FROM lt_cnv_src_mmis.T_RE_PMP_ASSIGN UNION ALL
select count(1) from lt_cnv_src_mmis.T_PMP_SVC_LOC 

--check tracking code 'c' query
select
    prsn_id,
    pae_id,
    enr_id,
    tracking_cd,
    enr_status_cd,
    enr_grp_cd,
    enr_start_dt,
    enr_end_dt,
    tns_id
from
    perlss.enr_rqst er
where
    enr_id in (
    select
        max(enr_id)
    from
        perlss.enr_rqst
    where
        active_sw = 'Y'
    group by
        prsn_id,
        pae_id)
    and enr_status_cd = 'ENR'
    and enr_grp_cd = 'CG3'
    and tracking_cd = 'C'
order by
    er.id desc;
	
	
	
	--mco query
select distinct prsn_id, assigned_mco_sw  from perlss.com_applcnt_access
where prsn_id in (select perlss_indv_id from legacy.wrk_ltss_clients_ch3 wlcc)
and assigned_mco_sw is not null
order by prsn_id;


--SEQUENCE
select ID,ENR_ID,* from perlss.enr_rqst ercb
where 1=1-- last_modified_by  like 'CV_CH3%'
order by ENR_ID DESC;

UPDATE perlss.tmg_task
SET task_status_cd  = 'CL', 
closure_dtl_desc  = 'Received CH3 MMIS record',
last_modified_by = 'CV_CH3',
last_modified_dt = now()
where task_status_cd  <> 'CL'
and input_Id in (select tmg_task.input_Id from  perlss.tmg_task,perlss.Tmg_Doc,perlss.tmg_task_master
    where
        tmg_task.input_Id = Tmg_Doc.input_Id
        and Tmg_Doc.task_Master_Id = tmg_task_master.task_Master_Id
        and tmg_task.task_status_cd <> 'CL'
        and tmg_task_master.task_Master_Id = 8)
and enr_id in (select enr_id from perlss.enr_rqst where active_sw='N' and last_modified_by like 'CV_CH3_SE13_%');


UPDATE perlss.tmg_task
SET task_status_cd  = 'CL', 
closure_dtl_desc  = 'Received CH3 MMIS record',
last_modified_by = 'CV_CH3',
last_modified_dt = now()
where task_status_cd  <> 'CL'
and input_Id in (select tmg_task.input_Id from  perlss.tmg_task,perlss.Tmg_Doc,perlss.tmg_task_master
    where
        tmg_task.input_Id = Tmg_Doc.input_Id
        and Tmg_Doc.task_Master_Id = tmg_task_master.task_Master_Id
        and tmg_task.task_status_cd <> 'CL'
        and tmg_task_master.task_Master_Id = 8)
and enr_id in (select enr_id from perlss.enr_rqst where active_sw='N' and last_modified_by like 'CV_CH3_SE14_%');


select * from perlss.enr_rqst where prsn_id in (6000062757,
6000062207,
6000062365,
6000062923,
6000063177,
6000063191,
6000062540,
6000062729,
6000063302,
6000061832,
6000062394,
6000062459,
6000063174,
6000063333,
6000063631,
6000003916,
6000062529,
6000063102,
6000063581,
6000063002,
6000063286,
6000063633,
6000062764,
6000063010,
6000062024,
6000063416
)
order by prsn_id;


select count(1) from perlss.adj_rqst ar ;



3.delete from perlss.aud_fwr_entity where created_by like 'CV_CH3%'

--Delete the 
4.delete FROM PERLSS.enr_dsnr_dtls WHERE CREATED_BY like 'CV_CH3%';
5.delete from perlss.slt_details where created_by like 'CV_CH3%'
6.delete from perlss.enr_bnft eb  where created_by like 'CV_CH3%'
7.delete from perlss.enr_patient_lblty_dtls  eb  where created_by like 'CV_CH3%'
8.delete from perlss.enr_financial_elig  eb  where created_by like 'CV_CH3%'
9.delete from perlss.enr_dtls ed where created_by like 'CV_CH3%'
10.delete from perlss.enr_rqst er where created_by like 'CV_CH3%'

11. --Roll back ENR RQST table updates 
update perlss.enr_rqst a
set enr_start_dt=b.enr_start_dt,
enr_end_dt=b.enr_end_dt ,
tracking_cd=b.tracking_cd,
last_modified_by=b.last_modified_by,
last_modified_dt=b.last_modified_dt,
active_sw = b.active_sw,
hstry_sw = b.hstry_sw
from legacy.enr_rqst_ch3_backup b
where a.enr_id=b.enr_id
and a.last_modified_by like 'CV_CH3%'
and a.enr_status_cd in ('ENR','DIS','PFE','NEE');


update perlss.enr_rqst A
set tracking_cd ='R' where ID in (
select id
from perlss.enr_rqst er
where    enr_id in (    select        max(enr_id)
    from        perlss.enr_rqst    where        active_sw = 'Y' --and prsn_id = 6000063287
    group by        prsn_id,        pae_id)
    and enr_status_cd = 'ENR'
    and enr_grp_cd = 'CG3'
        and tracking_cd = 'C'
order by    er.id desc);




select * from perlss.enr_rqst
where   (CREATED_BY LIKE 'CV_CH3_%' OR last_modified_by LIKE 'CV_CH3_%')
AND TRACKING_CD = 'C'
and enr_end_dt < now();


--any disenroll after conv date
--check any disenroll record
select * from perlss.enr_rqst
where   (CREATED_BY LIKE 'CV_CH3_%' OR last_modified_by LIKE 'CV_CH3_%')
AND TRACKING_CD = 'C'
and enr_end_dt > now() and enr_end_dt < '12/31/2299';


select COUNT(1), PRSN_ID , PAE_ID from PERLSS.ENR_RQST where tracking_cd = 'C' 
and enr_grp_cd='CG3' and active_sw= 'Y' and enr_status_cd  in ('DIS','ENR')
and PRSN_ID in (select perlss_indv_id from legacy.wrk_ltss_clients_ch3 wlcc)
group  by PRSN_ID , PAE_ID
having COUNT(1)>1

select distinct PRSN_ID from PERLSS.ENR_RQST where tracking_cd = 'C' 
and enr_grp_cd='CG3' 
and active_sw= 'Y' 
and enr_status_cd <>'ENR'
and PRSN_ID in (select perlss_indv_id from legacy.wrk_ltss_clients_ch3 wlcc);

select distinct PRSN_ID from PERLSS.ENR_RQST where tracking_cd = 'C' 
and enr_grp_cd='CG3' 
and active_sw= 'Y' 
and enr_status_cd <>'ENR'
and PRSN_ID in (select perlss_indv_id from legacy.wrk_ltss_clients_ch3 wlcc)



--Case 1 6000044954
select ENR_ID ,PAE_ID, enr_start_dt , ENR_END_DT ,TRACKING_CD, enr_status_cd , active_sw , created_by , last_modified_by 
from perlss.ENR_RQST where 
enr_grp_cd ='CG3' AND
prsn_id = 6000044954
order by enr_id desc

select ENR_ID ,PAE_ID, enr_start_dt , ENR_END_DT ,TRACKING_CD, enr_status_cd , active_sw , created_by , last_modified_by 
from legacy.ENR_RQST_ch3_backup where 
enr_grp_cd ='CG3' AND
prsn_id = 6000044954
order by enr_id desc

do we need update enr_end_dt with 2022-11-17 as MMIS start date is 2022-11-17?

--Case 2 6000062394
select ENR_ID ,PAE_ID, enr_start_dt , ENR_END_DT ,TRACKING_CD, enr_status_cd , active_sw , created_by , last_modified_by 
from perlss.ENR_RQST where 
enr_grp_cd ='CG3' AND
prsn_id = 6000062394
order by enr_id desc

select ENR_ID ,PAE_ID, enr_start_dt , ENR_END_DT ,TRACKING_CD, enr_status_cd , active_sw , created_by , last_modified_by 
from legacy.ENR_RQST_ch3_backup where 
enr_grp_cd ='CG3' AND
prsn_id = 6000062394
order by enr_id desc

do we need update enr_end_dt with 2022-11-17 as MMIS start date is 2022-11-17?


--Case 3 6000062207
select ENR_ID ,PAE_ID, enr_start_dt , ENR_END_DT ,TRACKING_CD, enr_status_cd , active_sw , created_by , last_modified_by 
from perlss.ENR_RQST where 
enr_grp_cd ='CG3' AND
prsn_id = 6000062207
order by enr_id desc

select ENR_ID ,PAE_ID, enr_start_dt , ENR_END_DT ,TRACKING_CD, enr_status_cd , active_sw , created_by , last_modified_by 
from legacy.ENR_RQST_ch3_backup where 
enr_grp_cd ='CG3' AND
prsn_id = 6000062207
order by enr_id desc


--6000063332
select ENR_ID ,PAE_ID, enr_start_dt , ENR_END_DT ,TRACKING_CD, enr_status_cd , active_sw , created_by , last_modified_by 
from perlss.ENR_RQST where 
enr_grp_cd ='CG3' AND
prsn_id = 6000063332
order by enr_id desc

select ENR_ID ,PAE_ID, enr_start_dt , ENR_END_DT ,TRACKING_CD, enr_status_cd , active_sw , created_by , last_modified_by 
from legacy.ENR_RQST_ch3_backup where 
enr_grp_cd ='CG3' AND
prsn_id = 6000063332
order by enr_id desc



--6000042078
select ENR_ID ,PAE_ID, enr_start_dt , ENR_END_DT ,TRACKING_CD, enr_status_cd , active_sw , created_by , last_modified_by 
from perlss.ENR_RQST where 
enr_grp_cd ='CG3' AND
prsn_id = 6000042078
order by enr_id desc

select ENR_ID ,PAE_ID, enr_start_dt , ENR_END_DT ,TRACKING_CD, enr_status_cd , active_sw , created_by , last_modified_by 
from legacy.ENR_RQST_ch3_backup where 
enr_grp_cd ='CG3' AND
prsn_id = 6000042078
order by enr_id desc

--6000039547

--6000044954
--6000062394
--6000062207

select ENR_ID ,PAE_ID, enr_start_dt , ENR_END_DT ,TRACKING_CD, enr_status_cd , active_sw , created_by , last_modified_by 
from perlss.ENR_RQST where 
enr_grp_cd ='CG3' AND
prsn_id = 6000039547
order by enr_id desc

update perlss.ENR_RQST
set enr_end_dt = '2299-12-31'
where enr_end_dt is null 
and prsn_id = 6000039547
and tracking_cd='C';


select ENR_ID ,PAE_ID, enr_start_dt , ENR_END_DT ,TRACKING_CD, enr_status_cd , active_sw , created_by , last_modified_by 
from perlss.ENR_RQST where 
enr_grp_cd ='CG3' AND
prsn_id = 6000029891
order by enr_id desc;

UPDATE perlss.tmg_task
SET task_status_cd  = 'CL', 
closure_dtl_desc  = 'Received CH3 MMIS record',
last_modified_by = 'CV_CH3',
last_modified_dt = now()
where task_status_cd  <> 'CL'
and input_Id in (select tmg_task.input_Id from  perlss.tmg_task,perlss.Tmg_Doc,perlss.tmg_task_master
    where
        tmg_task.input_Id = Tmg_Doc.input_Id
        and Tmg_Doc.task_Master_Id = tmg_task_master.task_Master_Id
        and tmg_task.task_status_cd <> 'CL'
        and tmg_task_master.task_Master_Id = 8)
and enr_id in (select enr_id from perlss.enr_rqst where active_sw='N' and last_modified_by like 'CV_CH3_SE13_%'); 


select * from perlss.tmg_task where
input_Id in (select tmg_task.input_Id from  perlss.tmg_task,perlss.Tmg_Doc,perlss.tmg_task_master
    where
        tmg_task.input_Id = Tmg_Doc.input_Id
        and Tmg_Doc.task_Master_Id = tmg_task_master.task_Master_Id
        and tmg_task.task_status_cd <> 'CL'
        and tmg_task_master.task_Master_Id = 8)
and enr_id in (select enr_id from perlss.enr_rqst where enr_id = 100043262);


delete FROM PERLSS.enr_dsnr_dtls WHERE CREATED_BY like 'CV_CH3%';
delete from perlss.slt_details where created_by like 'CV_CH3%'
delete from perlss.enr_bnft eb  where created_by like 'CV_CH3%'
delete from perlss.enr_patient_lblty_dtls  eb  where created_by like 'CV_CH3%'
delete from perlss.enr_financial_elig  eb  where created_by like 'CV_CH3%'
delete from perlss.enr_dtls ed where created_by like 'CV_CH3%'
delete from perlss.enr_rqst er where created_by like 'CV_CH3%'

select * from perlss.fwr_static_data fsd

update perlss.enr_rqst a
set enr_start_dt=b.enr_start_dt,
enr_end_dt=b.enr_end_dt ,
tracking_cd=b.tracking_cd,
last_modified_by=b.last_modified_by,
last_modified_dt=b.last_modified_dt,
active_sw = b.active_sw,
hstry_sw = b.hstry_sw
from legacy.enr_rqst_ch3_backup b
where a.enr_id=b.enr_id
and a.last_modified_by like 'CV_CH3%'
and a.enr_status_cd in ('ENR','DIS');


update perlss.enr_rqst A
set tracking_cd ='R' where ID in (
select id
from perlss.enr_rqst er
where    enr_id in (    select        max(enr_id)
    from        perlss.enr_rqst    where        active_sw = 'Y' 
    group by        prsn_id,        pae_id)
    and enr_status_cd = 'ENR'
    and enr_grp_cd = 'CG3'
        and tracking_cd = 'C'
order by    er.id desc);


select * from perlss.enr_rqst 
where last_modified_by is not null order by last_modified_by desc;




select * from perlss.enr_rqst where prsn_id = 6000065159
order by ID DESC;

select * from perlss.enr_rqst where prsn_id = 6000046794
order by id desc;

select * from perlss.adj_rqst where prsn_id = 6000064427
order by id desc;

6000063220 - discuss with Sathyan slot no 147 154
6000063330 - Discuss with Sathyan  slot no 147 154

6000064427 - Need to update existing with c and not create new record 148 154 14
6000065159 - create new record wth DIS enrolled status and wih start and end date as start date . What is disneollment reason code and type for disenrollemnt record? 

6000033137 yes 145 153
6000046794 yes 146 154

select * from perlss.adj_rqst where prsn_id = 6000065159;

8 disneollmen - only update tracking code  


select * from legacy.WRK_MMIS_BASE_MEMBER_POP_CH3 w 
join legacy.WRK_LTSS_CLIENTS_CH3 wl
on w.NUM_SSN = wl.SSN
and exists (select 1 from legacy.enr_rqst_ch3_backup e where wl.PERLSS_INDV_ID = e.PRSN_ID
and enr_status_cd ='ENR' and enr_grp_cd = 'CH3'
and enr_id in (select max(enr_id) from legacy.enr_rqst_ch3_backup ercb group by prsn_id, pae_id)
			)


select * from legacy.enr_rqst_ch3_backup where enr_status_cd ='ENR' and enr_grp_cd <> 'CH3'
and enr_id in (select max(enr_id) from legacy.enr_rqst_ch3_backup ercb group by prsn_id, pae_id);

select * from perlss.enr_rqst 
where prsn_id = 6000062207
order by id desc;

slot status - FIL

select * from legacy.enr_rqst_ch3_backup
where prsn_id = 6000062207
order by id desc
 
 
 select * from wrk_ltss_clients_ch3
where valid_sw='N'
GROUP BY INSRT_UPD_SW; 

SELECT COUNT(1),last_modified_by FROM enr_rqst_ch3
where last_modified_by like 'CV_CH3%'
GROUP BY last_modified_by
;--156

145	UPD
2	HIST
13	INS



select *
from LT_CNV_WRK.enr_rqst_ch3_aftr_load 
where (last_modified_by like 'CV_CH3_%' or created_by like 'CV_CH3_%')  
and tracking_cd='C' and ENR_STATUS_CD <> 'ENR';

No we need to update tracking code 'C'?
nO we need to create slot ?
4 rejected potential duplicates CH002


SELECT b.ENR_START_DT, b.ENR_END_DT,b.PAE_ID,b.PRSN_ID,b.enr_status_cd,id,
ROW_NUMBER() OVER(PARTITION BY PAE_ID ORDER BY ENR_END_DT desc) as row_num FROM (
select enr_status_cd,trim(ENR_START_DT) as ENR_START_DT, id,
NVL(ENR_END_DT,'31-DEC-2299') as ENR_END_DT,
trim(PAE_ID) as pae_id,trim(PRSN_ID) as PRSN_ID
from lt_cnv_wrk.enr_rqst_ch3 
where enr_grp_cd = 'CG3' and active_sw='Y' and PRSN_ID=6000064427) b
--AND ENR_STATUS_CD IN ('DIS','ENR')
and enr_id in (select max(enr_id) from lt_cnv_wrk.ENR_RQST_CH3 group by prsn_id,pae_id);

select * from wrk_error_log_ch3;







select *  
from lt_cnv_wrk.WRK_MMIS_BASE_MEMBER_POP_CH3 a
join  lt_cnv_wrk.wrk_ltss_clients_ch3 b on a.SAK_RECIP = b.SAK_RECIP and b.SSN = a.NUM_SSN
where perlss_indv_id in (select prsn_id
from LT_CNV_WRK.enr_rqst_ch3_aftr_load
where (last_modified_by like 'CV_CH3_%' or created_by like 'CV_CH3_%')  
and tracking_cd='C' and ENR_STATUS_CD <> 'ENR');


select *  
from lt_cnv_wrk.WRK_MMIS_BASE_MEMBER_POP_CH3 a
join  lt_cnv_wrk.wrk_ltss_clients_ch3 b on a.SAK_RECIP = b.SAK_RECIP and b.SSN = a.NUM_SSN
where perlss_indv_id in (6000033137,6000046794)

select *  
from lt_cnv_wrk.WRK_MMIS_BASE_MEMBER_POP_CH3 a
join  lt_cnv_wrk.wrk_ltss_clients_ch3 b on a.SAK_RECIP = b.SAK_RECIP and b.SSN = a.NUM_SSN
where perlss_indv_id in (6000063243,
6000061832,
6000062394,
6000044954,
6000062207,
6000032743,
6000065876,
6000063704);


select * from lt_src_cnv_mmis.t_CDE_ECF_COST_CAP;

SELECT pg_size_pretty(pg_relation_size('legacy.T_CDE_DISENROLL_REASONS) union all
SELECT pg_size_pretty(pg_relation_size('legacy.T_RE_DISENROLL_REASONS) union all
SELECT pg_size_pretty(pg_relation_size('legacy.T_RE_ELIG) union all
SELECT pg_size_pretty(pg_relation_size('legacy.T_RE_BASE) union all
SELECT pg_size_pretty(pg_relation_size('legacy.T_PUB_HLTH_PGM) union all
SELECT pg_size_pretty(pg_relation_size('legacy.T_RE_CHOICES_TRACKING) union all
SELECT pg_size_pretty(pg_relation_size('legacy.T_RE_PAT_LIAB) union all
SELECT pg_size_pretty(pg_relation_size('legacy.T_RE_LIV_ARNG) union all
SELECT pg_size_pretty(pg_relation_size('legacy.T_PR_PROV) union all
SELECT pg_size_pretty(pg_relation_size('legacy.T_RE_PMP_ASSIGN) union all
SELECT pg_size_pretty(pg_relation_size('legacy.T_PMP_SVC_LOC);


From ENR ID 100065899 TO 100065914 where created from Informatica- 16 records created from Infromatica flow which uses nextval to fetch enr_id no issue
ENR ID =100065915 and 100065916 where manually inserted as DF. Not used nextval object
Starting ENR_ID=100065917 are created from APP

Application should have errored only two times because of two manual inserts which is for 100065915 and 100065916?


update perlss.ref_app_addr_dtl a
set addr_line_1 = b.addr_line_1,
addr_line_2 = b.addr_line_2,
city = b.city,
state_cd = b.state_cd,
zip = b.zip,
zip_extsn = b.zip_extsn,
cnty_cd =b.cnty_cd
from
(select * from perlss.ref_app_addr_dtl raad 
where created_by like 'CV_28%' and user_type_cd ='HOH' and addr_line_1 <> 'NA'
and ref_id not in ('RF000006320','RF000006825','RF000006826')) b where A.REF_ID = B.REF_ID
and a.created_by like 'CV_28%' and a.addr_line_1 ='NA' and a.user_type_cd ='HOH'
and a.ref_id not in ('RF000006320','RF000006825','RF000006826');



update perlss.pae_app_addr_dtl a
set addr_line_1 = b.addr_line_1,
addr_line_2 = b.addr_line_2,
city = b.city,
state_cd = b.state_cd,
zip = b.zip,
zip_extsn = b.zip_extsn,
cnty_cd =b.cnty_cd
from
(select * from perlss.pae_app_addr_dtl 
where created_by like 'CV_28%' and user_type_cd ='HOH' and addr_line_1 <> 'NA'
) b where A.pae_id = B.pae_id
and a.created_by like 'CV_28%' and a.addr_line_1 ='NA' and a.user_type_cd ='HOH'
;

update perlss.pae_rqst a
set user_id=b.create_user_id
from legacy.KB_PAE_RQST_GDR b
where a.pae_id=b.pae_id
and a.created_by  like 'CV_4%';

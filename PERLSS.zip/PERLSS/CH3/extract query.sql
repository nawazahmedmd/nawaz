SELECT distinct e.SAK_RECIP,B.num_ssn,B.id_medicaid ,E.SAK_PGM_ELIG,E.SAK_PUB_HLTH,pgm.CDE_PGM_HEALTH,
pgm.DSC_PGM_HEALTH,e.DTE_EFFECTIVE,e.DTE_END,e.dte_last_update,
b.dte_death,t.SYS_CDE,e.dte_added,r.CDE_DISENROLL_RSN,cd.DESC_DISENROLL_RSN,cd.CDE_TYPE,
a.CDE_RSN_MC_STOP,a.DTE_LAST_ROSTER,a.SAK_RE_PMP_ASSIGN,
a.CDE_RSN_MC_START,
a.SAK_PMP_SER_LOC,
a.CDE_STATE_REGION AS PROVIDER_REGION ,
COUN.CDE_STATE_REGION AS RECEIP_REGION
,a.SAK_PROV,a.ID_PROVIDER
,pt.dTE_EFFECTIVE,pt.DTE_END,pt.AMT_PATNT_LIAB,lv.CDE_LIV_ARNG
FROM
--select count(1) from
LT_CNV_SRC_MMIS.T_RE_elig e
JOIN LT_CNV_SRC_MMIS.t_re_base b ON  b.sak_recip = e.sak_recip
JOIN LT_CNV_SRC_MMIS.t_re_choices_tracking t ON (t.sak_recip = e.sak_recip AND e.sak_pgm_elig = t.sak_pgm_elig)
JOIN lt_cnv_src_mmis.t_pub_hlth_pgm pgm ON  e.sak_pub_hlth = pgm.sak_pub_hlth
JOIN (SELECT e1.sak_recip ,e1.dte_end ,e1.sak_pgm_elig ,a.SAK_RE_PMP_ASSIGN ,a.SAK_PMP_SER_LOC ,l.SAK_PROV ,p.id_provider ,
l.CDE_STATE_REGION,a.CDE_RSN_MC_START,a.DTE_LAST_ROSTER,a.CDE_RSN_MC_STOP
FROM LT_CNV_SRC_MMIS.T_RE_elig E1  
JOIN lt_cnv_src_mmis.t_re_pmp_assign a ON ( a.sak_recip = e1.sak_recip and a.sak_pgm_elig = e1.sak_pgm_elig)
JOIN lt_cnv_src_mmis.t_pmp_svc_loc l ON l.sak_pmp_ser_loc = a.sak_pmp_ser_loc
JOIN lt_cnv_src_mmis.t_pr_prov P ON p.sak_prov =l.SAK_PROV
WHERE  e1.sak_pub_hlth=1024  AND e1.cde_status1 = ' ')a
ON a.sak_recip =e.SAK_RECIP
LEFT JOIN LT_CNV_SRC_MMIS.T_COUNTY COUN ON B.CDE_COUNTY = COUN.CDE_COUNTY
LEFT JOIN LT_CNV_SRC_MMIS.T_RE_DISENROLL_REASONS r ON (e.SAK_RECIP=r.SAK_RECIP AND r.SAK_PGM_ELIG=t.SAK_PGM_ELIG)
LEFT JOIN LT_CNV_SRC_MMIS.T_CDE_DISENROLL_REASONS cd ON   cd.CDE_DISENROLL_RSN=r.CDE_DISENROLL_RSN
LEFT JOIN (select * from (
select SAK_RECIP, DTE_EFFECTIVE, DTE_END, AMT_PATNT_LIAB,
row_number() over(partition by sak_recip order by DTE_EFFECTIVE desc) as row_num
from LT_CNV_SRC_MMIS.T_RE_PAT_LIAB
) where row_num = 1) pt on (pt.sak_recip=e.sak_recip)
LEFT JOIN LT_CNV_SRC_MMIS.T_RE_LIV_ARNG lv on trim(lv.SAK_LIV_ARNG)=trim(b.SAK_LIV_ARNG)
WHERE e.sak_pub_hlth = 1049
AND b.ind_active = 'Y'
AND e.cde_status1 = ' '
AND e.dte_end >= 20221001
AND e.DTE_EFFECTIVE >= 20221001
AND t.SYS_CDE ='C'
and a.dte_end = (select max(e2.dte_end) from lt_cnv_src_mmis.t_Re_elig e2 where e2.sak_recip = a.sak_recip and e2.sak_pub_hlth = 1024 and e2.cde_status1=' ');
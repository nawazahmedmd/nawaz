SELECT LEG.perlss_indv_id,LEG.SAK_RECIP,LEG.VALID_SW, LEG.MMIS_START_DATE, 
LEG.MMIS_END_DATE,LEG.tracking_cd,old_enr_start_dt, old_enr_end_dt , old_tracking_cd 
,PERL.enr_start_dt,PERL.enr_end_dt,PERL.tracking_cd, PERL.last_modified_by FROM
(SELECT b.perlss_indv_id,a.SAK_RECIP,b.VALID_SW, TO_DATE(NVL(A.dte_effective,'22991231'),'YYYYMMDD') AS MMIS_START_DATE, 
TO_DATE(NVL(A.DTE_END,'22991231'),'YYYYMMDD') AS MMIS_END_DATE, a.tracking_cd
from lt_cnv_wrk.WRK_MMIS_BASE_MEMBER_POP_CH3 a
join  lt_cnv_wrk.wrk_ltss_clients_ch3 b on a.SAK_RECIP = b.SAK_RECIP and b.SSN = a.NUM_SSN ) LEG
LEFT JOIN
(select prsn_id, enr_start_dt, enr_end_dt , tracking_cd , last_modified_by
from LT_CNV_WRK.enr_rqst_ch3_aftr_load 
where (last_modified_by like 'CV_CH3_%' or created_by like 'CV_CH3_%')) PERL
ON LEG.perlss_indv_id = PERL.prsn_id
LEFT JOIN
(select prsn_id, old_enr_start_dt, old_enr_end_dt , old_tracking_cd 
from LT_CNV_WRK.enr_rqst_ch3
where (last_modified_by like 'CV_CH3_%' or created_by like 'CV_CH3_%') and tracking_cd='C') old
ON LEG.perlss_indv_id = old.prsn_id
ORDER BY 1,3;

--comparing adj and enr pae_id's

select * from (select adj_pae_id , enr_pae_id from
(select distinct pae_id as adj_pae_id,prsn_id from lt_cnv_wrk.adj_rqst_ch3 ar  
                        where enr_grp_cd  = 'CG3'
                        and pae_eff_dt = (select max(pae_eff_dt)
                        from lt_cnv_wrk.adj_rqst_ch3 ar1
                        where enr_grp_cd  = 'CG3'
                        and ar.prsn_id = ar1.prsn_id)
and prsn_id in (select perlss_indv_id from wrk_ltss_clients_ch3)) adj
JOIN 
(select prsn_id, enr_start_dt, enr_end_dt , tracking_cd , last_modified_by, pae_id as enr_pae_id
from LT_CNV_WRK.enr_rqst_ch3_aftr_load 
where (last_modified_by like 'CV_CH3_%' or created_by like 'CV_CH3_%')
AND tracking_cd='C') enr
on enr.prsn_id = adj.prsn_id
) where adj_pae_id <> enr_pae_id
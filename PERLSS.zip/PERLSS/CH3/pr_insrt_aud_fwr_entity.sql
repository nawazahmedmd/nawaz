CREATE OR REPLACE  PROCEDURE legacy.pr_insrt_aud_fwr_entity()
 LANGUAGE plpgsql
AS $procedure$

declare V_SQL text;
--V_seq_id INTEGER;
V_seq_id INTEGER := 1;
V_ID INTEGER := 1;
V_Loop INTEGER := 1;
V_Max integer := 1;
v_cnt integer;

begin
--select * from perlss.aud_fwr_entity
--enr_rqst
insert into perlss.aud_fwr_entity
(id,
action
,user_id
,prsn_id
,pae_id
--,txn_id
,ref_id
,apl_id
,page_id
,commit_version
,entity_id
,entity_type
,entity_value
,created_by
,created_dt
,workflow_id)
select cast(nextval('legacy.V_Audit_CH3_SEQ') as int),
'UPDATE' 
,NULL user_id
,a.prsn_id prsn_id
,a.pae_id pae_id
--,a.txn_id txn_id
,NULL ref_id
,NULL apl_id
,NULL page_id
,1 as commit_version
,a.id entity_id
,'com.ltss.common.enrollment.model.EnrRqst' as entity_type
,cast(b.test_val  as json) entity_value
,'CV_CH3' created_by
,now()  created_dt
,Null workflow_id
--select *
from perlss.enr_rqst a
join legacy.Temp_h b on a.id = b.id
and b.table_name = 'enr_rqst';

--enr_bnft
insert into perlss.aud_fwr_entity
(id,
action
,user_id
,prsn_id
,pae_id
--,txn_id
,ref_id
,apl_id
,page_id
,commit_version
,entity_id
,entity_type
,entity_value
,created_by
,created_dt
,workflow_id)
select cast(nextval('legacy.V_Audit_CH3_SEQ') as int),
'UPDATE'
,NULL user_id
,a.prsn_id prsn_id
,a.pae_id pae_id
--,a.txn_id txn_id
,NULL ref_id
,NULL apl_id
,NULL page_id
,1 as commit_version
,b.id entity_id
,'com.ltss.common.enrollment.model.EnrBnft' as entity_type
,CAST(c.test_val AS json) entity_value
,'CV_CH3' created_by
,now()  created_dt
,Null workflow_id
--select *
from  perlss.enr_rqst a 
join perlss.enr_bnft b on a.enr_id =b.enr_id
join legacy.Temp_H c on b.id = c.id
where c.table_name='enr_bnft'
;

--enr_dsnr_dtls
insert into perlss.aud_fwr_entity
(id,
action
,user_id
,prsn_id
,pae_id
--,txn_id
,ref_id
,apl_id
,page_id
,commit_version
,entity_id
,entity_type
,entity_value
,created_by
,created_dt
,workflow_id)
select cast(nextval('legacy.V_Audit_CH3_SEQ') as int),
'UPDATE'
,NULL user_id
,a.prsn_id prsn_id
,a.pae_id pae_id
--,a.txn_id txn_id
,NULL ref_id
,NULL apl_id
,NULL page_id
,1 as commit_version
,b.id entity_id
,'com.ltss.common.enrollment.model.EnrDsnrDtl' as entity_type
,CAST(c.test_val AS json) entity_value
,'CV_CH3' created_by
,now()  created_dt
,Null workflow_id
--select *
from  perlss.enr_rqst a 
join perlss.enr_dsnr_dtls b on a.enr_id =b.enr_id
join legacy.Temp_H c on b.id = c.id
where c.table_name='enr_dsnr_dtls'
;


--enr_dtls
insert into perlss.aud_fwr_entity
(id,
action
,user_id
,prsn_id
,pae_id
--,txn_id
,ref_id
,apl_id
,page_id
,commit_version
,entity_id
,entity_type
,entity_value
,created_by
,created_dt
,workflow_id)
select cast(nextval('legacy.V_Audit_CH3_SEQ') as int),
'UPDATE'
,NULL user_id
,a.prsn_id prsn_id
,a.pae_id pae_id
--,a.txn_id txn_id
,NULL ref_id
,NULL apl_id
,NULL page_id
,1 as commit_version
,c.id entity_id
,'com.ltss.common.enrollment.model.EnrDtl' as entity_type
,CAST(b.test_val AS json) entity_value
,'CV_CH3' created_by
,now()  created_dt
,Null workflow_id
--select *
from perlss.enr_rqst a 
JOIN perlss.enr_dtls  c ON a.enr_id=c.enr_id and a.hstry_sw ='Y'
join legacy.Temp_H b on c.id = b.id
where b.table_name='enr_dtls'
;


--enr_financial_elig
insert into perlss.aud_fwr_entity
(id,
action
,user_id
,prsn_id
,pae_id
--,txn_id
,ref_id
,apl_id
,page_id
,commit_version
,entity_id
,entity_type
,entity_value
,created_by
,created_dt
,workflow_id)
select cast(nextval('legacy.V_Audit_CH3_SEQ') as int),
'UPDATE'
,NULL user_id
,a.prsn_id prsn_id
,a.pae_id pae_id
--,a.txn_id txn_id
,NULL ref_id
,NULL apl_id
,NULL page_id
,1 as commit_version
,c.id entity_id
,'com.ltss.common.enrollment.model.EnrFinancialElig' as entity_type
,CAST(b.test_val AS json) entity_value
,'CV_CH3' created_by
,now()  created_dt
,Null workflow_id
--select *
from perlss.enr_rqst a JOIN perlss.enr_financial_elig  c ON a.enr_id=c.enr_id
join legacy.Temp_H b on c.id = b.id
where b.table_name ='enr_financial_elig';



--enr_patient_lblty_dtls
insert into perlss.aud_fwr_entity
(id,
action
,user_id
,prsn_id
,pae_id
--,txn_id
,ref_id
,apl_id
,page_id
,commit_version
,entity_id
,entity_type
,entity_value
,created_by
,created_dt
,workflow_id)
select cast(nextval('legacy.V_Audit_CH3_SEQ') as int),
'UPDATE'
,NULL user_id
,a.prsn_id prsn_id
,a.pae_id pae_id
--,a.txn_id txn_id
,NULL ref_id
,NULL apl_id
,NULL page_id
,1 as commit_version
,d.id entity_id
,'com.ltss.common.enrollment.model.EnrPatientLbltyDtl' as entity_type
,CAST(b.test_val AS json) entity_value
,'CV_CH3' created_by
,now()  created_dt
,Null workflow_id
--select *
from perlss.enr_rqst a JOIN perlss.enr_financial_elig  c ON a.enr_id=c.enr_id
join perlss.enr_patient_lblty_dtls d on c.id=d.financial_elig_id
join legacy.Temp_H b on d.id = b.id
where b.table_name ='enr_patient_lblty_dtls';

end ;

$procedure$
;


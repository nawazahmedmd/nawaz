1. Take a backup of perlss.enr_rqst table.
2. Take a backup of perlss.com_applcnt_access table

3.delete from perlss.aud_fwr_entity where created_by like 'CV_CH3%'

--Delete the 
4.delete FROM PERLSS.enr_dsnr_dtls WHERE CREATED_BY like 'CV_CH3%';
5.delete from perlss.slt_details where created_by like 'CV_CH3%'
6.delete from perlss.enr_bnft eb  where created_by like 'CV_CH3%'
7.delete from perlss.enr_patient_lblty_dtls  eb  where created_by like 'CV_CH3%'
8.delete from perlss.enr_financial_elig  eb  where created_by like 'CV_CH3%'
9.delete from perlss.enr_dtls ed where created_by like 'CV_CH3%'
10.delete from perlss.enr_rqst er where created_by like 'CV_CH3%'

11. --Roll back ENR RQST table updates 
update perlss.enr_rqst a
set enr_start_dt=b.enr_start_dt,
enr_end_dt=b.enr_end_dt ,
tracking_cd=b.tracking_cd,
last_modified_by=b.last_modified_by,
last_modified_dt=b.last_modified_dt,
active_sw = b.active_sw,
hstry_sw = b.hstry_sw
from legacy.enr_rqst_10242022 b
where a.enr_id=b.enr_id
and a.last_modified_by like 'CV_CH3%'
and a.enr_status_cd in ('ENR','DIS');

12. --Roll back Com applicant update updates

13. Verify application is working
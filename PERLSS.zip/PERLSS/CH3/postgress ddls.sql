create table LEGACY.TARGET_MASTER_TABLES_CH3
(
MODULE_NAME varchar(25),
TABLE_NAME varchar(50),
MIGRATION_REQUIRED CHAR(1),
unique (MODULE_NAME,TABLE_NAME)
);

alter table LEGACY.TARGET_MASTER_TABLES_CH3
add constraint check_MIGRATION_REQUIRED
check(MIGRATION_REQUIRED='Y' or 'N');

GRANT SELECT ON TABLE Legacy.TARGET_MASTER_TABLES_CH3 TO ro_perlss;
GRANT ALL ON TABLE Legacy.TARGET_MASTER_TABLES_CH3 TO rw_perlss;


truncate table LEGACY.TARGET_MASTER_TABLES_CH3;
--select * from LEGACY.TARGET_MASTER_TABLES_CH3
insert into LEGACY.TARGET_MASTER_TABLES_CH3 (MODULE_NAME,TABLE_NAME,MIGRATION_REQUIRED)
values 
('ENROLLMENT','enr_bnft','Y'),
('ENROLLMENT','slt_details','Y'),
('ENROLLMENT','enr_rqst','Y'),
('ENROLLMENT','enr_financial_elig','Y'),
('ENROLLMENT','enr_dsnr_dtls','Y'),
('ENROLLMENT','enr_dtls','Y'),
('ENROLLMENT','enr_patient_lblty_dtls','Y');



CREATE OR REPLACE FUNCTION legacy.FN_Temp_Table_CH3(mod_name varchar(10))
 RETURNS table (
 				ID int,
 				tbl_nm varchar(200)
 				)
 				
 LANGUAGE plpgsql
AS $function$ 

BEGIN

	--raise notice 'this is test function';
drop sequence if exists legacy.V_Files_TgtValidation_CH3_SEQ;
CREATE SEQUENCE legacy.V_Files_TgtValidation_CH3_SEQ START 1;
return query
				select cast(nextval('legacy.V_Files_TgtValidation_CH3_SEQ') as int), A.TABLE_NAME
				---select *	
				from LEGACY.TARGET_MASTER_TABLES_CH3  A
				Where 1=1 and migration_required ='Y'
				AND A.MODULE_NAME = mod_name;---'PAE2';
			
--EXCEPTION
--WHEN OTHERS THEN
  -- raise_application_error(-20001,'An error was encountered - '||SQLCODE||' -ERROR- '||SQLERRM);
END;
 $function$
;

CREATE TABLE legacy.conv_target_dv_details_CH3 (
	seq_id int4 NOT NULL GENERATED ALWAYS AS IDENTITY,
	conv_run_num int4 NULL,
	table_name varchar(200) NULL,
	primary_column_name varchar(200) NULL,
	primary_column_value int4 NULL,
	issue_column_name varchar(200) NULL,
	issue_column_value text NULL,
	issue_code varchar(100) NULL,
	issue_description varchar(1000) NULL,
	ref_id varchar(100) NULL,
	pae_id varchar(100) NULL,
	tns_id varchar(100) NULL,
	prsn_id varchar(100) NULL,
	apl_id varchar(100) NULL,
	cor_id varchar(100) NULL,
	adj_id varchar(100) NULL,
	error_ind varchar(1) NULL,
	create_user_id varchar(50) NULL,
	create_datetime date NULL,
	CONSTRAINT uk_colnm_colval_CH3 UNIQUE (primary_column_value, issue_column_name, issue_column_value)
);

GRANT SELECT ON TABLE Legacy.CONV_TARGET_DV_DETAILS_CH3 TO ro_perlss;
GRANT ALL ON TABLE Legacy.CONV_TARGET_DV_DETAILS_CH3 TO rw_perlss;



CREATE SEQUENCE legacy.V_Audit_CH3_SEQ START 1;
GRANT SELECT ON TABLE Legacy.V_Audit_CH3_SEQ TO ro_perlss;
GRANT ALL ON TABLE Legacy.V_Audit_CH3_SEQ TO rw_perlss;


create table legacy.Temp_h (ID BIGINT, test_val VARCHAR(8000));
alter table legacy.Temp_h add table_name varchar(100);
GRANT SELECT ON TABLE Legacy.Temp_h TO ro_perlss;
GRANT ALL ON TABLE Legacy.Temp_h TO rw_perlss;

  CREATE TABLE LEGACY.WRK_MMIS_BASE_MEMBER_POP_CH3 
   (	SAK_RECIP int8, 
	NUM_SSN VARCHAR(9), 
	ID_MEDICAID VARCHAR(12), 
	SAK_PGM_ELIG int8, 
	SAK_PUB_HLTH int8, 
	CDE_PGM_HEALTH VARCHAR(5), 
	DSC_PGM_HEALTH VARCHAR(50), 
	CONVERSION_PHASE VARCHAR(7), 
	DTE_EFFECTIVE int8, 
	DTE_END int8, 
	DTE_LAST_UPDATE int8, 
	DTE_DEATH int8, 
	TRACKING_CD VARCHAR(4), 
	DTE_ADDED int8
   ) ;




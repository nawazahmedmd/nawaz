--PAE,ADJ,ENR reconcillation
--same count should come 74b 
SELECT distinct a.prsn_id ,a.pae_id as enrpaeid ,a.enr_id,a.enr_status_cd ,a.enr_grp_cd ,a.enr_start_dt ,a.enr_end_dt ,
c.pae_id as adjpaeid,c.adj_status_cd as adjstatus,c.pae_eff_dt,c.pae_end_dt,c.enr_grp_cd as adjgrpcd,
b.pae_id as paerqstpae_id ,
--b.program_cd ,
b.status_cd as paestatus FROM perlss.enr_rqst a
join perlss.pae_rqst b on a.prsn_id =b.prsn_id and a.pae_id =b.pae_id
join perlss.adj_rqst c on a.prsn_id=c.prsn_id  and  b.pae_id =c.pae_id
--left join perlss.com_applcnt_access d on  a.prsn_id=d.prsn_id
WHERE a.enr_grp_cd ='CG3'  and a.tracking_cd ='C' and a.active_sw ='Y' and a.enr_status_cd in('ENR','DIS')
and c.active_sw ='Y' 
and a.prsn_id in (SELECT PERLSS_INDV_ID from legacy.wrk_ltss_clients_ch3 wlcc )
order by 1;



--Target DI Checks:
--CASE1 Perlss enrollemnt start dt is after MMIS start dt--Verify PAE,ADJ dt prior to MMIS start dt --0 records expected
--Make sure pae_rqst dt is prior to <= enr_start_dt

select  e.prsn_id,e.enr_id,e.enr_status_cd,e.enr_start_dt,e.enr_end_dt,e.pae_id,p.program_cd,p.status_cd,p.pae_rqst_dt  
from perlss.pae_rqst p join perlss.enr_rqst e on p.pae_id =e.pae_id where tracking_cd='C' and e.enr_grp_cd ='CG3' and enr_status_cd in ('ENR','DIS')
and p.pae_rqst_dt > e.enr_start_dt

--Make sure pae_eff_dt is prior to <= enr_start_dt
select distinct e.prsn_id,e.enr_id,e.enr_status_cd,e.enr_start_dt,e.enr_end_dt,e.pae_id,p.enr_grp_cd ,p.adj_status_cd,p.pae_eff_dt,p.pae_end_dt  
from perlss.adj_rqst p join perlss.enr_rqst e on p.pae_id =e.pae_id where tracking_cd='C' and e.enr_grp_cd ='CG3' and enr_status_cd in ('ENR','DIS')
and p.pae_eff_dt <= e.enr_start_dt

--Case 2:PERLSS is active MMIS enrollemnt is ended after 1 month--To cross check there is no multiple enrollment for CH3
select prsn_id,pae_id,active_sw,enr_start_dt,enr_end_dt,enr_grp_cd,enr_status_cd  from perlss.enr_rqst p 
where tracking_cd='C' and 
enr_status_cd ='ENR'
and enr_grp_cd ='CG3'
and prsn_id in (SELECT PERLSS_INDV_ID from legacy.wrk_ltss_clients_ch3 wlcc )


--Check enr_end_dt prior to work conversion dt
--get wrk_conversion_dt and upadte in the query
select * from perlss.enr_rqst where enr_status_cd='ENR' and cast(to_char(enr_end_dt,'YYYYMMDD') as int8) > 20221109 
and cast(to_char(enr_end_dt,'YYYYMMDD') as int8) < 20221109--

--Check for Audit DI check
select entity_type,count(*) from perlss.aud_fwr_entity where prsn_id 
in (select distinct prsn_id from perlss.enr_rqst er where last_modified_by  like 'CV_CH3%' or created_by like 'CV_CH3%')
and created_by like 'CV_CH3%' group by entity_type



--select Max(last_modified_dt) lsd, Max(created_dt) from perlss.enr_rqst er ;
--select Max(last_modified_dt), Max(created_dt) from perlss.pae_rqst pr  ;
--DI Target checks:

select * from (
select 'Total Enrollment Request records created with Tracking Code C: ' || cast(Count(1) as varchar) as text from perlss.enr_rqst er
where created_by  like 'CV_CH3%' and last_modified_by  like 'CV_CH3%'
and tracking_cd = 'C'

union
select 'Total Enrollment Request records Updated with Tracking Code C: ' || cast(Count(1) as varchar)
from perlss.enr_rqst er
where created_by  not like 'CV_CH3%' and last_modified_by  like 'CV_CH3%'
and tracking_cd = 'C'

union
select 'Total Enrollment Request records Updated with Tracking Code R: ' || cast(Count(1) as varchar)
from perlss.enr_rqst er
where created_by  not like 'CV_CH3%' and last_modified_by  like 'CV_CH3%'
and tracking_cd = 'R'

union
select 'Total Enrollment Details records created with Tracking Code C: ' || cast(Count(1) as varchar)
from perlss.enr_dtls ed   
where created_by  like 'CV_CH3%'

union
select 'Total Enrollment Fin Elig records created with Tracking Code C: ' || cast(Count(1) as varchar)
from perlss.enr_financial_elig efe     
where created_by  like 'CV_CH3%'

union
select 'Total Enrollment Patient Liability records created with Tracking Code C: ' || cast(Count(1) as varchar)
from perlss.enr_patient_lblty_dtls epld       
where created_by  like 'CV_CH3%'

union
select 'Total enrollement_benefit records created with Tracking Code C: ' || cast(Count(1) as varchar)
from perlss.enr_bnft eb     
where created_by  like 'CV_CH3%'

union
select 'Total Slot details records created with Tracking Code C: ' || cast(Count(1) as varchar)
from perlss.slt_details sd    
where created_by  like 'CV_CH3%'
) a order by text;


select * from perlss.enr_rqst
where  ENR_STATUS_CD = 'ENR'
AND (CREATED_BY LIKE 'CV_CH3_%' OR last_modified_by LIKE 'CV_CH3_%')
AND TRACKING_CD = 'R'
and enr_end_dt < now();

update perlss.ENR_RQST
set enr_end_dt = '2299-12-31', last_modified_by = 'CV_CH3_SE15_322'
where enr_end_dt is null
and prsn_id = 6000039547
and tracking_cd='C';


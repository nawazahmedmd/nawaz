/*
For legacy 
DELETE FROM lt_cnv_wrk.WRK_MMIS_BASE_MEMBER_POP_ch3;
DELETE FROM  lt_cnv_wrk.WRK_LTSS_CLIENTS_CH3 ;
DELETE FROM lt_cnv_wrk.COM_APPLCNT_CH3 cac ;
DELETE FROM lt_cnv_wrk.ENR_RQST_CH3 erc ;
DELETE FROM lt_cnv_wrk.pae_rqst_ch3;
DELETE FROM lt_cnv_wrk.adj_rqst_ch3;
DELETE FROM lt_cnv_wrk.WRK_ERROR_LOG_CH3; 
*/

1. Take a backup of perlss.enr_rqst table.
2. Take a backup of perlss.com_applcnt_access table

3.delete from perlss.aud_fwr_entity where created_by like 'CV_CH3%'

--Delete the 
4.delete FROM PERLSS.enr_dsnr_dtls WHERE CREATED_BY like 'CV_CH3%';
5.delete from perlss.slt_details where created_by like 'CV_CH3%'
6.delete from perlss.enr_bnft eb  where created_by like 'CV_CH3%'
7.delete from perlss.enr_patient_lblty_dtls  eb  where created_by like 'CV_CH3%'
8.delete from perlss.enr_financial_elig  eb  where created_by like 'CV_CH3%'
9.delete from perlss.enr_dtls ed where created_by like 'CV_CH3%'
10.delete from perlss.enr_rqst er where created_by like 'CV_CH3%'

11. --Roll back ENR RQST table updates 
update perlss.enr_rqst a
set enr_start_dt=b.enr_start_dt,
enr_end_dt=b.enr_end_dt ,
tracking_cd=b.tracking_cd,
last_modified_by=b.last_modified_by,
last_modified_dt=b.last_modified_dt,
active_sw = b.active_sw,
hstry_sw = b.hstry_sw
from legacy.enr_rqst_ch3_backup b
where a.enr_id=b.enr_id
and a.last_modified_by like 'CV_CH3%'
and a.enr_status_cd in ('ENR','DIS','PFE');

12. --Roll back Com applicant update updates

13. Verify application is working


SELECT *
FROM PERLSS.ENR_RQST
WHERE TRACKING_CD ='C' AND ENR_STATUS_CD='ENR' AND ENR_GRP_CD='CG3'
;
CREATE OR REPLACE PROCEDURE Legacy.p_generate_audit_enr_rqst_updt()
language plpgsql
as $$ 

begin

insert into legacy.Temp_H (table_name, id , test_val)
select 'enr_rqst',b.id , 
'{"id":' || cast(b.id as varchar)
|| ',"enrGrpCd":"' || enr_Grp_Cd|| '"'
|| ',"enrStatusCd":"' || b.enr_status_cd || '"'
|| ',"authDt":"' ||  to_char(b.auth_dt, 'YYYY-MM-DD HH:MI:SS')  || '"'
|| ',"assignedUserId":null'
|| ',"createdDt":"' || to_char(b.created_dt, 'YYYY-MM-DD HH:MI:SS')  || '"'
|| ',"createdBy":"' || b.created_by|| '"'
|| ',"lastmodifiedby":"' || b.last_modified_by|| '"'
|| ',"lastModifiedDate":"' || to_char(b.last_modified_dt, 'YYYY-MM-DD') || '"'
|| ',"recordVersion":' || cast(b.record_version as varchar)
|| ',"archivedDt":null' 
|| ',"enrId":' || cast(b.enr_Id as varchar)
|| ',"authStatusCd":"' || b.auth_Status_Cd || '"'
|| ',"enrStartDt":"' || to_char(b.enr_start_dt, 'YYYY-MM-DD HH:MI:SS')   || '"'
|| ',"enrEndDt":"' || to_char(b.enr_End_dt, 'YYYY-MM-DD HH:MI:SS')   || '"'
|| ',"enrDenialRsnCd":null'
|| ',"tnsId":' || coalesce(cast(b.tns_id as varchar),'null') --|| '"'
|| ',"overrideSw":"' || b.override_sw || '"'
|| ',"aplOverrideSw":null'
|| ',"disEnrDt":"' ||   coalesce(to_char(b.dis_enr_dt, 'YYYY-MM-DD'),'null')  || '"'
|| ',"activeSw":"' || 'Y' || '"' 
|| ',"cobSw":null'
|| ',"histrySw":"' || 'N' || '"'
|| ',"paeId":"' || b.pae_id || '"'
|| ',"prsnId":' || cast(b.prsn_id as varchar) 
|| ',"authId":' || cast(b.auth_Id as varchar)
|| ',"srcEnrId":null'
|| ',"trackingCd":"' || tracking_cd ||  '"'
|| ',"enrDcsnDt":"' || coalesce(to_char(b.enr_dcsn_dt, 'YYYY-MM-DD'),'null') || '"}'
--SELECT *
from  legacy.enr_rqst_ch3_backup b
where exists(select 1 from perlss.enr_rqst c where c.id = b.id and c.last_modified_by like 'CV_CH3%' and c.created_by not like 'CV_CH3%')
;

end $$;






CREATE OR REPLACE PROCEDURE legacy.pr_conv_data_validation_enrollment_ch3()
 LANGUAGE plpgsql
AS $procedure$

 --call legacy.PR_CONV_DATA_VALIDATION_ENROLLMENT_CH3 () 
--select * from legacy.committed_table
--select * from LEGACY.CONV_TARGET_DV_DETAILS_CH3 where  = 'PAE_PROGRAM_SELECTION'
 declare V_SQL text;
V_Table_count INTEGER;
V_Hdr_ID INTEGER := 10;
V_Loop INTEGER := 1;
V_Max integer := 1;
V_START_Time DATE;
V_END_Time DATE;
v_current_tbl_nm varchar(100);
v_cnt integer;

begin
    raise notice 'STarting the stored Procedure for ENROLLMENT' ;

select 	max(id)
into 	V_Max
---select *
from
	legacy.FN_Temp_Table_CH3('ENROLLMENT');

raise notice 'function result %',
V_Max ;

while V_Loop <= V_Max loop 

select	tbl_nm into v_current_tbl_nm
	---select *
from
	(select tbl_nm, ID from legacy.FN_Temp_Table_CH3('ENROLLMENT')	
	) A
where ID = V_Loop;

raise notice 'Processing table for : %',
v_current_tbl_nm ;


delete from	LEGACY.CONV_TARGET_DV_DETAILS_CH3 where
	1 = 1
	and TABLE_NAME = v_current_tbl_nm;

if v_current_tbl_nm = 'enr_financial_elig' then

insert into LEGACY.CONV_TARGET_DV_DETAILS_CH3
(
CONV_RUN_NUM,
    Table_Name,
    Issue_code,
    Issue_description,
    Primary_Column_Name,
    Primary_Column_Value,
    Issue_Column_Name,
    Issue_Column_Value ,
    Ref_ID,
    PAE_ID,
    ERROR_IND,
    CREATE_USER_ID,
    CREATE_DATETIME
    )
select
    V_Hdr_ID CONV_RUN_NUM,
    v_current_tbl_nm Table_Name,
    'ENR_FINELIG_001' Issue_code,
    'apl_indctr_sw     is blank or null or has invalid value' Issue_description,
    'ID' as Primary_Column_Name,
    nolock as Primary_Column_Value,
    'apl_indctr_sw' as Issue_Column_Name,
    apl_indctr_sw as Issue_Column_Value,
    null as Ref_ID,
    null as PAE_ID,
    'Y' as ERROR_IND,
    user CREATE_USER_ID,
    now() CREATE_DATETIME
from
    perlss.enr_financial_elig A (NOLOCK)
where
    apl_indctr_sw is not null and created_by like 'CV_CH3_%'
    
union all

select
    V_Hdr_ID CONV_RUN_NUM,
    v_current_tbl_nm Table_Name,
    'ENR_FINELIG_002' Issue_code,
    'dual_member_indctr_sw     is blank value' Issue_description,
    'ID' as Primary_Column_Name,
    nolock as Primary_Column_Value,
    'dual_member_indctr_sw' as Issue_Column_Name,
    dual_member_indctr_sw as Issue_Column_Value
,
    null as Ref_ID,
    null as PAE_ID,
    'Y' as ERROR_IND,
    user CREATE_USER_ID,
    now() CREATE_DATETIME
from
    perlss.enr_financial_elig A (NOLOCK)
where    dual_member_indctr_sw = ''
    AND created_by like 'CV_CH3_%';
end if;


if v_current_tbl_nm = 'enr_dsnr_dtls' then

insert
	into
	LEGACY.CONV_TARGET_DV_DETAILS_CH3
(
 CONV_RUN_NUM, Table_Name,  Issue_code,  Issue_description,   Primary_Column_Name,   Primary_Column_Value, Issue_Column_Name,
	Issue_Column_Value , Ref_ID,	PAE_ID, ERROR_IND, CREATE_USER_ID, CREATE_DATETIME
	)
SELECT V_Hdr_ID CONV_RUN_NUM, v_current_tbl_nm Table_Name, 'ENR_DSNR_DTLS_001' Issue_code, 'dis_enr_rsn_cd should be in DISENROLLMENT_REASON table' Issue_description
, 'ID' as Primary_Column_Name, nolock as Primary_Column_Value, 'dis_enr_rsn_cd' as Issue_Column_Name, 	dis_enr_rsn_cd	as Issue_Column_Value, NULL as Ref_ID, NULL as PAE_ID
, 'Y' as ERROR_IND, user CREATE_USER_ID, now() CREATE_DATETIME	
FROM perlss.ENR_DSNR_DTLS	 A (NOLOCK)  
WHERE 	not exists (select * from legacy.PERLSS_REference_Data b where upper(name) = 'DISENROLLMENT_REASON' and b.code = a.dis_enr_rsn_cd)
and a.dis_enr_rsn_cd is not null
union all

SELECT V_Hdr_ID CONV_RUN_NUM, v_current_tbl_nm Table_Name, 'ENR_DSNR_DTLS_002' Issue_code, 'dis_enr_type_cd should be in DISENROLLMENT_TYPE Table' Issue_description
, 'ID' as Primary_Column_Name, nolock as Primary_Column_Value, 'dis_enr_type_cd' as Issue_Column_Name, 	dis_enr_type_cd	as Issue_Column_Value, NULL as Ref_ID, NULL as PAE_ID
, 'Y' as ERROR_IND, user CREATE_USER_ID, now() CREATE_DATETIME	
FROM perlss.ENR_DSNR_DTLS	 A (NOLOCK)  
WHERE 	not exists (select * from legacy.PERLSS_REference_Data b where upper(name) = 'DISENROLLMENT_TYPE' and b.code = a.dis_enr_type_cd)
and a.dis_enr_type_cd is not null;

end if;


--ENR_BNFT

if v_current_tbl_nm = 'enr_bnft' then

insert
	into
	LEGACY.CONV_TARGET_DV_DETAILS_CH3
(
 CONV_RUN_NUM,
	Table_Name,
	Issue_code,
	Issue_description,
	Primary_Column_Name,
	Primary_Column_Value,
	Issue_Column_Name,
	Issue_Column_Value ,
	Ref_ID,
	PAE_ID,
	ERROR_IND,
	CREATE_USER_ID,
	CREATE_DATETIME
	)

select
	V_Hdr_ID CONV_RUN_NUM,
	v_current_tbl_nm Table_Name,
	'enr_bnft_001' Issue_code,
	'enr_bnft_grp_cd is NULL' Issue_description,
	'ID' as Primary_Column_Name,
	nolock as Primary_Column_Value,
	'enr_bnft_grp_cd' as Issue_Column_Name,
	enr_bnft_grp_cd as Issue_Column_Value,
	null as Ref_ID,
	null as PAE_ID,
	'Y' as ERROR_IND,
	user CREATE_USER_ID,
	now() CREATE_DATETIME
from
	perlss.enr_bnft A (NOLOCK)
where
	enr_bnft_grp_cd is null
	and created_by like 'CV_CH3_%'
union all 

select
	V_Hdr_ID CONV_RUN_NUM,
	v_current_tbl_nm Table_Name,
	'enr_bnft_002' Issue_code,
	'enr_bnft_amt is NULL' Issue_description,
	'ID' as Primary_Column_Name,
	nolock as Primary_Column_Value,
	'enr_bnft_amt' as Issue_Column_Name,
	cast (enr_bnft_amt as varchar) as Issue_Column_Value,
	null as Ref_ID,
	null as PAE_ID,
	'Y' as ERROR_IND,
	user CREATE_USER_ID,
	now() CREATE_DATETIME
from
	perlss.enr_bnft A (NOLOCK)
where
	enr_bnft_amt is null
	and created_by like 'CV_CH3_%'
union all 

select
	V_Hdr_ID CONV_RUN_NUM,
	v_current_tbl_nm Table_Name,
	'enr_bnft_003' Issue_code,
	'enr_bnft_eff_dt is not enr_start_dt in enr_rqst' Issue_description,
	'ID' as Primary_Column_Name,
	nolock as Primary_Column_Value,
	'enr_bnft_eff_dt' as Issue_Column_Name,
	cast (enr_bnft_eff_dt as varchar) as Issue_Column_Value,
	null as Ref_ID,
	null as PAE_ID,
	'Y' as ERROR_IND,
	user CREATE_USER_ID,
	now() CREATE_DATETIME
from
	perlss.enr_bnft A (NOLOCK)
where
	--enr_bnft_eff_dt is null 
	--and 
	enr_bnft_eff_dt not in (
	select
		er.enr_start_dt
	from
		perlss.enr_rqst er,
		perlss.enr_bnft eb
	where
		er.enr_id = eb.enr_id )
	and created_by like 'CV_CH3_%'
union all 

select
	V_Hdr_ID CONV_RUN_NUM,
	v_current_tbl_nm Table_Name,
	'enr_bnft_004' Issue_code,
	'enr_bnft_end_dt is not enr_end_dt in enr_rqst' Issue_description,
	'ID' as Primary_Column_Name,
	nolock as Primary_Column_Value,
	'enr_bnft_end_dt' as Issue_Column_Name,
	cast (enr_bnft_end_dt as varchar) as Issue_Column_Value,
	null as Ref_ID,
	null as PAE_ID,
	'Y' as ERROR_IND,
	user CREATE_USER_ID,
	now() CREATE_DATETIME
	---select distinct apl_indctr_sw
from
	perlss.enr_bnft A (NOLOCK)
where
	enr_bnft_end_dt not in (
	select
		er.enr_end_dt
	from
		perlss.enr_rqst er,
		perlss.enr_bnft eb
	where
		er.enr_id = eb.enr_id )
	and created_by like 'CV_CH3_%';
end if;

if v_current_tbl_nm = 'enr_rqst' then

insert
	into
	LEGACY.CONV_TARGET_DV_DETAILS_CH3
(
 CONV_RUN_NUM, Table_Name,  Issue_code,  Issue_description,   Primary_Column_Name,   Primary_Column_Value, Issue_Column_Name,
	Issue_Column_Value , Ref_ID,	PAE_ID, ERROR_IND, CREATE_USER_ID, CREATE_DATETIME
	)

SELECT V_Hdr_ID CONV_RUN_NUM, v_current_tbl_nm Table_Name, 'ENR_RQST_001' Issue_code, 'active_sw is not Y' Issue_description
, 'ID' as Primary_Column_Name, nolock as Primary_Column_Value, 'active_sw' as Issue_Column_Name, 	active_sw	as Issue_Column_Value, NULL as Ref_ID, NULL as PAE_ID
, 'Y' as ERROR_IND, user CREATE_USER_ID, now() CREATE_DATETIME
---SELECT DISTINCT active_sw, CREATED_BY
FROM perlss.enr_rqst	 A (NOLOCK)  
WHERE 	active_sw not in ('N','Y') and (A.created_by like 'CV_CH3_%' OR A.last_modified_by like 'CV_CH3_%')
	 
union all 

----apl_override_sw not required for conv code
SELECT V_Hdr_ID CONV_RUN_NUM, v_current_tbl_nm Table_Name, 'ENR_RQST_002' Issue_code, 'apl_override_sw	 is blank or null or has invalid value' Issue_description
, 'ID' as Primary_Column_Name, nolock as Primary_Column_Value, 'apl_override_sw' as Issue_Column_Name, 	apl_override_sw	as Issue_Column_Value, NULL as Ref_ID, NULL as PAE_ID
, 'Y' as ERROR_IND, user CREATE_USER_ID, now() CREATE_DATETIME	
---select * 
FROM perlss.enr_rqst	 A (NOLOCK)  
WHERE 	(A.created_by like 'CV_CH3_%' OR A.last_modified_by like 'CV_CH3_%') AND apl_override_sw is not null
 

union all 

---cob_sw  not required for conv code
SELECT V_Hdr_ID CONV_RUN_NUM, v_current_tbl_nm Table_Name, 'ENR_RQST_003' Issue_code, 'cob_sw	 is blank or null or has invalid value' Issue_description
, 'ID' as Primary_Column_Name, nolock as Primary_Column_Value, 'cob_sw' as Issue_Column_Name, 	cob_sw	as Issue_Column_Value, NULL as Ref_ID, NULL as PAE_ID
, 'Y' as ERROR_IND, user CREATE_USER_ID, now() CREATE_DATETIME	
---select distinct cob_sw
FROM perlss.enr_rqst	 A (NOLOCK)  
WHERE (A.created_by like 'CV_CH3_%') AND cob_sw is not null	
	 

union all 


---hstry_sw can be left blank for conv data.
SELECT V_Hdr_ID CONV_RUN_NUM, v_current_tbl_nm Table_Name, 'ENR_RQST_004' Issue_code, 'hstry_sw	 is NOT null' Issue_description
, 'ID' as Primary_Column_Name, nolock as Primary_Column_Value, 'hstry_sw' as Issue_Column_Name, 	hstry_sw	as Issue_Column_Value, NULL as Ref_ID
, NULL as PAE_ID, 'Y' as ERROR_IND, user CREATE_USER_ID, now() CREATE_DATETIME	
---select distinct hstry_sw, CREATED_BY
FROM perlss.enr_rqst	 A (NOLOCK)  
WHERE 	hstry_sw is not null and (A.created_by like 'CV_CH3_%')
	 

union all 
---override_sw should be default to N as per mapping doc.
SELECT V_Hdr_ID CONV_RUN_NUM, v_current_tbl_nm Table_Name, 'ENR_RQST_005' Issue_code, 'override_sw	 is blank ' Issue_description
, 'ID' as Primary_Column_Name, nolock as Primary_Column_Value, 'override_sw' as Issue_Column_Name, 	override_sw	as Issue_Column_Value, NULL as Ref_ID, NULL as PAE_ID
, 'Y' as ERROR_IND, user CREATE_USER_ID, now() CREATE_DATETIME	
---select distinct override_sw, CREATED_BY
FROM perlss.enr_rqst	 A (NOLOCK)  
WHERE override_sw	 = '' and (A.created_by like 'CV_CH3_%')

union all 
SELECT V_Hdr_ID CONV_RUN_NUM, v_current_tbl_nm Table_Name, 'ENR_RQST_006' Issue_code, 'enr_grp_cd should be CG3' Issue_description
, 'ID' as Primary_Column_Name, nolock as Primary_Column_Value, 'enr_grp_cd' as Issue_Column_Name, 	enr_grp_cd	as Issue_Column_Value, NULL as Ref_ID, NULL as PAE_ID
, 'Y' as ERROR_IND, user CREATE_USER_ID, now() CREATE_DATETIME	
FROM perlss.enr_rqst	 A (NOLOCK)  
WHERE 	(A.created_by like 'CV_CH3_%')and a.enr_grp_cd <> 'CG3'


union all
SELECT V_Hdr_ID CONV_RUN_NUM, v_current_tbl_nm Table_Name, 'ENR_RQST_007' Issue_code, 'enr_status_cd should be ENR,DIS' Issue_description
, 'ID' as Primary_Column_Name, nolock as Primary_Column_Value, 'enr_status_cd' as Issue_Column_Name, 	enr_status_cd	as Issue_Column_Value, NULL as Ref_ID, NULL as PAE_ID
, 'Y' as ERROR_IND, user CREATE_USER_ID, now() CREATE_DATETIME	
FROM perlss.enr_rqst	 A (NOLOCK)  
WHERE (A.created_by like 'CV_CH3_%') AND	 a.enr_status_cd not in ('ENR','DIS')


union all
SELECT V_Hdr_ID CONV_RUN_NUM, v_current_tbl_nm Table_Name, 'ENR_RQST_009' Issue_code, 'auth_status_cd should be in APP , DEN' Issue_description
, 'ID' as Primary_Column_Name, nolock as Primary_Column_Value, 'auth_status_cd' as Issue_Column_Name, 	auth_status_cd	as Issue_Column_Value, NULL as Ref_ID, NULL as PAE_ID
, 'Y' as ERROR_IND, user CREATE_USER_ID, now() CREATE_DATETIME	
FROM perlss.enr_rqst	 A (NOLOCK)  
WHERE  (A.created_by like 'CV_CH3_%') AND	 a.auth_status_cd not in ('APP','DEN')

union all
SELECT V_Hdr_ID CONV_RUN_NUM, v_current_tbl_nm Table_Name, 'ENR_RQST_010' Issue_code, 'enr_denial_rsn_cd should be Null' Issue_description
, 'ID' as Primary_Column_Name, nolock as Primary_Column_Value, 'enr_denial_rsn_cd' as Issue_Column_Name, 	enr_denial_rsn_cd	as Issue_Column_Value, NULL as Ref_ID, NULL as PAE_ID
, 'Y' as ERROR_IND, user CREATE_USER_ID, now() CREATE_DATETIME	
FROM perlss.enr_rqst	 A (NOLOCK)  
WHERE 	a.enr_denial_rsn_cd is not null and (A.created_by like 'CV_CH3_%') 


union all
SELECT V_Hdr_ID CONV_RUN_NUM, v_current_tbl_nm Table_Name, 'ENR_RQST_011' Issue_code, 'tracking_cd should be defaulted to C' Issue_description
, 'ID' as Primary_Column_Name, nolock as Primary_Column_Value, 'tracking_cd' as Issue_Column_Name, 	tracking_cd	as Issue_Column_Value, NULL as Ref_ID, NULL as PAE_ID
, 'Y' as ERROR_IND, user CREATE_USER_ID, now() CREATE_DATETIME
---SELECT DISTINCT tracking_cd, created_by 
FROM perlss.enr_rqst	 A (NOLOCK)  
WHERE  (A.created_by like 'CV_CH3_%' OR A.last_modified_by like 'CV_CH3_%') AND tracking_cd NOT IN ('C','R')

union all
SELECT V_Hdr_ID CONV_RUN_NUM, v_current_tbl_nm Table_Name, 'ENR_RQST_012' Issue_code, 'enrollment start date is greather than end date' Issue_description
, 'ID' as Primary_Column_Name, nolock as Primary_Column_Value, 'tracking_cd' as Issue_Column_Name, 	tracking_cd	as Issue_Column_Value, NULL as Ref_ID, NULL as PAE_ID
, 'Y' as ERROR_IND, user CREATE_USER_ID, now() CREATE_DATETIME
---SELECT DISTINCT tracking_cd, created_by 
FROM perlss.enr_rqst	 A (NOLOCK)  
WHERE  (A.created_by like 'CV_CH3_%' OR A.last_modified_by like 'CV_CH3_%') 
AND a.enr_start_dt > a.enr_end_dt

union all
SELECT V_Hdr_ID CONV_RUN_NUM, v_current_tbl_nm Table_Name, 'ENR_RQST_013' Issue_code, 'enrollment start date is not same as  than enr decision date' Issue_description
, 'ID' as Primary_Column_Name, nolock as Primary_Column_Value, 'tracking_cd' as Issue_Column_Name, 	tracking_cd	as Issue_Column_Value, NULL as Ref_ID, NULL as PAE_ID
, 'Y' as ERROR_IND, user CREATE_USER_ID, now() CREATE_DATETIME
---SELECT DISTINCT tracking_cd, created_by 
FROM perlss.enr_rqst	 A (NOLOCK)  
WHERE  (A.created_by like 'CV_CH3_%') 
and a.enr_dcsn_dt <> a.enr_start_dt
;


end if;

if v_current_tbl_nm = 'slt_details' then

insert
	into
	LEGACY.CONV_TARGET_DV_DETAILS_CH3
(
 CONV_RUN_NUM,
	Table_Name,
	Issue_code,
	Issue_description,
	Primary_Column_Name,
	Primary_Column_Value,
	Issue_Column_Name,
	Issue_Column_Value ,
	Ref_ID,
	PAE_ID,
	tns_id,
	prsn_id,
	ERROR_IND,
	CREATE_USER_ID,
	CREATE_DATETIME
	)
select
	V_Hdr_ID CONV_RUN_NUM, 
	v_current_tbl_nm Table_Name, 
	'SLT_DETAILS_001' Issue_code,
	'slt_master_id is NULL' Issue_description,
	'ID' as Primary_Column_Name,
	nolock as Primary_Column_Value,
	'slt_master_id' as Issue_Column_Name,
	cast (slt_master_id as varchar) as Issue_Column_Value,
	ref_id as Ref_ID,
	PAE_ID as PAE_ID,
	tns_id,
	prsn_id ,
	'Y' as ERROR_IND,
	user CREATE_USER_ID,
	now() CREATE_DATETIME
	
from
	perlss.slt_details A (NOLOCK)
where
	slt_master_id is null 
	and slt_master_id <> 1112
	and created_by like 'CV_CH3_%' 
union all
select
	V_Hdr_ID CONV_RUN_NUM, 
	v_current_tbl_nm Table_Name, 
	'SLT_DETAILS_002' Issue_code,
	'slt_status_cd Is NULL' Issue_description,
	'ID' as Primary_Column_Name,
	nolock as Primary_Column_Value,
	'slt_status_cd' as Issue_Column_Name,
	slt_status_cd as Issue_Column_Value,
	ref_id as Ref_ID,
	PAE_ID as PAE_ID,
	tns_id,
	prsn_id ,
	'Y' as ERROR_IND,
	user CREATE_USER_ID,
	now() CREATE_DATETIME
	
from
	perlss.slt_details A (NOLOCK)
where
	slt_status_cd is null and created_by like 'CV_CH3_%' 
union all
select
	V_Hdr_ID CONV_RUN_NUM, 
	v_current_tbl_nm Table_Name, 
	'SLT_DETAILS_003' Issue_code,
	'PAE_ID Is NULL' Issue_description,
	'ID' as Primary_Column_Name,
	nolock as Primary_Column_Value,
	'PAE_ID' as Issue_Column_Name,
	PAE_ID as Issue_Column_Value,
	ref_id as Ref_ID,
	PAE_ID as PAE_ID,
	tns_id,
	prsn_id ,
	'Y' as ERROR_IND,
	user CREATE_USER_ID,
	now() CREATE_DATETIME
	
from
	perlss.slt_details A (NOLOCK)
where
	PAE_ID is null and created_by like 'CV_CH3_%' ;	
	

end if;

v_cnt := 0;

select
	Count(1)
into
	v_cnt
from
	LEGACY.CONV_TARGET_DV_DETAILS_CH3
where
	1 = 1
	and TABLE_NAME = v_current_tbl_nm
	and Error_IND = 'Y';

raise notice 'total Number of validations created for % : %' ,
v_current_tbl_nm ,
cast(v_cnt as varchar);

V_Loop := V_Loop + 1;
end loop ;
end ;

$procedure$
;


--------------------------------------------------------
--  DDL for Table T_RE_DISENROLL_REASONS_CH3
--------------------------------------------------------

  CREATE TABLE LEGACY.T_RE_DISENROLL_REASONS_CH3 
   (	SAK_RECIP int8, 
	SAK_PGM_ELIG int8, 
	CDE_DISENROLL_RSN varchar(2), 
	DTE_LAST_UPDATE int8
   );
--------------------------------------------------------
--  DDL for Table T_RE_LIV_ARNG_CH3
--------------------------------------------------------

  CREATE TABLE LEGACY.T_RE_LIV_ARNG_CH3 
   (	SAK_LIV_ARNG int8, 
	CDE_LIV_ARNG varchar(2), 
	DSC_LIV_ARNG varchar(50)
   );
--------------------------------------------------------
--  DDL for Table T_RE_PAT_LIAB_CH3
--------------------------------------------------------

  CREATE TABLE LEGACY.T_RE_PAT_LIAB_CH3 
   (	SAK_PAT_LIAB int8, 
	SAK_RECIP int8, 
	DTE_EFFECTIVE int8, 
	DTE_END int8, 
	AMT_PATNT_LIAB decimal(8,2), 
	DTE_ADD int8, 
	IND_ADJUST varchar(1), 
	DTE_LAST_UPDATED int8, 
	CDE_SOURCE varchar(3)
   );
--------------------------------------------------------
--  DDL for Table T_CDE_DISENROLL_REASONS_CH3
--------------------------------------------------------

  CREATE TABLE LEGACY.T_CDE_DISENROLL_REASONS_CH3 
   (	CDE_DISENROLL_RSN varchar(2), 
	DESC_DISENROLL_RSN varchar(25), 
	CDE_TYPE varchar(1), 
	IND_LETTER varchar(1)
   );
--------------------------------------------------------

----DDL for T_RE_ELIG_CH3
CREATE TABLE LEGACY.T_RE_ELIG_CH3 (
	sak_recip int4 NULL,
	sak_pgm_elig int4 NULL,
	sak_pub_hlth int4 NULL,
	dte_effective int4 NULL,
	dte_end int4 NULL,
	cde_status1 varchar(1) NULL,
	dte_added int4 NULL,
	dte_last_update int4 NULL
);


--DDL for T_RE_BASE_CH3
CREATE TABLE LEGACY.T_RE_BASE_CH3 (
	sak_recip int4 NULL,
	id_medicaid varchar(12) NULL,
	nam_last varchar(20) NULL,
	nam_first varchar(15) NULL,
	nam_mid_init varchar(1) NULL,
	adr_street_1 varchar(30) NULL,
	adr_street_2 varchar(30) NULL,
	adr_city varchar(18) NULL,
	adr_state varchar(2) NULL,
	adr_zip_code varchar(5) NULL,
	adr_zip_code_4 varchar(4) NULL,
	cde_addr_source varchar(3) NULL,
	num_latitude int4 NULL,
	num_longitude int4 NULL,
	cde_gis_quality int4 NULL,
	num_ssn varchar(9) NULL,
	dte_birth int4 NULL,
	dte_death int4 NULL,
	cde_sex varchar(1) NULL,
	cde_race varchar(2) NULL,
	cde_ethnic varchar(2) NULL,
	cde_marital varchar(1) NULL,
	cde_county varchar(2) NULL,
	cde_office varchar(1) NULL,
	sak_cnty_off_svc int4 NULL,
	cde_language varchar(3) NULL,
	sak_liv_arng int4 NULL,
	ind_mny_grant varchar(1) NULL,
	cde_facility varchar(3) NULL,
	ind_suspect varchar(1) NULL,
	cde_ward_type varchar(1) NULL,
	cde_county_ward varchar(2) NULL,
	sak_cde_phone int4 NULL,
	num_phone varchar(10) NULL,
	sak_add_phone int4 NULL,
	num_add_phone varchar(10) NULL,
	sak_man_excl int4 NULL,
	sak_citizen_dsc int4 NULL,
	ind_spec_hlth varchar(1) NULL,
	cde_soundex varchar(4) NULL,
	ind_active varchar(1) NULL,
	cde_source varchar(3) NULL,
	cde_source_state varchar(1) NULL,
	cde_other_media varchar(2) NULL,
	nam_payee varchar(35) NULL,
	dte_added int4 NULL,
	dte_last_update int4 NULL,
	sak_txt_phone int4 NULL,
	num_txt_phone varchar(10) NULL,
	email varchar(50) NULL
);



CREATE TABLE legacy.wrk_ltss_clients_ch3 (
	ltss_client_seq_id float8 NOT NULL,
	source_system_nm varchar(20) NULL,
	sak_recip varchar(20) NULL,
	perlss_pae_id varchar(20) NULL,
	program_cd varchar(20) NULL,
	cv_phase varchar(20) NULL,
	ssn varchar(9) NULL,
	perlss_indv_id float8 NULL,
	valid_sw bpchar(1) NULL,
	xref_valid_sw bpchar(1) NULL,
	src_last_update timestamp(0) NULL,
	create_dt timestamp(0) NULL,
	create_user_id varchar(20) NULL,
	insrt_upd_sw varchar(4) NULL,
	CONSTRAINT wrk_ltss_clients_ch3_pk PRIMARY KEY (ltss_client_seq_id)
);


CREATE TABLE legacy.wrk_error_log_ch3 (
	error_log_seq_num float8 NULL,
	src_sys_id varchar(30) NULL,
	src_seq_num varchar(30) NULL,
	legacy_tbl_nm varchar(30) NULL,
	legacy_client_id varchar(30) NULL,
	legacy_col_nm varchar(30) NULL,
	legacy_col_val varchar(4000) NULL,
	error_cd varchar(5) NULL,
	error_type varchar(30) NULL
);


CREATE TABLE legacy.wrk_mmis_base_member_pop_ch3 (
	sak_recip int8 NULL,
	num_ssn varchar(9) NULL,
	id_medicaid varchar(12) NULL,
	sak_pgm_elig int8 NULL,
	sak_pub_hlth int8 NULL,
	cde_pgm_health varchar(5) NULL,
	dsc_pgm_health varchar(50) NULL,
	conversion_phase varchar(7) NULL,
	dte_effective int8 NULL,
	dte_end int8 NULL,
	dte_last_update int8 NULL,
	dte_death int8 NULL,
	tracking_cd varchar(4) NULL,
	dte_added int8 NULL
);


CREATE TABLE legacy.t_re_pmp_assign_ch3 (
	sak_re_pmp_assign int4 NULL,
	sak_recip int4 NULL,
	sak_pgm_elig int4 NULL,
	sak_pmp_ser_loc int4 NULL,
	sak_prov_mbr int4 NULL,
	cde_service_loc_mbr bpchar(1) NULL,
	cde_rsn_mc_start bpchar(2) NULL,
	cde_rsn_mc_stop bpchar(2) NULL,
	sak_mc_ent_add int4 NULL,
	dte_added int4 NULL,
	sak_mc_ent_mbr int4 NULL,
	dte_prov_mbr_add int4 NULL,
	sak_mc_ent_change int4 NULL,
	dte_changed int4 NULL,
	sak_mc_ent_term int4 NULL,
	dte_termed int4 NULL,
	cde_source_state bpchar(1) NULL,
	dte_last_roster int4 NULL
);

CREATE TABLE legacy.t_pr_prov_ch3 (
	sak_prov int4 NULL,
	id_provider bpchar(9) NULL,
	num_upin bpchar(6) NULL,
	ind_on_review bpchar(1) NULL,
	ind_owner_interest bpchar(1) NULL,
	cde_gender bpchar(1) NULL,
	dte_birth_prov int4 NULL,
	num_prov_ssn bpchar(9) NULL
);



CREATE TABLE legacy.t_pmp_svc_loc_ch3 (
	sak_pmp_ser_loc int4 NULL,
	sak_prov int4 NULL,
	cde_service_loc bpchar(1) NULL,
	sak_pub_hlth int4 NULL,
	sak_prov_pgm int4 NULL,
	cde_state_region bpchar(2) NULL,
	dte_effective int4 NULL,
	dte_end int4 NULL,
	sak_pmp_focus int4 NULL,
	num_pho_24_hour bpchar(10) NULL,
	num_pho_ext bpchar(4) NULL,
	cde_file_format bpchar(1) NULL,
	num_act_panel int4 NULL,
	ind_autoassign bpchar(1) NULL,
	ind_panel_hold bpchar(1) NULL,
	ind_active bpchar(1) NULL
);



CREATE TABLE legacy.t_pub_hlth_pgm_ch3 (
	sak_pub_hlth int4 NULL,
	cde_pgm_health varchar(5) NULL,
	dsc_pgm_health varchar(50) NULL,
	dsc_pgm_definition varchar(4000) NULL,
	ind_recip_only varchar(1) NULL,
	ind_major_pgm varchar(1) NULL,
	ind_stand_alone varchar(1) NULL,
	ind_dual varchar(1) NULL,
	ind_ct_editing varchar(1) NULL,
	ind_copay varchar(1) NULL,
	ind_setup varchar(1) NULL,
	cde_enrollment varchar(1) NULL,
	elig_window_filter varchar(1) NULL
);



CREATE TABLE legacy.t_re_choices_tracking_ch3 (
	sak_recip int4 NULL,
	sak_pgm_elig int4 NULL,
	sys_cde varchar(5) NULL
);


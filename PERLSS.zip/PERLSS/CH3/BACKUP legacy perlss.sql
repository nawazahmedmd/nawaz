drop table legacy.enr_rqst_ch3_backup;
drop table legacy.COM_APPLCNT_ACCESS_ch3_backup;
drop table legacy.aud_fwr_entity_ch3_backup;


CREATE TABLE legacy.enr_rqst_ch3_backup AS SELECT * FROM PERLSS.ENR_RQST;
CREATE TABLE legacy.COM_APPLCNT_ACCESS_ch3_backup AS SELECT * FROM PERLSS.COM_APPLCNT_ACCESS;
CREATE TABLE legacy.aud_fwr_entity_ch3_backup AS SELECT * FROM PERLSS.aud_fwr_entity;

GRANT ALL ON TABLE Legacy.enr_rqst_ch3_backup TO ro_perlss;
GRANT ALL ON TABLE Legacy.enr_rqst_ch3_backup TO rw_perlss;

GRANT ALL ON TABLE Legacy.COM_APPLCNT_ACCESS_ch3_backup TO ro_perlss;
GRANT ALL ON TABLE Legacy.COM_APPLCNT_ACCESS_ch3_backup TO rw_perlss;

GRANT ALL ON TABLE Legacy.aud_fwr_entity_ch3_backup TO ro_perlss;
GRANT ALL ON TABLE Legacy.aud_fwr_entity_ch3_backup TO rw_perlss;



CREATE TABLE CV_CH3_RECON
(NUM_SSN CHAR(9),
SAK_RECIP NUMBER(9,0),
DTE_EFFECTIVE NUMBER(8,0), 
DTE_END NUMBER(8,0),
SYS_CDE VARCHAR2(10)
);


update perlss.enr_rqst A
set tracking_cd ='R' where ID in (
select id
from perlss.enr_rqst er
where    enr_id in (    select        max(enr_id)
    from        perlss.enr_rqst    where        active_sw = 'Y' --and prsn_id = 6000063287
    group by        prsn_id,        pae_id)
    and enr_status_cd = 'ENR'
    and enr_grp_cd = 'CG3'
        and tracking_cd = 'C'
order by    er.id desc);



update perlss.enr_rqst A
set tracking_cd ='R' where ID in (
select id
from perlss.enr_rqst er
where    enr_id in (    select        max(enr_id)
    from        perlss.enr_rqst    where        active_sw = 'Y' --and prsn_id = 6000063287
    group by        prsn_id,        pae_id)
    and enr_status_cd = 'DIS'
    and enr_grp_cd = 'CG3'
        and tracking_cd = 'C'
order by    er.id desc);

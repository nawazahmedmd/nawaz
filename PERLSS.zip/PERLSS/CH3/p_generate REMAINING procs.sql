CREATE OR REPLACE PROCEDURE legacy.p_generate_audit_enr_bnft()
 LANGUAGE plpgsql
AS $procedure$ 

--Variable declarations
declare		
 Column_list legacy.Temp_H.test_val%type ;


begin
	

insert into legacy.Temp_H (test_val,id,table_name)
select  
'{"id":' || cast(a.id as varchar)
|| ',"enr_id":' || cast(a.enr_Id as varchar)
||',"enr_bnft_type_cd":'|| coalesce(a.enr_bnft_type_cd,'" "')
||',"enr_bnft_grp_cd":"'|| a.enr_bnft_grp_cd ||'"'
||',"enr_bnft_amt":"'|| a.enr_bnft_amt ||'"'
||',"enr_bnft_eff_dt":"'||a.enr_bnft_eff_dt||'"'
||',"enr_bnft_end_dt":"'||a.enr_bnft_end_dt||'"'
|| ',"created_dt":"' || to_char(a.created_dt, 'YYYY-MM-DD HH:MI:SS')|| '"'
||',"last_modified_by":"' || a.last_modified_by || '"'
||',"last_modified_dt":"' || to_char(a.last_modified_dt, 'YYYY-MM-DD HH:MI:SS') || '"'
|| ',"record_version":' || cast(a.record_version as varchar)
||',"archived_dt":"'|| to_char(a.last_modified_dt, 'YYYY-MM-DD HH:MI:SS') || '"'
||',"created_by":"' || a.created_by|| '"'
||',"lon_cd":'||coalesce(a.lon_cd,'" "')  || '}'
,a.id
,'enr_bnft' as table_name 
from  perlss.enr_rqst b join perlss.enr_bnft a on a.enr_id =b.enr_id 
where  b.hstry_sw ='Y'and 
   b.last_modified_by like 'CV_CH3%';
 

end $procedure$



;






CREATE OR REPLACE PROCEDURE legacy.p_generate_audit_enr_dsnr_dtls()
 LANGUAGE plpgsql
AS $procedure$ 

--Variable declarations
declare		
 Column_list legacy.Temp_H.test_val%type ;

/*
-- create table legacy.Temp_H_dsnr_dtls (test_val varchar(8000),id int8);
--DROP PROCEDURE Legacy.P_GENERATE_Audit_enr_rqst

  */

begin
	
--delete from legacy.Temp_H;

insert into legacy.Temp_H (test_val,id,table_name)
select 
'{"createdBy":"' || b.created_by|| '"'
|| ',"createdDt":"' || to_char(b.created_dt, 'YYYY-MM-DD HH:MI:SS')  || '"'
||',"archivedDt":'||  coalesce(to_char(b.archived_dt, 'YYYY-MM-DD HH:MI:SS'),'null')
|| ',"reqPageId":null'
|| ',"recordVersion":' || cast(b.record_version as varchar)
||',"id":' || cast(b.id as varchar)
||',"auth_dt":' ||  coalesce(to_char(b.auth_dt, 'YYYY-MM-DD HH:MI:SS'),'null') 
||',"authUserId":'|| coalesce(b.auth_user_id,'null')
||',"disEnrDt":"'||  coalesce(to_char(b.dis_enr_dt, 'YYYY-MM-DD HH:MI:SS'),'null')|| '"'
||',"disEnrRsnCd":"'||b.dis_enr_rsn_cd||'"' 
||',"disEnrTypeCd":"'||b.dis_enr_type_cd||'"'
||',"ltssDscnCd":"'||b.ltss_dscn_cd||'"'
|| ',"enr_id":' || cast(b.enr_id as varchar)
||',"enrRqst":null'
|| ',"lastModifiedDate":' || coalesce(to_char(b.last_modified_dt, 'YYYY-MM-DD'),'null') 
|| ',"createdDate":"' || to_char(b.created_dt, 'YYYY-MM-DD HH:MI:SS')   || '"}'
,b.id
,'ENR_DSNR_DTLS' as table_name 
from  perlss.enr_rqst a join perlss.enr_dsnr_dtls b on a.enr_id =b.enr_id 
where a.hstry_sw ='Y'and 
   a.last_modified_by like 'CV_CH3%';

end $procedure$
;




CREATE OR REPLACE PROCEDURE legacy.p_generate_audit_enr_dtls()
 LANGUAGE plpgsql
AS $procedure$ 
 
begin
insert into legacy.Temp_H (test_val,id,table_name)
select
	'{"createdBy":"' || a.created_by || '"'
|| ',"createdDt":"' || to_char(a.created_dt, 'YYYY-MM-DD HH:MI:SS') || '"'
|| ',"archivedDt":null'
|| ',"reqPageId":null'
|| ',"recordVersion":' || cast(a.record_version as varchar)
|| ',"id":' || cast(a.id as varchar)
|| ',"authStatusCd":"' || a.auth_Status_Cd || '"'
|| ',"comments":null'
|| ',"enrDenialRsnCd":null'
|| ',"cobStartDt":"' ||coalesce(to_char(a.cob_End_dt, 'YYYY-MM-DD HH:MI:SS'),'null') || '"'
|| ',"cobEndDt":"' ||coalesce(to_char(a.cob_End_dt, 'YYYY-MM-DD HH:MI:SS'),'null') || '"'
|| ',"grandfatheredSw":null'
|| ',"enrId":' || cast(a.enr_Id as varchar)
|| ',"enrRqst":'
|| '{"createdBy":"' || b.created_by || '"'
|| ',"createdDt":"' || to_char(b.created_dt, 'YYYY-MM-DD HH:MI:SS') || '"'
|| ',"archivedDt":null' 
|| ',"reqPageId":null'
|| ',"recordVersion":' || cast(b.record_version as varchar)
|| ',"id":' || cast(b.id as varchar)
|| ',"enrId":' || cast(b.enr_Id as varchar)
|| ',"activeSw":"' || b.active_Sw || '"' 
|| ',"aplOverrideSw":null,"assignedUserId":null'
|| ',"authDt":"' || to_char(b.auth_dt, 'YYYY-MM-DD HH:MI:SS') || '"'
|| ',"authId":' || cast(b.auth_Id as varchar)
|| ',"authStatusCd":"' || b.auth_Status_Cd || '"'
|| ',"cobSw":null,"disEnrDt":null,"enrDenialRsnCd":null'
|| ',"enrEndDt":"' || to_char(b.enr_End_dt, 'YYYY-MM-DD HH:MI:SS') || '"'
|| ',"enrGrpCd":"' || b.enr_Grp_Cd || '"'
|| ',"srcEnrId":null'
|| ',"enrStartDt":"' || to_char(b.enr_start_dt, 'YYYY-MM-DD HH:MI:SS') || '"'
|| ',"enrDcsnDt":"' || coalesce(to_char(b.enr_dcsn_dt, 'YYYY-MM-DD'),'null') || '"'
|| ',"enrStatusCd":"' || b.enr_status_cd || '"'
|| ',"historySw":null'
|| ',"overrideSw":"' || b.override_sw || '"'
|| ',"paeId":"' || b.pae_id || '"'
|| ',"prsnId":' || cast(b.prsn_id as varchar) 
|| ',"trackingCd":"' || b.tracking_cd || '"'
|| ',"tnsId":' || coalesce(cast(b.tns_id as varchar), 'null')
	--|| '"'
|| ',"lastModifiedDate":"' || to_char(a.last_modified_dt, 'YYYY-MM-DD') || '"'
|| ',"createdDate":"' || to_char(a.created_dt, 'YYYY-MM-DD') || '"}'
|| ',"lastModifiedDate":"' || to_char(b.last_modified_dt, 'YYYY-MM-DD') || '"'
|| ',"createdDate":"' || to_char(b.created_dt, 'YYYY-MM-DD') || '"}'
,a.id as id
,'enr_dtls' as table_name
from
	perlss.enr_rqst b
join perlss.enr_dtls a 
on
	b.enr_id = a.enr_id
	and b.hstry_sw ='Y'
	and b.last_modified_by like 'CV_CH3%';

end $procedure$
;


CREATE OR REPLACE PROCEDURE legacy.p_generate_audit_enr_financial_elig()
 LANGUAGE plpgsql
AS $procedure$ 

 
begin

insert into legacy.Temp_H (test_val,id,table_name)
select
	'{"createdBy":"' || a.created_by || '"'
|| ',"createdDt":"' || a.created_dt|| '"'
|| ',"archivedDt":null'
|| ',"reqPageId":null'
|| ',"recordVersion":' || cast(a.record_version as varchar)
|| ',"id":' || cast(a.id as varchar)
||',"aplIndctrSw":null'
||',"ctgryEligBeginDt":"' ||a.ctgry_elig_begin_dt || '"'
||',"ctgryEligCd":"' || a.ctgry_elig_cd || '"'
||',"ctgryEligDesc":"' ||a.ctgry_elig_desc ||'"'
||',"ctgryEligEndDt":"' || coalesce(to_char(a.ctgry_elig_end_dt,'YYYY-MM-DD'),'null')|| '"'
||',"dobDt":"' || a.dob_dt || '"' 
||',"dualMemIndctrSw":"' || a.dual_member_indctr_sw || '"'
||',"dualMemberSw":null'
||',"firstName":"'||a.first_name||'"'
||',"genderCd":"' ||a.gender_cd||'"'
||',"lastName":"'||a.last_name ||'"'
||',"lvngArrgmntTypeCd":"'||a.lvng_arrgmnt_type_cd||'"'
||',"middleInitial":"'||a.middle_initial||'"'
||',"penaltyEndDt":null'
||',"penaltyStartDt":null'
||',"penaltySw":null'
||',"primaryIndivId":null'
||',"prsnId":' || cast(a.prsn_id as varchar)
||',"ssn":"' || a.ssn ||'"'
||',"termntnRsn":null'
||',"updateFrmLinkSw":null'
|| ',"enrId":' || cast(a.enr_Id as varchar)
|| ',"enrRqst":'
|| '{"createdBy":"' || b.created_by || '"'
|| ',"createdDt":"' || b.created_dt || '"'
|| ',"archivedDt":null' 
|| ',"reqPageId":null'
|| ',"recordVersion":' || cast(b.record_version as varchar)
|| ',"id":' || cast(b.id as varchar)
|| ',"enrId":' || cast(b.enr_Id as varchar)
|| ',"activeSw":"' || b.active_Sw || '"' 
|| ',"aplOverrideSw":null,"assignedUserId":null'
|| ',"authDt":"' || to_char(b.auth_dt, 'YYYY-MM-DD HH:MI:SS') || '"'
|| ',"authId":' || cast(b.auth_Id as varchar)
|| ',"authStatusCd":"' || b.auth_Status_Cd || '"'
|| ',"cobSw":null,"disEnrDt":null,"enrDenialRsnCd":null'
|| ',"enrEndDt":"' || to_char(b.enr_End_dt, 'YYYY-MM-DD HH:MI:SS') || '"'
|| ',"enrGrpCd":"' || b.enr_Grp_Cd || '"'
|| ',"srcEnrId":null'
|| ',"enrStartDt":"' || b.enr_start_dt || '"'
|| ',"enrDcsnDt":"' || coalesce(to_char(b.enr_dcsn_dt, 'YYYY-MM-DD'),'null') || '"'
|| ',"enrStatusCd":"' || b.enr_status_cd || '"'
|| ',"historySw":null'
||',"historySw":"' ||coalesce(cast(b.hstry_sw as varchar),'null') || '"'
|| ',"overrideSw":"' || b.override_sw || '"'
|| ',"paeId":"' || b.pae_id || '"'
|| ',"prsnId":' || cast(b.prsn_id as varchar) 
|| ',"trackingCd":"' || b.tracking_cd || '"'
|| ',"tnsId":' || coalesce(cast(b.tns_id as varchar), 'null')
	--|| '"'
|| ',"lastModifiedDate":"' || to_char(b.last_modified_dt, 'YYYY-MM-DD') || '"'
|| ',"createdDate":"' || to_char(b.created_dt, 'YYYY-MM-DD') || '"}'
|| ',"lastModifiedDate":"' ||  coalesce(to_char(a.last_modified_dt, 'YYYY-MM-DD'),'null') || '"'
|| ',"createdDate":"' || coalesce(to_char(a.created_dt, 'YYYY-MM-DD'),'null') || '"}'
,a.id as id
,'enr_financial_elig' as table_name
from
	perlss.enr_rqst b
join perlss.enr_financial_elig a 
on
	b.enr_id = a.enr_id
	and b.hstry_sw ='Y'
	and b.last_modified_by like 'CV_CH3%';
	

end $procedure$
;


CREATE OR REPLACE PROCEDURE legacy.p_generate_audit_enr_patient_lblty_dtls()
 LANGUAGE plpgsql
AS $procedure$ 


 
 
begin
	


insert into legacy.Temp_H (test_val,id,table_name)
select
'{"createdBy":"' || c.created_by || '"'
|| ',"createdDt":"' || c.created_dt|| '"'
|| ',"archivedDt":null'
|| ',"reqPageId":null'
|| ',"recordVersion":' || cast(c.record_version as varchar)
|| ',"id":' || cast(a.id as varchar)
||',"amount":'||coalesce(cast(b.tns_id as varchar), 'null')
||',"patientLblty":null'
||',"patientLbltyEndDt":"' ||coalesce(to_char(c.patient_lblty_end_dt,'YYYY-MM-DD'),'null')|| '"'
||',"patientLbltyStartDt":"' ||c.patient_lblty_start_dt|| '"'
|| ',"financialEligId":' || cast(c.financial_elig_id as varchar)
|| ',"enr_financial_elig":'
||	'{"createdBy":"' || a.created_by || '"'
|| ',"createdDt":"' || a.created_dt|| '"'
|| ',"archivedDt":null'
|| ',"reqPageId":null'
|| ',"recordVersion":' || cast(a.record_version as varchar)
|| ',"id":' || cast(a.id as varchar)
--||',"aplIndctrSw":'|| coalesce(a.apl_indctr_sw,'" "')
||',"aplIndctrSw":null'
||',"ctgryEligBeginDt":"' ||a.ctgry_elig_begin_dt || '"'
||',"ctgryEligCd":"' || a.ctgry_elig_cd || '"'
||',"ctgryEligDesc":"' ||a.ctgry_elig_desc ||'"'
||',"ctgryEligEndDt":"' || coalesce(to_char(a.ctgry_elig_end_dt,'YYYY-MM-DD'),'null')|| '"'
||',"dobDt":"' || a.dob_dt || '"' 
||',"dualMemIndctrSw":"' || a.dual_member_indctr_sw || '"'
||',"dualMemberSw":null'
||',"firstName":"'||a.first_name||'"'
||',"genderCd":"' ||a.gender_cd||'"'
||',"lastName":"'||a.last_name ||'"'
||',"lvngArrgmntTypeCd":"'||a.lvng_arrgmnt_type_cd||'"'
||',"middleInitial":"'||a.middle_initial||'"'
||',"penaltyEndDt":null'
||',"penaltyStartDt":null'
||',"penaltySw":null'
||',"primaryIndivId":null'
|| ',"prsnId":' || cast(a.prsn_id as varchar)
|| ',"ssn":"' || a.ssn ||'"'
||',"termntnRsn":null'
--||',"termntnRsn":'|| coalesce(termntn_rsn,'" "')
||',"updateFrmLinkSw":null'
--||',"updateFrmLinkSw":'|| coalesce(a.update_from_link_sw,'" "')
|| ',"enrId":' || cast(a.enr_Id as varchar)
|| ',"enrRqst":'
|| '{"createdBy":"' || b.created_by || '"'
|| ',"createdDt":"' || b.created_dt || '"'
|| ',"archivedDt":null' 
|| ',"reqPageId":null'
|| ',"recordVersion":' || cast(b.record_version as varchar)
|| ',"id":' || cast(b.id as varchar)
|| ',"enrId":' || cast(b.enr_Id as varchar)
|| ',"activeSw":"' || b.active_Sw || '"' 
|| ',"aplOverrideSw":null'
||',"assignedUserId":"' || b.assigned_user_id ||'"'
|| ',"authDt":"' || to_char(b.auth_dt, 'YYYY-MM-DD HH:MI:SS') || '"'
|| ',"authId":' || cast(b.auth_Id as varchar)
|| ',"authStatusCd":"' || b.auth_Status_Cd || '"'
|| ',"cobSw":null,"disEnrDt":null'
||',"enrDenialRsnCd":'|| coalesce(b.enr_denial_rsn_cd,'" "')
|| ',"enrEndDt":"' || to_char(b.enr_End_dt, 'YYYY-MM-DD HH:MI:SS') || '"'
|| ',"enrGrpCd":"' || b.enr_Grp_Cd || '"'
|| ',"srcEnrId":null'
|| ',"enrStartDt":"' || b.enr_start_dt || '"'
|| ',"enrDcsnDt":"' || coalesce(to_char(b.enr_dcsn_dt, 'YYYY-MM-DD'),'null') || '"'
|| ',"enrStatusCd":"' || b.enr_status_cd || '"'
|| ',"historySw":null'
|| ',"overrideSw":"' || b.override_sw || '"'
|| ',"paeId":"' || b.pae_id || '"'
|| ',"prsnId":' || cast(b.prsn_id as varchar) 
|| ',"trackingCd":"' || b.tracking_cd || '"'
|| ',"tnsId":' || coalesce(cast(b.tns_id as varchar), 'null')
	--|| '"'
|| ',"lastModifiedDate":"' || to_char(b.last_modified_dt, 'YYYY-MM-DD') || '"'
|| ',"createdDate":"' || to_char(b.created_dt, 'YYYY-MM-DD') || '"}'
|| ',"lastModifiedDate":"' || to_char(b.last_modified_dt, 'YYYY-MM-DD') || '"'
|| ',"createdDate":"' || to_char(b.created_dt, 'YYYY-MM-DD') || '"}'
||',"lastModifiedDate":"' || coalesce(to_char(c.last_modified_dt, 'YYYY-MM-DD'),'null') || '"'
||',"createdDate":"' || to_char(c.created_dt, 'YYYY-MM-DD') || '"}'
,c.id as id
,'enr_patient_lblty_dtls' as table_name
from
	perlss.enr_rqst b
join perlss.enr_financial_elig a 
on
	b.enr_id = a.enr_id join perlss.enr_patient_lblty_dtls c on a.id=c.financial_elig_id 
	and b.hstry_sw ='Y'
    and b.last_modified_by like 'CV_CH3%';
	
end $procedure$
;





select * from perlss.pae_rqst 
where created_by = 'PASRR_CV'
and status_cd not in ('AA','AP','DN');

select * from perlss.pae_rqst 
where created_by = 'PASRR_CV'
and program_cd is null;

select * from perlss.pasrr_rqst 
where created_by = 'PASRR_CV'
and status_cd  not in ('CO');

select * from perlss.pasrr_rqst 
where created_by = 'PASRR_CV'
and source_cd  not in ('CNV');

select * from perlss.pasrr_rqst 
where created_by = 'PASRR_CV'
and type_cd  not in ('O','T');

select * from perlss.adj_rqst 
where created_by = 'PASRR_CV'
and adj_status_cd  not in ('CO');

select * from perlss.adj_rqst 
where created_by = 'PASRR_CV'
and loc_dcsn_cd  not in ('NWE','NFS','DNF','NED','FAC','NSE','DWE');

select * from perlss.enr_rqst 
where created_by = 'PASRR_CV'
and enr_status_cd  not in ('ENR','DIS'); 

select * from perlss.enr_rqst 
where created_by = 'PASRR_CV'
and enr_start_dt > current_date;

select * from perlss.pasrr_rqst 
where created_by = 'PASRR_CV'
and lvl2_outcome_cd is not null
and lvl2_outcome_cd not in ('LTA','DEN', 'CAN', 'HAL', 'STA');

select * from perlss.pasrr_rqst 
where created_by = 'PASRR_CV'
and lvl1_outcome_cd is not null
and lvl1_outcome_cd not in ('EHD','CON', 'REF', 'NSC', 'CAN', 'NEG','EXE', 'CAT','RES','SPI');

select * from perlss.adj_pasrr_outcome 
where created_by = 'PASRR_CV'
and lvl1_dcsn_cd is not null
and lvl1_dcsn_cd not in ( 'REF');

select * from perlss.adj_pasrr_outcome 
where created_by = 'PASRR_CV'
and lvl2_dcsn_cd is not null
and lvl2_dcsn_cd not in ( 'LTA','DEN','STA');
select * from perlss.pae_skilled_srvc_dtl 
where created_by = 'PASRR_CV'
and section_type_cd not in ('TFE','OCT','PHT','ISS',
'WCS','OWC','IOT','ISP','PED','TCO','TRS','INT','TPN','TSI');

select * from perlss.pae_activities_lvng pal  
where created_by = 'PASRR_CV'
and trnsfr_without_help_cd not in ('US','AL','NE','UN');

select * from perlss.pae_activities_lvng pal  
where created_by = 'PASRR_CV'
and walk_without_help_cd  not in ('US','AL','NE','UN');

select * from perlss.pae_activities_lvng pal  
where created_by = 'PASRR_CV'
and eat_without_help_cd  not in ('US','AL','NE','UN');

select * from perlss.pae_activities_lvng pal  
where created_by = 'PASRR_CV'
and wheelchair_capable_cd  not in ('US','AL','NE','UN');

select * from perlss.pae_activities_lvng pal  
where created_by = 'PASRR_CV'
and toilet_without_help_cd  not in ('US','AL','NE','UN');

select * from perlss.pae_activities_lvng pal  
where created_by = 'PASRR_CV'
and incont_without_help_cd  not in ('US','AL','NE','UN');

select * from perlss.pae_activities_lvng pal  
where created_by = 'PASRR_CV'
and cath_ost_whithout_help_cd  not in ('US','AL','NE','UN');

select * from perlss.pae_activities_lvng pal  
where created_by = 'PASRR_CV'
and orientation_prsn_place_cd  not in ('US','AL','NE','UN');

select * from perlss.pasrr_skilled_srvcs 
where created_by = 'PASRR_CV'
and srvc_name_cd  not in ('TFE','OCT','PHT','ISS',
'WCS','OWC','IOT','ISP','PED','TCO','TRS','INT','TPN','TSI');


select * from perlss.adj_functnl_assmnt 
where created_by = 'PASRR_CV' 
and functnl_measure_cd  not in ('TRAN','MOBL','MOBW','EATG','TLTG','TLTI','TLTC','ORNT','ECOM','RCOM','MEDC','BHVR')

select * from perlss.pasrr_functnl_assmnt pfa  
where created_by = 'PASRR_CV' 
and functnl_measure_cd  not in ('TRAN','MOBL','MOBW','EATG','TLTG','TLTI','TLTC','ORNT','ECOM','RCOM','MEDC','BHVR')



 







select  distinct ssn --, reviewid,locoutcome, locdeterminationdate 
 from 
(select a.locoutcome , d.ssn , a.locdeterminationdate,reviewid  
from  
(select * from legacy.pasrr_loc where revisionof=0) a
join legacy.pasrr_events e on a.eventid = e.eventid
join legacy.pasrr_demographics d on d.individualid = e.individualid
join (select * from legacy.pasrr_level_ii where reconof is null) l on l.eventid = e.eventid 
where locoutcome <> 'Cancelled / Withdrawn' and e.payersource like '%Medicaid%'
 ) a 
where exists 
(select 1 from 
(select a.locoutcome , d.ssn , a.locdeterminationdate,reviewid from 
(select * from legacy.pasrr_loc where revisionof=0) a
join legacy.pasrr_events e on a.eventid = e.eventid
join legacy.pasrr_demographics d on d.individualid = e.individualid
join (select * from legacy.pasrr_level_ii where reconof is null) l on l.eventid = e.eventid 
where locoutcome <> 'Cancelled / Withdrawn' and e.payersource like '%Medicaid%'
) b 
where a.ssn =b.ssn and a.locoutcome<> b.locoutcome and 
EXTRACT(DAY FROM (a.locdeterminationdate)-(b.locdeterminationdate)) between -15 and 15)
except
select distinct d.ssn-- ,e.reviewid,l.assessmentid , locoutcome , locdeterminationdate, reconof , revisionof 
from legacy.pasrr_loc a
join legacy.pasrr_events e on a.eventid =e.eventid 
join legacy.pasrr_demographics d on e.individualid = d.individualid 
join legacy.pasrr_level_ii l on l.eventid = e.eventid 
where reconof is not null or revisionof <> 0 and e.payersource like '%Medicaid%';

select distinct locoutcome  from legacy.pasrr_loc where eventid 
in (select * from legacy.pasrr_events where reviewid= 189524)

Hi Kai, 30 day count is 283 and 15 days is 181
This analysis is only for Medicaid Pending,Medicaid,PACE-Medicaid,PACE-Medicaid Pending Payersources

--283
--181
individuals with different level of care within the 30/15 days where we dont have recon/revision

select d.ssn ,e.reviewid,l.assessmentid , locoutcome , locdeterminationdate, reconof , revisionof 
from legacy.pasrr_events e 
join legacy.pasrr_demographics d on e.individualid = d.individualid 
left join legacy.pasrr_loc a  on a.eventid =e.eventid 
left join legacy.pasrr_level_ii l on l.eventid = e.eventid 
where d.ssn = '251464202';

select * from legacy.pasrr_level_ii   where assessmentid  in ( 37432,37578,38814,42356,44784);
select * from legacy.pasrr_level_ii   where reconof  in ( 12426,10872,11938);
select * from legacy.pasrr_level_ii   where reconof  in ( 4957,5859,5367);


select avg(cnt) from (
select  count(1) as cnt , level1determinationdate::date
from (
select level1determinationdate from legacy.pasrr_level_i a 
join legacy.pasrr_events b on a.eventid::text = b.eventid ::text 
join legacy.pasrr_demographics c on c.individualid::text = b.individualid::text
where b.payersource like '%Medicaid%' and C.SSN is not NULL
and ssn::text not in (select ssn from perlss.com_applcnt where created_by <> 'PASRR_CV' and ssn is not null)
union  
select level1determinationdate from legacy.pasrr_level_i a 
join legacy.pasrr_events b on a.eventid::text = b.eventid ::text 
join legacy.pasrr_demographics c on c.individualid::text = b.individualid::text
where b.payersource like '%Medicaid%'
and ssn::text in (select ssn from perlss.com_applcnt where ssn is not null 
and prsn_id not in (select prsn_id from perlss.com_applcnt_access where assigned_mco_sw='Y' and active_sw='Y')))a
group by level1determinationdate::date)a



select avg(cnt) from (
select count(1) cnt,l.level1determinationdate::date
from legacy.pasrr_loc a
join legacy.pasrr_events e on a.eventid =e.eventid 
join legacy.pasrr_demographics d on e.individualid = d.individualid 
join legacy.pasrr_level_i l on l.eventid = e.eventid 
where e.payersource like '%Medicaid%'
group by level1determinationdate::date)a
; --7


select avg(cnt) from (
select count(1) cnt,l.level2determinationdate::date
from legacy.pasrr_loc a
join legacy.pasrr_events e on a.eventid =e.eventid 
join legacy.pasrr_demographics d on e.individualid = d.individualid 
join legacy.pasrr_level_ii l on l.eventid = e.eventid 
where e.payersource like '%Medicaid%'
group by level2determinationdate::date)a; --9

select avg(cnt) from (
select count(1) cnt,coalesce(e.nfadmitdate,e.hospitaladmitdate)::date as  admitdate
from legacy.pasrr_events e  
join legacy.pasrr_demographics d on e.individualid = d.individualid 
--join legacy.pasrr_level_ii l on l.eventid = e.eventid 
where e.payersource like '%Medicaid%'
group by admitdate)a; --19


select * from legacy.pasrr_events pe 


select avg(cnt) from (
select count(1) cnt,l.level1determinationdate::date
from legacy.pasrr_loc a
join legacy.pasrr_events e on a.eventid =e.eventid 
join legacy.pasrr_demographics d on e.individualid = d.individualid 
join legacy.pasrr_level_i l on l.eventid = e.eventid 
where e.payersource like '%Medicaid%' and level1determinationdate::date > '2024-01-01'
group by level1determinationdate::date
--order by 1 desc

)a
; --6.86

select avg(cnt) from (
select count(1) cnt,l.level2determinationdate::date
from legacy.pasrr_loc a
join legacy.pasrr_events e on a.eventid =e.eventid 
join legacy.pasrr_demographics d on e.individualid = d.individualid 
join legacy.pasrr_level_ii l on l.eventid = e.eventid 
where e.payersource like '%Medicaid%' and level2determinationdate::date > '2024-01-01'
group by level2determinationdate::date 
order by 1 desc
)a; --9.57

select avg(cnt) from (
select count(1) cnt,admitdate from 
(select admitdate from 
(select  coalesce(e.nfadmitdate,e.hospitaladmitdate) as  admitdate
from legacy.pasrr_events e  
join legacy.pasrr_demographics d on e.individualid = d.individualid 
where e.payersource like '%Medicaid%')a where admitdate is not null  )a
group by admitdate
--order by 2
)a;




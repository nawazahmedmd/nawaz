--com_applcnt_access
select *  from perlss.com_applcnt_access where created_by='CV_111';
--slot details
select *  from perlss.SLT_KB_TRIGGER  where created_by='CV_111';      
select *  from perlss.slt_details sd   where created_by='CV_111';


--Doc
select *   from perlss.cnv_doc_dtls  where created_by='CV_111';
select *  from perlss.doc_module_mapping  where created_by='CV_111';
select *  from perlss.APP_DOC  where created_by='CV_111';

--Task
select *   from perlss.cnv_task  where created_by='CV_111';

--Cor

select *   from perlss.cor_print_vendor_dtls  where created_by='CV_111';
select *   from perlss.cor_req_hstry  where created_by='CV_111';
delet from perlss.COR_NOTICE_ADDR  where created_by='CV_111';

---PAE tables

select *   from perlss.pae_lvng_arrgmnt  where created_by='CV_111';
select *   from perlss.pae_app_addr_dtl  where created_by='CV_111';
select *   from perlss.pae_app_cntct_dtl  where created_by='CV_111';
select *   from perlss.pae_program_selection  where created_by='CV_111';
select *   from perlss.pae_skilled_srvc_summary  where created_by='CV_111';
select *   from perlss.pae_submission  where created_by='CV_111';
select *  from perlss.pae_med_diagns_dtls  where created_by='CV_111';
select *   from perlss.pae_medical_diagnosis  where created_by='CV_111';
select *  from perlss.pae_add_behavrl_qualifiers  where created_by='CV_111';
select *  from perlss.pae_beh_sup_phycl_agr  where created_by='CV_111';
select *  from perlss.pae_beh_sup_self_injury  where created_by='CV_111';
select *  from perlss.pae_beh_sup_srvc_sys  where created_by='CV_111';
select *  from perlss.pae_intlctl_dvlpmntl_disblty_dtls  where created_by='CV_111';
select *  from perlss.pae_kb_parta_wtng_list  where created_by='CV_111';
select *  from perlss.pae_kb_partb_wtng_list  where created_by='CV_111';
select *  from perlss.pae_kb_skilled_srvc_dtl  where created_by='CV_111';
select *  from perlss.pae_loc_determn_disenr  where created_by='CV_111';
select *  from perlss.pae_prior_caregiver_detail  where created_by='CV_111';
select *  from perlss.pae_prior_intnsv_intrvntn  where created_by='CV_111';
select *  from perlss.pae_prior_medical_prgnss  where created_by='CV_111';
select *  from perlss.pae_prior_medical_regimen  where created_by='CV_111';
select *  from perlss.pae_prior_non_fblr_sezr  where created_by='CV_111';
select *  from perlss.pae_prior_nutri_feeding  where created_by='CV_111';
select *  from perlss.pae_prior_transpt_spclty_care  where created_by='CV_111';
select *  from perlss.pae_comparable_cost_care  where created_by='CV_111';
select *  from perlss.pae_kb_fa_details  where created_by='CV_111';
select *  from perlss.pae_loc_determn_disenr  where created_by='CV_111';
select *  from perlss.pae_loc_determn_dcsn  where created_by='CV_111';
select *  from perlss.pae_loc_sys_calc  where created_by='CV_111';
select *   from perlss.pae_driver_flow  where created_by='CV_111';
select *  from perlss.pae_flow_sequence  where created_by='CV_111';
select *  from perlss.com_comments  where created_by='CV_111';
select *   from perlss.pae_rqst  where created_by='CV_111';

---Ref tables

select *   from perlss.ref_app_addr_dtl  where created_by='CV_111';
select *   from perlss.ref_app_cntct_dtl  where created_by='CV_111';
select *   from perlss.ref_applcnt_dtls  where created_by='CV_111';
select *   from perlss.ref_kb_living_arrngmt  where created_by='CV_111';
select *   from perlss.kb_REFERRAL_CLOSURE  where created_by='CV_111';
select *   from perlss.ref_rqst  where created_by='CV_111';

-----------To load ref_rqst table never select *  com applicant tables:
--com_applcnt
select *  from perlss.com_applcnt  where created_by='CV_111';



select * FROM perlss.REF_RQST
where CREATED_BY like 'CV_111%'
order by id;

select * FROM perlss.REF_RQST
where CREATED_BY like 'CV_111%'
and ref_id is null;

select * FROM perlss.ref_rqst 
where legacy_id ='RF900000399' not like 'CV_111%'
order by id desc;


select count(1), legacy_id  from perlss.ref_rqst
where created_by like 'CV_111%'
group by legacy_id
having count(1)>1;

select distinct none_disable_sw  from perlss.ref_applcnt_dtls

select count(1), ref_id from perlss.ref_applcnt_dtls
where created_by like 'CV_111%'
group by ref_id
having count(1)>1;

select * from perlss.ref_applcnt_dtls
where created_by like 'CV_111%'
and ref_id is null;

select * from perlss.ref_applcnt_dtls
where created_by like 'CV_111%'
and ref_id not in (select ref_id from perlss.ref_rqst);

select count(1), pae_id, self_beh_cd  from perlss.pae_beh_sup_self_injury pbssi 
where created_by like 'CV_111%'
group by pae_id, self_beh_cd
having count(1)>1;

select distinct self_severe_sw  
from perlss.pae_beh_sup_self_injury pbssi where created_by like 'CV_111%';

select distinct self_arm_reach_cd  
from perlss.pae_beh_sup_self_injury pbssi where created_by like 'CV_111%';

select distinct self_crisis_inter_cd  
from perlss.pae_beh_sup_self_injury pbssi where created_by like 'CV_111%';

select *  from perlss.pae_beh_sup_self_injury pbssi 
where created_by like 'CV_111%' and  pae_id is null;

select *  from perlss.pae_beh_sup_self_injury a
where not exists(select 1 from perlss.pae_rqst b where b.pae_id = a.pae_id);

select count(distinct legacy_id) from  
perlss.pae_rqst  where created_by like 'CV_111%';

select distinct self_beh_cd  from perlss.pae_beh_sup_self_injury pbssi 
where created_by like 'CV_111%';

select * from perlss.fwr_static_data fsd where name = 'KBLIVARRANGE';

select distinct long_term_care_sw from perlss.pae_lvng_arrgmnt pla ;

select distinct sch_outside_sw from perlss.pae_lvng_arrgmnt pla ;

select distinct phychiatric_hosp_sw,mental_hlth_sw,mental_hlth_sw from perlss.pae_lvng_arrgmnt pla ;

select distinct special_sch_sw,phycl_disable_sw,intlctl_disable_sw,sch_outside_sw from perlss.pae_lvng_arrgmnt pla ;

select *  from perlss.pae_lvng_arrgmnt pbssi 
where created_by like 'CV_111%' and  pae_id is null;

select *  from perlss.pae_lvng_arrgmnt a
where not exists(select 1 from perlss.pae_rqst b where b.pae_id = a.pae_id);

select *  from perlss.pae_lvng_arrgmnt a
where not exists(select 1 from perlss.pae_rqst b where b.pae_id = a.pae_id);

select *  from perlss.pae_lvng_arrgmnt a
where created_by like 'CV_111%';

select distinct curr_lvng_arrgmnt_cd  from perlss.pae_lvng_arrgmnt a
where created_by like 'CV_111%';

select *  from perlss.pae_lvng_arrgmnt a
where created_by like 'CV_111%'
and curr_lvng_arrgmnt_cd is null;

select count(1), pae_id  from perlss.pae_lvng_arrgmnt a
where created_by like 'CV_111%'
group by pae_id
having count(1)>1;


select distinct  rsn_cmc_sw  from perlss.ref_kb_living_arrngmt a
where created_by like 'CV_111%';

select *  from perlss.ref_kb_living_arrngmt a
where created_by like 'CV_111%'
and prsn_id not in (select prsn_id from perlss.com_applcnt ca);

select *  from perlss.ref_kb_living_arrngmt a
where created_by like 'CV_111%'
and current_living_cd  is null;

select count(1), ref_id  from perlss.ref_kb_living_arrngmt rkla  
where created_by like 'CV_111%'
group by ref_id
having count(1)>1;

select * from perlss.fwr_static_data fsd where name like '%KBLIV%';
[{"P3":[{"code":"LT","value":"Long-term care facility - e.g., nursing home ","activateSW":"Y"}, 
{"code":"ME","value":"Mental health residence - e.g., psychiatric group home","activateSW":"Y"}, 
{"code":"PS","value":"Psychiatric hospital or unit","activateSW":"Y"}, 
{"code":"IN","value":"Group home for children / youths with intellectual disability","activateSW":"Y"}, 
{"code":"PH","value":"Group home for children / youth with physical disability","activateSW":"Y"}, 
{"code":"SC","value":"Specialized school - e.g., school for deaf, blind","activateSW":"Y"}, 
{"code":"HO","value":"Home","activateSW":"Y"}, 
{"code":"OT","value":"Other","activateSW":"Y"}]}]

select *  from perlss.ref_kb_living_arrngmt a
where created_by like 'CV_111%';

select *  from perlss.pae_action a
where created_by like 'CV_111%'
and pae_id is null;

select count(1), pae_id  from perlss.pae_action a
where created_by like 'CV_111%'
group by pae_id
having count(1)>1;

select * from perlss.pae_action
where created_by like 'CV_111%';

select *  from perlss.pae_action a
where created_by like 'CV_111%'
and pae_id not in (select pae_id from perlss.pae_action ca);

select * from perlss.fwr_static_data fsd where name like '%MILI%';

[{"code": "APO", "value":"APO - Air/Army Post Office","activateSW":"Y"},
{"code": "FPO", "value":"FPO - Fleet Post Office","activateSW":"Y"}]AA

[{"code": "AA", "value":"AA - Armed Forces America ","activateSW":"Y"},
{"code": "AE", "value":"AE - Armed Forces Africa, Canada, Europe, Middle East","activateSW":"Y"},
{"code": "AP", "value":"AP - Armed Forces Pacific","activateSW":"Y"}] APO 

[{"P3":[{"code":"NW","value":"New","activateSW":"Y"}, 
{"code":"IN","value":"Intake","activateSW":"Y"}, 
{"code":"PP","value":"Pending PAE","activateSW":"Y"}, 
{"code":"CP","value":"Complete","activateSW":"Y"}, 
{"code":"EN","value":"Ended","activateSW":"Y"}, 
{"code":"OW","value":"On Waiting List","activateSW":"Y"}, 
{"code":"RE","value":"To Be Removed from Waiting List","activateSW":"Y"}, 
{"code":"CL","value":"Closed","activateSW":"Y"}]}]


select *  from perlss.pae_program_selection a
where created_by like 'CV_111%'
and pae_id is null;

select count(1), pae_id  from perlss.pae_program_selection a
where created_by like 'CV_111%'
group by pae_id
having count(1)>1;

select * from perlss.pae_program_selection pps 
where created_by like 'CV_111%';

select *  from perlss.pae_program_selection a
where created_by like 'CV_111%'
and pae_id not in (select pae_id from perlss.pae_rqst ca);


select distinct addr_type_cd  from perlss.pae_app_addr_dtl paad;

select distinct mail_addr_sw  from perlss.pae_app_addr_dtl paad;

select * from perlss.pae_program_selection rad
where created_by like 'CV_111%';


select *  from perlss.pae_kb_parta_wtng_list pkpwl 
where created_by like 'CV_111%'
and pae_id is null;

select *  from perlss.pae_kb_parta_wtng_list pkpwl 
where created_by like 'CV_111%'
and ref_id is null;

select count(1), pae_id  from perlss.pae_kb_parta_wtng_list a
where created_by like 'CV_111%'
group by pae_id
having count(1)>1;

select * from perlss.pae_kb_parta_wtng_list pps 
where created_by like 'CV_111%';

select *  from perlss.pae_kb_parta_wtng_list a
where created_by like 'CV_111%'
and pae_id not in (select pae_id from perlss.pae_rqst ca);

select *  from perlss.pae_kb_parta_wtng_list a
where created_by like 'CV_111%'
and ref_id not in (select ref_id from perlss.pae_rqst ca);


select * from perlss.pae_app_addr_dtl paad  
where created_by like 'CV_111%' 
order by 2;

select * from 
perlss.pae_app_addr_dtl paad  
where created_by like 'CV_111%' 
and pae_id ='PAE100000140';


select count(1), pae_id  from perlss.pae_prior_caregiver_detail ppcd  
where created_by like 'CV_111%'
group by pae_id
having count(1)>1;

select * from perlss.pae_prior_caregiver_detail 
where created_by like 'CV_111%';

select *  from perlss.pae_prior_caregiver_detail a
where created_by like 'CV_111%'
and pae_id not in (select pae_id from perlss.pae_rqst ca);

select distinct single_two_parent_fmly_cd  from perlss.pae_prior_caregiver_detail;
select distinct cargvr_intervn_cd  from perlss.pae_prior_caregiver_detail;
NA
DS
CS
select * from perlss.fwr_static_data fsd where name like 'PARENT_FAMILY%';
[{"P1":[{"code":"TP","value":"Two Parent Family","activateSW":"Y"}]}, 
{"P2":[{"code":"TP","value":"Two Parent Family","activateSW":"Y"}]}, 
{"P3":[{"code":"SP","value":"Single Parent Family","activateSW":"Y"}, 
{"code":"TP","value":"Two Parent Family","activateSW":"Y"}]}]
[{"P1":[{"code":"DS","value":"Caregiving includes (non-complex) daily skilled nursing tasks (not including medication administration) ","activateSW":"Y"}]}, 
{"P2":[{"code":"DS","value":"Caregiving includes (non-complex) daily skilled nursing tasks (not including medication administration) ","activateSW":"Y"}]}, 
{"P3":[{"code":"CS","value":"Caregiving includes complex skilled medical interventions","activateSW":"Y"}, 
{"code":"DS","value":"Caregiving includes (non-complex) daily skilled nursing tasks (not including medication administration) ","activateSW":"Y"}]}]


select * from 


select * FROM perlss.pae_app_addr_dtl where CREATED_BY like 'CV_111%'
and  PAE_ID='PAE100000238';


select * FROM perlss.pae_app_addr_dtl where CREATED_BY  like 'CV_111%'
AND mail_addr_sw ='Y';


select count(1), pae_id  from perlss.pae_prior_nutri_feeding ppnf  
where created_by like 'CV_111%'
group by pae_id
having count(1)>1;

select * from perlss.pae_prior_nutri_feeding 
where created_by like 'CV_111%';

select *  from perlss.pae_prior_caregiver_detail a
where created_by like 'CV_111%'
and pae_id not in (select pae_id from perlss.pae_rqst ca);



select count(1), pae_id  from perlss.pae_beh_sup_srvc_sys pbsss  
where created_by like 'CV_111%'
group by pae_id
having count(1)>1;

select * from perlss.pae_beh_sup_srvc_sys 
where created_by like 'CV_111%';

select *  from perlss.pae_beh_sup_srvc_sys a
where created_by like 'CV_111%'
and pae_id not in (select pae_id from perlss.pae_rqst ca);


select * from perlss.pae_beh_sup_self_injury pbssi  
where created_by like 'CV_111%'
and self_arm_reach_cd is not null 
and self_duration_sw ='N';

select * from PERLSS.pae_prior_nutri_feeding ppnf 
where created_by like 'CV_111%'
and hands_on_feedng_duration_cd is null;

select * from perlss.pae_intlctl_dvlpmntl_disblty_dtls;


select count(1), pae_id  from perlss.pae_intlctl_dvlpmntl_disblty_dtls pbsss  
where created_by like 'CV_111%'
group by pae_id
having count(1)>1;

select * from perlss.pae_intlctl_dvlpmntl_disblty_dtls 
where created_by like 'CV_111%';

select *  from perlss.pae_intlctl_dvlpmntl_disblty_dtls a
where created_by like 'CV_111%'
and pae_id not in (select pae_id from perlss.pae_rqst ca);

select * from perlss.pae_prior_transpt_spclty_care 

select * from perlss.PAE_ADD_BEHAVRL_QUALIFIERS a
where created_by like 'CV_111%';

select count(1),pae_id from perlss.PAE_ADD_BEHAVRL_QUALIFIERS a
where created_by like 'CV_111%'
group by pae_id
having count(1)>1;

select *  from perlss.PAE_ADD_BEHAVRL_QUALIFIERS a
where created_by like 'CV_111%'
and pae_id not in (select pae_id from perlss.pae_rqst pr);

select *  from perlss.PAE_ADD_BEHAVRL_QUALIFIERS a
where created_by like 'CV_111%'
and pae_id  is null;

select * from perlss.PAE_BEH_SUP_PHYCL_AGR a
where created_by like 'CV_111%';

select count(1),pae_id, TYPE_CD from perlss.PAE_BEH_SUP_PHYCL_AGR a
where created_by like 'CV_111%'
group by pae_id,TYPE_CD
having count(1)>1;

select *  from perlss.PAE_BEH_SUP_PHYCL_AGR a
where created_by like 'CV_111%'
and pae_id not in (select pae_id from perlss.pae_rqst pr);

select *  from perlss.PAE_BEH_SUP_PHYCL_AGR a
where created_by like 'CV_111%'
and pae_id  is null;





select * from perlss.PAE_PRIOR_MEDICAL_REGIMEN a
where created_by like 'CV_111%';

select count(1),pae_id from perlss.PAE_PRIOR_MEDICAL_REGIMEN a
where created_by like 'CV_111%'
group by pae_id
having count(1)>1;

select *  from perlss.PAE_PRIOR_MEDICAL_REGIMEN a
where created_by like 'CV_111%'
and pae_id not in (select pae_id from perlss.pae_rqst pr);

select *  from perlss.PAE_PRIOR_MEDICAL_REGIMEN a
where created_by like 'CV_111%'
and pae_id  is null;



select * from perlss.pae_prior_non_fbrl_sezr a
where created_by like 'CV_111%';

select count(1),pae_id from perlss.pae_prior_non_fbrl_sezr a
where created_by like 'CV_111%'
group by pae_id
having count(1)>1;

select *  from perlss.pae_prior_non_fbrl_sezr a
where created_by like 'CV_111%'
and pae_id not in (select pae_id from perlss.pae_rqst pr);

select *  from perlss.pae_prior_non_fbrl_sezr a
where created_by like 'CV_111%'
and pae_id  is null;


select * from perlss.PAE_PRIOR_INTNSV_INTRVNTN a
where created_by like 'CV_111%';

select count(1),pae_id from perlss.PAE_PRIOR_INTNSV_INTRVNTN a
where created_by like 'CV_111%'
group by pae_id
having count(1)>1;

select *  from perlss.PAE_PRIOR_INTNSV_INTRVNTN a
where created_by like 'CV_111%'
and pae_id not in (select pae_id from perlss.pae_rqst pr);

select *  from perlss.PAE_PRIOR_INTNSV_INTRVNTN a
where created_by like 'CV_111%'
and pae_id  is null;




select * from perlss.PAE_MEDICAL_DIAGNOSIS a
where created_by like 'CV_111%';

select count(1),pae_id from perlss.PAE_MEDICAL_DIAGNOSIS a
where created_by like 'CV_111%'
group by pae_id
having count(1)>1;

select *  from perlss.PAE_MEDICAL_DIAGNOSIS a
where created_by like 'CV_111%'
and pae_id not in (select pae_id from perlss.pae_rqst pr);

select *  from perlss.PAE_MEDICAL_DIAGNOSIS a
where created_by like 'CV_111%'
and pae_id  is null;


select * from perlss.PAE_PRIOR_MEDICAL_PRGNSS a
where created_by like 'CV_111%';

select count(1),pae_id from perlss.PAE_PRIOR_MEDICAL_PRGNSS a
where created_by like 'CV_111%'
group by pae_id
having count(1)>1;

select *  from perlss.PAE_PRIOR_MEDICAL_PRGNSS a
where created_by like 'CV_111%'
and pae_id not in (select pae_id from perlss.pae_rqst pr);

select *  from perlss.PAE_PRIOR_MEDICAL_PRGNSS a
where created_by like 'CV_111%'
and pae_id  is null;


select *  from perlss.PAE_MED_DIAGNS_DTLS a
where created_by like 'CV_111%'
and pae_diagns_id not in (select id from perlss.PAE_MEDICAL_DIAGNOSIS pr); 


select *  from perlss.PAE_MED_DIAGNS_DTLS a
where created_by like 'CV_111%'
;

select *  from perlss.PAE_COMPARABLE_COST_CARE a
where created_by like 'CV_111%'
and pae_id not in (select pae_id from perlss.pae_rqst pr);

select distinct ltss_approve  from perlss.PAE_COMPARABLE_COST_CARE a
where created_by like 'CV_111%'
and pae_id  is null;


select *  from perlss.PAE_MED_DIAGNS_DTLS a
where created_by like 'CV_111%'
and pae_diagns_id not in (select id from perlss.PAE_MEDICAL_DIAGNOSIS pr); 


select part_a_loc_cd,part_b_loc_cd  from perlss.PAE_LOC_SYS_CALC a
where created_by like 'CV_111%'
;


select distinct loc_determn_part_cd  from perlss.PAE_LOC_DETERMN_DCSN a
where created_by like 'CV_111%'
;


select distinct expctd_12_months_sw from perlss.pae_med_diagns_dtls pmdd  
where created_by like 'CV_111%'
;

select * from perlss.PAE_LOC_DETERMN_DCSN a
where created_by like 'CV_111%'
;


select distinct report_resp_sw  from perlss.PAE_KB_FA_DETAILS a
where created_by like 'CV_111%'
;

select * from perlss.slt_details sd 
where created_by like 'CV_111%'
order by ref_id
;

select * from perlss.slt_details sd 
where created_by like 'CV_111%'
group by type_cd
;

select count(ref_id),slt_master_id ,slt_status_cd from perlss.slt_details sd 
where created_by like 'CV_111%'
group by slt_master_id,slt_status_cd
order by 2,3

select * from information_schema.columns where column_name like '%slt%group%';

select * from perlss.slt_master

select * from perlss.pae_loc_determn_dcsn pldd where-- user_role_cd='AP'
pae_id = 'PAE100001457'
;


select * from perlss.cnv_doc_dtls ct 
where created_by like 'CV_111%'
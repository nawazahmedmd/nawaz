SELECT
1 as default_port,
'Y' external_ref_sw,
NULL AS DOC_ID,
'N' pdf_generated_sw,
1234 prsn_id,
C.NEW_REF_ID AS  ref_id,
LTRIM(RTRIM(B.REF_STATUS_CD)) AS  ref_status,
'KB' AS  program_cd,
NULL AS  start_dt,
A.RECEIVED_DT AS  submsn_dt,
LTRIM(RTRIM(A.SOURCE_CD)) AS  source_cd ,
'KB' AS  ref_type_cd,
NULL AS  entity_type,
F_GET_ARCHIVE_DATE AS  archived_dt,
F_GET_CONV_USER AS  created_by ,
F_GET_CONV_DATE AS  created_dt ,
NULL AS  last_modified_by,
NULL  AS  last_modified_dt,
0 AS  record_version,
'N' AS new_prsn_sw,
NULL AS  legacy_id,
'808' AS entity_id,
LTRIM(RTRIM(A.MA_STANDARD_SW)) AS  ma_standard_sw,
LTRIM(RTRIM(A.NINETY_DAY_RECON_SW)) AS ninety_day_recon_sw,
--LTRIM(RTRIM(A.RENEWAL_REQD_SW)) --COLUMN CURRENTLY NOT IN DEV TEDS DB
Null as renewal_reqd_sw,
LTRIM(RTRIM(A.INDV_ID)) AS teds_indv_id 
--SELECT *
FROM LT_CNV_SRC_KB.KB_REF_RQST A 
JOIN (SELECT REF_ID, REF_STATUS_CD FROM LT_CNV_SRC_KB.KB_REF_STATUS WHERE EFF_END_DT IS NULL) B ON A.REF_ID = B.REF_ID
JOIN LT_CNV_WRK.REFERRAL_CROSSWALK C ON A.REF_ID = C.OLD_REF_ID
JOIN LT_CNV_WRK.WRK_LTSS_CLIENTS WRK_LTSS_CLIENTS ON  WRK_LTSS_CLIENTS.KB_REF_ID = C.OLD_REF_ID 
WHERE WRK_LTSS_CLIENTS.source_system_nm='KatieBeckett'
AND WRK_LTSS_CLIENTS.VALID_SW = 'Y' 
AND WRK_LTSS_CLIENTS.XREF_VALID_SW = 'Y' 
--AND WRK_LTSS_CLIENTS.PERLSS_INDV_ID IS NOT NULL
AND WRK_LTSS_CLIENTS.CV_PHASE = F_GET_CONV_TYPE;
select 'cnv_task' as table_name,
 task_master_id
,1234 as prsn_id --NEED TO REVISIT
,cr.new_pae_id as pae_id
,null as apl_id
,null as assigned_user_id
,null as due_dt
,null as role_id
,null as entity_id
,'LO' as prirty_cd
,rf.new_ref_id as ref_id
,Perlss_Task 
,null as last_modified_by
,null as last_modified_dt
,0 as record_version
,F_GET_CONV_USER as created_by
,SYSDATE as created_dt
,F_GET_ARCHIVE_DATE as archived_dt
,null as processed_flag
from (
select r.ref_id,
a.pae_id,
'PAE: New Katie Beckett Referral Received – DIDD' as Perlss_Task
,21 as task_master_id
from LT_CNV_SRC_KB.KB_REF_RQST r
left join LT_CNV_SRC_KB.KB_PAE_RQST a on r.ref_id = a.ref_id
left join LT_CNV_SRC_KB.kb_loc_partb_det b on a.pae_id = b.pae_id
where (a.pae_id is null or b.pae_id is null)
and a.pae_status_cd<>'CL'
union 
--Loc determination started
select r.ref_id,
a.pae_id
,case when a.pae_action_cd in ('BR','BD') then 'PAE: DIDD Part B Supervisor Review Queue'
when a.pae_action_cd in ('AP','AU','AI') then 'PAE: Complete Part A Assessment'
when a.pae_action_cd = 'AR' then 'PAE: Physician Review for KB Part A'
when a.pae_action_cd = 'AL' then 'PAE: Nurse Review for KB Part A'
end as Perlss_Task,
case when a.pae_action_cd in ('BR','BD') then 9
when a.pae_action_cd in ('AP','AU','AI') then 10
when a.pae_action_cd = 'AR' then 12
when a.pae_action_cd = 'AL' then 13
end as task_master_id
from LT_CNV_SRC_KB.KB_REF_RQST r
inner join LT_CNV_SRC_KB.KB_PAE_RQST a on r.ref_id = a.ref_id
inner join LT_CNV_SRC_KB.kb_loc_partb_det b on a.pae_id = b.pae_id
where a.pae_status_cd='PE'
) t
join lt_cnv_wrk.pae_crosswalk cr on cr.old_pae_id = t.pae_id
join lt_cnv_wrk.referral_crosswalk rf on rf.old_ref_id = t.ref_id
join LT_CNV_WRK.WRK_LTSS_CLIENTS WRK_LTSS_CLIENTS ON  (WRK_LTSS_CLIENTS.KB_PAE_ID = t.pae_id AND WRK_LTSS_CLIENTS.KB_REF_ID = t.ref_id)
WHERE WRK_LTSS_CLIENTS.source_system_nm='KatieBeckett'
AND WRK_LTSS_CLIENTS.VALID_SW = 'Y' 
AND WRK_LTSS_CLIENTS.XREF_VALID_SW = 'Y' 
--AND WRK_LTSS_CLIENTS.PERLSS_INDV_ID IS NOT NULL
AND WRK_LTSS_CLIENTS.CV_PHASE = F_GET_CONV_TYPE;

SELECT
'pae_skilled_srvc_summary' as table_name
, B.NEW_PAE_ID	pae_id
,'Y'	need_skilled_srvcs_sw
,'N'	need_respiratory_care_sw
,A.CREATE_DT	created_dt
,ltrim(rtrim(A.UPDATE_USER_ID))	last_modified_by
,A.UPDATE_DT	last_modified_dt
,0	record_version
,F_GET_ARCHIVE_dATE	archived_dt
,ltrim(rtrim(A.CREATE_USER_ID))	created_by
,'N'	dsnt_need_srvcs_sw
,null as	total_submitted_skilled_srvcs_acuity_score
--select *
FROM LT_CNV_SRC_KB.KB_DS_SKILLED_SERVICES A
JOIN LT_CNV_WRK.PAE_CROSSWALK B ON A.PAE_ID = B.OLD_PAE_ID
JOIN LT_CNV_WRK.WRK_LTSS_CLIENTS WRK_LTSS_CLIENTS ON  WRK_LTSS_CLIENTS.KB_PAE_ID = B.OLD_PAE_ID 
WHERE WRK_LTSS_CLIENTS.source_system_nm='KatieBeckett'
AND WRK_LTSS_CLIENTS.VALID_SW = 'Y' 
AND WRK_LTSS_CLIENTS.XREF_VALID_SW = 'Y' 
--AND WRK_LTSS_CLIENTS.PERLSS_INDV_ID IS NOT NULL
AND WRK_LTSS_CLIENTS.CV_PHASE = F_GET_CONV_TYPE;

SELECT
'slt_action_history' as table_name
,CASE WHEN LTRIM(RTRIM(A.TYPE_CD)) = 'PA' THEN 1017
		WHEN LTRIM(RTRIM(A.TYPE_CD)) = 'PB' THEN 1018 END	slt_master_id
,NULL	action_type_cd
,LTRIM(RTRIM(B.CAPACITY_NUM))	previous_capacity
,LTRIM(RTRIM(A.CAPACITY))	curr_capacity
,CASE WHEN LTRIM(RTRIM(A.TYPE_CD)) = 'PA' THEN 'KBA'
		WHEN	LTRIM(RTRIM(A.TYPE_CD)) = 'PB' THEN 'KBB' END	previous_program_type_cd
,CASE WHEN LTRIM(RTRIM(A.TYPE_CD)) = 'PA' THEN 'KBA'
		WHEN	LTRIM(RTRIM(A.TYPE_CD)) = 'PB' THEN 'KBB' END	new_program_type_cd
,NULL AS	linked_slt_master_id
,NULL AS	active_sw
,NULL AS	eval_comments
,A.CREATE_DT	created_dt
,LTRIM(RTRIM(A.CREATE_USER_ID))	created_by
,A.UPDATE_DT	last_modified_by
,LTRIM(RTRIM(A.UPDATE_USER_ID))	last_modified_dt
,0	record_version
,F_GET_ARCHIVE_DATE	archived_dt
--SELECT *
from LT_CNV_SRC_KB.kb_slot_master A
JOIN (SELECT TYPE_CD, CAPACITY, T1_ALLOCATED, T2_ALLOCATED FROM LT_CNV_SRC_KB.kb_slot_master_HIST 
GROUP BY TYPE_CD) B ON A.TYPE_CD = B.TYPE_CD AND A.T1_ALLOCATED = B.T1_ALLOCATED AND A.T2_ALLOCATED=B2.T2_ALLOCATED

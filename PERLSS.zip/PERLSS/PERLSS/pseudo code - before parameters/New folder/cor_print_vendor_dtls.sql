SELECT 
'cor_print_vendor_dtls' as table_name
C.NEW_COR_ID AS cor_id												,
LTRIM(RTRIM(A.FILE_NAME_TXT)) AS file_name_txt                            ,
LTRIM(RTRIM(A.ENV_TYPE_CD)) AS env_type_cd                                ,
LTRIM(RTRIM(A.MAIL_PIECE_COUNT_NUM)) AS mail_piece_count_num              ,
LTRIM(RTRIM(A.PAGE_COUNT_NUM)) AS page_count_num                          ,
A.FILE_SENT_DT AS file_sent_dt                              ,
A.ACK_RECEIVED_DT AS ack_received_dt                        ,
LTRIM(RTRIM(A.FILE_RECEIVED_SW)) AS file_received_sw                      ,
LTRIM(RTRIM(A.VALID_FILE_SW)) AS valid_file_sw                            ,
A.VALID_FILE_NOTIFICATION_DT AS valid_file_notification_dt  ,
LTRIM(RTRIM(A.FAILURE_ID)) AS failure_id                                  ,
LTRIM(RTRIM(A.UPDATE_USER_ID)) AS last_modified_by                                    ,
A.UPDATE_DT AS  last_modified_dt                                   ,
0 AS record_version                                      ,
LTRIM(RTRIM(A.CREATE_USER_ID)) AS created_by                                          ,
A.CREATE_DT AS created_dt                                          ,
F_GET_ARCHIVE_DATE AS archived_dt                                         
--SELECT *
FROM LT_CNV_SRC_KB.KB_CO_PRINT_VENDOR_DETAILS A
JOIN LT_CNV_SRC_KB.KB_CO_REQUEST_HISTORY B
JOIN LT_CNV_WRK.COR_CROSSWALK C ON B.CO_REQ_SEQ = C.OLD_COR_ID 
SELECT
'com_applcnt_access' as table_name
,NULL AS pae_id
,B.NEW_REF_ID AS REF_ID
,1234 	prsn_id 
,NULL AS	entity_cd
,F_GET_CONV_DATE AS	eff_begin_dt 
,NULL AS	eff_end_dt
,'Y'	active_sw
,A.CREATE_DT	created_dt
,NULL AS last_modified_by
,NULL AS last_modified_dt
,0	record_version
,F_GET_ARCHIVE_DATE	archived_dt
,'KBREFSERV'	created_by
,'DIDD'	entity_type_cd
,NULL AS assigned_mco_sw
,'808'	entity_id
--SELECT *
FROM LT_CNV_SRC_KB.KB_REF_RQST A
JOIN LT_CNV_WRK.REFERRAL_CROSSWALK B ON A.REF_ID = B.OLD_REF_ID
JOIN LT_CNV_WRK.WRK_LTSS_CLIENTS WRK_LTSS_CLIENTS ON  WRK_LTSS_CLIENTS.KB_REF_ID = B.OLD_REF_ID 
WHERE WRK_LTSS_CLIENTS.source_system_nm='KatieBeckett'
AND WRK_LTSS_CLIENTS.VALID_SW = 'Y' 
AND WRK_LTSS_CLIENTS.XREF_VALID_SW = 'Y' 
--AND WRK_LTSS_CLIENTS.PERLSS_INDV_ID IS NOT NULL
AND WRK_LTSS_CLIENTS.CV_PHASE = F_GET_CONV_TYPE;


SELECT 1017 AS slt_master_id,
(SELECT CAST(A.CAPACITY AS INT)
FROM LT_CNV_SRC_KB.KB_SLOT_MASTER A
WHERE TYPE_CD='PA') AS CURRENT_CAPACITY, 
(select CAST(CAPACITY_NUM AS INT) from (
select a.*,row_number() OVER(PARTITION BY TYPE_CD ORDER BY create_Dt DESC) row_num
from LT_CNV_SRC_KB.kb_slot_master_hist a 
where type_cd in('PA') order by create_Dt desc)
where row_num=1) AS PREVIOUS_CAPACITY
FROM DUAL
union
SELECT 1018 as slt_master_id,
(SELECT CAST(A.CAPACITY AS INT) 
FROM LT_CNV_SRC_KB.KB_SLOT_MASTER A
WHERE TYPE_CD='PB') AS CURRENT_CAPACITY,
CASE WHEN (select CAST(CAPACITY_NUM AS INT) from (
        select a.*,row_number() OVER(PARTITION BY TYPE_CD ORDER BY create_Dt DESC) row_num
        from LT_CNV_SRC_KB.kb_slot_master_hist a 
        where type_cd in('PB') order by create_Dt desc )
        where row_num=1) IS NULL THEN (SELECT CAST(A.CAPACITY AS INT)
FROM LT_CNV_SRC_KB.KB_SLOT_MASTER A
WHERE TYPE_CD='PB') ELSE(select CAST(CAPACITY_NUM AS INT) from (
        select a.*,row_number() OVER(PARTITION BY TYPE_CD ORDER BY create_Dt DESC) row_num
        from LT_CNV_SRC_KB.kb_slot_master_hist a 
        where type_cd in('PB') order by create_Dt desc
        )
        where row_num=1) END AS PREVIOUS_CAPACITY
FROM DUAL
;
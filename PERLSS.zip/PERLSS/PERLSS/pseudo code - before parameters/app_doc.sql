SELECT 
 'app_doc' AS table_name
,NULL	doc_id--revisit
,LTRIM(RTRIM(B.DOCUMENT_CONTENT))	doc  --revisit
,LTRIM(RTRIM(A.CREATE_USER_ID))	created_by
,LTRIM(RTRIM(A.CREATE_DT))	created_dt
,LTRIM(RTRIM(A.UPDATE_USER_ID))	last_modified_by
,LTRIM(RTRIM(A.UPDATE_DT))	last_modified_dt
,0	record_version
,F_GET_ARCHIVE_DATE	archived_dt
,CASE WHEN LTRIM(RTRIM(A.DELETE_SW))  IS NULL THEN 'N' ELSE A.DELETE_SW END	delete_sw
,CASE WHEN LTRIM(RTRIM(A.FN_DOCUMENT_ID)) IS NOT NULL THEN 'Y' ELSE 'N' END AS	filenet_upload_sw
FROM LT_CNV_SRC_KB.kb_doc_dtl A
JOIN LT_CNV_SRC_KB.kb_documents B ON A.DOC_SEQ_NUM =B.DOC_SEQ_NUM
;

SELECT 
'pae_lvng_arrgmnt' AS table_name
,r.NEW_PAE_ID	pae_id
, LTRIM(RTRIM(A.CURRENT_LIVING_CD))	curr_lvng_arrgmnt_cd
, NULL AS	lvng_arrgmnt_desc
, NULL AS	nursing_facility_name_cd
, NULL AS	addr_line_1
, NULL AS	addr_line_2
, NULL AS	city
, NULL AS	state_cd
, NULL AS	zip
, NULL AS	extsn
, NULL AS	cnty_cd
, NULL AS	ph_num
, LTRIM(RTRIM(A.LIV_LTC_SW))	long_term_care_sw
, LTRIM(RTRIM(A.LIV_HOSP_SW))	phychiatric_hosp_sw
, LTRIM(RTRIM(A.LIV_MENTAL_SW))	mental_hlth_sw
, LTRIM(RTRIM(A.LIV_SPEC_SW))	special_sch_sw
, LTRIM(RTRIM(A.LIV_IDD_SW))	intlctl_disable_sw
, LTRIM(RTRIM(A.LIV_PD_SW))	phycl_disable_sw
, CASE WHEN (LTRIM(RTRIM(A.LIV_LTC_SW)) = '1' 
             OR LTRIM(RTRIM(A.LIV_HOSP_SW))='1'
             OR LTRIM(RTRIM(A.LIV_SPEC_SW))='1'	
			 OR LTRIM(RTRIM(A.LIV_MENTAL_SW))='1'
			 OR LTRIM(RTRIM(A.LIV_IDD_SW))='1'
			 OR LTRIM(RTRIM(A.LIV_PD_SW))='1') THEN 'N' ELSE 'Y' END AS	none_sw
, LTRIM(RTRIM(A.SCHOOL_OUTSIDE_HOME_SW))	sch_outside_sw
, NULL AS	admsn_dt
, NULL AS	expctd_discharge_cd
, NULL AS	anticipated_discharge_dt
, NULL AS	incarceration_dt
, NULL AS	anticipated_release_dt
, A.CREATE_DT	created_dt
, LTRIM(RTRIM(A.UPDATE_USER_ID))	last_modified_by
, A.UPDATE_DT	last_modified_dt
, 0 AS	record_version
, F_GET_ARCHIVE_DATE AS	archived_dt
, LTRIM(RTRIM(A.CREATE_USER_ID))	created_by
, NULL AS	othr_facility_name
, NULL AS	org_id
, NULL AS	org_loc_id
, NULL AS		provider_id
FROM LT_CNV_SRC_KB.kb_ri_app_dtl A
JOIN LT_CNV_SRC_KB.KB_PAE_RQST P ON A.REF_ID = P.REF_ID
JOIN LT_CNV_WRK.PAE_CROSSWALK R ON P.PAE_ID = R.OLD_PAE_ID
JOIN LT_CNV_WRK.WRK_LTSS_CLIENTS WRK_LTSS_CLIENTS ON  WRK_LTSS_CLIENTS.KB_PAE_ID = R.OLD_PAE_ID 
WHERE WRK_LTSS_CLIENTS.source_system_nm='KatieBeckett'
AND WRK_LTSS_CLIENTS.VALID_SW = 'Y' 
AND WRK_LTSS_CLIENTS.XREF_VALID_SW = 'Y' 
--AND WRK_LTSS_CLIENTS.PERLSS_INDV_ID IS NOT NULL
AND WRK_LTSS_CLIENTS.CV_PHASE = F_GET_CONV_TYPE;
SELECT
 1 as default_port
, CR.NEW_PAE_ID	pae_id
,'N' AS 	pdf_generated_sw
,'N' AS 	new_prsn_sw
,'KB' AS 	program_cd
,A.CREATE_DT	pae_rqst_dt
,NULL AS 	entity_type
,NULL AS 	grand_region_cd
,LTRIM(RTRIM(A.CREATE_USER_ID))	user_id
,A.REASSESSMENT_DUE_DT	recrtfctn_due_dt
,LTRIM(RTRIM(C.SSI_APP_STATUS))	ssi_applcatn_status_cd
,NULL AS 	submitted_enr_grp_cd
,NULL AS 	rqstd_enr_grp_cd
,'N' AS 	assigned_grp_submit_sw
,'N' AS 	grp3_intrst_sw
,NULL AS 	actual_discharge_dt
,NULL AS 	mopd_dt
,A.CREATE_DT	begin_dt
,LTRIM(RTRIM(B.CLOSURE_RSN_CD))	closure_rsn_cd
,NULL AS 	closure_rsn_desc
,'N' AS 	closure_attestation_sw
,NULL AS 	due_dt
,NULL AS 	mode_cd
,LTRIM(RTRIM(A.PAE_STATUS_CD))	status_cd
,F_GET_ARCHIVE_DATE AS 	archived_dt
,LTRIM(RTRIM(A.CREATE_USER_ID))	created_by
,A.CREATE_DT	created_dt
,LTRIM(RTRIM(A.UPDATE_USER_ID))	last_modified_by
,A.UPDATE_DT	last_modified_dt
,0 AS 	record_version
,'NA' AS 	pae_type_cd
,CK.NEW_REF_ID	ref_id
,NULL AS 	tmed_id
,NULL AS 	tns_id
,1234 AS 	prsn_id -- NEEDS TO REVISIT
,A.PAE_ID AS 	legacy_id
,NULL AS 	entity_id
,NULL AS 	enroll_in_mfp_sw
,CASE WHEN B.CLR_PROG_CD='PA' then 'Y' else 'N'  END AS	abandon_parta_sw
-- SELECT *
FROM LT_CNV_SRC_KB.KB_PAE_RQST A
JOIN LT_CNV_WRK.PAE_CROSSWALK CR ON A.PAE_ID = CR.OLD_PAE_ID
JOIN LT_CNV_WRK.REFERRAL_CROSSWALK CK ON A.REF_ID = CK.OLD_REF_ID
JOIN (SELECT REF_ID, CLOSURE_RSN_CD,CLR_PROG_CD FROM LT_CNV_SRC_KB.KB_REF_STATUS WHERE EFF_END_DT IS NULL) B ON A.REF_ID = B.REF_ID
JOIN LT_CNV_WRK.WRK_LTSS_CLIENTS WRK_LTSS_CLIENTS ON  WRK_LTSS_CLIENTS.KB_PAE_ID = CR.OLD_PAE_ID 
LEFT JOIN LT_CNV_SRC_KB.kb_ssi_noncompliance C ON A.REF_ID = C.REF_ID
WHERE WRK_LTSS_CLIENTS.source_system_nm='KatieBeckett'
AND WRK_LTSS_CLIENTS.VALID_SW = 'Y' 
AND WRK_LTSS_CLIENTS.XREF_VALID_SW = 'Y' 
--AND WRK_LTSS_CLIENTS.PERLSS_INDV_ID IS NOT NULL
AND WRK_LTSS_CLIENTS.CV_PHASE = F_GET_CONV_TYPE;

SELECT 
'pae_submission' as table_name
, B.NEW_PAE_ID	pae_id
,'OTH'	who_submitting_cd
,'' AS 	signature
,NULL AS 	comments
,NULL AS 	pae_recrtfctn_sw
,NULL AS 	pae_recrtfctn_ack_sw
,C.CREATE_DT	created_dt
,LTRIM(RTRIM(A.UPDATE_USER_ID))	last_modified_by
,A.UPDATE_DT	last_modified_dt
,0 AS 	record_version
,F_GET_ARCHIVE_DATE AS 	archived_dt
,LTRIM(RTRIM(C.CREATE_USER_ID))	created_by
,NULL AS 	cea_determn_cd
,NULL AS 	certificate_dt
,CASE WHEN A.PAE_STATUS_CD IN ('DS','CL','DN','AP') THEN A.UPDATE_DT ELSE NULL END	submit_dt
,'N' AS 	revised_pae_sw
,'N' AS 	cea_sw
--SELECT COUNT(1)
FROM LT_CNV_SRC_KB.KB_PAE_RQST A 
JOIN LT_CNV_WRK.PAE_CROSSWALK B ON A.PAE_ID = B.OLD_PAE_ID
JOIN LT_CNV_SRC_KB.KB_LOC_PARTB_DET C ON A.PAE_ID = C.PAE_ID
JOIN LT_CNV_WRK.WRK_LTSS_CLIENTS WRK_LTSS_CLIENTS ON  WRK_LTSS_CLIENTS.KB_PAE_ID = B.OLD_PAE_ID 
WHERE WRK_LTSS_CLIENTS.source_system_nm='KatieBeckett'
AND WRK_LTSS_CLIENTS.VALID_SW = 'Y' 
AND WRK_LTSS_CLIENTS.XREF_VALID_SW = 'Y' 
--AND WRK_LTSS_CLIENTS.PERLSS_INDV_ID IS NOT NULL
AND WRK_LTSS_CLIENTS.CV_PHASE = F_GET_CONV_TYPE;


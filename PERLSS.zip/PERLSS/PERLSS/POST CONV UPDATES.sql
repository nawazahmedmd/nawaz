update perlss.ref_app_cntct_dtl  a
set pref_ph_type_cd = case when CELL_PH_NUM is not null then 'CL'
							when CELL_PH_NUM is null and HOME_PH_NUM is not null then 'HM' --else pref_ph_type_cd 
							END , last_modified_by='CV_KB_TN_242205'
where created_by like 'CV_28%' 
and (CELL_PH_NUM is not null and HOME_PH_NUM is not null
or
work_ph_num  is not null and HOME_PH_NUM is not null
or 
CELL_PH_NUM is not null and work_ph_num is not NULL);
--3448

update perlss.com_applcnt  a
set pref_ph_type_cd = b.pref_ph_type_cd,, last_modified_by='CV_KB_TN_242205'
from (select DISTINCT r.prsn_id , c.pref_ph_type_cd  , c.ref_id  from perlss.ref_rqst r
join perlss.ref_app_cntct_dtl c on r.ref_id = c.ref_id  
where C.created_by like 'CV_28%'
and (CELL_PH_NUM is not null and HOME_PH_NUM is not null
or
work_ph_num  is not null and HOME_PH_NUM is not null
or 
CELL_PH_NUM is not null and work_ph_num is not NULL)) b where a.prsn_id = b.prsn_id 
and  created_by like 'CV_28%' ;
--2139



INSERT INTO perlss.slt_details
(id, slt_master_id, ref_id, ref_intake_outcome_cd, pae_id, tns_id, slt_status_cd, update_rsn_cd, update_rsn_desc, created_dt, created_by, last_modified_by, last_modified_dt, record_version, archived_dt, cea_status_cd, slt_held_dt, release_rsn_cd, prsn_id, ref_list_id, correction_sw)
VALUES(nextval('perlss.hibernate_sequence'),
1018, 'RF000006246', NULL, 'PAE100004058', NULL, 'FIL', 'BE', 'Part B Enrollment', '16-MAR-2023 10:50:02', 'CV_KB_TN_242205', NULL, '22-MAR-2023 23:14:22', 0, NULL, NULL, '22-MAR-2023 23:14:22', NULL, 6000076554, NULL, NULL);

INSERT INTO perlss.slt_details
(id, slt_master_id, ref_id, ref_intake_outcome_cd, pae_id, tns_id, slt_status_cd, update_rsn_cd, update_rsn_desc, created_dt, created_by, last_modified_by, last_modified_dt, record_version, archived_dt, cea_status_cd, slt_held_dt, release_rsn_cd, prsn_id, ref_list_id, correction_sw)
VALUES(nextval('perlss.hibernate_sequence'),
1018, 'RF300000753', NULL, 'PAE100000668', NULL, 'FIL', 'BE', 'Part B Enrollment', '04-JAN-2021 10:50:11', 'CV_KB_TN_242205', NULL, '17-FEB-2021 23:26:47', 0, NULL, NULL, '17-FEB-2021 23:26:47', NULL, 6000074949, NULL, NULL);

INSERT INTO perlss.slt_details
(id, slt_master_id, ref_id, ref_intake_outcome_cd, pae_id, tns_id, slt_status_cd, update_rsn_cd, update_rsn_desc, created_dt, created_by, last_modified_by, last_modified_dt, record_version, archived_dt, cea_status_cd, slt_held_dt, release_rsn_cd, prsn_id, ref_list_id, correction_sw)
VALUES(nextval('perlss.hibernate_sequence'),
1018, 'RF400000134', NULL, 'PAE100000583', NULL, 'VAC', 'AE', 'Part A Enrollment', '23-NOV-2020 08:09:39', 'CV_KB_TN_242205', NULL, '22-OCT-2021 20:36:49', 0, NULL, NULL, '04-MAY-2021 00:00:00', NULL, 6000075989, NULL, NULL);
Issue 2
update perlss.doc_module_mapping a
set created_dt = c.create_dt , last_modified_by = 'TN_243271', last_modified_dt =Now()
from (select distinct create_dt , FN_DOCUMENT_ID from  legacy.kb_doc_dtl) c
where coalesce(c.FN_DOCUMENT_ID,'x')= coalesce(a.on_prem_filenet_id,'x')
where a.created_by  ='CV_282';
--38774

--Issue 3
update perlss.doc_module_mapping a
set created_dt = b.pae_rqst_dt , last_modified_by = 'TN_243271', last_modified_dt =Now()
from perlss.pae_rqst b
where a.pae_id = b.pae_id
and a.CREATED_BY ='CNV_PAEPDF_ADHOC'
and a.created_dt::DATE  ='2023-06-17' 
and a.app_pdf_sw ='Y'
;
--4707


--Issue 4
update perlss.pae_loc_sys_calc a
set created_dt = b.create_dt, last_modified_by = 'TN_243273', last_modified_dt =Now()
from legacy.kb_loc_sys_calc b 
where a.pae_id = b.pae_id and a.seq_num =b.seq_num
and a.created_by = b.create_user_id  
and a.created_dt::DATE  ='2023-06-17' 
;
--17373


--issue 6
update perlss.pae_kb_partb_wtng_list a
set created_dt = b.create_dt, last_modified_by = 'TN_243275'
FROM legacy.KB_SLOT_WL_PARTB_RANK b WHERE a.pae_id = b.pae_id 
where a.created_by like 'CV_282%' 
and b.active_sw='Y'
commit
;
--145


update perlss.doc_module_mapping a
set created_dt = b.reassessment_due_dt - INTERVAL '365 DAY' , last_modified_by = 'TN_243271', last_modified_dt =Now()
from perlss.pae_rqst b
where a.pae_id = b.pae_id and b.reassessment_due_dt is not  null and B.created_by ='CV_282'
and a.CREATED_BY ='CNV_PAEPDF_ADHOC'
and a.created_dt::DATE  ='2023-06-17'
and a.app_pdf_sw ='Y';


update perlss.doc_module_mapping a
set created_dt = b.UPDATE_DT , last_modified_by = 'TN_243271', last_modified_dt =Now()
from legacy.test_pae_221 b
where a.pae_id = b.pae_id
and a.CREATED_BY ='CNV_PAEPDF_ADHOC'
and a.created_dt::DATE ='2023-06-17'
and a.app_pdf_sw ='Y'
;

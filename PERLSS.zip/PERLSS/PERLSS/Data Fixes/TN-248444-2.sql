SET TIME ZONE 'US/Central';
DO $$
DECLARE
dfix_no varchar(20) := 'TN-249492';						-- TODO 1: Update this
_table_name text := 'pae_rqst';  					-- TODO 2: Update this
audit_table text := 'aud_fwr_entity';					-- TODO 3: Update table name as required; ADMIN Team, Notices Team special attention.
_schemaname text := 'perlss';
_dynamic_schema text := '';

--Constants
cond_col_values text := ''; 							-- TODO: Update condition as required
_record record;
_sql text;
old_rec text;
integer_var text;
updateQuery text;
notices_table_flag boolean := false;
admin_table_flag boolean := false;
all_table_flag boolean := false;
table_name_flag boolean := false;

-- VERSION 7
read_table_name text := _table_name;					-- TODO 3: If there are multiple table joins please use only main table in read table field.
update_table_names varchar[] := ARRAY[_table_name];		-- TODO 3: update this if update table is different that read table.

--VERSION 7: counter variables
read_counter bigint   := 0;
update_counter bigint[] := ARRAY[0];                    -- TODO 3: If more than one table is updating please add another count variable.  E.g.  ARRAY[0,0,0];

module_name varchar(20) := 'Pae';					-- TODO 4: Module name Appeals/Pae/Adjudication etc.
frequency varchar(20) := 'Recurring';  					-- TODO 4: Recurring/One-Time/On-Demand
description varchar (500) := 'Update statuscd, closure rsn cd in pae rqst table';				-- TODO 4: Descriotion of the datafix

update_counter_all_zero_flag BOOLEAN := TRUE;
non_zero_count bigint := 0;
expected_num_rows_updated bigint :=39;					--VERSION 7.4
multiple_records_updated boolean := false;				--VERSION 7.4


-- audit table columns
audit_user_id text := dfix_no; 
audit_prsn_id bigint := 1 ; 
audit_cor_id bigint := 1 ; 
rec_count  bigint := 0 ; 
audit_pae_id text := '';
audit_txn_id bigint := 0;
audit_ref_id text := '';
audit_apl_id text := '';
audit_page_id text := '';
audit_commit_version bigint := 0;
audit_entity_id bigint := 0;
audit_entity_type text := 'com.ltss.common.pae.model.PaeRqst';  -- TODO 5: Update as per requirement 
audit_workflow_id bigint := 0;

-- audit table variables
all_col_names text;
audit_col_names text;
query text;
t_recheck text;

--custom update columns												-- TODO: Modify/Remove these
new_closure_rsn_desc text := 'Closed as part of TN-248444 due to KB Denial in TEDS';
new_closure_rsn_cd text := 'FI';
new_status_cd='CL'


BEGIN

    --TODO 6: Write select query
FOR _record IN 
select * from (
select *, case when entity_value->>'statusCd' = 'PS' then 'PS'
when entity_value->>'statusCd' = 'AA' then 'AA'
when entity_value->>'statusCd' = 'AP' then  'AP'
when entity_value->>'statusCd' = 'DN' then 'DN' end old_status_cd  from
(select a.*,RANK () OVER (PARTITION BY pae_id ORDER BY created_dt DESC) rnk  from perlss.aud_fwr_entity a
where entity_type like 'com.ltss.common.pae.model.PaeRqst'
--and pae_id = 'PAE200075982'
and entity_value->>'statusCd' in ('AA','AP','DN', 'PS'))a where rnk=1
and pae_id in 
(select pr.pae_id from perlss.pae_rqst pr 
inner join perlss.ref_rqst rr on pr.ref_id = rr.ref_id
where pr.status_cd = 'WI'
and pr.program_cd = 'KB'
and pr.id  in (select entity_id from perlss.aud_fwr_entity where entity_type like 'com.ltss.common.pae.model.PaeRqst' 
        and entity_value->>'statusCd' = 'WI' and created_by like 'ADM-S%' order by created_dt desc)))a 
        where old_status_cd ='PS'

loop
	read_counter := read_counter +1;
	raise info '------------Iterating No. % record-------------', rec_count+1;

	raise info '      [ Data Fix % ]     ',dfix_no;
	cond_col_values := 'pae_id= '''|| _record.pae_id || '''';

    --TODO 6: Write Update query
	updateQuery := 'UPDATE ' || _schemaname ||'.'|| _table_name || 
    ' SET ' 
	|| 'record_version ='''|| _record.record_version+1 || ''' , '				-- TODO: MAKE SURE THIS IS INCLUDED.
	|| 'closure_rsn_desc ='''|| new_closure_rsn_desc || ''' , '
	|| 'status_cd ='''|| new_status_cd || ''' , '
	|| 'closure_rsn_cd ='''|| new_closure_rsn_cd || ''' , '
	|| ' last_modified_by =''' || dfix_no 
	|| ''', last_modified_dt =''' || current_timestamp || ''''
    || ' where '|| cond_col_values;

	--****VERSION 5 UPDATE START ---- DO NOT MODIFY BELOW THIS ****---------
	if(updateQuery is not null
	and position('where' in updateQuery)>0) then
		 	execute updateQuery;
	else 
            
			raise exception ' Critical: No where clause found in update query!';
	end if;
	--VERSION 7.4{
	GET DIAGNOSTICS integer_var = ROW_COUNT;
	if(integer_var::INT>1) then 
	multiple_records_updated := true;
	RAISE EXCEPTION 'Attempt to update multiple records in a loop. Please update one record at a time.';
	END IF;
	--VERSION 7.4}
	update_counter[1] := update_counter[1] +integer_var::bigint;      -- TODO 7: update counter index based on number of table currently in use.
	--**** VERSION 5 UPDATE END ---- DO NOT MODIFY ABOVE THIS ****---------
	
	GET DIAGNOSTICS integer_var = ROW_COUNT;
    RAISE INFO '> % ', integer_var || ' records updated in table ' || _table_name ||' where  id ='|| _record.id; --TODO: add your specific IDs as needed

	-- Update audit table values
	audit_ref_id := _record.ref_id;					-- TODO: Update as per requirement
	audit_user_id := dfix_no; 							-- TODO: Update as per requirement
   	audit_prsn_id := _record.prsn_id ; 					-- TODO: Update as per requirement
    --audit_ref__id := _record.ref_id ; 					-- TODO: Update as per requirement
	--audit_pae_id := '';					     		-- TODO: Update as per requirement
	--audit_txn_id := 0;								-- TODO: Update as per requirement
	--audit_apl_id := '';								-- TODO: Update as per requirement
	audit_entity_id := _record.id;
	audit_entity_type := 'com.ltss.common.pae.model.PaeRqst';

	audit_commit_version := _record.record_version+2;
	
	--raise info 'audit_ref_id %',audit_ref_id;
		----------***** Audit starts ------------- DO NOT UPDATE BELOW THIS ******-----------------------
	select dt.columns_test from (
	select array_to_string(array_agg(column_name),',') as columns_test ,table_schema||'.'||TABLE_NAME as table_name from 
	INFORMATION_SCHEMA.COLUMNS  where TABLE_NAME = _table_name  GROUP BY 2)dt into all_col_names ;
	
	raise notice 'Columns to be audited: [%]', all_col_names;

	query :=   format('SELECT json_agg(row_to_json( (SELECT ColumnName FROM (SELECT %1$s ) AS ColumnName ( %1$s))))  from  %4$s.%2$s  
						where %3$s',all_col_names,_table_name,  cond_col_values,_schemaname
				);

	execute query into old_rec;
		if old_rec is not NULL then
		old_rec := subString(old_rec, 2, LENGTH(old_rec)-2);  -- VERSION 4 UPDATE
	end if ;

	if dfix_no is not NULL then
			dfix_no := dfix_no;
	else
		dfix_no := current_user;
	end if ;
	
	--***** VERSION 5 UPDATE START ---- DO NOT MODIFY BELOW THIS *****---------
	if (length(audit_entity_type) = 0) then raise exception ' Audit: audit_entity_type is missing. Please review.';
	end if;		
	if (audit_entity_id <= 1 or audit_entity_id is null) then raise exception ' Audit: entity_id is missing. Please review.';
	end if;		
	if (audit_commit_version is null or audit_commit_version = 0 or audit_commit_version<>_record.record_version+2) then raise exception ' Audit: audit_commit_version is not set correctly. Please review.';
	end if;		
	if(audit_prsn_id = 0	or audit_prsn_id = 1) then raise warning ' 		WARNING: "Audit: Person_id is not set"		';
	end if;		
	
	if(_table_name is not null and length(_table_name)<> 0 and length(_table_name)>3)  then
		table_name_flag = true;
	else 
		raise exception 'Table name is missing!';
	end if;
	if (table_name_flag = true and lower(subString(_table_name, 1, 3)) = 'cor') then
		notices_table_flag = true;
	end if;

	if (table_name_flag = true and (LOWER(subString(_table_name, 1, 3)) = 'sec'
	or LOWER(subString(_table_name, 1, 3)) = 'tmg'
	or (LOWER(_table_name)= 'com_assessor'
	or LOWER(_table_name)= 'com_master_clone_rqst'
	or LOWER(_table_name)= 'com_module_clone_rqst'
	or LOWER(_table_name)= 'com_pae_clone_rqst'
	or LOWER(_table_name)= 'com_prsn_reconciliation'
	or LOWER(_table_name)= 'cnv_task'))) then
		admin_table_flag = true;
	end if;

	if (table_name_flag = true and notices_table_flag= false and admin_table_flag= false) then
		all_table_flag = true;
	end if;
						
	if ( notices_table_flag = true and audit_table <> 'aud_cor_entity') then					
					raise exception 'Incorrect Audit Table entry for Notices table. Please update it to aud_cor_entity.';
	end if;
	
	if ( admin_table_flag = true 	and audit_table <> 'aud_adm_entity') then 
		raise exception 'Incorrect Audit Table entry for Admin table. Please update it to aud_adm_entity.';
	end if;

	if ( all_table_flag = true	and audit_table <> 'aud_fwr_entity') then 
					raise exception 'Incorrect Audit Table Entry or its missing.';
	end if;
	--****** VERSION 5 UPDATE END---- DO NOT MODIFY ABOVE THIS*****---------

	if old_rec is not NULL then
		IF (notices_table_flag = true OR admin_table_flag = true) THEN
			_sql = format('insert into %s.%s values ( nextval(''perlss.hibernate_sequence''),''UPDATE'',%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s, now())',_schemaname,audit_table,
					quote_literal(audit_user_id),audit_prsn_id,quote_literal(audit_pae_id),
					audit_txn_id,quote_literal(audit_ref_id),quote_literal(audit_apl_id),
					quote_literal(audit_page_id),audit_commit_version,quote_literal(audit_entity_id),
					quote_literal(audit_entity_type),quote_literal(old_rec),quote_literal(dfix_no) );
		END IF;
		IF (notices_table_flag <> true AND admin_table_flag <> true AND all_table_flag = true) then
		_sql = format('insert into %s.%s values ( nextval(''perlss.hibernate_sequence''),''UPDATE'',%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s, now(),%s)',_schemaname,audit_table,
				quote_literal(audit_user_id),audit_prsn_id,quote_literal(audit_pae_id),
				audit_txn_id,quote_literal(audit_ref_id),quote_literal(audit_apl_id),
				quote_literal(audit_page_id),audit_commit_version,quote_literal(audit_entity_id),
				quote_literal(audit_entity_type),quote_literal(old_rec),quote_literal(dfix_no),audit_workflow_id );
	 	END IF; 
		execute _sql;
		raise info 'Posting matching records to % ', audit_table;
	else
		raise notice 'No Matching records found';
	end if;
		----------***** Audit ends-------------DO NOT UPDATE ABOVE THIS *****-----------------------
			
--RAISE NOTICE '%', _record.ref_id;  --- OPTIONAL

GET DIAGNOSTICS integer_var = ROW_COUNT;

RAISE INFO '> % ', integer_var || ' records updated in audit table where '|| cond_col_values;
raise info '      [ Data Fix % ]     ',dfix_no; 						-- VERSION 5

rec_count := rec_count +1;

END loop ;

raise info '============ REPORT =============';

RAISE INFO '% ', ' Total records affected = '|| rec_count;
RAISE INFO 'Multiple records updated in the script = %', CASE WHEN multiple_records_updated THEN 'Yes' ELSE 'No' END; --V 7.2


--****** VERSION 1.7 UPDATE START ---- DO NOT MODIFY BELOW THIS*****---------
	if (length(read_table_name) = 0 or count(update_table_names[1]) = 0) then raise exception ' Read/Update Table Names are missing!';
	end if;
	if(read_counter=0) then raise WARNING ' WARNING: Read counter is zero!';
	end if;
	--VERSION 7.4{
	if(expected_num_rows_updated =0) then 
		raise exception 'Excepted number of records to be affected is not initialized. Please update varialbe expected_num_rows_updated.';
	end if;
	IF ( read_counter::int > (1.15 * expected_num_rows_updated::int)) THEN
	 	raise exception 'Number of rows updated outside range of expected value. 
						Actual number of rows updated: % 
					    Expected number of rows updated: %', read_counter , expected_num_rows_updated;
	ELSE
	 	raise notice 'Success: Number of rows updated within range of expected value.';
	END IF;
	--VERSION 7.4}
	IF(read_counter>0) THEN 
        FOR i IN 1..array_length(update_counter,1) loop
	       IF(update_counter[i]!= 0 and update_counter_all_zero_flag) THEN update_counter_all_zero_flag = FALSE ;
            END IF;
            if(update_counter[i]!=0) then non_zero_count := non_zero_count +1;
            end if;           
        END LOOP;
        if(update_counter_all_zero_flag) then  raise exception 'Update counter is not set';
        end if;
        IF (array_length(update_table_names,1) <> non_zero_count) THEN
            RAISE exception 'Update table count is not matching with total number of update counters. Please check of update_table_names and update_counter variables are correctly defined.';
        END IF;
        FOR i IN 1..array_length(update_counter,1) LOOP
            IF(update_counter[i]= 0) THEN RAISE WARNING '!!! "WARNING: Update table count is missing for table %" !!!', i ;
            END IF;
        END LOOP;
    END IF;

--Common
if (length(module_name) = 0) then raise exception 'Module name is missing!';
end if;
if (length(frequency) = 0) then raise exception 'Frequency value is missing!';
end if;
if (length(description) = 0) then raise exception 'Description value is missing!';
end if;

insert into bamboo_deployment_schema.dfix_summary (
	jira_ticket, action, table_name, num_records, functional_area, type_of_datafix, datafix_description)
values (dfix_no, 'Read', read_table_name, read_counter, module_name, frequency, description); 

FOR i IN 1.. array_upper(update_table_names,1) LOOP
	insert into bamboo_deployment_schema.dfix_summary (
		jira_ticket, action, table_name, num_records, functional_area, type_of_datafix, datafix_description)
	values (dfix_no, 'Update', update_table_names[i], update_counter[i], module_name, frequency, description);
END LOOP;
--****** VERSION 1.7 UPDATE END ---- DO NOT MODIFY ABOVE THIS*****---------


commit;
END$$;

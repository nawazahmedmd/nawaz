SELECT
'pae_driver_flow' as table_name
,'KB'	program_cd
,NULL AS	next_page
,NULL AS	curr_page
,C.NEW_PAE_ID	pae_id
,LTRIM(RTRIM(B.CREATE_USER_ID))	created_by
,B.CREATE_DT	created_dt
,B.UPDATE_DT	last_modified_dt
,0	record_version
--select *
FROM LT_CNV_SRC_KB.KB_DRVR A
JOIN LT_CNV_SRC_KB.KB_PAE_RQST B ON A.PAE_ID = B.PAE_ID
JOIN LT_CNV_WRK.PAE_CROSSWALK C ON A.PAE_ID = C.OLD_PAE_ID;

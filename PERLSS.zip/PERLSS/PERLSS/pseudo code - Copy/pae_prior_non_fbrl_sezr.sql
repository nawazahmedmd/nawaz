SELECT
  'pae_prior_non_fbrl_sezr' as table_name
,B.NEW_PAE_ID	PAE_ID
,LTRIM(RTRIM(A.SHORT_SEIZURES_CD))	frqcy_short_non_feb_sezr_cd
,LTRIM(RTRIM(A.PRO_SEIZURES_CD))	frqcy_prolng_non_feb_sezr_cd
,F_GET_CONV_DATE	created_dt
,NULL	last_modified_by
,NULL	last_modified_dt
,0	record_version
,F_GET_ARCHIVE_DATE	archived_dt
,F_GET_CONV_USER	created_by
--SELECT *
FROM LT_CNV_SRC_KB.KB_PD_SEIZURES A
JOIN LT_CNV_WRK.PAE_CROSSWALK B ON A.PAE_ID=B.OLD_PAE_ID;
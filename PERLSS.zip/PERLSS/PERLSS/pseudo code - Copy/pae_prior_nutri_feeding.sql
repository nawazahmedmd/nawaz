SELECT
 'pae_prior_nutri_feeding' AS table_name
,B.NEW_PAE_ID	pae_id
,LTRIM(RTRIM(A.DIET_SW))	spclty_prescbd_diet_sw
,LTRIM(RTRIM(A.PRADER_WILLI_SW))	applcnt_prader_willi_sw
,LTRIM(RTRIM(A.CHOKING_SW))	applcnt_choking_aspi_sw
,LTRIM(RTRIM(A.FEED_SW))	hands_on_feedng_assist_cd
,LTRIM(RTRIM(A.FEED_FREQ_CD))	hands_on_feedng_duration_cd
,A.CREATE_DT	created_dt
,LTRIM(RTRIM(A.UPDATE_USER_ID))	last_modified_by
,A.UPDATE_DT	last_modified_dt
,0	record_version
,F_GET_ARCHIVE_DATE	archived_dt
,LTRIM(RTRIM(A.CREATE_USER_ID))	created_by
-- SELECT COUNT(1)
FROM LT_CNV_SRC_KB.KB_PD_NUT_FEEDING A
JOIN LT_CNV_WRK.PAE_CROSSWALK B ON A.PAE_ID = B.OLD_PAE_ID;
SELECT
'pae_beh_sup_srvc_sys' AS TABLE_NAME
,B.NEW_PAE_ID	pae_id
,LTRIM(RTRIM(A.CMHS_SW))	crisis_men_hlth_srvc_sw
,LTRIM(RTRIM(A.CPS_SW))	child_protective_srvc_sw
,LTRIM(RTRIM(A.CJS_SW))	criminal_justice_sys_sw
,A.CREATED_DT	created_dt
,LTRIM(RTRIM(A.UPDATED_BY))	last_modified_by
,A.UPDATED_DT	last_modified_dt
,0	record_version
,F_GET_ARCHIVE_DATE	archived_dt
,LTRIM(RTRIM(A.CREATED_BY))	created_by
-- SELECT *
FROM LT_CNV_SRC_KB.KB_BHS_SERVICE_SYSTEMS A
JOIN LT_CNV_WRK.PAE_CROSSWALK B ON A.PAE_ID = B.OLD_PAE_ID;
SELECT 
'pae_loc_determn_dcsn' as table_name,
AA.* FROM (SELECT B.NEW_PAE_ID,
'KBB' AS LOC_DETERMN_PART_CD, 
'DPS' AS USER_ROLE_CD, NULL AS PAE_STATUS_CD,
LTRIM(RTRIM(INIT_PAE_STATUS_CD)) AS PAE_DCSN_CD,
NULL AS PRTZN_SCORE_NUM,
LTRIM(RTRIM(INIT_LOC_CD)) AS LOC_DCSN_CD,
LTRIM(RTRIM(REQ_PARTA_EVAL_SW)) AS USER_EVAL_SW,
A.DET_DT AS DET_DT,
NULL AS PAE_COMPLETE_DT,
NULL AS PARTA_DENIAL_RSN_CD 
, NULL AS 	avg_cost_of_care_indv_num
, NULL AS 	avg_cost_loc_num
, NULL AS 	elig_dcsn_cd
, NULL AS 	elig_dcsn_confirm_sw
, NULL AS 	comments
, NULL AS 	user_id
, NULL AS 	entity_id
, NULL AS 	sys_loc_determn_cd
, NULL AS 	indv_trig_for_parta_sw
, 'N' as continued_elig_sw
, 'N' AS 	premium_payment_sw
, NULL AS 	cost_of_care_status_cd
,A.CREATE_DT	created_dt
,ltrim(rtrim(A.UPDATE_USER_ID))	LAST_MODIFIED_BY
,A.UPDATE_DT	last_modified_dt
,0	record_version
,F_GET_ARCHIVE_DATE	archived_dt
,LTRIM(RTRIM(A.CREATE_USER_ID))	CREATED_BY
FROM LT_CNV_SRC_KB.KB_LOC_PARTB_DET A
JOIN LT_CNV_WRK.PAE_CROSSWALK B ON A.PAE_ID=B.OLD_PAE_ID
UNION
SELECT A.PAE_ID,
'KBB' AS LOC_DETERMN_PART_CD,
'DS' AS USER_ROLE_CD, NULL AS PAE_STATUS_CD,
LTRIM(RTRIM(FINAL_PAE_STATUS_CD)) AS PAE_DCSN_CD,
NULL AS PRTZN_SCORE_NUM, 
LTRIM(RTRIM(FINAL_LOC_CD)) AS LOC_DCSN_CD,
LTRIM(RTRIM(REQ_PARTA_EVAL_SW)) AS USER_EVAL_SW,
A.DET_DT AS DET_DT,
NULL AS PAE_COMPLETE_DT,
NULL AS PARTA_DENIAL_RSN_CD 
, NULL AS 	avg_cost_of_care_indv_num
, NULL AS 	avg_cost_loc_num
, NULL AS 	elig_dcsn_cd
, NULL AS 	elig_dcsn_confirm_sw
, NULL AS 	comments
, NULL AS 	user_id
, NULL AS 	entity_id
, NULL AS 	sys_loc_determn_cd
, NULL AS 	indv_trig_for_parta_sw
, 'N' as continued_elig_sw
, 'N' AS 	premium_payment_sw
, NULL AS 	cost_of_care_status_cd
,A.CREATE_DT	created_dt
,ltrim(rtrim(A.UPDATE_USER_ID))	LAST_MODIFIED_BY
,A.UPDATE_DT	last_modified_dt
,0	record_version
,F_GET_ARCHIVE_DATE	archived_dt
,LTRIM(RTRIM(A.CREATE_USER_ID))	CREATED_BY
FROM LT_CNV_SRC_KB.KB_LOC_PARTB_DET A
JOIN LT_CNV_WRK.PAE_CROSSWALK B ON A.PAE_ID=B.OLD_PAE_ID
UNION
SELECT A.PAE_ID,
'KBA' AS LOC_DETERMN_PART_CD,
'ASA' AS USER_ROLE_CD, NULL AS PAE_STATUS_CD,
LTRIM(RTRIM(INIT_PAE_STATUS_CD)) AS PAE_DCSN_CD,
LTRIM(RTRIM(PRIOR_SCORE_NUM)) as PRTZN_SCORE_NUM, 
LTRIM(RTRIM(INIT_LOC_CD)) AS LOC_DCSN_CD,
NULL AS USER_EVAL_SW,
A.DET_DT AS DET_DT,
NULL AS PAE_COMPLETE_DT,
LTRIM(RTRIM(INIT_DENIAL_RSN_CD)) AS PARTA_DENIAL_RSN_CD 
, NULL AS 	avg_cost_of_care_indv_num
, NULL AS 	avg_cost_loc_num
, NULL AS 	elig_dcsn_cd
, NULL AS 	elig_dcsn_confirm_sw
, NULL AS 	comments
, NULL AS 	user_id
, NULL AS 	entity_id
, NULL AS 	sys_loc_determn_cd
, NULL AS 	indv_trig_for_parta_sw
, 'N' as continued_elig_sw
, 'N' AS 	premium_payment_sw
, NULL AS 	cost_of_care_status_cd
,A.CREATE_DT	created_dt
,ltrim(rtrim(A.UPDATE_USER_ID))	LAST_MODIFIED_BY
,A.UPDATE_DT	last_modified_dt
,0	record_version
,F_GET_ARCHIVE_DATE	archived_dt
,LTRIM(RTRIM(A.CREATE_USER_ID))	CREATED_BY
FROM LT_CNV_SRC_KB.KB_LOC_PARTA_DET A
JOIN LT_CNV_WRK.PAE_CROSSWALK B ON A.PAE_ID=B.OLD_PAE_ID
UNION
SELECT B.NEW_PAE_ID,
'KBA' AS LOC_DETERMN_PART_CD, 
'AP' AS USER_ROLE_CD, NULL AS PAE_STATUS_CD,
LTRIM(RTRIM(PHYS_PAE_STATUS_CD)) AS PAE_DCSN_CD,
LTRIM(RTRIM(PRIOR_SCORE_NUM)) as PRTZN_SCORE_NUM, 
LTRIM(RTRIM(PHYS_LOC_CD)) AS LOC_DCSN_CD,
NULL AS USER_EVAL_SW,
A.DET_DT AS DET_DT,
NULL AS PAE_COMPLETE_DT,
LTRIM(RTRIM(PHYS_DENIAL_RSN_CD)) AS PARTA_DENIAL_RSN_CD
, NULL AS 	avg_cost_of_care_indv_num
, NULL AS 	avg_cost_loc_num
, NULL AS 	elig_dcsn_cd
, NULL AS 	elig_dcsn_confirm_sw
, NULL AS 	comments
, NULL AS 	user_id
, NULL AS 	entity_id
, NULL AS 	sys_loc_determn_cd
, NULL AS 	indv_trig_for_parta_sw
, 'N' as continued_elig_sw
, 'N' AS 	premium_payment_sw
, NULL AS 	cost_of_care_status_cd
,A.CREATE_DT	created_dt
,ltrim(rtrim(A.UPDATE_USER_ID))	LAST_MODIFIED_BY
,A.UPDATE_DT	last_modified_dt
,0	record_version
,F_GET_ARCHIVE_DATE	archived_dt
,LTRIM(RTRIM(A.CREATE_USER_ID))	CREATED_BY 
FROM LT_CNV_SRC_KB.KB_LOC_PARTA_DET A
JOIN LT_CNV_WRK.PAE_CROSSWALK B ON A.PAE_ID=B.OLD_PAE_ID
UNION
SELECT A.PAE_ID,
'KBA' AS LOC_DETERMN_PART_CD,
'LN' AS USER_ROLE_CD, NULL AS PAE_STATUS_CD,
LTRIM(RTRIM(LTSS_PAE_STATUS_CD)) AS PAE_DCSN_CD,
LTRIM(RTRIM(PRIOR_SCORE_NUM)) as PRTZN_SCORE_NUM,
LTRIM(RTRIM(LTSS_LOC_CD)) AS LOC_DCSN_CD,
NULL AS USER_EVAL_SW,
A.DET_DT AS DET_DT,
PAE_COMPLETE_DT,
LTRIM(RTRIM(LTSS_DENIAL_RSN_CD)) AS PARTA_DENIAL_RSN_CD 
, NULL AS 	avg_cost_of_care_indv_num
, NULL AS 	avg_cost_loc_num
, NULL AS 	elig_dcsn_cd
, NULL AS 	elig_dcsn_confirm_sw
, NULL AS 	comments
, NULL AS 	user_id
, NULL AS 	entity_id
, NULL AS 	sys_loc_determn_cd
, NULL AS 	indv_trig_for_parta_sw
, 'N' as continued_elig_sw
, 'N' AS 	premium_payment_sw
, NULL AS 	cost_of_care_status_cd
,A.CREATE_DT	created_dt
,ltrim(rtrim(A.UPDATE_USER_ID))	LAST_MODIFIED_BY
,A.UPDATE_DT	last_modified_dt
,0	record_version
,F_GET_ARCHIVE_DATE	archived_dt
,LTRIM(RTRIM(A.CREATE_USER_ID))	CREATED_BY
FROM LT_CNV_SRC_KB.KB_LOC_PARTA_DET A
JOIN LT_CNV_WRK.PAE_CROSSWALK B ON A.PAE_ID=B.OLD_PAE_ID) AA;
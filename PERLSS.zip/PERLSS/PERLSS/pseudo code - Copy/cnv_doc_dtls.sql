select 'cnv_doc_dtls' as table_name
,1234 as prsn_id --REVISIT
,null as first_name
,null as last_name
, rf.NEW_REF_ID
, cr.NEW_PAE_ID
,null as apl_id
,null as tns_id
,null folder_name
,null as file_name
,null as notice_type
,null as last_modified_by
,null as last_modified_dt
,0 as record_version
,F_GET_CONV_USER as created_by
,SYSDATE as created_dt
,F_GET_ARCHIVE_DATE as archived_dt
,'N' as processed_flag
, LTRIM(RTRIM(A.DOC_TYPE_CD)) AS DOC_TYPE_CD
,null as notice_type_cd
,NULL source_sys_nm
,LTRIM(RTRIM(A.FN_DOCUMENT_ID)) AS kb_fn_id
from LT_CNV_SRC_KB.kb_doc_dtl A
join lt_cnv_wrk.pae_crosswalk cr on cr.old_pae_id = A.pae_id
join lt_cnv_wrk.referral_crosswalk rf on rf.old_ref_id = A.ref_id
LEFT JOIN LT_CNV_SRC_KB.kb_documents B ON A.DOC_SEQ_NUM = B.DOC_SEQ_NUM
where delete_sw IS NULL
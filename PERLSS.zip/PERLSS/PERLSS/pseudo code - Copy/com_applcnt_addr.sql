SELECT 
 'com_applcnt_addr' AS table_name
,1234	prsn_id--NEED TO REVISIT
,LTRIM(RTRIM(A.ADDRESS_FORMAT_CD))	addr_format_cd
,LTRIM(RTRIM(A.L1_ADDR))	addr_line_1
,LTRIM(RTRIM(A.L1_ADDR))	addr_line_2
,LTRIM(RTRIM(A.CITY))	city
,LTRIM(RTRIM(A.STATE_CD))	state_cd
,LTRIM(RTRIM(A.ZIPCODE))	zip
,LTRIM(RTRIM(A.ZIP_EXTN))	zip_extsn
,LTRIM(RTRIM(A.CNTY_CD))	cnty_cd
,LTRIM(RTRIM(A.APO_FPO_CD))	military_po_cd
,LTRIM(RTRIM(A.AA_AE_AP_CD))	military_state_cd
,LTRIM(RTRIM(A.ADDR_TYPE_CD))	addr_type_cd
,NULL AS	validated_addr_cd
,case when LTRIM(RTRIM(A.SAME_MAIL_ADDR_SW)) is null then 'N' ELSE LTRIM(RTRIM(A.SAME_MAIL_ADDR_SW)) END mail_addr_sw
,LTRIM(RTRIM(A.CREATE_USER_ID))	created_by
,LTRIM(RTRIM(A.CREATE_DT))	created_dt
,LTRIM(RTRIM(A.UPDATE_USER_ID))	last_modified_by
,LTRIM(RTRIM(A.UPDATE_DT))	last_modified_dt
,0 AS	record_version
,F_GET_ARCHIVE_DATE AS	archived_dt
--SELECT COUNT(1)
FROM LT_CNV_SRC_KB.KB_RI_ADDRESSES A;
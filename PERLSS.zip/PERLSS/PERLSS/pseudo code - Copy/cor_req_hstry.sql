SELECT 
'cor_req_hstry' as table_name
,B.NEW_COR_ID cor_id
,A.ORIG_PRINT_DT AS original_print_dt
,LTRIM(RTRIM(E.NEW_PAE_ID)) pae_id
,LTRIM(RTRIM(A.INDV_ID)) prsn_id
,NULL apl_id
,LTRIM(RTRIM(A.DOC_ID)) doc_id
,LTRIM(RTRIM(A.PAGE_NUM)) page_num
,LTRIM(RTRIM(A.GO_GREEN)) go_green
,LTRIM(RTRIM(A.LANGUAGE_CD)) lang_cd
,LTRIM(RTRIM(A.GENERATE_DT)) generate_dt
,LTRIM(RTRIM(A.MISC_PARMS)) misc_params
,LTRIM(RTRIM(A.HISTORY_SW)) hstry_sw
,LTRIM(RTRIM(A.PENDING_TRIG_SW)) pending_trig_sw
,'KB' as rqst_type_cd
,LTRIM(RTRIM(A.HST_PRINT_STRING)) hstry_print_string
,'N' manually_generated_sw
,null manual_notice_txt
,LTRIM(RTRIM(C.NEW_LOG_ID)) log_id
,LTRIM(RTRIM(D.NEW_REF_ID)) ref_id
,LTRIM(RTRIM(A.LOCATION_ID)) lctn_id
,LTRIM(RTRIM(A.SENT_DT)) sent_dt
,LTRIM(RTRIM(A.MAIL_PIECE_ID)) mail_piece_id
,LTRIM(RTRIM(A.PULL_DT)) pull_dt
,LTRIM(RTRIM(A.PULL_TEXT)) pull_txt
,NULL cor_type_cd
,NULL cor_generated_cd
,LTRIM(RTRIM(A.REPRINT_SW)) reprint_sw
,LTRIM(RTRIM(A.EN_DIS_ID)) en_file_net_id
,LTRIM(RTRIM(A.DIS_ID)) file_net_id
,LTRIM(RTRIM(A.TRACKING_NUM)) tracking_num
,LTRIM(RTRIM(A.PRINT_MODE)) print_type_cd
,LTRIM(RTRIM(A.RECIPIENT_TYPE)) cor_recipient_type_cd
,LTRIM(RTRIM(A.RECIPIENT_DATA)) cor_recipient_data
,LTRIM(RTRIM(A.CO_STATUS_SW)) cor_status_sw
,A.UPDATE_USER_ID last_modified_by
,A.UPDATE_DT last_modified_dt
,0 AS record_version
,A.CREATE_USER_ID created_by
,A.CREATE_DT created_dt
,F_GET_ARCHIVE_DATE archived_dt
,NULL notice_lang_options
,NULL return_notice_file_net_id
,NULL return_mail_dt
,LTRIM(RTRIM(A.SPECIAL_NOTES)) user_note
,'KB' enr_grp_cd
,NULL enr_start_dt
,NULL cv_sw											
FROM LT_CNV_SRC_KB.KB_CO_REQUEST_HISTORY A
JOIN LT_CNV_WRK.COR_CROSSWALK B ON A.CO_REQ_SEQ = B.OLD_COR_ID
JOIN LT_CNV_WRK.LOG_CROSSWALK C ON A.LOG_ID = C.OLD_LOG_ID
JOIN LT_CNV_WRK.REFERRAL_CROSSWALK D ON A.REF_ID = D.OLD_REF_ID
JOIN LT_CNV_WRK.PAE_CROSSWALK E ON A.PAE_ID = E.OLD_PAE_ID;
SELECT 
'com_comments' as table_name
,B.NEW_PAE_ID	PAE_ID
,C.NEW_REF_ID	REF_ID
,NULL AS	apl_id
,NULL AS	tns_id
,NULL AS	chm_id
,NULL AS	type_cd
,LTRIM(RTRIM(A.NOTES_TXT))	comments
,NULL AS	entity_id
,A.PAGE_ID	page_id
,NULL AS	prsn_id
,A.CREATE_USER_ID	created_by
,A.CREATE_DT	created_dt
,NULL AS	last_modified_by
,NULL AS	last_modified_dt
,0 AS	record_version
,F_GET_ARCHIVE_DATE AS	archived_dt
--SELECT COUNT(1)
FROM 
LT_CNV_SRC_KB.KB_NOTES A
JOIN LT_CNV_WRK.PAE_CROSSWALK B ON B.OLD_PAE_ID = A.PAE_ID
JOIN LT_CNV_WRK.REFERRAL_cROSSWALK C ON C.OLD_REF_ID= A.REF_ID
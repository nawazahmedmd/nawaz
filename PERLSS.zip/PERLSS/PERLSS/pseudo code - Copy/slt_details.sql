SELECT 
 'slt_details' AS table_name
,CASE WHEN A.TYPE_CD= 'PB' THEN 1018
      WHEN A.TYPE_CD= 'PA' THEN 1017 END slt_master_id
,C.NEW_REF_ID	ref_id
,NULL AS	ref_intake_outcome_cd
,D.NEW_PAE_ID	pae_id
,NULL AS	tns_id
,LTRIM(RTRIM(A.STATUS_CD))	slt_status_cd
,LTRIM(RTRIM(A.UPDATE_RS_CD))	update_rsn_cd
,LTRIM(RTRIM(B.update_rsn))	update_rsn_desc
,LTRIM(RTRIM(A.CREATE_DT))	created_dt
,LTRIM(RTRIM(A.CREATE_USER_ID))	created_by
,LTRIM(RTRIM(A.UPDATE_USER_ID))	last_modified_by
,LTRIM(RTRIM(A.UPDATE_DT))	last_modified_dt
,0 AS	record_version
,F_GET_ARCHIVE_DATE AS	archived_dt
,NULL AS	cea_status_cd
,A.STATUS_DT	slt_held_dt
,NULL AS	release_rsn_cd
,1234 AS	prsn_id -- NEED TO REVIST
,NULL AS	ref_list_id
,NULL AS	correction_sw
--SELECT COUNT(1)
FROM LT_CNV_SRC_KB.kb_slot_dtl A
JOIN LT_CNV_SRC_KB.kb_slot_status_manual B ON A.TYPE_CD=B.TYPE_CD AND A.REF_ID=B.REF_ID
JOIN LT_CNV_WRK.REFERRAL_CROSSWALK C ON A.REF_ID = C.OLD_REF_ID
JOIN LT_CNV_WRK.PAE_CROSSWALK D ON D.OLD_PAE_ID = A.PAE_ID;

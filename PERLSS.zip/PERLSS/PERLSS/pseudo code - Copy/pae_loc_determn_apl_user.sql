SELECT 
'pae_loc_determn_apl_user' as table_name
, AA.* FROM 
 (SELECT 
 B.NEW_PAE_ID	pae_id
,'KBB'	loc_determn_part_cd
,'AUB'	user_role_cd
,LTRIM(RTRIM(A.OVERRIDE_PAE_STATUS_CD))	pae_status_post_apl_cd
,LTRIM(RTRIM(A.OVERRIDE_LOC_CD))	loc_determn_post_apl_cd
,A.OVERRIDE_DET_DT	loc_determn_post_apl_dt
,A.CREATE_DT	created_dt
,LTRIM(RTRIM(A.UPDATE_USER_ID))	last_modified_by
,A.UPDATE_DT	last_modified_dt
,0	record_version
,F_GET_ARCHIVE_DATE	archived_dt
,LTRIM(RTRIM(A.CREATE_USER_ID))	created_by
FROM LT_CNV_SRC_KB.KB_LOC_PARTB_DET A
JOIN LT_CNV_WRK.PAE_CROSSWALK B ON A.PAE_ID = B.OLD_PAE_ID
WHERE A.OVERRIDE_PAE_STATUS_CD IS NOT NULL AND A.OVERRIDE_PAE_STATUS_CD <>'SE'
UNION
SELECT
 B.NEW_PAE_ID	pae_id
,'KBA'	loc_determn_part_cd
,'AUA' user_role_cd
,LTRIM(RTRIM(A.OVERRIDE_PAE_STATUS_CD))	pae_status_post_apl_cd
,LTRIM(RTRIM(A.OVERRIDE_LOC_CD))	loc_determn_post_apl_cd
,A.OVERRIDE_DET_DT	loc_determn_post_apl_dt
,A.CREATE_DT	created_dt
,LTRIM(RTRIM(A.UPDATE_USER_ID))	last_modified_by
,A.UPDATE_DT	last_modified_dt
,0	record_version
,F_GET_ARCHIVE_DATE	archived_dt
,LTRIM(RTRIM(A.CREATE_USER_ID))	created_by
FROM LT_CNV_SRC_KB.KB_LOC_PARTA_DET A
JOIN LT_CNV_WRK.PAE_CROSSWALK B ON A.PAE_ID = B.OLD_PAE_ID
WHERE A.OVERRIDE_PAE_STATUS_CD IS NOT NULL AND A.OVERRIDE_PAE_STATUS_CD <>'SE'
) AA;

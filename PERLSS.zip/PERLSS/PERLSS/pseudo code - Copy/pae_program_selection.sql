SELECT
 'pae_program_selection' as table_name
,B.NEW_PAE_ID	pae_id
,'KB'	program_type_cd
,A.CREATE_DT	program_rqst_dt
,'N'	choices_grp_3_sw --DEFAULTED AS PER DATABASE
,NULL	actual_discharge_dt
,A.CREATE_DT	created_dt
,LTRIM(RTRIM(A.UPDATE_USER_ID))	last_modified_by
,A.UPDATE_DT	last_modified_dt
,0	record_version
,F_GET_ARCHIVE_DATE	archived_dt
,LTRIM(RTRIM(A.CREATE_USER_ID))	created_by
--SELECT *
FROM LT_CNV_SRC_KB.KB_PAE_RQST A
JOIN LT_CNV_WRK.PAE_CROSSWALK B ON A.PAE_ID = B.OLD_PAE_ID
;
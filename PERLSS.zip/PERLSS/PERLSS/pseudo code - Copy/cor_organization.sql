SELECT 'cor_organization' as table_name
,LTRIM(RTRIM(A.ORG_CODE))	organization_cd
,LTRIM(RTRIM(A.DESCRIPTION))	as dsc
,LTRIM(RTRIM(A.ADDRESSLINE1))	addr_line_1
,LTRIM(RTRIM(A.ADDRESSLINE2))	addr_line_2
,LTRIM(RTRIM(A.CITY))	city
,LTRIM(RTRIM(A.STATE)) AS	state
,LTRIM(RTRIM(A.ZIPCODE))	zip
,LTRIM(RTRIM(A.PHONE_NUM))	ph_num
,LTRIM(RTRIM(A.TOLL_FREE_NUM))	toll_free_num
,NULL nashville_num
,LTRIM(RTRIM(A.WEBSITE_URL))	website_url
,LTRIM(RTRIM(A.ORG_NAME))	organization_name
,LTRIM(RTRIM(A.FAX_NUM))	fax_num
,LTRIM(RTRIM(A.UPDATE_USER_ID))	last_modified_by
,A.UPDATE_DT	last_modified_dt
,0 AS record_version
,LTRIM(RTRIM(A.CREATE_USER_ID))	created_by
,A.CREATE_DT	created_dt
,F_GET_ARCHIVE_DATE	archived_dt
,LTRIM(RTRIM(A.EMAIL))	email_addr
,NULL AS	entity_id
,NULL AS	entity_name FROM 
LT_CNV_SRC_KB.KB_CO_ORGANIZATION A;
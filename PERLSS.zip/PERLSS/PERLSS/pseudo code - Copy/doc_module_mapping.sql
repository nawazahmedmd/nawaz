SELECT 
 'doc_module_mapping' AS table_name
,A.DESTINATION_CD	destination_cd
,NULL AS  doc_id
,LTRIM(RTRIM(A.DOC_TYPE_CD))	doc_type
,LTRIM(RTRIM(A.FN_DOCUMENT_ID))	gen_generated_id
,NULL AS  page_id
,NULL AS  prsn_id
,B.NEW_PAE_ID	pae_id
,C.NEW_REF_ID	ref_id
,NULL AS  apl_id
,'N' AS  app_pdf_sw
,NULL AS  apl_pdf_type_cd
,F_GET_ARCHIVE_DATE AS  archived_dt
,LTRIM(RTRIM(A.CREATE_USER_ID))	created_by
,A.CREATE_DT	created_dt
,LTRIM(RTRIM(A.UPDATE_USER_ID))	last_modified_by
,A.UPDATE_DT	last_modified_dt
,0 AS  record_version
,NULL AS  doc_desc
,NULL AS  chm_id
,NULL AS  tns_id
,NULL AS  adj_id
,NULL AS  lnk_id
,NULL AS  entity_id
FROM LT_CNV_SRC_KB.KB_DOC_DTL A
JOIN LT_CNV_WRK.PAE_CROSSWALK B ON B.OLD_PAE_ID = A.PAE_ID
JOIN LT_CNV_WRK.REFERRAL_CROSSWALK C ON C.OLD_REF_ID = A.REF_ID;

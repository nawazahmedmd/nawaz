SELECT
 'pae_prior_caregiver_detail' as table_name
,B.NEW_PAE_ID	pae_id
,ltrim(rtrim(A.SKILLED_INTV_CD))	cargvr_intervn_cd
,ltrim(rtrim(A.NIGHT_MON_CD))	applcnt_frqcy_awake_monitor_cd
,CASE WHEN ltrim(rtrim(A.HANDS_ON_SW))= 1 THEN 'Y' ELSE 'N' END	hands_on_caregvng_sw
,CASE WHEN ltrim(rtrim(A.CONTRACT_SW))= 1 THEN 'Y' ELSE 'N' END	musculo_contrac_deform_sw
,CASE WHEN ltrim(rtrim(A.CHOKING_SW))= 1 THEN 'Y' ELSE 'N' END	risk_choking_rsp_dis_sw
,CASE WHEN ltrim(rtrim(A.BEHAVE_PLAN_SW))= 1 THEN 'Y' ELSE 'N' END	impl_behavrl_plan_sw
,CASE WHEN ltrim(rtrim(A.LOC_MONITORING_SW))= 1 THEN 'Y' ELSE 'N' END	req_lctn_monitoring_sw
,CASE WHEN ltrim(rtrim(A.HOME_ED_SW))= 1 THEN 'Y' ELSE 'N' END	home_bound_edu_sw
,'Y' othr_care_none_above_sw  --Mapping not provided
,ltrim(rtrim(A.FAMILY_TYPE_CD))	single_two_parent_fmly_cd
,ltrim(rtrim(A.OTHER_CAREGIVER_CD))	othr_adlt_cargvr_sw
,ltrim(rtrim(A.SINGLE_PARENT_HLTH_PROB_CD))	parent_hlth_dis_sw
,ltrim(rtrim(A.PARENTS_HLTH_PROB_CD))	more_parent_hlth_dis_cd
,CASE WHEN ltrim(rtrim(A.MORE_CHILD_SW))= 1 THEN 'Y' ELSE 'N' END	more_child_dis_sw
,CASE WHEN ltrim(rtrim(A.OTHER_ADULT_SW))= 1 THEN 'Y' ELSE 'N' END	othr_adlt_dis_sw
,CASE WHEN ltrim(rtrim(A.OTHER_CHILDREN_SW))= 1 THEN 'Y' ELSE 'N' END	othr_child_liv_home_sw
,CASE WHEN ltrim(rtrim(A.PARENT_CAREGIVER_SW))= 1 THEN 'Y' ELSE 'N' END	parent_adlt_dis_sw
,'Y'	add_none_above_sw --Mapping not provided
,A.CREATE_DT	created_dt
,ltrim(rtrim(A.UPDATE_USER_ID))	last_modified_by
,A.UPDATE_DT	last_modified_dt
,0	record_version
,F_GET_ARCHIVE_DATE	archived_dt
,ltrim(rtrim(A.CREATE_USER_ID))	created_by
-- SELECT COUNT(1)
FROM LT_CNV_SRC_KB.KB_PD_CARE_GIVING A
JOIN LT_CNV_WRK.PAE_CROSSWALK B ON A.PAE_ID = B.OLD_PAE_ID;
SELECT
  'pae_prior_intnsv_intrvntn' as table_name
,B.NEW_PAE_ID	PAE_ID
, CASE WHEN  LTRIM(RTRIM(ICU_ADMIT_SW))=1 then 'Y' Else 'N'   END	more_icu_admsn_sw
, CASE WHEN  LTRIM(RTRIM(MED_HOSP_SW))=1 then 'Y' Else 'N'   END	more_med_hsptlztn_sw
, CASE WHEN  LTRIM(RTRIM(PSY_HOSP_SW))=1 then 'Y' Else 'N'   END	more_psychiatric_hsptlztn_sw
, CASE WHEN  LTRIM(RTRIM(HOSP_30_DAYS_SW))=1 then 'Y' Else 'N'   END	thirty_more_hsptlzd_sw
, CASE WHEN  LTRIM(RTRIM(ER_VISITS_SW))=1 then 'Y' Else 'N'  END 	four_more_er_visits_sw
, CASE WHEN  LTRIM(RTRIM(MOBILE_CRISIS_SW))=1 then 'Y' Else 'N'  END 	mobile_crisis_calls_sw
, CASE WHEN  LTRIM(RTRIM(RESP_DISTRESS_SW))=1 then 'Y' Else 'N'  END 	rescu_breath_rsp_dis_sw
, CASE WHEN  LTRIM(RTRIM(PHY_RESTRAINT_SW))=1 then 'Y' Else 'N'  END 	phycl_restrain_sw
, CASE WHEN  LTRIM(RTRIM(RES_TREAMENT_SW))=1 then 'Y' Else 'N'  END 	out_home_res_treat_sw
, CASE WHEN  LTRIM(RTRIM(DCS_CUSTODY_SW))=1 then 'Y' Else 'N'  END 	out_home_dcs_custdy_sw
, CASE WHEN  LTRIM(RTRIM(INV_CRIME_SW))=1 then 'Y' Else 'N'  END 	involv_criminal_jus_sw
, CASE WHEN (    LTRIM(RTRIM(ICU_ADMIT_SW)) =1
             OR  LTRIM(RTRIM(MED_HOSP_SW)) =1
			 OR  LTRIM(RTRIM(PSY_HOSP_SW))=1 
			 OR  LTRIM(RTRIM(HOSP_30_DAYS_SW))=1
			 OR  LTRIM(RTRIM(ER_VISITS_SW))=1
			 OR  LTRIM(RTRIM(MOBILE_CRISIS_SW))=1
			 OR  LTRIM(RTRIM(PHY_RESTRAINT_SW))=1
			 OR  LTRIM(RTRIM(RESP_DISTRESS_SW))=1
			 OR  LTRIM(RTRIM(RES_TREAMENT_SW))=1
			 OR  LTRIM(RTRIM(DCS_CUSTODY_SW))=1
			 OR  LTRIM(RTRIM(INV_CRIME_SW))=1)  THEN 'N' ELSE 'Y' END	NONE_ABOVE_SW
,F_GET_CONV_DATE	CREATED_DT
,NULL AS	LAST_MODIFIED_BY
,NULL AS	LAST_MODIFIED_DT
,0	RECORD_VERSION
,F_GET_ARCHIVE_DATE	ARCHIVED_DT
,F_GET_CONV_USER 	CREATED_BY
--SELECT *
FROM LT_CNV_SRC_KB.KB_PD_INTENSE_INT A
JOIN LT_CNV_WRK.PAE_cROSSWALK B ON A.PAE_ID=B.OLD_PAE_ID;

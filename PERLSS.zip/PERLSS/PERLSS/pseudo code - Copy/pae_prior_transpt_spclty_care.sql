SELECT
'pae_prior_transpt_spclty_care' as table_name
,B.NEW_PAE_ID	pae_id
, LTRIM(RTRIM(A.SPEC_TRAN_SW))	applcnt_amb_splcare_sw
, LTRIM(RTRIM(A.TRANS_EQUIP_SW)) 	applcnt_trnsprt_equip_sw
, LTRIM(RTRIM(A.SPEC_MON_SW))	applcnt_spclzd_monitor_sw
, CASE When LTRIM(RTRIM(A.VISITS_SW))='1' then 'Y' Else 'N' END	req_six_primary_6months_sw
, CASE When LTRIM(RTRIM(A.TRAN_PRIM_SW))='1' then 'Y' Else 'N' END	req_trnsprtn_fifty_primary_sw
, CASE When LTRIM(RTRIM(A.TRAN_SPEC_SW))='1' then 'Y' Else 'N' END	req_trnsprtn_fifty_spclty_sw
, CASE WHEN (LTRIM(RTRIM(A.SPEC_TRAN_SW))='Y' 
      OR LTRIM(RTRIM(A.TRANS_EQUIP_SW))='Y' 
	  OR LTRIM(RTRIM(A.SPEC_MON_SW))='Y' 
	  OR LTRIM(RTRIM(A.VISITS_SW))='1' 
	  OR LTRIM(RTRIM(A.TRAN_PRIM_SW))='1' 
	  OR LTRIM(RTRIM(A.TRAN_SPEC_SW))='1') THEN 'N' ELSE 'Y' END 	not_applicable_sw
,F_GET_CONV_DATE	created_dt
,NULL	last_modified_by
,NULL	last_modified_dt
,0	record_version
,F_GET_ARCHIVE_DATE	archived_dt
,F_GET_CONV_USER	created_by
--SELECT *
FROM LT_CNV_SRC_KB.KB_PD_TRANS_CARE A
JOIN LT_CNV_WRK.PAE_CROSSWALK B ON A.PAE_ID = B.OLD_PAE_ID;






SELECT 
 'ref_applcnt_dtls' AS table_name 
,B.NEW_REF_ID AS REF_ID
,1234	prsn_id -- NEED TO REVIST
,'N'	intel_disable_sw
,'N'	none_disable_sw
,'N'	dev_disable_sw
,NULL	diagns_txt
,ltrim(rtrim(A.CREATE_USER_ID))	created_by
,A.CREATE_DT	created_dt
,ltrim(rtrim(A.UPDATE_USER_ID))	last_modified_by
,A.UPDATE_DT	last_modified_dt
,0	RECORD_VERSION
,F_GET_ARCHIVE_DATE	ARCHIVED_DT
FROM LT_CNV_SRC_KB.KB_RI_APP_DTL A
JOIN LT_CNV_WRK.REFERRAL_CROSSWALK B ON B.OLD_REF_ID = A.REF_ID;

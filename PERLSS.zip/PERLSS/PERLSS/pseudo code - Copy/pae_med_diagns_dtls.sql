SELECT
 B.NEW_PAE_ID	pae_id
,LTRIM(RTRIM(A.MED_DGS_TYPE_CD))	med_diagns_cd
,LTRIM(RTRIM(A.OTH_MED_DGS_NAME))	othr_med_diagns
,LTRIM(RTRIM(A.PERS_6_MONTH_SW))	persist_6_months_sw
,LTRIM(RTRIM(A.EXPECT_12_MONTH_SW))	expctd_12_months_sw
,NULL	primary_diagns_sw
,A.CREATE_DT	created_dt
,LTRIM(RTRIM(A.UPDATE_USER_ID))	last_modified_by
,A.UPDATE_DT	last_modified_dt
,0	record_version
,F_GET_ARCHIVE_DATE	archived_dt
,LTRIM(RTRIM(A.CREATE_USER_ID))	created_by
FROM LT_CNV_SRC_KB.KB_DS_MED_DIAGNOSIS A
JOIN LT_CNV_WRK.PAE_CROSSWALK B ON A.PAE_ID = B.OLD_PAE_ID
;
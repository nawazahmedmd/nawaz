SELECT
'pae_skilled_srvc_summary' as table_name
, B.NEW_PAE_ID	pae_id
,'Y'	need_skilled_srvcs_sw
,'N'	need_respiratory_care_sw
,A.CREATE_DT	created_dt
,ltrim(rtrim(A.UPDATE_USER_ID))	last_modified_by
,A.UPDATE_DT	last_modified_dt
,0	record_version
,F_GET_ARCHIVE_dATE	archived_dt
,ltrim(rtrim(A.CREATE_USER_ID))	created_by
,'N'	dsnt_need_srvcs_sw
,null as	total_submitted_skilled_srvcs_acuity_score
--select *
FROM LT_CNV_SRC_KB.KB_DS_SKILLED_SERVICES A
JOIN LT_CNV_WRK.PAE_CROSSWALK B ON A.PAE_ID = B.OLD_PAE_ID;

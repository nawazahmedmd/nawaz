SELECT
'pae_intlctl_dvlpmntl_disblty_dtls' as table_name
,B.NEW_PAE_ID	pae_id
,LTRIM(RTRIM(A.IDD_FUNC_CAPACITY_SW))	indv_dtrmnd_disblty_sw
,LTRIM(RTRIM(A.IQ_TEST_SW))	iq_test_12_months_sw
,LTRIM(RTRIM(A.IQ_TEST_CD))	iq_score_cd
,LTRIM(RTRIM(A.AUTISM_DIAGNOSIS_SW))	autism_diagns_sw
,LTRIM(RTRIM(A.COMM_DISORDER_SW))	communication_disorder_sw
,'N' int_dimin_functnl_cap_sw
,LTRIM(RTRIM(A.CHILD_IDD_CD))	int_dvlpmntl_disblty_cd
,LTRIM(RTRIM(A.CHILD_NEED_ASSISTANCE_SW))	assist_req_sw
,LTRIM(RTRIM(A.CHILD_REQ_DAILY_LEVEL_ASST_CD))	assist_req_cd
,LTRIM(RTRIM(A.CHILD_BHS_SW))	cooccurr_hlth_beh_sup_sw
,F_GET_CONV_DATE	created_dt
,null as	last_modified_by
,null as	last_modified_dt
,0	record_version
,F_GET_ARCHIVE_DATE	archived_dt
,F_GET_CONV_USER	created_by
--SELECT COUNT(1)
FROM LT_CNV_SRC_KB.KB_IDD_DETAILS A
JOIN LT_CNV_WRK.PAE_CROSSWALK B ON A.PAE_ID=B.OLD_PAE_ID;

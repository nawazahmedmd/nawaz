SELECT
'pae_kb_partb_wtng_list' AS table_name
,D.NEW_REF_ID	ref_id
,C.NEW_PAE_ID	pae_id
,A.INDV_ID AS	prsn_id
,NULL AS	update_action_cd
,NULL AS	rmvl_rsn_cd
,NULL AS	auth_rmvl
,NULL AS	auth_rmvl_reltshp_cd
,NULL AS	auth_rmvl_dt
,NULL AS	auth_rmvl_cntct_type_cd
,NULL AS	auth_rmvl_cntct_by
,NULL AS	comments
,F_GET_CONV_DATE AS	created_dt
,F_GET_CONV_USER AS	created_by
,null AS	last_modified_by
,null AS	last_modified_dt
,0 AS	record_version
,F_GET_ARCHIVE_DATE AS	archived_dt
,'Y'	active_sw
,NULL AS	initial_rank
,TO_CHAR(B.RECEIVED_DT, 'YYMMDDHHMMSS') AS	curr_position
,NULL AS	initial_position
,NULL AS	prev_position
,NULL AS	prev_rank
,NULL AS	rank_update_dt
FROM LT_CNV_SRC_KB.KB_SLOT_WL_PARTB_RANK A
JOIN LT_CNV_SRC_KB.KB_REF_RQST B ON A.REF_ID=B.REF_ID
JOIN LT_CNV_WRK.PAE_CROSSWALK C ON A.PAE_ID = C.OLD_PAE_ID
JOIN LT_CNV_WRK.REFERRAL_CROSSWALK D ON A.REF_ID = D.OLD_REF_ID;

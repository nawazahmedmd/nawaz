select
'cor_notice_addr' as table_name
,LTRIM(RTRIM(D.NEW_COR_ID))	cor_id
,LTRIM(RTRIM(B.L1_ADDR))	addr_line_1
,LTRIM(RTRIM(B.L2_ADDR))	addr_line_2
,LTRIM(RTRIM(B.city))	city
,LTRIM(RTRIM(B.state_cd))	state_cd
,LTRIM(RTRIM(B.zipcode))	zip
,LTRIM(RTRIM(B.zip_extn))	zip_extsn
,LTRIM(RTRIM(B.cnty_cd))	cnty_cd
,LTRIM(RTRIM(B.APO_FPO_CD))	military_po_cd
,LTRIM(RTRIM(B.AA_AE_AP_CD))	military_state_cd
,LTRIM(RTRIM(B.ADDR_TYPE_CD))	addr_type_cd
,NULL	validated_addr_cd
,NULL	manual_addr_sw
,'M'	applcnt_type_cd
,'Y'	active_sw
,LTRIM(RTRIM(A.UPDATE_USER_ID))	last_modified_by
,A.UPDATE_DT	last_modified_dt
,0	record_version
,F_GET_ARCHIVE_DATE	archived_dt
,LTRIM(RTRIM(A.CREATE_USER_ID))	created_by
,NULL	addr_log_id
,LTRIM(RTRIM(C.FIRST_NAME))	first_name
,LTRIM(RTRIM(C.LAST_NAME))	last_name
,LTRIM(RTRIM(C.MID_INITIAL))	middle_initial
,A.CREATE_DT	created_dt
from LT_CNV_SRC_KB.kb_co_request_history a
join LT_CNV_SRC_KB.kb_ri_addresses b on a.ref_id = b.ref_id
and Decode(a.RECIPIENT_TYPE,'CT','HH','AR','AR')=b.user_type_cd
join LT_CNV_SRC_KB.kb_ri_app_dtl c on a.ref_id = c.ref_id
join LT_CNV_WRK.COR_CROSSWALK D ON D.OLD_COR_ID = A.CO_REQ_SEQ
;



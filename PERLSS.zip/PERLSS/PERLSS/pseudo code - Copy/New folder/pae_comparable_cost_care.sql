SELECT
'pae_comparable_cost_care' as table_name
,B.NEW_PAE_ID	pae_id
,C.NEW_REF_ID	ref_id
,LTRIM(RTRIM(A.mco_assigned))	mco_assigned
,LTRIM(RTRIM(A.mco_avg_cost))	mco_avg_cost
,LTRIM(RTRIM(A.mco_update_dt))	mco_update_dt
,LTRIM(RTRIM(A.mco_exceed_sw))	mco_exceed_sw
,LTRIM(RTRIM(A.ltss_approve))	ltss_approve
,LTRIM(RTRIM(A.ltss_confirm_sw))	ltss_confirm_sw
,LTRIM(RTRIM(A.ccc_ap_sw))	ccc_ap_sw
,LTRIM(RTRIM(A.ap_outcome_cd))	ap_outcome_cd
,LTRIM(RTRIM(A.ap_outcome_dt))	ap_outcome_dt
,A.CREATE_DT	CREATED_DT
,LTRIM(RTRIM(A.UPDATE_USER_ID)) 	LAST_MODIFIED_BY
,A.UPDATE_DT	LAST_MODIFIED_DT
,0	RECORD_VERSION
,F_GET_ARCHIVE_DATE	ARCHIVED_DT
,LTRIM(RTRIM(A.CREATE_USER_ID)) 	CREATED_BY
--SELECT *
FROM LT_CNV_SRC_KB.KB_COMPARABLE_COST A
JOIN LT_CNV_SRC_KB.KB_PAE_RQST R ON A.REF_ID = R.REF_ID
JOIN LT_CNV_WRK.PAE_CROSSWALK B ON R.PAE_ID = B.OLD_PAE_ID
JOIN LT_CNV_WRK.REFERRAL_CROSSWALK C ON A.REF_ID=C.OLD_REF_ID;

CREATE TABLE REFERRAL_CROSSWALK (OLD_REF_ID VARCHAR2(11) , NEW_REF_ID VARCHAR2(11));

CREATE TABLE PAE_CROSSWALK (OLD_PAE_ID VARCHAR2(12) , NEW_PAE_ID VARCHAR2(12));

CREATE TABLE COR_CROSSWALK (OLD_COR_ID NUMBER , NEW_COR_ID NUMBER);

CREATE TABLE LOG_ID_CROSSWALK(OLD_LOG_ID NUMBER, NEW_LOG_ID NUMBER);

CREATE TABLE TEMP_PARTA_WTNG_CURR_POSITION
(LOC INTEGER , TAG INTEGER , PRIOR_SCORE_NUM INT);


CREATE OR REPLACE EDITIONABLE FUNCTION F_GET_REFERENCE_DATA (Legacy_Table IN VARCHAR2, LEG_CODE IN VARCHAR2,REFERENCE_TABLE IN VARCHAR2)
RETURN VARCHAR2
IS l_PERLSS_Reference_Code VARCHAR2(200);

BEGIN

SELECT LTRIM(RTRIM(TO_XREF_CD)) INTO l_PERLSS_Reference_Code 
FROM LT_CNV_WRK.WRK_XREF_CODES
where SRC_SYS_ID = 'KatiBeckett'
AND LEGACY_TBL_NM = LTRIM(RTRIM(Legacy_Table)) 
AND FROM_XREF_CD= LTRIM(RTRIM(LEG_CODE))
AND REF_TBL_NM = LTRIM(RTRIM(REFERENCE_TABLE))
and rownum=1;

RETURN l_PERLSS_Reference_Code;

END;

 F_GET_REFERENCE_DATA_TLCS('RGST',LTRIM(RTRIM(RS.REST_STATUS)),'u_regulatory_status')

SELECT 
REF_ID AS OLD_REF_ID, 
'RF' || '0' || SUBSTR(REF_ID,4,11) AS NEW_REF_ID
FROM KB_REF_RQST;

/*
SELECT 
PAE_ID AS OLD_PAE_ID,
'PAE' || '0' || SUBSTR(PAE_ID,5,11) AS NEW_PAE_ID
FROM KB_PAE_RQST;
*/

SELECT * FROM PAE_CROSSWALK
ORDER BY 2;

SELECT * FROM COR_CROSSWALK;

SELECT * FROM kb_co_request_history

SELECT * FROM REFERRAL_CROSSWALK;

SELECT * FROM KB_CO_REQUEST_HISTORY;

select cast(MAX(replace(pae_id,'PAE','') as bigint) as MAX_PAE_ID , 'pae_rqst' as table_name from PERLSS.PAE_RQST;
select cast(MAX(id) as bigint) as MAXID , 'pae_flow_sequence' as table_name from PERLSS.pae_flow_sequence;
select cast(MAX(id) as bigint) as MAXID , 'app_doc' as table_name from PERLSS.app_doc;
select cast(MAX(id) as bigint) as MAXID , 'doc_module_mapping' as table_name from PERLSS.doc_module_mapping dmm ;
select cast(MAX(id) as bigint) as MAXID , 'pae_flow_sequence' as table_name from PERLSS.pae_flow_sequence;
select cast(MAX(id) as bigint) as MAXID , 'com_app_addr' as table_name from PERLSS.com_app_addr;
select cast(MAX(id) as bigint) as MAXID , 'com_app' as table_name from PERLSS.com_app;
select cast(MAX(id) as bigint) as MAXID , 'pae_action' as table_name from PERLSS.pae_action pa ;
select cast(MAX(id) as bigint) as MAXID , 'cor_notice_addr' as table_name from PERLSS.cor_notice_addr cna;
select cast(MAX(id) as bigint) as MAXID , 'cor_organization' as table_name from PERLSS.cor_organization pa ;
select cast(MAX(id) as bigint) as MAXID , 'cnv_doc_dtls' as table_name from PERLSS.cnv_doc_dtls cdd ;


select last_value, log_cnt, nextval('perlss.hibernate_sequence') as NextID, 
1 as default_port  from perlss.hibernate_sequence;


SELECT setval('perlss.hibernate_sequence', 
((select last_value::integer from perlss.hibernate_sequence)	
+ (SELECT max(id)::integer FROM perlss.pae_app_addr_dtl)))
SELECT distinct
1 as default_port
,A.PAE_ID	pae_id
,LTRIM(RTRIM(A.IDD_FUNC_CAPACITY_SW))	indv_dtrmnd_disblty_sw
,LTRIM(RTRIM(A.IQ_TEST_SW))	iq_test_12_months_sw
,F_GET_REFERENCE_DATA('KB_IDD_DETAILS',LTRIM(RTRIM(A.IQ_TEST_CD)),'IQSCORE') as iq_score_cd
,LTRIM(RTRIM(A.AUTISM_DIAGNOSIS_SW))	autism_diagns_sw
,LTRIM(RTRIM(A.COMM_DISORDER_SW))	communication_disorder_sw
,'N' int_dimin_functnl_cap_sw
,F_GET_REFERENCE_DATA('KB_IDD_DETAILS',LTRIM(RTRIM(A.CHILD_IDD_CD)),'IDD_TYPE') as int_dvlpmntl_disblty_cd
,LTRIM(RTRIM(A.CHILD_NEED_ASSISTANCE_SW))	assist_req_sw
,F_GET_REFERENCE_DATA('KB_IDD_DETAILS',LTRIM(RTRIM(A.CHILD_REQ_DAILY_LEVEL_ASST_CD)),'DAILY_ASSISTANCE') as assist_req_cd
,LTRIM(RTRIM(A.CHILD_BHS_SW))	cooccurr_hlth_beh_sup_sw
,Null as	created_dt
,null as	last_modified_by
,null as	last_modified_dt
,0	record_version
,null as	archived_dt
,null as	created_by
FROM $$SRC_KB.KB_IDD_DETAILS A
JOIN $$CNV_WRK.WRK_LTSS_CLIENTS WRK_LTSS_CLIENTS ON  WRK_LTSS_CLIENTS.KB_PAE_ID = A.PAE_ID 
WHERE WRK_LTSS_CLIENTS.source_system_nm='KatieBeckett'
AND WRK_LTSS_CLIENTS.VALID_SW = 'Y' 
AND WRK_LTSS_CLIENTS.XREF_VALID_SW = 'Y' 
AND WRK_LTSS_CLIENTS.PERLSS_INDV_ID IS NOT NULL
;


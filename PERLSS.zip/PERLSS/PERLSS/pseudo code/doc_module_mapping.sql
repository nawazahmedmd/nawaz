SELECT 
1 as default_port
,A.DESTINATION_CD	destination_cd
,80813082 AS  doc_id
,LTRIM(RTRIM(A.DOC_TYPE_CD))	doc_type
,null	gen_generated_id
,NULL AS  page_id
,WRK_LTSS_CLIENTS.PERLSS_INDV_ID AS  prsn_id
,A.PAE_ID	pae_id
,A.REF_ID	ref_id
,NULL AS  apl_id
,'N' AS  app_pdf_sw
,NULL AS  apl_pdf_type_cd
,NULL AS    archived_dt
,NULL AS 	created_by
,NULL AS 	created_dt
,NULL AS 	last_modified_by
,NULL AS 	last_modified_dt
,0 AS  record_version
,NULL AS  doc_desc
,NULL AS  chm_id
,NULL AS  tns_id
,NULL AS  adj_id
,NULL AS  lnk_id
,NULL AS  entity_id
, 'Y' AS on_prem_flag
,  LTRIM(RTRIM(A.FN_DOCUMENT_ID))  AS on_prem_filenet_id
FROM $$SRC_KB.KB_DOC_DTL A
JOIN $$CNV_WRK.WRK_LTSS_CLIENTS WRK_LTSS_CLIENTS ON  (WRK_LTSS_CLIENTS.KB_PAE_ID = A.PAE_ID AND WRK_LTSS_CLIENTS.KB_REF_ID = A.REF_ID)
WHERE WRK_LTSS_CLIENTS.source_system_nm='KatieBeckett'
AND WRK_LTSS_CLIENTS.VALID_SW = 'Y' 
AND WRK_LTSS_CLIENTS.XREF_VALID_SW = 'Y' 
AND WRK_LTSS_CLIENTS.PERLSS_INDV_ID IS NOT NULL

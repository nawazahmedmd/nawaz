SELECT distinct 
1 as default_port
,A.PAE_ID	pae_id
,LTRIM(RTRIM(A.DIET_SW))	spclty_prescbd_diet_sw
,LTRIM(RTRIM(A.PRADER_WILLI_SW))	applcnt_prader_willi_sw
,LTRIM(RTRIM(A.CHOKING_SW))	applcnt_choking_aspi_sw
, CASE WHEN LTRIM(RTRIM(A.FEED_SW)) = 'Y' THEN 'Y'
	   WHEN LTRIM(RTRIM(A.FEED_SW)) = 'N' THEN 'N'
	   WHEN LTRIM(RTRIM(A.FEED_SW)) = 'A' THEN 'NA' END  hands_on_feedng_assist_cd
,F_GET_REFERENCE_DATA('KB_PD_NUT_FEEDING',LTRIM(RTRIM(A.FEED_FREQ_CD)),'HANDS_ON_FEEDING')	hands_on_feedng_duration_cd
,NULL	created_dt
,NULL	last_modified_by
,NULL	last_modified_dt
,0	record_version
,NULL	archived_dt
,NULL	created_by
FROM $$SRC_KB.KB_PD_NUT_FEEDING A
JOIN $$CNV_WRK.WRK_LTSS_CLIENTS WRK_LTSS_CLIENTS ON  WRK_LTSS_CLIENTS.KB_PAE_ID = A.PAE_ID 
WHERE WRK_LTSS_CLIENTS.source_system_nm='KatieBeckett'
AND WRK_LTSS_CLIENTS.VALID_SW = 'Y' 
AND WRK_LTSS_CLIENTS.XREF_VALID_SW = 'Y' 
AND WRK_LTSS_CLIENTS.PERLSS_INDV_ID IS NOT NULL
;
SELECT 
'pae_loc_determn_disenr' as table_name
,C.NEW_PAE_ID AS pae_id
, CASE WHEN LTRIM(RTRIM(A.PROG_CD))='K01' then 'KBA' 
       WHEN LTRIM(RTRIM(A.PROG_CD))='K03' then 'KBB'       END loc_determn_part_cd
, 'DIS' AS user_role_cd
, NULL AS disenr_type_cd
, F_GET_REFERENCE_DATA('KB_LOC_DISENROLL',,LTRIM(RTRIM(A.REASON_CD)),'KB_DISENROLLMENT_REASON') disenr_rsn_cd
, LTRIM(RTRIM(A.AVERAGE_COST)) avg_cost_of_care_indv_num
, NULL AS avg_cost_loc_num
, NULL AS comments_chng_mgmt
, LTRIM(RTRIM(A.AP_OUTCOME_CD)) AS disenr_dcsn_cd
, LTRIM(RTRIM(A.AP_OUTCOME_DT)) AS disenr_dt
, Null as comments
, LTRIM(RTRIM(a.create_dt)) created_dt
, LTRIM(RTRIM(a.update_user_id)) last_modified_by
, LTRIM(RTRIM(a.update_dt)) last_modified_dt
, 0 record_version
,F_GET_ARCHIVE_DATE Archived_dt
, LTRIM(RTRIM(a.create_user_id)) created_by
--SELECT *
FROM $$SRC_KB.KB_LOC_DISENROLL A 
JOIN $$SRC_KB.KB_PAE_RQST B ON A.PAE_ID = B.PAE_ID
JOIN $$CNV_WRK.PAE_CROSSWALK C ON A.PAE_ID = C.OLD_PAE_ID
JOIN $$CNV_WRK.WRK_LTSS_CLIENTS WRK_LTSS_CLIENTS ON  WRK_LTSS_CLIENTS.KB_PAE_ID = C.OLD_PAE_ID 
WHERE WRK_LTSS_CLIENTS.source_system_nm='KatieBeckett'
AND WRK_LTSS_CLIENTS.VALID_SW = 'Y' 
AND WRK_LTSS_CLIENTS.XREF_VALID_SW = 'Y' 
AND WRK_LTSS_CLIENTS.PERLSS_INDV_ID IS NOT NULL
AND WRK_LTSS_CLIENTS.CV_PHASE = F_GET_CONV_TYPE
;

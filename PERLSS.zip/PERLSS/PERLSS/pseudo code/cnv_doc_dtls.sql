select 'cnv_doc_dtls' as table_name
,1234 as prsn_id --REVISIT
,null as first_name
,null as last_name
, rf.NEW_REF_ID
, cr.NEW_PAE_ID
,null as apl_id
,null as tns_id
,null folder_name
,null as file_name
,null as notice_type
,null as last_modified_by
,null as last_modified_dt
,0 as record_version
,F_GET_CONV_USER as created_by
,SYSDATE as created_dt
,F_GET_ARCHIVE_DATE as archived_dt
,'N' as processed_flag
, LTRIM(RTRIM(A.DOC_TYPE_CD)) AS DOC_TYPE_CD
,null as notice_type_cd
,NULL source_sys_nm
,LTRIM(RTRIM(A.FN_DOCUMENT_ID)) AS kb_fn_id
from $$SRC_KB.kb_doc_dtl A
join $$CNV_WRK.pae_crosswalk cr on cr.old_pae_id = A.pae_id
join $$CNV_WRK.referral_crosswalk rf on rf.old_ref_id = A.ref_id
join $$CNV_WRK.WRK_LTSS_CLIENTS WRK_LTSS_CLIENTS ON  (WRK_LTSS_CLIENTS.KB_PAE_ID = cr.OLD_PAE_ID AND WRK_LTSS_CLIENTS.KB_REF_ID = rf.OLD_REF_ID)
LEFT JOIN $$SRC_KB.kb_documents B ON A.DOC_SEQ_NUM = B.DOC_SEQ_NUM
where delete_sw IS NULL
AND WRK_LTSS_CLIENTS.source_system_nm='KatieBeckett'
AND WRK_LTSS_CLIENTS.VALID_SW = 'Y' 
AND WRK_LTSS_CLIENTS.XREF_VALID_SW = 'Y' 
AND WRK_LTSS_CLIENTS.PERLSS_INDV_ID IS NOT NULL
AND WRK_LTSS_CLIENTS.CV_PHASE = F_GET_CONV_TYPE;
SELECT 
'pae_flow_sequence' AS table_name, A.*
 FROM (SELECT C.NEW_PAE_ID AS PAE_ID
,'PPWEL' as page_id
,'PERDE' as module
,'Y' as visited_sw
,'Y' as completed_sw
,'Y' as req_sw
,null as inactive_sw
,b.create_user_id as created_by
,b.create_dt as created_dt
,null as last_modified_dt
,0 as record_version
,'N' as sum_sw
FROM $$SRC_KB.KB_DRVR A
JOIN $$SRC_KB.KB_PAE_RQST B ON A.PAE_ID = B.PAE_ID
JOIN $$CNV_WRK.PAE_CROSSWALK C ON A.PAE_ID = C.OLD_PAE_ID
JOIN $$CNV_WRK.WRK_LTSS_CLIENTS WRK_LTSS_CLIENTS ON  WRK_LTSS_CLIENTS.KB_PAE_ID = C.OLD_PAE_ID 
WHERE WRK_LTSS_CLIENTS.source_system_nm='KatieBeckett'
AND WRK_LTSS_CLIENTS.VALID_SW = 'Y' 
AND WRK_LTSS_CLIENTS.XREF_VALID_SW = 'Y' 
AND WRK_LTSS_CLIENTS.PERLSS_INDV_ID IS NOT NULL
AND WRK_LTSS_CLIENTS.CV_PHASE = F_GET_CONV_TYPE

UNION
SELECT C.NEW_PAE_ID AS PAE_ID
,'PPPAI' as page_id
,'PERDE' as module
,'Y' as visited_sw
,'Y' as completed_sw
,'Y' as req_sw
,null as inactive_sw
,b.create_user_id as created_by
,b.create_dt as created_dt
,null as last_modified_dt
,0 as record_version
,'N' as sum_sw
FROM $$SRC_KB.KB_DRVR A
JOIN $$SRC_KB.KB_PAE_RQST B ON A.PAE_ID = B.PAE_ID
JOIN $$CNV_WRK.PAE_CROSSWALK C ON A.PAE_ID = C.OLD_PAE_ID
JOIN $$CNV_WRK.WRK_LTSS_CLIENTS WRK_LTSS_CLIENTS ON  WRK_LTSS_CLIENTS.KB_PAE_ID = C.OLD_PAE_ID 
WHERE WRK_LTSS_CLIENTS.source_system_nm='KatieBeckett'
AND WRK_LTSS_CLIENTS.VALID_SW = 'Y' 
AND WRK_LTSS_CLIENTS.XREF_VALID_SW = 'Y' 
AND WRK_LTSS_CLIENTS.PERLSS_INDV_ID IS NOT NULL
AND WRK_LTSS_CLIENTS.CV_PHASE = F_GET_CONV_TYPE

UNION
SELECT C.NEW_PAE_ID AS PAE_ID
,'PPPCI' as page_id
,'PERDE' as module
,'Y' as visited_sw
,'Y' as completed_sw
,'Y' as req_sw
,null as inactive_sw
,b.create_user_id as created_by
,b.create_dt as created_dt
,null as last_modified_dt
,0 as record_version
,'N' as sum_sw
FROM $$SRC_KB.KB_DRVR A
JOIN $$SRC_KB.KB_PAE_RQST B ON A.PAE_ID = B.PAE_ID
JOIN $$CNV_WRK.PAE_CROSSWALK C ON A.PAE_ID = C.OLD_PAE_ID
JOIN $$CNV_WRK.WRK_LTSS_CLIENTS WRK_LTSS_CLIENTS ON  WRK_LTSS_CLIENTS.KB_PAE_ID = C.OLD_PAE_ID 
WHERE WRK_LTSS_CLIENTS.source_system_nm='KatieBeckett'
AND WRK_LTSS_CLIENTS.VALID_SW = 'Y' 
AND WRK_LTSS_CLIENTS.XREF_VALID_SW = 'Y' 
AND WRK_LTSS_CLIENTS.PERLSS_INDV_ID IS NOT NULL
AND WRK_LTSS_CLIENTS.CV_PHASE = F_GET_CONV_TYPE

UNION
SELECT C.NEW_PAE_ID AS PAE_ID
,'PPPAD' as page_id
,'PERDE' as module
,'Y' as visited_sw
,'Y' as completed_sw
,'Y' as req_sw
,null as inactive_sw
,b.create_user_id as created_by
,b.create_dt as created_dt
,null as last_modified_dt
,0 as record_version
,'N' as sum_sw
FROM $$SRC_KB.KB_DRVR A
JOIN $$SRC_KB.KB_PAE_RQST B ON A.PAE_ID = B.PAE_ID
JOIN $$CNV_WRK.PAE_CROSSWALK C ON A.PAE_ID = C.OLD_PAE_ID
JOIN $$CNV_WRK.WRK_LTSS_CLIENTS WRK_LTSS_CLIENTS ON  WRK_LTSS_CLIENTS.KB_PAE_ID = C.OLD_PAE_ID 
WHERE WRK_LTSS_CLIENTS.source_system_nm='KatieBeckett'
AND WRK_LTSS_CLIENTS.VALID_SW = 'Y' 
AND WRK_LTSS_CLIENTS.XREF_VALID_SW = 'Y' 
AND WRK_LTSS_CLIENTS.PERLSS_INDV_ID IS NOT NULL
AND WRK_LTSS_CLIENTS.CV_PHASE = F_GET_CONV_TYPE

UNION
SELECT C.NEW_PAE_ID AS PAE_ID
,'PPPLA' as page_id
,'PERDE' as module
,'Y' as visited_sw
,'Y' as completed_sw
,'Y' as req_sw
,null as inactive_sw
,b.create_user_id as created_by
,b.create_dt as created_dt
,null as last_modified_dt
,0 as record_version
,'N' as sum_sw
FROM $$SRC_KB.KB_DRVR A
JOIN $$SRC_KB.KB_PAE_RQST B ON A.PAE_ID = B.PAE_ID
JOIN $$CNV_WRK.PAE_CROSSWALK C ON A.PAE_ID = C.OLD_PAE_ID
JOIN $$CNV_WRK.WRK_LTSS_CLIENTS WRK_LTSS_CLIENTS ON  WRK_LTSS_CLIENTS.KB_PAE_ID = C.OLD_PAE_ID 
WHERE WRK_LTSS_CLIENTS.source_system_nm='KatieBeckett'
AND WRK_LTSS_CLIENTS.VALID_SW = 'Y' 
AND WRK_LTSS_CLIENTS.XREF_VALID_SW = 'Y' 
AND WRK_LTSS_CLIENTS.PERLSS_INDV_ID IS NOT NULL
AND WRK_LTSS_CLIENTS.CV_PHASE = F_GET_CONV_TYPE

UNION
SELECT C.NEW_PAE_ID AS PAE_ID
,'PPPSP' as page_id
,'PRORE' as module
,'Y' as visited_sw
,'Y' as completed_sw
,'Y' as req_sw
,null as inactive_sw
,b.create_user_id as created_by
,b.create_dt as created_dt
,null as last_modified_dt
,0 as record_version
,'N' as sum_sw
FROM $$SRC_KB.KB_DRVR A
JOIN $$SRC_KB.KB_PAE_RQST B ON A.PAE_ID = B.PAE_ID
JOIN $$CNV_WRK.PAE_CROSSWALK C ON A.PAE_ID = C.OLD_PAE_ID
JOIN $$CNV_WRK.WRK_LTSS_CLIENTS WRK_LTSS_CLIENTS ON  WRK_LTSS_CLIENTS.KB_PAE_ID = C.OLD_PAE_ID 
WHERE WRK_LTSS_CLIENTS.source_system_nm='KatieBeckett'
AND WRK_LTSS_CLIENTS.VALID_SW = 'Y' 
AND WRK_LTSS_CLIENTS.XREF_VALID_SW = 'Y' 
AND WRK_LTSS_CLIENTS.PERLSS_INDV_ID IS NOT NULL
AND WRK_LTSS_CLIENTS.CV_PHASE = F_GET_CONV_TYPE

UNION
SELECT C.NEW_PAE_ID AS PAE_ID
,'PPDDS' as page_id
,'PAEDI' as module
,case when KBMDX_STAT_IND in (2,4) then 'Y' else 'N' end as visited_sw
,case when KBMDX_STAT_IND in (2,4) then 'Y' else 'N' end as completed_sw
,case when KBMDX_STAT_IND in (1,2,4) then 'Y' else 'N' end as req_sw
,null as inactive_sw
,b.create_user_id as created_by
,b.create_dt as created_dt
,null as last_modified_dt
,0 as record_version
,case when KBMDX_STAT_IND=4 then 'Y' else 'N' end as sum_sw
FROM $$SRC_KB.KB_DRVR A
JOIN $$SRC_KB.KB_PAE_RQST B ON A.PAE_ID = B.PAE_ID
JOIN $$CNV_WRK.PAE_CROSSWALK C ON A.PAE_ID = C.OLD_PAE_ID
JOIN $$CNV_WRK.WRK_LTSS_CLIENTS WRK_LTSS_CLIENTS ON  WRK_LTSS_CLIENTS.KB_PAE_ID = C.OLD_PAE_ID 
WHERE WRK_LTSS_CLIENTS.source_system_nm='KatieBeckett'
AND WRK_LTSS_CLIENTS.VALID_SW = 'Y' 
AND WRK_LTSS_CLIENTS.XREF_VALID_SW = 'Y' 
AND WRK_LTSS_CLIENTS.PERLSS_INDV_ID IS NOT NULL
AND WRK_LTSS_CLIENTS.CV_PHASE = F_GET_CONV_TYPE

UNION
SELECT C.NEW_PAE_ID AS PAE_ID
,'PPDMD' as page_id
,'PAEDI' as module
,case when KBMDX_STAT_IND in (2,4) then 'Y' else 'N' end as visited_sw
,case when KBMDX_STAT_IND in (2,4) then 'Y' else 'N' end as completed_sw
,case when KBMDX_STAT_IND in (1,2,4) then 'Y' else 'N' end as req_sw
,null as inactive_sw
,b.create_user_id as created_by
,b.create_dt as created_dt
,null as last_modified_dt
,0 as record_version
,case when KBMDX_STAT_IND=4 then 'Y' else 'N' end as sum_sw
FROM $$SRC_KB.KB_DRVR A
JOIN $$SRC_KB.KB_PAE_RQST B ON A.PAE_ID = B.PAE_ID
JOIN $$CNV_WRK.PAE_CROSSWALK C ON A.PAE_ID = C.OLD_PAE_ID
JOIN $$CNV_WRK.WRK_LTSS_CLIENTS WRK_LTSS_CLIENTS ON  WRK_LTSS_CLIENTS.KB_PAE_ID = C.OLD_PAE_ID 
WHERE WRK_LTSS_CLIENTS.source_system_nm='KatieBeckett'
AND WRK_LTSS_CLIENTS.VALID_SW = 'Y' 
AND WRK_LTSS_CLIENTS.XREF_VALID_SW = 'Y' 
AND WRK_LTSS_CLIENTS.PERLSS_INDV_ID IS NOT NULL
AND WRK_LTSS_CLIENTS.CV_PHASE = F_GET_CONV_TYPE

UNION
SELECT C.NEW_PAE_ID AS PAE_ID
,'PPFFA' as page_id
,'PAEFU' as module
,case when KBLAC_STAT_IND in (2,4) then 'Y' else 'N' end as visited_sw
,case when KBLAC_STAT_IND in (2,4) then 'Y' else 'N' end as completed_sw
,case when KBLAC_STAT_IND in (1,2,4) then 'Y' else 'N' end as req_sw
,null as inactive_sw
,b.create_user_id as created_by
,b.create_dt as created_dt
,null as last_modified_dt
,0 as record_version
,case when KBLAC_STAT_IND=4 then 'Y' else 'N' end as sum_sw
FROM $$SRC_KB.KB_DRVR A
JOIN $$SRC_KB.KB_PAE_RQST B ON A.PAE_ID = B.PAE_ID
JOIN $$CNV_WRK.PAE_CROSSWALK C ON A.PAE_ID = C.OLD_PAE_ID
JOIN $$CNV_WRK.WRK_LTSS_CLIENTS WRK_LTSS_CLIENTS ON  WRK_LTSS_CLIENTS.KB_PAE_ID = C.OLD_PAE_ID 
WHERE WRK_LTSS_CLIENTS.source_system_nm='KatieBeckett'
AND WRK_LTSS_CLIENTS.VALID_SW = 'Y' 
AND WRK_LTSS_CLIENTS.XREF_VALID_SW = 'Y' 
AND WRK_LTSS_CLIENTS.PERLSS_INDV_ID IS NOT NULL
AND WRK_LTSS_CLIENTS.CV_PHASE = F_GET_CONV_TYPE

UNION
SELECT C.NEW_PAE_ID AS PAE_ID
,'PPFK1' as page_id
,'PAEFU' as module
,case when KBLAC_STAT_IND in (2,4) then 'Y' else 'N' end as visited_sw
,case when KBLAC_STAT_IND in (2,4) then 'Y' else 'N' end as completed_sw
,case when KBLAC_STAT_IND in (1,2,4) then 'Y' else 'N' end as req_sw
,null as inactive_sw
,b.create_user_id as created_by
,b.create_dt as created_dt
,null as last_modified_dt
,0 as record_version
,case when KBLAC_STAT_IND=4 then 'Y' else 'N' end as sum_sw
FROM $$SRC_KB.KB_DRVR A
JOIN $$SRC_KB.KB_PAE_RQST B ON A.PAE_ID = B.PAE_ID
JOIN $$CNV_WRK.PAE_CROSSWALK C ON A.PAE_ID = C.OLD_PAE_ID
JOIN $$CNV_WRK.WRK_LTSS_CLIENTS WRK_LTSS_CLIENTS ON  WRK_LTSS_CLIENTS.KB_PAE_ID = C.OLD_PAE_ID 
WHERE WRK_LTSS_CLIENTS.source_system_nm='KatieBeckett'
AND WRK_LTSS_CLIENTS.VALID_SW = 'Y' 
AND WRK_LTSS_CLIENTS.XREF_VALID_SW = 'Y' 
AND WRK_LTSS_CLIENTS.PERLSS_INDV_ID IS NOT NULL
AND WRK_LTSS_CLIENTS.CV_PHASE = F_GET_CONV_TYPE

UNION
SELECT C.NEW_PAE_ID AS PAE_ID
,'PPFK2' as page_id
,'PAEFU' as module
,case when KBLAC_STAT_IND in (2,4) then 'Y' else 'N' end as visited_sw
,case when KBLAC_STAT_IND in (2,4) then 'Y' else 'N' end as completed_sw
,case when KBLAC_STAT_IND in (1,2,4) then 'Y' else 'N' end as req_sw
,null as inactive_sw
,b.create_user_id as created_by
,b.create_dt as created_dt
,null as last_modified_dt
,0 as record_version
,case when KBLAC_STAT_IND=4 then 'Y' else 'N' end as sum_sw
FROM $$SRC_KB.KB_DRVR A
JOIN $$SRC_KB.KB_PAE_RQST B ON A.PAE_ID = B.PAE_ID
JOIN $$CNV_WRK.PAE_CROSSWALK C ON A.PAE_ID = C.OLD_PAE_ID
JOIN $$CNV_WRK.WRK_LTSS_CLIENTS WRK_LTSS_CLIENTS ON  WRK_LTSS_CLIENTS.KB_PAE_ID = C.OLD_PAE_ID 
WHERE WRK_LTSS_CLIENTS.source_system_nm='KatieBeckett'
AND WRK_LTSS_CLIENTS.VALID_SW = 'Y' 
AND WRK_LTSS_CLIENTS.XREF_VALID_SW = 'Y' 
AND WRK_LTSS_CLIENTS.PERLSS_INDV_ID IS NOT NULL
AND WRK_LTSS_CLIENTS.CV_PHASE = F_GET_CONV_TYPE

UNION
SELECT C.NEW_PAE_ID AS PAE_ID
,'PPSSS' as page_id
,'PAESK' as module
,case when KBSKS_STAT_IND in (2,4) then 'Y' else 'N' end as visited_sw
,case when KBSKS_STAT_IND in (2,4) then 'Y' else 'N' end as completed_sw
,case when KBSKS_STAT_IND in (1,2,4) then 'Y' else 'N' end as req_sw
,null as inactive_sw
,b.create_user_id as created_by
,b.create_dt as created_dt
,null as last_modified_dt
,0 as record_version
,case when KBSKS_STAT_IND=4 then 'Y' else 'N' end as sum_sw
FROM $$SRC_KB.KB_DRVR A
JOIN $$SRC_KB.KB_PAE_RQST B ON A.PAE_ID = B.PAE_ID
JOIN $$CNV_WRK.PAE_CROSSWALK C ON A.PAE_ID = C.OLD_PAE_ID
JOIN $$CNV_WRK.WRK_LTSS_CLIENTS WRK_LTSS_CLIENTS ON  WRK_LTSS_CLIENTS.KB_PAE_ID = C.OLD_PAE_ID 
WHERE WRK_LTSS_CLIENTS.source_system_nm='KatieBeckett'
AND WRK_LTSS_CLIENTS.VALID_SW = 'Y' 
AND WRK_LTSS_CLIENTS.XREF_VALID_SW = 'Y' 
AND WRK_LTSS_CLIENTS.PERLSS_INDV_ID IS NOT NULL
AND WRK_LTSS_CLIENTS.CV_PHASE = F_GET_CONV_TYPE

UNION
SELECT C.NEW_PAE_ID AS PAE_ID
,'PPSSD' as page_id
,'PAESK' as module
,case when KBSKS_STAT_IND in (2,4) then 'Y' else 'N' end as visited_sw
,case when KBSKS_STAT_IND in (2,4) then 'Y' else 'N' end as completed_sw
,case when KBSKS_STAT_IND in (1,2,4) then 'Y' else 'N' end as req_sw
,null as inactive_sw
,b.create_user_id as created_by
,b.create_dt as created_dt
,null as last_modified_dt
,0 as record_version
,case when KBSKS_STAT_IND=4 then 'Y' else 'N' end as sum_sw
FROM $$SRC_KB.KB_DRVR A
JOIN $$SRC_KB.KB_PAE_RQST B ON A.PAE_ID = B.PAE_ID
JOIN $$CNV_WRK.PAE_CROSSWALK C ON A.PAE_ID = C.OLD_PAE_ID
JOIN $$CNV_WRK.WRK_LTSS_CLIENTS WRK_LTSS_CLIENTS ON  WRK_LTSS_CLIENTS.KB_PAE_ID = C.OLD_PAE_ID 
WHERE WRK_LTSS_CLIENTS.source_system_nm='KatieBeckett'
AND WRK_LTSS_CLIENTS.VALID_SW = 'Y' 
AND WRK_LTSS_CLIENTS.XREF_VALID_SW = 'Y' 
AND WRK_LTSS_CLIENTS.PERLSS_INDV_ID IS NOT NULL
AND WRK_LTSS_CLIENTS.CV_PHASE = F_GET_CONV_TYPE

UNION
SELECT C.NEW_PAE_ID AS PAE_ID
,'PPIIS' as page_id
,'PPIDD' as module
,case when KBIDD_STAT_IND in (2,4) then 'Y' else 'N' end as visited_sw
,case when KBIDD_STAT_IND in (2,4) then 'Y' else 'N' end as completed_sw
,case when KBIDD_STAT_IND in (1,2,4) then 'Y' else 'N' end as req_sw
,null as inactive_sw
,b.create_user_id as created_by
,b.create_dt as created_dt
,null as last_modified_dt
,0 as record_version
,case when KBIDD_STAT_IND=4 then 'Y' else 'N' end as sum_sw
FROM $$SRC_KB.KB_DRVR A
JOIN $$SRC_KB.KB_PAE_RQST B ON A.PAE_ID = B.PAE_ID
JOIN $$CNV_WRK.PAE_CROSSWALK C ON A.PAE_ID = C.OLD_PAE_ID
JOIN $$CNV_WRK.WRK_LTSS_CLIENTS WRK_LTSS_CLIENTS ON  WRK_LTSS_CLIENTS.KB_PAE_ID = C.OLD_PAE_ID 
WHERE WRK_LTSS_CLIENTS.source_system_nm='KatieBeckett'
AND WRK_LTSS_CLIENTS.VALID_SW = 'Y' 
AND WRK_LTSS_CLIENTS.XREF_VALID_SW = 'Y' 
AND WRK_LTSS_CLIENTS.PERLSS_INDV_ID IS NOT NULL
AND WRK_LTSS_CLIENTS.CV_PHASE = F_GET_CONV_TYPE

UNION
SELECT C.NEW_PAE_ID AS PAE_ID
,'PPIDI' as page_id
,'PPIDD' as module
,case when KBIDD_STAT_IND in (2,4) then 'Y' else 'N' end as visited_sw
,case when KBIDD_STAT_IND in (2,4) then 'Y' else 'N' end as completed_sw
,case when KBIDD_STAT_IND in (1,2,4) then 'Y' else 'N' end as req_sw
,null as inactive_sw
,b.create_user_id as created_by
,b.create_dt as created_dt
,null as last_modified_dt
,0 as record_version
,case when KBIDD_STAT_IND=4 then 'Y' else 'N' end as sum_sw
FROM $$SRC_KB.KB_DRVR A
JOIN $$SRC_KB.KB_PAE_RQST B ON A.PAE_ID = B.PAE_ID
JOIN $$CNV_WRK.PAE_CROSSWALK C ON A.PAE_ID = C.OLD_PAE_ID
JOIN $$CNV_WRK.WRK_LTSS_CLIENTS WRK_LTSS_CLIENTS ON  WRK_LTSS_CLIENTS.KB_PAE_ID = C.OLD_PAE_ID 
WHERE WRK_LTSS_CLIENTS.source_system_nm='KatieBeckett'
AND WRK_LTSS_CLIENTS.VALID_SW = 'Y' 
AND WRK_LTSS_CLIENTS.XREF_VALID_SW = 'Y' 
AND WRK_LTSS_CLIENTS.PERLSS_INDV_ID IS NOT NULL
AND WRK_LTSS_CLIENTS.CV_PHASE = F_GET_CONV_TYPE

UNION
SELECT C.NEW_PAE_ID AS PAE_ID
,'PPBBS' as page_id
,'PAEBE' as module
,case when KBABQ_STAT_IND in (2,4) then 'Y' else 'N' end as visited_sw
,case when KBABQ_STAT_IND in (2,4) then 'Y' else 'N' end as completed_sw
,case when KBABQ_STAT_IND in (1,2,4) then 'Y' else 'N' end as req_sw
,null as inactive_sw
,b.create_user_id as created_by
,b.create_dt as created_dt
,null as last_modified_dt
,0 as record_version
,case when KBABQ_STAT_IND=4 then 'Y' else 'N' end as sum_sw
FROM $$SRC_KB.KB_DRVR A
JOIN $$SRC_KB.KB_PAE_RQST B ON A.PAE_ID = B.PAE_ID
JOIN $$CNV_WRK.PAE_CROSSWALK C ON A.PAE_ID = C.OLD_PAE_ID
JOIN $$CNV_WRK.WRK_LTSS_CLIENTS WRK_LTSS_CLIENTS ON  WRK_LTSS_CLIENTS.KB_PAE_ID = C.OLD_PAE_ID 
WHERE WRK_LTSS_CLIENTS.source_system_nm='KatieBeckett'
AND WRK_LTSS_CLIENTS.VALID_SW = 'Y' 
AND WRK_LTSS_CLIENTS.XREF_VALID_SW = 'Y' 
AND WRK_LTSS_CLIENTS.PERLSS_INDV_ID IS NOT NULL
AND WRK_LTSS_CLIENTS.CV_PHASE = F_GET_CONV_TYPE

UNION
SELECT C.NEW_PAE_ID AS PAE_ID
,'PPBSB' as page_id
,'PAEBE' as module
,case when KBSIB_STAT_IND in (2,4) then 'Y' else 'N' end as visited_sw
,case when KBSIB_STAT_IND in (2,4) then 'Y' else 'N' end as completed_sw
,case when KBSIB_STAT_IND in (1,2,4) then 'Y' else 'N' end as req_sw
,null as inactive_sw
,b.create_user_id as created_by
,b.create_dt as created_dt
,null as last_modified_dt
,0 as record_version
,case when KBSIB_STAT_IND=4 then 'Y' else 'N' end as sum_sw
FROM $$SRC_KB.KB_DRVR A
JOIN $$SRC_KB.KB_PAE_RQST B ON A.PAE_ID = B.PAE_ID
JOIN $$CNV_WRK.PAE_CROSSWALK C ON A.PAE_ID = C.OLD_PAE_ID
JOIN $$CNV_WRK.WRK_LTSS_CLIENTS WRK_LTSS_CLIENTS ON  WRK_LTSS_CLIENTS.KB_PAE_ID = C.OLD_PAE_ID 
WHERE WRK_LTSS_CLIENTS.source_system_nm='KatieBeckett'
AND WRK_LTSS_CLIENTS.VALID_SW = 'Y' 
AND WRK_LTSS_CLIENTS.XREF_VALID_SW = 'Y' 
AND WRK_LTSS_CLIENTS.PERLSS_INDV_ID IS NOT NULL
AND WRK_LTSS_CLIENTS.CV_PHASE = F_GET_CONV_TYPE

UNION
SELECT C.NEW_PAE_ID AS PAE_ID
,'PPBPA' as page_id
,'PAEBE' as module
,case when KBPAB_STAT_IND in (2,4) then 'Y' else 'N' end as visited_sw
,case when KBPAB_STAT_IND in (2,4) then 'Y' else 'N' end as completed_sw
,case when KBPAB_STAT_IND in (1,2,4) then 'Y' else 'N' end as req_sw
,null as inactive_sw
,b.create_user_id as created_by
,b.create_dt as created_dt
,null as last_modified_dt
,0 as record_version
,case when KBPAB_STAT_IND=4 then 'Y' else 'N' end as sum_sw
FROM $$SRC_KB.KB_DRVR A
JOIN $$SRC_KB.KB_PAE_RQST B ON A.PAE_ID = B.PAE_ID
JOIN $$CNV_WRK.PAE_CROSSWALK C ON A.PAE_ID = C.OLD_PAE_ID
JOIN $$CNV_WRK.WRK_LTSS_CLIENTS WRK_LTSS_CLIENTS ON  WRK_LTSS_CLIENTS.KB_PAE_ID = C.OLD_PAE_ID 
WHERE WRK_LTSS_CLIENTS.source_system_nm='KatieBeckett'
AND WRK_LTSS_CLIENTS.VALID_SW = 'Y' 
AND WRK_LTSS_CLIENTS.XREF_VALID_SW = 'Y' 
AND WRK_LTSS_CLIENTS.PERLSS_INDV_ID IS NOT NULL
AND WRK_LTSS_CLIENTS.CV_PHASE = F_GET_CONV_TYPE

UNION
SELECT C.NEW_PAE_ID AS PAE_ID
,'PPBSS' as page_id
,'PAEBE' as module
,case when KBSSY_STAT_IND in (2,4) then 'Y' else 'N' end as visited_sw
,case when KBSSY_STAT_IND in (2,4) then 'Y' else 'N' end as completed_sw
,case when KBSSY_STAT_IND in (1,2,4) then 'Y' else 'N' end as req_sw
,null as inactive_sw
,b.create_user_id as created_by
,b.create_dt as created_dt
,null as last_modified_dt
,0 as record_version
,case when KBSSY_STAT_IND=4 then 'Y' else 'N' end as sum_sw
FROM $$SRC_KB.KB_DRVR A
JOIN $$SRC_KB.KB_PAE_RQST B ON A.PAE_ID = B.PAE_ID
JOIN $$CNV_WRK.PAE_CROSSWALK C ON A.PAE_ID = C.OLD_PAE_ID
JOIN $$CNV_WRK.WRK_LTSS_CLIENTS WRK_LTSS_CLIENTS ON  WRK_LTSS_CLIENTS.KB_PAE_ID = C.OLD_PAE_ID 
WHERE WRK_LTSS_CLIENTS.source_system_nm='KatieBeckett'
AND WRK_LTSS_CLIENTS.VALID_SW = 'Y' 
AND WRK_LTSS_CLIENTS.XREF_VALID_SW = 'Y' 
AND WRK_LTSS_CLIENTS.PERLSS_INDV_ID IS NOT NULL
AND WRK_LTSS_CLIENTS.CV_PHASE = F_GET_CONV_TYPE

UNION
SELECT C.NEW_PAE_ID AS PAE_ID
,'PPBAB' as page_id
,'PAEBE' as module
,case when KBABQ_STAT_IND in (2,4) then 'Y' else 'N' end as visited_sw
,case when KBABQ_STAT_IND in (2,4) then 'Y' else 'N' end as completed_sw
,case when KBABQ_STAT_IND in (1,2,4) then 'Y' else 'N' end as req_sw
,null as inactive_sw
,b.create_user_id as created_by
,b.create_dt as created_dt
,null as last_modified_dt
,0 as record_version
,case when KBABQ_STAT_IND=4 then 'Y' else 'N' end as sum_sw
FROM $$SRC_KB.KB_DRVR A
JOIN $$SRC_KB.KB_PAE_RQST B ON A.PAE_ID = B.PAE_ID
JOIN $$CNV_WRK.PAE_CROSSWALK C ON A.PAE_ID = C.OLD_PAE_ID
JOIN $$CNV_WRK.WRK_LTSS_CLIENTS WRK_LTSS_CLIENTS ON  WRK_LTSS_CLIENTS.KB_PAE_ID = C.OLD_PAE_ID 
WHERE WRK_LTSS_CLIENTS.source_system_nm='KatieBeckett'
AND WRK_LTSS_CLIENTS.VALID_SW = 'Y' 
AND WRK_LTSS_CLIENTS.XREF_VALID_SW = 'Y' 
AND WRK_LTSS_CLIENTS.PERLSS_INDV_ID IS NOT NULL
AND WRK_LTSS_CLIENTS.CV_PHASE = F_GET_CONV_TYPE

UNION
SELECT C.NEW_PAE_ID AS PAE_ID
,'PPPPS' as page_id
,'PPEPR' as module
,case when KBCGD_STAT_IND in (2,4) then 'Y' else 'N' end as visited_sw
,case when KBCGD_STAT_IND in (2,4) then 'Y' else 'N' end as completed_sw
,case when KBCGD_STAT_IND in (1,2,4) then 'Y' else 'N' end as req_sw
,null as inactive_sw
,b.create_user_id as created_by
,b.create_dt as created_dt
,null as last_modified_dt
,0 as record_version
,case when KBCGD_STAT_IND=4 then 'Y' else 'N' end as sum_sw
FROM $$SRC_KB.KB_DRVR A
JOIN $$SRC_KB.KB_PAE_RQST B ON A.PAE_ID = B.PAE_ID
JOIN $$CNV_WRK.PAE_CROSSWALK C ON A.PAE_ID = C.OLD_PAE_ID
JOIN $$CNV_WRK.WRK_LTSS_CLIENTS WRK_LTSS_CLIENTS ON  WRK_LTSS_CLIENTS.KB_PAE_ID = C.OLD_PAE_ID 
WHERE WRK_LTSS_CLIENTS.source_system_nm='KatieBeckett'
AND WRK_LTSS_CLIENTS.VALID_SW = 'Y' 
AND WRK_LTSS_CLIENTS.XREF_VALID_SW = 'Y' 
AND WRK_LTSS_CLIENTS.PERLSS_INDV_ID IS NOT NULL
AND WRK_LTSS_CLIENTS.CV_PHASE = F_GET_CONV_TYPE

UNION
SELECT C.NEW_PAE_ID AS PAE_ID
,'PPPMP' as page_id
,'PPEPR' as module
,case when KBMPX_STAT_IND in (2,4) then 'Y' else 'N' end as visited_sw
,case when KBMPX_STAT_IND in (2,4) then 'Y' else 'N' end as completed_sw
,case when KBMPX_STAT_IND in (1,2,4) then 'Y' else 'N' end as req_sw
,null as inactive_sw
,b.create_user_id as created_by
,b.create_dt as created_dt
,null as last_modified_dt
,0 as record_version
,case when KBMPX_STAT_IND=4 then 'Y' else 'N' end as sum_sw
FROM $$SRC_KB.KB_DRVR A
JOIN $$SRC_KB.KB_PAE_RQST B ON A.PAE_ID = B.PAE_ID
JOIN $$CNV_WRK.PAE_CROSSWALK C ON A.PAE_ID = C.OLD_PAE_ID
JOIN $$CNV_WRK.WRK_LTSS_CLIENTS WRK_LTSS_CLIENTS ON  WRK_LTSS_CLIENTS.KB_PAE_ID = C.OLD_PAE_ID 
WHERE WRK_LTSS_CLIENTS.source_system_nm='KatieBeckett'
AND WRK_LTSS_CLIENTS.VALID_SW = 'Y' 
AND WRK_LTSS_CLIENTS.XREF_VALID_SW = 'Y' 
AND WRK_LTSS_CLIENTS.PERLSS_INDV_ID IS NOT NULL
AND WRK_LTSS_CLIENTS.CV_PHASE = F_GET_CONV_TYPE

UNION
SELECT C.NEW_PAE_ID AS PAE_ID
,'PPPII' as page_id
,'PPEPR' as module
,case when KBITI_STAT_IND in (2,4) then 'Y' else 'N' end as visited_sw
,case when KBITI_STAT_IND in (2,4) then 'Y' else 'N' end as completed_sw
,case when KBITI_STAT_IND in (1,2,4) then 'Y' else 'N' end as req_sw
,null as inactive_sw
,b.create_user_id as created_by
,b.create_dt as created_dt
,null as last_modified_dt
,0 as record_version
,case when KBITI_STAT_IND=4 then 'Y' else 'N' end as sum_sw
FROM $$SRC_KB.KB_DRVR A
JOIN $$SRC_KB.KB_PAE_RQST B ON A.PAE_ID = B.PAE_ID
JOIN $$CNV_WRK.PAE_CROSSWALK C ON A.PAE_ID = C.OLD_PAE_ID
JOIN $$CNV_WRK.WRK_LTSS_CLIENTS WRK_LTSS_CLIENTS ON  WRK_LTSS_CLIENTS.KB_PAE_ID = C.OLD_PAE_ID 
WHERE WRK_LTSS_CLIENTS.source_system_nm='KatieBeckett'
AND WRK_LTSS_CLIENTS.VALID_SW = 'Y' 
AND WRK_LTSS_CLIENTS.XREF_VALID_SW = 'Y' 
AND WRK_LTSS_CLIENTS.PERLSS_INDV_ID IS NOT NULL
AND WRK_LTSS_CLIENTS.CV_PHASE = F_GET_CONV_TYPE

UNION
SELECT C.NEW_PAE_ID AS PAE_ID
,'PPPTS' as page_id
,'PPEPR' as module
,case when KBTSC_STAT_IND in (2,4) then 'Y' else 'N' end as visited_sw
,case when KBTSC_STAT_IND in (2,4) then 'Y' else 'N' end as completed_sw
,case when KBTSC_STAT_IND in (1,2,4) then 'Y' else 'N' end as req_sw
,null as inactive_sw
,b.create_user_id as created_by
,b.create_dt as created_dt
,null as last_modified_dt
,0 as record_version
,case when KBTSC_STAT_IND=4 then 'Y' else 'N' end as sum_sw
FROM $$SRC_KB.KB_DRVR A
JOIN $$SRC_KB.KB_PAE_RQST B ON A.PAE_ID = B.PAE_ID
JOIN $$CNV_WRK.PAE_CROSSWALK C ON A.PAE_ID = C.OLD_PAE_ID
JOIN $$CNV_WRK.WRK_LTSS_CLIENTS WRK_LTSS_CLIENTS ON  WRK_LTSS_CLIENTS.KB_PAE_ID = C.OLD_PAE_ID 
WHERE WRK_LTSS_CLIENTS.source_system_nm='KatieBeckett'
AND WRK_LTSS_CLIENTS.VALID_SW = 'Y' 
AND WRK_LTSS_CLIENTS.XREF_VALID_SW = 'Y' 
AND WRK_LTSS_CLIENTS.PERLSS_INDV_ID IS NOT NULL
AND WRK_LTSS_CLIENTS.CV_PHASE = F_GET_CONV_TYPE

UNION
SELECT C.NEW_PAE_ID AS PAE_ID
,'PPPNF' as page_id
,'PPEPR' as module
,case when KBNFS_STAT_IND in (2,4) then 'Y' else 'N' end as visited_sw
,case when KBNFS_STAT_IND in (2,4) then 'Y' else 'N' end as completed_sw
,case when KBNFS_STAT_IND in (1,2,4) then 'Y' else 'N' end as req_sw
,null as inactive_sw
,b.create_user_id as created_by
,b.create_dt as created_dt
,null as last_modified_dt
,0 as record_version
,case when KBNFS_STAT_IND=4 then 'Y' else 'N' end as sum_sw
FROM $$SRC_KB.KB_DRVR A
JOIN $$SRC_KB.KB_PAE_RQST B ON A.PAE_ID = B.PAE_ID
JOIN $$CNV_WRK.PAE_CROSSWALK C ON A.PAE_ID = C.OLD_PAE_ID
JOIN $$CNV_WRK.WRK_LTSS_CLIENTS WRK_LTSS_CLIENTS ON  WRK_LTSS_CLIENTS.KB_PAE_ID = C.OLD_PAE_ID 
WHERE WRK_LTSS_CLIENTS.source_system_nm='KatieBeckett'
AND WRK_LTSS_CLIENTS.VALID_SW = 'Y' 
AND WRK_LTSS_CLIENTS.XREF_VALID_SW = 'Y' 
AND WRK_LTSS_CLIENTS.PERLSS_INDV_ID IS NOT NULL
AND WRK_LTSS_CLIENTS.CV_PHASE = F_GET_CONV_TYPE

UNION
SELECT C.NEW_PAE_ID AS PAE_ID
,'PPPNT' as page_id
,'PPEPR' as module
,case when KBNUF_STAT_IND in (2,4) then 'Y' else 'N' end as visited_sw
,case when KBNUF_STAT_IND in (2,4) then 'Y' else 'N' end as completed_sw
,case when KBNUF_STAT_IND in (1,2,4) then 'Y' else 'N' end as req_sw
,null as inactive_sw
,b.create_user_id as created_by
,b.create_dt as created_dt
,null as last_modified_dt
,0 as record_version
,case when KBNUF_STAT_IND=4 then 'Y' else 'N' end as sum_sw
FROM $$SRC_KB.KB_DRVR A
JOIN $$SRC_KB.KB_PAE_RQST B ON A.PAE_ID = B.PAE_ID
JOIN $$CNV_WRK.PAE_CROSSWALK C ON A.PAE_ID = C.OLD_PAE_ID
JOIN $$CNV_WRK.WRK_LTSS_CLIENTS WRK_LTSS_CLIENTS ON  WRK_LTSS_CLIENTS.KB_PAE_ID = C.OLD_PAE_ID 
WHERE WRK_LTSS_CLIENTS.source_system_nm='KatieBeckett'
AND WRK_LTSS_CLIENTS.VALID_SW = 'Y' 
AND WRK_LTSS_CLIENTS.XREF_VALID_SW = 'Y' 
AND WRK_LTSS_CLIENTS.PERLSS_INDV_ID IS NOT NULL
AND WRK_LTSS_CLIENTS.CV_PHASE = F_GET_CONV_TYPE

UNION
SELECT C.NEW_PAE_ID AS PAE_ID
,'PPPMR' as page_id
,'PPEPR' as module
,case when KBMDR_STAT_IND in (2,4) then 'Y' else 'N' end as visited_sw
,case when KBMDR_STAT_IND in (2,4) then 'Y' else 'N' end as completed_sw
,case when KBMDR_STAT_IND in (1,2,4) then 'Y' else 'N' end as req_sw
,null as inactive_sw
,b.create_user_id as created_by
,b.create_dt as created_dt
,null as last_modified_dt
,0 as record_version
,case when KBMDR_STAT_IND=4 then 'Y' else 'N' end as sum_sw
FROM $$SRC_KB.KB_DRVR A
JOIN $$SRC_KB.KB_PAE_RQST B ON A.PAE_ID = B.PAE_ID
JOIN $$CNV_WRK.PAE_CROSSWALK C ON A.PAE_ID = C.OLD_PAE_ID
JOIN $$CNV_WRK.WRK_LTSS_CLIENTS WRK_LTSS_CLIENTS ON  WRK_LTSS_CLIENTS.KB_PAE_ID = C.OLD_PAE_ID 
WHERE WRK_LTSS_CLIENTS.source_system_nm='KatieBeckett'
AND WRK_LTSS_CLIENTS.VALID_SW = 'Y' 
AND WRK_LTSS_CLIENTS.XREF_VALID_SW = 'Y' 
AND WRK_LTSS_CLIENTS.PERLSS_INDV_ID IS NOT NULL
AND WRK_LTSS_CLIENTS.CV_PHASE = F_GET_CONV_TYPE

UNION
SELECT C.NEW_PAE_ID AS PAE_ID
,'PPPCD' as page_id
,'PPEPR' as module
,case when KBCGD_STAT_IND in (2,4) then 'Y' else 'N' end as visited_sw
,case when KBCGD_STAT_IND in (2,4) then 'Y' else 'N' end as completed_sw
,case when KBCGD_STAT_IND in (1,2,4) then 'Y' else 'N' end as req_sw
,null as inactive_sw
,b.create_user_id as created_by
,b.create_dt as created_dt
,null as last_modified_dt
,0 as record_version
,case when KBCGD_STAT_IND=4 then 'Y' else 'N' end as sum_sw
FROM $$SRC_KB.KB_DRVR A
JOIN $$SRC_KB.KB_PAE_RQST B ON A.PAE_ID = B.PAE_ID
JOIN $$CNV_WRK.PAE_CROSSWALK C ON A.PAE_ID = C.OLD_PAE_ID
JOIN $$CNV_WRK.WRK_LTSS_CLIENTS WRK_LTSS_CLIENTS ON  WRK_LTSS_CLIENTS.KB_PAE_ID = C.OLD_PAE_ID 
WHERE WRK_LTSS_CLIENTS.source_system_nm='KatieBeckett'
AND WRK_LTSS_CLIENTS.VALID_SW = 'Y' 
AND WRK_LTSS_CLIENTS.XREF_VALID_SW = 'Y' 
AND WRK_LTSS_CLIENTS.PERLSS_INDV_ID IS NOT NULL
AND WRK_LTSS_CLIENTS.CV_PHASE = F_GET_CONV_TYPE

UNION
SELECT C.NEW_PAE_ID AS PAE_ID
,'PPSDD' as page_id
,'PAESP' as module
,case when KBSDC_STAT_IND in (2,4) then 'Y' else 'N' end as visited_sw
,case when KBSDC_STAT_IND in (2,4) then 'Y' else 'N' end as completed_sw
,case when KBSDC_STAT_IND in (1,2,4) then 'Y' else 'N' end as req_sw
,null as inactive_sw
,b.create_user_id as created_by
,b.create_dt as created_dt
,null as last_modified_dt
,0 as record_version
,case when KBSDC_STAT_IND=4 then 'Y' else 'N' end as sum_sw
FROM $$SRC_KB.KB_DRVR A
JOIN $$SRC_KB.KB_PAE_RQST B ON A.PAE_ID = B.PAE_ID
JOIN $$CNV_WRK.PAE_CROSSWALK C ON A.PAE_ID = C.OLD_PAE_ID
JOIN $$CNV_WRK.WRK_LTSS_CLIENTS WRK_LTSS_CLIENTS ON  WRK_LTSS_CLIENTS.KB_PAE_ID = C.OLD_PAE_ID 
WHERE WRK_LTSS_CLIENTS.source_system_nm='KatieBeckett'
AND WRK_LTSS_CLIENTS.VALID_SW = 'Y' 
AND WRK_LTSS_CLIENTS.XREF_VALID_SW = 'Y' 
AND WRK_LTSS_CLIENTS.PERLSS_INDV_ID IS NOT NULL
AND WRK_LTSS_CLIENTS.CV_PHASE = F_GET_CONV_TYPE

UNION
SELECT C.NEW_PAE_ID AS PAE_ID
,'PPSPS' as page_id
,'PAESU' as module
,case when KBASU_STAT_IND in (2,4) then 'Y' else 'N' end as visited_sw
,case when KBASU_STAT_IND in (2,4) then 'Y' else 'N' end as completed_sw
,case when KBASU_STAT_IND in (1,2,4) then 'Y' else 'N' end as req_sw
,null as inactive_sw
,b.create_user_id as created_by
,b.create_dt as created_dt
,null as last_modified_dt
,0 as record_version
,case when KBASU_STAT_IND=4 then 'Y' else 'N' end as sum_sw
FROM $$SRC_KB.KB_DRVR A
JOIN $$SRC_KB.KB_PAE_RQST B ON A.PAE_ID = B.PAE_ID
JOIN $$CNV_WRK.PAE_CROSSWALK C ON A.PAE_ID = C.OLD_PAE_ID
JOIN $$CNV_WRK.WRK_LTSS_CLIENTS WRK_LTSS_CLIENTS ON  WRK_LTSS_CLIENTS.KB_PAE_ID = C.OLD_PAE_ID 
WHERE WRK_LTSS_CLIENTS.source_system_nm='KatieBeckett'
AND WRK_LTSS_CLIENTS.VALID_SW = 'Y' 
AND WRK_LTSS_CLIENTS.XREF_VALID_SW = 'Y' 
AND WRK_LTSS_CLIENTS.PERLSS_INDV_ID IS NOT NULL
AND WRK_LTSS_CLIENTS.CV_PHASE = F_GET_CONV_TYPE

UNION
SELECT C.NEW_PAE_ID AS PAE_ID
,'PPSRR' as page_id
,'PAESU' as module
,case when KBASU_STAT_IND=4 then 'Y' else 'N' end as visited_sw
,case when KBASU_STAT_IND=4 then 'Y' else 'N' end as completed_sw
,case when KBASU_STAT_IND=4 then 'Y' else 'N' end as req_sw
,null as inactive_sw
,b.create_user_id as created_by
,b.create_dt as created_dt
,null as last_modified_dt
,0 as record_version
,case when KBASU_STAT_IND=4 then 'Y' else 'N' END as sum_sw
FROM $$SRC_KB.KB_DRVR A
JOIN $$SRC_KB.KB_PAE_RQST B ON A.PAE_ID = B.PAE_ID
JOIN $$CNV_WRK.PAE_CROSSWALK C ON A.PAE_ID = C.OLD_PAE_ID
JOIN $$CNV_WRK.WRK_LTSS_CLIENTS WRK_LTSS_CLIENTS ON  WRK_LTSS_CLIENTS.KB_PAE_ID = C.OLD_PAE_ID 
WHERE WRK_LTSS_CLIENTS.source_system_nm='KatieBeckett'
AND WRK_LTSS_CLIENTS.VALID_SW = 'Y' 
AND WRK_LTSS_CLIENTS.XREF_VALID_SW = 'Y' 
AND WRK_LTSS_CLIENTS.PERLSS_INDV_ID IS NOT NULL
AND WRK_LTSS_CLIENTS.CV_PHASE = F_GET_CONV_TYPE

UNION
SELECT C.NEW_PAE_ID AS PAE_ID
,'PPLOC' as page_id
,'PAESU' as module
,case when KBLOC_STAT_IND in (2,4) then 'Y' else 'N' end as visited_sw
,case when KBLOC_STAT_IND in (2,4) then 'Y' else 'N' end as completed_sw
,case when KBLOC_STAT_IND in (1,2,4) then 'Y' else 'N' end as req_sw
,null as inactive_sw
,b.create_user_id as created_by
,b.create_dt as created_dt
,null as last_modified_dt
,0 as record_version
,case when KBLOC_STAT_IND=4 then 'Y' else 'N' end as sum_sw
FROM $$SRC_KB.KB_DRVR A
JOIN $$SRC_KB.KB_PAE_RQST B ON A.PAE_ID = B.PAE_ID
JOIN $$CNV_WRK.PAE_CROSSWALK C ON A.PAE_ID = C.OLD_PAE_ID
JOIN $$CNV_WRK.WRK_LTSS_CLIENTS WRK_LTSS_CLIENTS ON  WRK_LTSS_CLIENTS.KB_PAE_ID = C.OLD_PAE_ID 
WHERE WRK_LTSS_CLIENTS.source_system_nm='KatieBeckett'
AND WRK_LTSS_CLIENTS.VALID_SW = 'Y' 
AND WRK_LTSS_CLIENTS.XREF_VALID_SW = 'Y' 
AND WRK_LTSS_CLIENTS.PERLSS_INDV_ID IS NOT NULL
AND WRK_LTSS_CLIENTS.CV_PHASE = F_GET_CONV_TYPE) A
;

SELECT  
'1' as Default_Port
,NULL	doc_id 
,null doc
,null	created_by
,null	created_dt
,null	last_modified_by
,null	last_modified_dt
,0	record_version
,null	archived_dt
,CASE WHEN LTRIM(RTRIM(A.DELETE_SW))  IS NULL THEN 'N' ELSE A.DELETE_SW END	delete_sw
,CASE WHEN LTRIM(RTRIM(A.FN_DOCUMENT_ID)) IS NOT NULL THEN 'Y' ELSE 'N' END AS	filenet_upload_sw
,'app_doc' table_name
,A.DESTINATION_CD	destination_cd
,LTRIM(RTRIM(A.DOC_TYPE_CD))	doc_type
,WRK_LTSS_CLIENTS.PERLSS_INDV_ID AS  prsn_id
,A.PAE_ID	pae_id
,A.REF_ID	ref_id
,'N' AS  app_pdf_sw
, 'Y' AS on_prem_flag
,  LTRIM(RTRIM(A.FN_DOCUMENT_ID))  AS on_prem_filenet_id
--select *
--FROM LT_CNV_SRC_KB.kb_doc_dtl A
--LEFT JOIN LT_CNV_SRC_KB.kb_documents B ON A.DOC_SEQ_NUM =B.DOC_SEQ_NUM
FROM $$SRC_KB.KB_DOC_DTL A
JOIN $$CNV_WRK.WRK_LTSS_CLIENTS WRK_LTSS_CLIENTS ON  (WRK_LTSS_CLIENTS.KB_PAE_ID = A.PAE_ID AND WRK_LTSS_CLIENTS.KB_REF_ID = A.REF_ID)
WHERE WRK_LTSS_CLIENTS.source_system_nm='KatieBeckett'
AND WRK_LTSS_CLIENTS.VALID_SW = 'Y' 
AND WRK_LTSS_CLIENTS.XREF_VALID_SW = 'Y' 
AND WRK_LTSS_CLIENTS.PERLSS_INDV_ID IS NOT NULL
AND A.PAE_ID ='PAE100000004'
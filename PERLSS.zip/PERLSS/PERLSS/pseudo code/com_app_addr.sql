SELECT 
'com_app_addr' as table_name
,ltrim(rtrim(A.APT_L1_ADDR))	addr_line_1
,ltrim(rtrim(A.APT_L2_ADDR))	addr_line_2
,ltrim(rtrim(A.APT_CITY))	city
,ltrim(rtrim(A.APT_STATE_CD))	state_cd
,ltrim(rtrim(A.APT_ZIPCODE))	zip
,ltrim(rtrim(A.APT_ZIP_EXTN))	extsn
,ltrim(rtrim(A.APT_CNTY_CD))	county_cd
,A.CREATE_DT	created_dt
,ltrim(rtrim(A.UPDATE_USER_ID))	last_modified_by
,A.UPDATE_DT	last_modified_dt
,0 AS	 record_version
,F_GET_ARCHIVE_DATE AS	archived_dt
,ltrim(rtrim(A.CREATE_USER_ID))	created_by
,NULL AS	app_id
--SELECT COUNT(1)
FROM $$SRC_KB.KB_RI_APPOINTMENTS A
;
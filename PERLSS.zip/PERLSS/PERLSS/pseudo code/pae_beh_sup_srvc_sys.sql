SELECT distinct
1 as default_port
,A.PAE_ID	pae_id
,LTRIM(RTRIM(A.CMHS_SW))	crisis_men_hlth_srvc_sw
,LTRIM(RTRIM(A.CPS_SW))	child_protective_srvc_sw
,LTRIM(RTRIM(A.CJS_SW))	criminal_justice_sys_sw
,NULL	created_dt
,NULL	last_modified_by
,NULL	last_modified_dt
,0	record_version
,NULL	archived_dt
,NULL	created_by
-- SELECT *
FROM $$SRC_KB.KB_BHS_SERVICE_SYSTEMS A
JOIN $$CNV_WRK.WRK_LTSS_CLIENTS WRK_LTSS_CLIENTS ON  WRK_LTSS_CLIENTS.KB_PAE_ID = A.PAE_ID 
WHERE WRK_LTSS_CLIENTS.source_system_nm='KatieBeckett'
AND WRK_LTSS_CLIENTS.VALID_SW = 'Y' 
AND WRK_LTSS_CLIENTS.XREF_VALID_SW = 'Y' 
AND WRK_LTSS_CLIENTS.PERLSS_INDV_ID IS NOT NULL
;
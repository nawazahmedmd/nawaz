SELECT distinct
1 as default_port
, A.PAE_ID	pae_id
, LTRIM(RTRIM(A.SPEC_TRAN_SW))	applcnt_amb_splcare_sw
, LTRIM(RTRIM(A.TRANS_EQUIP_SW)) 	applcnt_trnsprt_equip_sw
, LTRIM(RTRIM(A.SPEC_MON_SW))	applcnt_spclzd_monitor_sw
, CASE When LTRIM(RTRIM(A.VISITS_SW))='1' then 'Y' Else 'N' END	req_six_primary_6months_sw
, CASE When LTRIM(RTRIM(A.TRAN_PRIM_SW))='1' then 'Y' Else 'N' END	req_trnsprtn_fifty_primary_sw
, CASE When LTRIM(RTRIM(A.TRAN_SPEC_SW))='1' then 'Y' Else 'N' END	req_trnsprtn_fifty_spclty_sw
, CASE WHEN (LTRIM(RTRIM(A.SPEC_TRAN_SW))='Y' 
      OR LTRIM(RTRIM(A.TRANS_EQUIP_SW))='Y' 
	  OR LTRIM(RTRIM(A.SPEC_MON_SW))='Y' 
	  OR LTRIM(RTRIM(A.VISITS_SW))='1' 
	  OR LTRIM(RTRIM(A.TRAN_PRIM_SW))='1' 
	  OR LTRIM(RTRIM(A.TRAN_SPEC_SW))='1') THEN 'N' ELSE 'Y' END 	not_applicable_sw
,NULL	created_dt
,NULL	last_modified_by
,NULL	last_modified_dt
,0	record_version
,NULL	archived_dt
,NULL	created_by
--SELECT *
FROM $$SRC_KB.KB_PD_TRANS_CARE A
JOIN $$CNV_WRK.WRK_LTSS_CLIENTS WRK_LTSS_CLIENTS ON  WRK_LTSS_CLIENTS.KB_PAE_ID = A.PAE_ID 
WHERE WRK_LTSS_CLIENTS.source_system_nm='KatieBeckett'
AND WRK_LTSS_CLIENTS.VALID_SW = 'Y' 
AND WRK_LTSS_CLIENTS.XREF_VALID_SW = 'Y' 
AND WRK_LTSS_CLIENTS.PERLSS_INDV_ID IS NOT NULL
;






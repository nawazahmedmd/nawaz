SELECT DISTINCT
1 as default_port
,A.PAE_ID	pae_id
,'KB'	program_type_cd
,A.CREATE_DT	program_rqst_dt
,null	choices_grp_3_sw
,NULL	actual_discharge_dt
,NULL	created_dt
,NULL	last_modified_by
,NULL	last_modified_dt
,0	record_version
,NULL	archived_dt
,NULL	created_by
--SELECT *
FROM $$SRC_KB.KB_PAE_RQST A
JOIN $$CNV_WRK.WRK_LTSS_CLIENTS WRK_LTSS_CLIENTS ON  WRK_LTSS_CLIENTS.KB_PAE_ID = A.PAE_ID 
WHERE WRK_LTSS_CLIENTS.source_system_nm='KatieBeckett'
AND WRK_LTSS_CLIENTS.VALID_SW = 'Y' 
AND WRK_LTSS_CLIENTS.XREF_VALID_SW = 'Y' 
AND WRK_LTSS_CLIENTS.PERLSS_INDV_ID IS NOT NULL
;
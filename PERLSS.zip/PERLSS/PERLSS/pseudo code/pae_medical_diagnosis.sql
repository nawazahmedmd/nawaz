SELECT
 'pae_medical_diagnosis' as table_name
,B.NEW_PAE_ID	pae_id
, 'N' AS 	intlctl_dis_sw  -- 'N' as database column is defaulted to 'N'
, 'N' AS 	psyclgcl_eval_sw  --'N' as database column is defaulted to 'N'
, NULL AS 	lvl_intlctl_disblty_cd
, NULL AS 	iq_test_score
, NULL AS 	iq_test_dt
, NULL AS 	iq_test_type_desc
, 'Y' AS 	chrnc_diagns_sw
, NULL AS 	trgt_popltn_diagns_cd
, NULL AS 	doc_dtls_desc
,AA.CREATE_DT	created_dt
,LTRIM(RTRIM(AA.UPDATE_USER_ID))	last_modified_by
,AA.UPDATE_DT	last_modified_dt
, 0 AS 	record_version
, F_GET_ARCHIVE_DATE AS 	archived_dt
,LTRIM(RTRIM(AA.CREATE_USER_ID))	created_by
, NULL AS 	id_diagns_doc_sw
, NULL AS 	iq_score_avail_sw
, NULL AS 	iq_score_nottest_sw
, NULL AS 	iq_score_not_avail_sw
FROM
(SELECT A.PAE_ID,A.CREATE_USER_ID , A.UPDATE_DT , A.UPDATE_USER_ID , A.CREATE_DT  FROM
(SELECT A.*, MAX(A.SEQ_NUM) OVER (PARTITION BY A.PAE_ID) AS LATEST_REC
FROM $$SRC_KB.KB_DS_MED_DIAGNOSIS A) A
WHERE A.LATEST_REC = A.SEQ_NUM) AA 
JOIN $$CNV_WRK.PAE_CROSSWALK B ON AA.PAE_ID = B.OLD_PAE_ID
JOIN $$CNV_WRK.WRK_LTSS_CLIENTS WRK_LTSS_CLIENTS ON  WRK_LTSS_CLIENTS.KB_PAE_ID = B.OLD_PAE_ID 
WHERE WRK_LTSS_CLIENTS.source_system_nm='KatieBeckett'
AND WRK_LTSS_CLIENTS.VALID_SW = 'Y' 
AND WRK_LTSS_CLIENTS.XREF_VALID_SW = 'Y' 
AND WRK_LTSS_CLIENTS.PERLSS_INDV_ID IS NOT NULL
AND WRK_LTSS_CLIENTS.CV_PHASE = F_GET_CONV_TYPE
;
SELECT distinct
1 as default_port
,A.PAE_ID	pae_id
,F_GET_REFERENCE_DATA('KB_PD_CARE_GIVING',ltrim(rtrim(A.SKILLED_INTV_CD)),'CAREGIVER_INTERVENTIONS')	cargvr_intervn_cd
,CASE WHEN A.NIGHT_MON_CD= 'CS' THEN  'OA'
	  WHEN A.NIGHT_MON_CD= 'NT' THEN  'II'
	  WHEN A.NIGHT_MON_CD= 'NA' THEN  'NA' END	applcnt_frqcy_awake_monitor_cd
,CASE WHEN ltrim(rtrim(A.HANDS_ON_SW))= 1 THEN 'Y' ELSE 'N' END	hands_on_caregvng_sw
,CASE WHEN ltrim(rtrim(A.CONTRACT_SW))= 1 THEN 'Y' ELSE 'N' END	musculo_contrac_deform_sw
,CASE WHEN ltrim(rtrim(A.CHOKING_SW))= 1 THEN 'Y' ELSE 'N' END	risk_choking_rsp_dis_sw
,CASE WHEN ltrim(rtrim(A.BEHAVE_PLAN_SW))= 1 THEN 'Y' ELSE 'N' END	impl_behavrl_plan_sw
,CASE WHEN ltrim(rtrim(A.LOC_MONITORING_SW))= 1 THEN 'Y' ELSE 'N' END	req_lctn_monitoring_sw
,CASE WHEN ltrim(rtrim(A.HOME_ED_SW))= 1 THEN 'Y' ELSE 'N' END	home_bound_edu_sw
,CASE WHEN (ltrim(rtrim(A.HANDS_ON_SW))= 1 
				OR ltrim(rtrim(A.CONTRACT_SW))= 1
				OR ltrim(rtrim(A.CHOKING_SW))= 1
				OR ltrim(rtrim(A.BEHAVE_PLAN_SW))= 1
				OR ltrim(rtrim(A.LOC_MONITORING_SW))= 1
				 ) THEN 'Y' ELSE 'N' END othr_care_none_above_sw 
,F_GET_REFERENCE_DATA('KB_PD_CARE_GIVING',ltrim(rtrim(A.FAMILY_TYPE_CD)),'PARENT_FAMILY')	single_two_parent_fmly_cd
,ltrim(rtrim(A.OTHER_CAREGIVER_CD))	othr_adlt_cargvr_sw
,CASE WHEN ltrim(rtrim(A.SINGLE_PARENT_HLTH_PROB_CD))='Y' THEN 'Y' ELSE 'N' END	parent_hlth_dis_sw
,CASE WHEN ltrim(rtrim(A.PARENTS_HLTH_PROB_CD)) IS NULL THEN 'NO' 
     ELSE F_GET_REFERENCE_DATA('KB_PD_CARE_GIVING',ltrim(rtrim(A.PARENTS_HLTH_PROB_CD)),'PARENT_HEALTH_PROBLEM') END	more_parent_hlth_dis_cd
,CASE WHEN ltrim(rtrim(A.MORE_CHILD_SW))= 1 THEN 'Y' ELSE 'N' END	more_child_dis_sw
,CASE WHEN ltrim(rtrim(A.OTHER_ADULT_SW))= 1 THEN 'Y' ELSE 'N' END	othr_adlt_dis_sw
,CASE WHEN ltrim(rtrim(A.OTHER_CHILDREN_SW))= 1 THEN 'Y' ELSE 'N' END	othr_child_liv_home_sw
,CASE WHEN ltrim(rtrim(A.PARENT_CAREGIVER_SW))= 1 THEN 'Y' ELSE 'N' END	parent_adlt_dis_sw
,CASE WHEN (ltrim(rtrim(A.MORE_CHILD_SW))= 1 
			OR ltrim(rtrim(A.OTHER_ADULT_SW))= 1
			OR ltrim(rtrim(A.OTHER_CHILDREN_SW))= 1
			OR ltrim(rtrim(A.PARENT_CAREGIVER_SW))= 1) THEN 'Y' ELSE 'N' END add_none_above_sw 
,NULL	created_dt
,NULL	last_modified_by
,NULL	last_modified_dt
,0	record_version
,NULL	archived_dt
,NULL	created_by
FROM $$SRC_KB.KB_PD_CARE_GIVING A
JOIN $$CNV_WRK.WRK_LTSS_CLIENTS WRK_LTSS_CLIENTS ON  WRK_LTSS_CLIENTS.KB_PAE_ID = A.PAE_ID 
WHERE WRK_LTSS_CLIENTS.source_system_nm='KatieBeckett'
AND WRK_LTSS_CLIENTS.VALID_SW = 'Y' 
AND WRK_LTSS_CLIENTS.XREF_VALID_SW = 'Y' 
AND WRK_LTSS_CLIENTS.PERLSS_INDV_ID IS NOT NULL
;


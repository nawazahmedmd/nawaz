SELECT distinct
1 as default_port,
'Y' external_ref_sw,
NULL AS DOC_ID,
'N' pdf_generated_sw,
WRK_LTSS_CLIENTS.PERLSS_INDV_ID prsn_id,
F_GET_REFERENCE_DATA('KB_REF_STATUS',LTRIM(RTRIM(B.REF_STATUS_CD)),'KB_REFERRAL_STATUS') AS  ref_status,
'KB' AS  program_cd,
NULL AS  start_dt,
A.RECEIVED_DT AS  submsn_dt,
LTRIM(RTRIM(A.SOURCE_CD)) AS  source_cd ,
'KB' AS  ref_type_cd,
NULL AS  entity_type,
Null AS  archived_dt,
Null AS  created_by ,
Null AS  created_dt ,
NULL AS  last_modified_by,
NULL  AS  last_modified_dt,
0 AS  record_version,
'N' AS new_prsn_sw,
A.REF_ID AS  legacy_id,
'808' AS entity_id,
LTRIM(RTRIM(A.MA_STANDARD_SW)) AS  ma_standard_sw,
LTRIM(RTRIM(A.NINETY_DAY_RECON_SW)) AS ninety_day_recon_sw,
LTRIM(RTRIM(A.RENEWAL_REQD_SW)) as renewal_reqd_sw,
LTRIM(RTRIM(A.INDV_ID)) AS teds_indv_id 
--SELECT *
FROM $$SRC_KB.KB_REF_RQST A 
JOIN (SELECT REF_ID, REF_STATUS_CD FROM $$SRC_KB.KB_REF_STATUS WHERE EFF_END_DT IS NULL) B ON A.REF_ID = B.REF_ID
JOIN $$CNV_WRK.WRK_LTSS_CLIENTS WRK_LTSS_CLIENTS ON  WRK_LTSS_CLIENTS.KB_REF_ID = A.REF_ID 
WHERE WRK_LTSS_CLIENTS.source_system_nm='KatieBeckett'
AND WRK_LTSS_CLIENTS.VALID_SW = 'Y' 
AND WRK_LTSS_CLIENTS.XREF_VALID_SW = 'Y' 
AND WRK_LTSS_CLIENTS.PERLSS_INDV_ID IS NOT NULL
--AND WRK_LTSS_CLIENTS.CV_PHASE = '$$CNV_PHASE'
;

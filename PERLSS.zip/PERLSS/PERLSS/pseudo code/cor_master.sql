SELECT
 'cor_master' as table_name
,LTRIM(RTRIM(A.DOC_ID))	doc_id
,LTRIM(RTRIM(A.DOC_NAME))	doc_name
,LTRIM(RTRIM(A.GENERATE_MANUALLY_SW))	generate_manually_sw
,LTRIM(RTRIM(A.DOC_TYPE_CD))	doc_type_cd
,LTRIM(RTRIM(A.PRINT_MODE_CD))	print_mode_cd
,NULL	freeform_sw
,NULL	mass_enabled_sw
,NULL	prirty_num
,LTRIM(RTRIM(A.NOTICE_VERSION))	notice_version
,LTRIM(RTRIM(A.NOTICE_DT_VERSION_TXT))	notice_dt_version_txt
,LTRIM(RTRIM(A.UPDATE_USER_ID))	last_modified_by
,A.UPDATE_DT	last_modified_dt
,0	record_version
,LTRIM(RTRIM(A.CREATE_USER_ID))	created_by
,A.CREATE_DT	created_dt
,F_GET_ARCHIVE_DATE	archived_dt
,'Y'	active_sw
,LTRIM(RTRIM(A.PUB_FILE_NAME))	pub_file_name
,NULL	notice_category
--SELECT *
FROM $$SRC_KB.KB_CO_MASTER A
;

SELECT distinct 
1 as default_port
,P.PAE_ID	pae_id
, F_GET_REFERENCE_DATA('KB_RI_APP_DTL',LTRIM(RTRIM(A.CURRENT_LIVING_CD)),'KBLIVARRANGE')	curr_lvng_arrgmnt_cd
, NULL AS	lvng_arrgmnt_desc
, NULL AS	nursing_facility_name_cd
, NULL AS	addr_line_1
, NULL AS	addr_line_2
, NULL AS	city
, NULL AS	state_cd
, NULL AS	zip
, NULL AS	extsn
, NULL AS	cnty_cd
, NULL AS	ph_num
, CASE WHEN LTRIM(RTRIM(A.LIV_LTC_SW))='1' THEN 'Y' ELSE 'N' END long_term_care_sw
, CASE WHEN LTRIM(RTRIM(A.LIV_HOSP_SW))='1' THEN 'Y' ELSE 'N' END phychiatric_hosp_sw
, CASE WHEN LTRIM(RTRIM(A.LIV_MENTAL_SW))='1' THEN 'Y' ELSE 'N' END mental_hlth_sw
, CASE WHEN LTRIM(RTRIM(A.LIV_SPEC_SW))='1' THEN 'Y' ELSE 'N' END	special_sch_sw
, CASE WHEN LTRIM(RTRIM(A.LIV_IDD_SW))='1' THEN 'Y'	ELSE 'N' END intlctl_disable_sw
, CASE WHEN LTRIM(RTRIM(A.LIV_PD_SW))='1' THEN 'Y'	ELSE 'N' END phycl_disable_sw
, CASE WHEN (LTRIM(RTRIM(A.LIV_LTC_SW)) = '1' 
             OR LTRIM(RTRIM(A.LIV_HOSP_SW))='1'
             OR LTRIM(RTRIM(A.LIV_SPEC_SW))='1'	
			 OR LTRIM(RTRIM(A.LIV_MENTAL_SW))='1'
			 OR LTRIM(RTRIM(A.LIV_IDD_SW))='1'
			 OR LTRIM(RTRIM(A.LIV_PD_SW))='1') THEN 'N' ELSE 'Y' END AS	none_sw
, CASE WHEN LTRIM(RTRIM(A.SCHOOL_OUTSIDE_HOME_SW))='Y' THEN 'Y' ELSE 'N' END	sch_outside_sw
, NULL AS	admsn_dt
, NULL AS	expctd_discharge_cd
, NULL AS	anticipated_discharge_dt
, NULL AS	incarceration_dt
, NULL AS	anticipated_release_dt
, NULL AS	created_dt
, NULL	last_modified_by
, NULL	last_modified_dt
, 0 AS	record_version
, NULL AS	archived_dt
, NULL	created_by
, NULL AS	othr_facility_name
, NULL AS	org_id
, NULL AS	org_loc_id
, NULL AS		provider_id
--SELECT 
FROM $$SRC_KB.kb_ri_app_dtl A
JOIN $$SRC_KB.KB_PAE_RQST P ON A.REF_ID = P.REF_ID
JOIN $$CNV_WRK.WRK_LTSS_CLIENTS WRK_LTSS_CLIENTS ON  (WRK_LTSS_CLIENTS.KB_PAE_ID = P.PAE_ID and WRK_LTSS_CLIENTS.KB_REF_ID = A.REF_ID)
WHERE WRK_LTSS_CLIENTS.source_system_nm='KatieBeckett'
AND WRK_LTSS_CLIENTS.VALID_SW = 'Y' 
AND WRK_LTSS_CLIENTS.XREF_VALID_SW = 'Y' 
AND WRK_LTSS_CLIENTS.PERLSS_INDV_ID IS NOT NULL
--AND WRK_LTSS_CLIENTS.CV_PHASE = F_GET_CONV_TYPE;
SELECT distinct 
1 as default_port
,A.REF_ID AS REF_ID
,WRK_LTSS_CLIENTS.PERLSS_INDV_ID	prsn_id 
,null	intel_disable_sw
,null	none_disable_sw
,null	dev_disable_sw
,NULL	diagns_txt
,NULL	created_by
,NULL	created_dt
,NULL	last_modified_by
,NULL	last_modified_dt
,0	RECORD_VERSION
,NULL	ARCHIVED_DT
FROM $$SRC_KB.KB_RI_APP_DTL A
JOIN $$CNV_WRK.WRK_LTSS_CLIENTS WRK_LTSS_CLIENTS ON  WRK_LTSS_CLIENTS.KB_REF_ID = A.REF_ID
WHERE WRK_LTSS_CLIENTS.source_system_nm='KatieBeckett'
AND WRK_LTSS_CLIENTS.VALID_SW = 'Y' 
AND WRK_LTSS_CLIENTS.XREF_VALID_SW = 'Y' 
AND WRK_LTSS_CLIENTS.PERLSS_INDV_ID IS NOT NULL
;

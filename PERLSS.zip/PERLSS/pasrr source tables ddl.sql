create table legacy.pasrr_demographics
(IndividualID varchar(36),
LastName varchar(20), 
FirstName varchar(20),
MiddleInitial varchar(1),
SSN varchar(11),
DOB date,
Gender varchar(1),
created_dt TIMESTAMP,
filename varchar(250)
);


create table legacy.pasrr_Events
 ( EventID  varchar(36)
,IndividualID  varchar(36)
,GuardianFirstName varchar(20) 
,GuardianLastName varchar(20 )
,GuardianAddress varchar(100)
,GuardianAddress2 varchar(100)
,GuardianCity varchar(50)
,GuardianState varchar(2)
,GuardianZip varchar(5)
,IndividualAddress1 varchar(100)
,IndividualAddress2 varchar(100)
,IndividualCity varchar(50)
,IndividualState varchar(2)
,IndividualZip varchar(5)
,IndividualCounty varchar(20)
,PayerSource varchar(50)
,HospitalAdmitDate date
,NFAdmitDate date
,ReviewType varchar(50)
,created_dt TIMESTAMP
,filename varchar(250)
);






create table legacy.pasrr_Level_I
(EventID 	varchar(36)
,Level1Outcome	varchar(60)
,Level1DeterminationDate	TIMESTAMP
,Level1LetterTypeSent	varchar(30)
,Level1SubmissionDate	TIMESTAMP
,Level1LetterSentDate	TIMESTAMP
,Level1DeterminationEffectiveDate	TIMESTAMP
,Level1DeterminationEndDate	TIMESTAMP
,Level1SubmitterLastName	varchar(20)
,Level1SubmitterFirstName	varchar(20)
,Level1SubmittingFacility	varchar(255)
,Level1SubmittingFacilityAddress	varchar(100)
,Level1SubmittingFacilityCity	varchar(50)
,Level1SubmittingFacilityState	varchar(2)
,Level1SubmittingFacilityZip	varchar(5)
,created_dt TIMESTAMP
,filename varchar(250)
);


create table legacy.pasrr_Level_II
(EventID	varchar(36)
,Level2NoticeType	varchar(40)
,Level2NoticeSentDate	TIMESTAMP
,Level2SentToStateDate	TIMESTAMP
,Level2AssessmentDate	TIMESTAMP
,Level2Outcome	varchar(50)
,Level2DeterminationDate	TIMESTAMP
,Level2DeterminationEffectiveDate	TIMESTAMP
,Level2DeterminationEndDate	TIMESTAMP
,Level2SpecializedServicesDetermination	varchar(5)
,Level2SkilledServiceApprovedStartDate	TIMESTAMP
,Level2SkilledServiceEndDate	TIMESTAMP
,Leve2ApprovedSTReason	varchar(20)
,Level2ShortTermDays	int4
,Level2PASRRCondition	varchar(10)
,created_dt TIMESTAMP
,filename varchar(250)
);


create table legacy.pasrr_LOC
(EventID 	varchar(36)
,LOCReimbursementLevel	varchar(50)
,ReferralDate	TIMESTAMP
,ReferralName	varchar(50)
,ReferralFacility	varchar(255)
,LOCOutcome	varchar(50)
,LOCDeterminationDate	TIMESTAMP
,SafetyFormRequest	varchar(5)
,ReferralComments	varchar(25614)
,DiagnosisRelevantToNeeds	varchar(30710)
,SafetyFormDeclinedDate	TIMESTAMP
,Rationale	varchar(4253)
,AttestationDate	TIMESTAMP
,SubmittedAcuityScore	int2
,ApprovedAcuityScore	int2
,FunctionalDeficitIdentified	varchar(5)
,SafetyFormReviewed	varchar(5)
,SafetyFormOutcome	varchar(50)
,SkilledServicesApproved	varchar(5)
,SkilledServicesDuration	int4
,ADLTransfer	varchar(20)
,ADLTransferClinicianDetermination	varchar(20)
,ADLTransferClinicianResponse	varchar(20)
,ADLTransferDenialReason	varchar(50)
,ADLTransferRationale	varchar(1110)
,ADLWalking	varchar(20)
,ADLWalkingClinicianDetermination	varchar(20)
,ADLWalkingClinicianResponse	varchar(20)
,ADLWalkingDenialReason	varchar(50)
,ADLWalkingRationale	varchar(1110)
,ADLMobility	varchar(20)
,ADLMobilityClinicianDetermination	varchar(20)
,ADLMobilityClinicianResponse	varchar(20)
,ADLMobilityDenialReason	varchar(50)
,ADLMobilityRationale	varchar(1110)
,ADLEating	varchar(20)
,ADLEatingClinicianDetermination	varchar(20)
,ADLEatingClinicianResponse	varchar(20)
,ADLEatingDenialReason	varchar(50)
,ADLEatingRationale	varchar(1214)
,ADLToileting	varchar(20)
,ADLToiletingClinicianDetermination	varchar(20)
,ADLToiletingClinicianResponse	varchar(20)
,ADLToiletingDenialReason	varchar(50)
,ADLToiletingRationale	varchar(1110)
,ADLIncontinentCare	varchar(20)
,ADLIncontinentCareClinicianDetermination	varchar(20)
,ADLIncontinentCareClinicianResponse	varchar(20)
,ADLIncontinentCareDenialReason	varchar(50)
,ADLIncontinentBowel	varchar(5)
,ADLIncontinentBladder	varchar(5)
,ADLIncontinentCareRationale	varchar(407)
,ADLCatheterCare	varchar(20)
,ADLCatheterCareClinicianDetermination	varchar(20)
,ADLCatheterCareClinicianResponse	varchar(20)
,ADLCatheterCareDenialReason	varchar(50)
,ADLCatheterCareRationale	varchar(345)
,ADLOrientation	varchar(20)
,ADLOrientationClinicianDetermination	varchar(20)
,ADLOrientationClinicianResponse	varchar(20)
,ADLOrientationDenialReason	varchar(50)
,ADLOrientationRationale	varchar(853)
,ADLExpressive	varchar(20)
,ADLExpressiveClinicianDetermination	varchar(20)
,ADLExpressiveClinicianResponse	varchar(20)
,ADLExpressiveDenialReason	varchar(50)
,ADLExpressiveRationale	varchar(444)
,ADLReceptive	varchar(20)
,ADLReceptiveClinicianDetermination	varchar(20)
,ADLReceptiveClinicianResponse	varchar(20)
,ADLReceptiveDenialReason	varchar(50)
,ADLReceptiveRationale	varchar(813)
,ADLMedsAdmin	varchar(20)
,ADLMedsAdminClinicianDetermination	varchar(20)
,ADLMedsAdminClinicianResponse	varchar(20)
,ADLMedsAdminDenialReason	varchar(50)
,ADLMedsAdminRationale	varchar(11025)
,ADLMedsAdminNotes	varchar(10578)
,ADLBehavior	varchar(20)
,ADLBehaviorClinicianDetermination	varchar(20)
,ADLBehaviorClinicianResponse	varchar(20)
,ADLBehaviorDenialReason	varchar(50)
,ADLBehaviorRationale	varchar(1260)
,ADLBehaviorNotes	varchar(6487)
,ChronicVentilatorServices	varchar(5)
,VentilatorClinicalDetermination	varchar(10)
,VentilatorRationale	varchar(3236)
,TrachealSuctioning	varchar(5)
,TrachealSuctioningClinicalDetermination	varchar(10)
,TrachealSuctioningRationale	varchar(3236)
,WoundCareDecubitus	varchar(5)
,WoundCareDecubitusStartDate	date
,WoundCareDecubitusEndDate	date
,WoundCareDecubitusClinicalDetermination	varchar(10)
,WoundCareDecubitusRationale	varchar(3236)
,WoundCareOther	varchar(5)
,WoundCareOtherStartDate	date
,WoundCareOtherEndDate	date
,WoundCareOtherClinicalDetermination	varchar(10)
,WoundCareOtherRationale	varchar(3236)
,InjectionsInsulin	varchar(5)
,InjectionsInsulinStartDate	date
,InjectionsInsulinEndDate	date
,InjectionsInsulinClinicalDetermination	varchar(10)
,InjectionsInsulinRationale	varchar(3236)
,InjectionsOther	varchar(5)
,InjectionsOtherStartDate	date
,InjectionsOtherEndDate	date
,InjectionsOtherClinicalDetermination	varchar(10)
,InjectionsOtherRationale	varchar(3236)
,IntravenousFluids	varchar(5)
,IntravenousFluidsStartDate	date
,IntravenousFluidsEndDate	date
,IntravenousFluidsClinicalDetermination	varchar(10)
,IntravenousFluidsRationale	varchar(3236)
,IsolationPrecautions	varchar(5)
,IsolationPrecautionsStartDate	date
,IsolationPrecautionsEndDate	date
,IsolationPrecautionsClinicalDetermination	varchar(10)
,IsolationPrecautionsRationale	varchar(3236)
,OccupationalTherapy	varchar(5)
,OccupationalTherapyStartDate	date
,OccupationalTherapyEndDate	date
,OccupationalTherapyClinicalDetermination	varchar(10)
,OccupationalTherapyRationale	varchar(3236)
,PhysicalTherapy	varchar(5)
,PhysicalTherapyStartDate	date
,PhysicalTherapyEndDate	date
,PhysicalTherapyClinicalDetermination	varchar(10)
,PhysicalTherapyRationale	varchar(3236)
,CatheterOstomy	varchar(5)
,CatheterOstomyStartDate	date
,CatheterOstomyEndDate	date
,CatheterOstomyClinicalDetermination	varchar(10)
,CatheterOstomyRationale	varchar(3236)
,SelfInjection	varchar(5)
,SelfInjectionStartDate	date
,SelfInjectionEndDate	date
,SelfInjectionClinicalDetermination	varchar(10)
,SelfInjectionRationale	varchar(3236)
,ParenteralNutrition	varchar(5)
,ParenteralNutritionStartDate	date
,ParenteralNutritionEndDate	date
,ParenteralNutritionClinicalDetermination	varchar(10)
,ParenteralNutritionRationale	varchar(3236)
,TubeFeeding	varchar(5)
,TubeFeedingStartDate	date
,TubeFeedingEndDate	date
,TubeFeedingClinicalDetermination	varchar(10)
,TubeFeedingRationale	varchar(3236)
,PeritonealDialysis	varchar(5)
,PeritonealDialysisStartDate	date
,PeritonealDialysisEndDate	date
,PeritonealDialysisClinicalDetermination	varchar(10)
,PeritonealDialysisRationale	varchar(3236)
,PCAPump	varchar(5)
,PCAPumpStartDate	date
,PCAPumpEndDate	date
,PCAPumpClinicalDetermination	varchar(10)
,PCAPumpRationale	varchar(3236)
,Tracheostomy	varchar(5)
,TracheostomyStartDate	date
,TracheostomyEndDate	date
,TracheostomyClinicalDetermination	varchar(10)
,TracheostomyRationale	varchar(3236)
,Other	varchar(5)
,OtherStartDate	date
,OtherEndDate	date
,OtherClinicalDetermination	varchar(10)
,OtherRationale	varchar(3236)
,created_dt TIMESTAMP
,filename varchar(250)
);

create   table legacy.pasrr_doc
(EventID	varchar(36)
,FileName	varchar(255)
,AttachmentType	varchar(30)
,MimeType	varchar(75)	
,FileSize	varchar(10)
,created_dt TIMESTAMP
,srcfilename varchar(250)
);

alter table legacy.pasrr_level_ii add created_by varchar(50);
alter table  legacy.pasrr_level_i add created_by varchar(50);
alter table  legacy.pasrr_loc add created_by varchar(50);
alter table  legacy.pasrr_events add created_by varchar(50);
alter table  legacy.pasrr_demographics add created_by varchar(50);
alter table  legacy.pasrr_doc  add created_by varchar(50);




ALTER TABLE LEGACY.PASRR_EVENTS ADD AdmittingFacilityName varchar(255);
ALTER TABLE LEGACY.PASRR_EVENTS ADD ResponsiblePartyFirstName varchar(20);
ALTER TABLE LEGACY.PASRR_EVENTS ADD ResponsiblePartyLastName varchar(20);
ALTER TABLE LEGACY.PASRR_EVENTS ADD ResponsiblePartyAddress1 varchar(100);
ALTER TABLE LEGACY.PASRR_EVENTS ADD ResponsiblePartyAddress2 varchar(100);
ALTER TABLE LEGACY.PASRR_EVENTS ADD ResponsiblePartyCity varchar(50);
ALTER TABLE LEGACY.PASRR_EVENTS ADD ResponsiblePartyState varchar(2);
ALTER TABLE LEGACY.PASRR_EVENTS ADD ResponsiblePartyZip varchar(5);
ALTER TABLE LEGACY.PASRR_EVENTS ADD CurrentLocation varchar(50);
ALTER TABLE LEGACY.PASRR_EVENTS ADD CurrentLocationFacility varchar(255);
ALTER TABLE LEGACY.PASRR_EVENTS ADD CurrentLocationAddress1 varchar(100);
ALTER TABLE LEGACY.PASRR_EVENTS ADD CurrentLocationAddress2 varchar(100);
ALTER TABLE LEGACY.PASRR_EVENTS ADD CurrentLocationCity varchar(50);
ALTER TABLE LEGACY.PASRR_EVENTS ADD CurrentLocationState varchar(2);
ALTER TABLE LEGACY.PASRR_EVENTS ADD CurrentLocationZip varchar(5);
ALTER TABLE LEGACY.PASRR_EVENTS ADD PrimaryLanguage varchar(50);

ALTER TABLE LEGACY.PASRR_DEMOGRAPHICS ADD AscendID  bigint;
ALTER TABLE LEGACY.PASRR_EVENTS ADD ReviewID  bigint;

ALTER TABLE LEGACY.PASRR_LEVEL_II ADD Level2DueToStateDate TIMESTAMP;

ALTER TABLE LEGACY.PASRR_LEVEL_II ADD Expedited varchar(5);
ALTER TABLE LEGACY.PASRR_LEVEL_II ADD AssessmentID bigint;
ALTER TABLE LEGACY.PASRR_LEVEL_II ADD ReconOf bigint;


ALTER TABLE LEGACY.PASRR_LOC ADD RevisionOf bigint;
ALTER TABLE LEGACY.PASRR_DOC ADD ReviewID bigint;






grant all on table legacy.pasrr_demographics to public;
grant all on table legacy.pasrr_level_i to public;
grant all on table legacy.pasrr_level_ii to public;
grant all on table legacy.pasrr_events to public;
grant all on table legacy.pasrr_loc to public;






grant all on table legacy.pasrr_demographics to perlssconv_dev_sa;
grant all on table legacy.pasrr_level_i to perlssconv_dev_sa;
grant all on table legacy.pasrr_level_ii to perlssconv_dev_sa;
grant all on table legacy.pasrr_events to perlssconv_dev_sa;
grant all on table legacy.pasrr_loc to perlssconv_dev_sa;
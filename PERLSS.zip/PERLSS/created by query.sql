select distinct created_by from perlss.pae_loc_determn_dcsn pldd 
where pae_id in (select pae_id from perlss.pae_rqst where created_by like 'CV_402%')
except
select user_id from perlss.sec_user_organization suo;

select distinct created_by from perlss.pae_loc_sys_calc plsc  
where pae_id in (select pae_id from perlss.pae_rqst where created_by like 'CV_402%')
except
select user_id from perlss.sec_user_organization suo;


update perlss.pae_loc_sys_calc a
set created_by  = 'CV_402'
where pae_id in (select pae_id from perlss.pae_rqst where created_by like 'CV_402%')
and a.created_by in ('DD21187','TNT4421','DCV3491');

update perlss.pae_loc_determn_dcsn a
set created_by  = 'CV_402'
where pae_id in (select pae_id from perlss.pae_rqst where created_by like 'CV_402%')
and a.created_by in ('DD22122','TNT4421');
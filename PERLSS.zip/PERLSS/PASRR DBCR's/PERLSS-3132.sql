--PERLSS-2307

--create table
create table perlss.pasrr_addr_dtl
(
id	BIGINT	NOT NULL,
pasrr_id	character varying(20)	NOT NULL,
first_name	character varying(45)	NULL,
middle_name	character varying(5)	NULL,
last_name	character varying(45)	NULL,
suffix	character varying(5)	NULL,
user_type_cd	character varying(4)	NULL,
addr_Line_1	character varying(100)	NULL,
addr_Line_2	character varying(88)	NULL,
city	character varying(25)	NULL,
state_cd	character varying(4)	NULL,
zip	character varying(5)	NULL,
zip_extsn	character varying(4)	NULL,
cnty_cd	character varying(4)	NULL,
current_location	character varying(50)	NULL,
current_location_facility	character varying(255)	NULL,
admtng_facility_name	character varying(255)	NULL,
archived_dt	timestamp	NULL,
created_by	character varying(20)	NOT NULL,
created_dt	timestamp	NOT NULL,
last_modified_by	character varying(20)	NULL,
last_modified_dt	timestamp	NULL,
record_version	BIGINT	NULL,
constraint pasrr_addr_dtl_pk primary key (id),
constraint pasrr_addr_dtl_1fk foreign key (pasrr_id) references perlss.pasrr_rqst (pasrr_id)
)
tablespace pg_default;

alter table perlss.pasrr_addr_dtl owner to svccldnprdpssrds;

-- adding index on foreign key column
create index pasrr_addr_dtl_1ix
    on perlss.pasrr_addr_dtl (pasrr_id)
    tablespace pg_default;

-- table grants
grant select on perlss.pasrr_addr_dtl to ro_perlss;
grant delete, insert, select, update
    on perlss.pasrr_addr_dtl
    to rw_perlss;
	
----- THIS SHOULD BE ONLY IMPLEMENTED IN DEV DATABASE. MAKE SURE TO REMOVE/COMMENT IT OUT BEFORE UPLOADING THE DBCR TO BITBUCKET------
--grant delete, insert, select, update
 --   on perlss.pasrr_addr_dtl
  --  to rw_perlss_dev_developers; 
	
-- tables/column comments
comment on table perlss.pasrr_addr_dtl is
    'Table required to store address information for a pasrr';

Comment on column perlss.pasrr_addr_dtl.id is 'This column stores the primary key.';
Comment on column perlss.pasrr_addr_dtl.pasrr_id is 'This column stores the unique pasrr_id of the pasrr. This is a FK referring to the pasrr_rqst table with the column pasrr_id';
Comment on column perlss.pasrr_addr_dtl.first_name is 'This column stores first name information';
Comment on column perlss.pasrr_addr_dtl.middle_name is 'This field stores the middle initial of an individual';
Comment on column perlss.pasrr_addr_dtl.last_name is 'This column stores last name information';
Comment on column perlss.pasrr_addr_dtl.suffix is 'This field stores the suffix of an individual';
Comment on column perlss.pasrr_addr_dtl.user_type_cd is '"This column stores user type information RT: USER_TYPE';
Comment on column perlss.pasrr_addr_dtl.addr_Line_1 is 'This column stores Address Line 1 information';
Comment on column perlss.pasrr_addr_dtl.addr_Line_2 is 'This column stores Address Line 2 information';
Comment on column perlss.pasrr_addr_dtl.city is 'This column stores city information';
Comment on column perlss.pasrr_addr_dtl.state_cd is 'This column stores the State information RT : STATE';
Comment on column perlss.pasrr_addr_dtl.zip is 'This column stores Zip Code information';
Comment on column perlss.pasrr_addr_dtl.zip_extsn is 'This column stores Zip extension Code information';
Comment on column perlss.pasrr_addr_dtl.cnty_cd is 'This column stores the county value from RT : COUNTY';
Comment on column perlss.pasrr_addr_dtl.current_location is 'This column stores the event current location facility';
Comment on column perlss.pasrr_addr_dtl.current_location_facility is 'This column stores the event current location';
Comment on column perlss.pasrr_addr_dtl.admtng_facility_name is 'This column stores admitting facility name';
Comment on column perlss.pasrr_addr_dtl.archived_dt is 'This column stores info of when the record was archived';
Comment on column perlss.pasrr_addr_dtl.created_by is 'This column stores info of who created this record';
Comment on column perlss.pasrr_addr_dtl.created_dt is 'This column stores the information of when the record is created';
Comment on column perlss.pasrr_addr_dtl.last_modified_by is 'This column stores info of who last updated the record';
Comment on column perlss.pasrr_addr_dtl.last_modified_dt is 'This column stores the date and time when the record was changed';
Comment on column perlss.pasrr_addr_dtl.record_version is 'This column stores the record version of the current entry. This is used to keep track of changes and prevent conflicting requests.';

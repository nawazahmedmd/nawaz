--PERLSS-2316

--create table
create table perlss.pasrr_functnl_assmnt
(
id	bigint	NOT NULL,
pasrr_id	character varying(20)	NOT NULL,
functnl_measure_cd	character varying(4)	NULL,
sbmttr_rsp_cd	character varying(4)	NULL,
clinical_deter_cd	character varying(4)	NULL,
clinical_rsp_cd	character varying(4)	NULL,
denial_cd	character varying(4)	NULL,
comments	character varying(4253)	NULL,
loc_medication_admin_notes	character varying(10578)	NULL,
archived_dt	timestamp	NULL,
created_by	character varying(20)	NOT NULL,
created_dt	timestamp	NOT NULL,
last_modified_by	character varying(20)	NULL,
last_modified_dt	timestamp	NULL,
record_version	BIGINT	NULL,
constraint pasrr_functnl_assmnt_pk primary key (id),
constraint pasrr_functnl_assmnt_1fk foreign key (pasrr_id) references perlss.pasrr_rqst (pasrr_id)
)
tablespace pg_default;

alter table perlss.pasrr_functnl_assmnt owner to svccldnprdpssrds;

-- adding index on foreign key column
create index pasrr_functnl_assmnt_1ix
    on perlss.pasrr_functnl_assmnt (pasrr_id)
    tablespace pg_default;

-- table grants
grant select on perlss.pasrr_functnl_assmnt to ro_perlss;
grant delete, insert, select, update
    on perlss.pasrr_functnl_assmnt
    to rw_perlss;
	
----- THIS SHOULD BE ONLY IMPLEMENTED IN DEV DATABASE. MAKE SURE TO REMOVE/COMMENT IT OUT BEFORE UPLOADING THE DBCR TO BITBUCKET------
--grant delete, insert, select, update
--on perlss.pasrr_functnl_assmnt
--to rw_perlss_dev_developers; 
	
-- tables/column comments
comment on table perlss.pasrr_functnl_assmnt is
    'This table stores information related to PASRR functional assessment.';

comment on column perlss.pasrr_functnl_assmnt.id is 'This column stores the primary key.';
comment on column perlss.pasrr_functnl_assmnt.pasrr_id is 'Displays the ''PASRR ID''.';
comment on column perlss.pasrr_functnl_assmnt.functnl_measure_cd is 'Display the ''Functional Measure'' as received from the PASRR Vendor. The table rows correspond to each functional measure as received by the vendor.  RT:FUNCTIONAL_MEASURE_CD';
comment on column perlss.pasrr_functnl_assmnt.sbmttr_rsp_cd is 'Display the submitter Response as received from the PASRR Vendor associated to the given functional measure. RT:FUNCTIONAL_ASSESSMENT.';
comment on column perlss.pasrr_functnl_assmnt.clinical_deter_cd is 'Display the ''Clinician Determination'' as received from the PASRR Vendor associated to the given functional measure.  RT:REVIEW_DECISION. ';
comment on column perlss.pasrr_functnl_assmnt.clinical_rsp_cd is 'Display the ''Clinician Response'' as received from the PASRR Vendor associated to the given functional measure.  RT:FUNCTIONAL_ASSESSMENT.';
comment on column perlss.pasrr_functnl_assmnt.denial_cd is 'Display the Denial Reason as received from the PASRR Vendor associated to the given functional measure. RT:FUNCTIONAL_DENIAL.';
comment on column perlss.pasrr_functnl_assmnt.comments is 'Display the ''Rationale'' as received from the PASRR Vendor associated to the given functional measure.';
comment on column perlss.pasrr_functnl_assmnt.loc_medication_admin_notes is 'Displays the ''Medication Admin Notes'' as received by the vendor.';
comment on column perlss.pasrr_functnl_assmnt.archived_dt is 'This column stores info of when the record was archived';
comment on column perlss.pasrr_functnl_assmnt.created_by is 'This column stores info of who created this record';
comment on column perlss.pasrr_functnl_assmnt.created_dt is 'This column stores the information of when the record is created';
comment on column perlss.pasrr_functnl_assmnt.last_modified_by is 'This column stores info of who last updated the record.';
comment on column perlss.pasrr_functnl_assmnt.last_modified_dt is 'This column stores the date and time when the record was changed.';
comment on column perlss.pasrr_functnl_assmnt.record_version is 'This column stores the record version of the current entry. This is used to keep track of changes and prevent conflicting requests.';


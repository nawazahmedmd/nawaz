--PERLSS-2314

--create table
create table perlss.pasrr_outcome_dtls
(
id	BIGINT	NOT NULL,
pasrr_id	character varying(20)	NOT NULL,
payor_src_cd	character varying(4)	NULL,
hos_admit_dt	date	NULL,
nf_admit_dt	date	NULL,
review_type	character varying(50)	NULL,
prim_lang	character varying(50)	NULL,
ascendid	character varying(16)	NULL,
lvl1_letter_sent_dt	date	NULL,
lvl1_Letter_Type_Sent	character varying(30)	NULL,
lvl2_notice_type	character varying(40)	NULL,
lvl2_notice_sent_dt	date	NULL,
lvl2_sent_to_state_dt	date	NULL,
lvl2_assessment_dt	date	NULL,
lvl2_specialized_services_dtr	character varying(5)	NULL,
lvl2_approved_str	character varying(20)	NULL,
lvl2_Short_Term_Days	bigint	NULL,
lvl2_pasrr_condition	character varying(10)	NULL,
lvl2_due_dt	date	NULL,
archived_dt	timestamp	NULL,
created_by	character varying(20)	NOT NULL,
created_dt	timestamp	NOT NULL,
last_modified_by	character varying(20)	NULL,
last_modified_dt	timestamp	NULL,
record_version	BIGINT	NULL,
constraint pasrr_outcome_dtls_pk primary key (id),
constraint pasrr_outcome_dtls_1fk foreign key (pasrr_id) references perlss.pasrr_rqst (pasrr_id)
)
tablespace pg_default;

alter table perlss.pasrr_outcome_dtls owner to svccldnprdpssrds;

-- adding index on foreign key column
create index pasrr_outcome_dtls_1ix
    on perlss.pasrr_outcome_dtls (pasrr_id)
    tablespace pg_default;

-- table grants
grant select on perlss.pasrr_outcome_dtls to ro_perlss;
grant delete, insert, select, update
    on perlss.pasrr_outcome_dtls
    to rw_perlss;
	
----- THIS SHOULD BE ONLY IMPLEMENTED IN DEV DATABASE. MAKE SURE TO REMOVE/COMMENT IT OUT BEFORE UPLOADING THE DBCR TO BITBUCKET------
--grant delete, insert, select, update
--on perlss.pasrr_outcome_dtls
--to rw_perlss_dev_developers; 
	
-- tables/column comments
comment on table perlss.pasrr_outcome_dtls is
    'This table stores PASRR detail information';

comment on column perlss.pasrr_outcome_dtls.id is 'This column stores the primary key';
comment on column perlss.pasrr_outcome_dtls.pasrr_id is 'This column stores the unique pasrr_id. This is a FK referring to the pasrr_rqst table with the column pasrr_id';
comment on column perlss.pasrr_outcome_dtls.payor_src_cd is 'Displays the ''Payer Source'' associate with the PASRR''s record as received from the PASRR Vendor.  RT: PAYOR_SOURCE';
comment on column perlss.pasrr_outcome_dtls.hos_admit_dt is 'Displays the date the person was admitted to the hospital as received from the PASRR Vendor.';
comment on column perlss.pasrr_outcome_dtls.nf_admit_dt is 'Displays the date the person was admitted to the Nursing Facility as received from the PASRR Vendor. ';
comment on column perlss.pasrr_outcome_dtls.review_type is 'Displays the Assessment ''Review Type'' associate with the PASRR''s record as received from the PASRR Vendor.';
comment on column perlss.pasrr_outcome_dtls.prim_lang is 'Displays the ''Primary Language'' associate with the PASRR''s record as received from the PASRR Vendor.';
comment on column perlss.pasrr_outcome_dtls.ascendid is 'Displays ascendis from demographics';
comment on column perlss.pasrr_outcome_dtls.lvl1_letter_sent_dt is 'This column captures the level 1 letter sent date';
comment on column perlss.pasrr_outcome_dtls.lvl1_Letter_Type_Sent is 'This column saves the level1 letter type sent information';
comment on column perlss.pasrr_outcome_dtls.lvl2_notice_type is 'This column captures the level 2 notice type';
comment on column perlss.pasrr_outcome_dtls.lvl2_notice_sent_dt is 'This column captures the level 2 notice sent date';
comment on column perlss.pasrr_outcome_dtls.lvl2_sent_to_state_dt is 'This column captures the level 2 sent to state date';
comment on column perlss.pasrr_outcome_dtls.lvl2_assessment_dt is 'This column captures the level 2 assessment date';
comment on column perlss.pasrr_outcome_dtls.lvl2_specialized_services_dtr is 'This column captures the level specalized services determination';
comment on column perlss.pasrr_outcome_dtls.lvl2_approved_str is 'This column captures the level 2 approved short term reason';
comment on column perlss.pasrr_outcome_dtls.lvl2_Short_Term_Days is 'This column captures the level 2 short term days';
comment on column perlss.pasrr_outcome_dtls.lvl2_pasrr_condition is 'This column captures the level 2 pasrr condition';
comment on column perlss.pasrr_outcome_dtls.lvl2_due_dt is 'This column captures the level 2 due date';
comment on column perlss.pasrr_outcome_dtls.archived_dt is 'This column stores info of when the record was archived';
comment on column perlss.pasrr_outcome_dtls.created_by is 'This column stores info of who created this record';
comment on column perlss.pasrr_outcome_dtls.created_dt is 'This column stores the information of when the record is created';
comment on column perlss.pasrr_outcome_dtls.last_modified_by is 'This column stores info of who last updated the record';
comment on column perlss.pasrr_outcome_dtls.last_modified_dt is 'This column stores the date and time when the record was changed';
comment on column perlss.pasrr_outcome_dtls.record_version is 'This column stores the record version of the current entry. This is used to keep track of changes and prevent conflicting requests.';

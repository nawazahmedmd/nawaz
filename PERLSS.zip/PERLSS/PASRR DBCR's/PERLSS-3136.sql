--PERLSS-2315

--create table
create table perlss.pasrr_skilled_srvcs
(
id	bigint	NOT NULL,
pasrr_id	character varying(20)	NOT NULL,
srvc_name_cd	character varying(4)	NULL,
start_date	date	NULL,
end_date	date	NULL,
clinical_der_cd	character varying(4)	NULL,
comments	character varying(3236)	NULL,
archived_dt	timestamp	NULL,
created_by	character varying(20)	NOT NULL,
created_dt	timestamp	NOT NULL,
last_modified_by	character varying(20)	NULL,
last_modified_dt	timestamp	NULL,
record_version	BIGINT	NULL,
constraint pasrr_skilled_srvcs_pk primary key (id),
constraint pasrr_skilled_srvcs_1fk foreign key (pasrr_id) references perlss.pasrr_rqst (pasrr_id)
)
tablespace pg_default;

alter table perlss.pasrr_skilled_srvcs owner to svccldnprdpssrds;

-- adding index on foreign key column
create index pasrr_skilled_srvcs_1ix
    on perlss.pasrr_skilled_srvcs (pasrr_id)
    tablespace pg_default;

-- table grants
grant select on perlss.pasrr_skilled_srvcs to ro_perlss;
grant delete, insert, select, update
    on perlss.pasrr_skilled_srvcs
    to rw_perlss;
	
----- THIS SHOULD BE ONLY IMPLEMENTED IN DEV DATABASE. MAKE SURE TO REMOVE/COMMENT IT OUT BEFORE UPLOADING THE DBCR TO BITBUCKET------
--grant delete, insert, select, update
--on perlss.pasrr_skilled_srvcs
--to rw_perlss_dev_developers; 
	
-- tables/column comments
comment on table perlss.pasrr_skilled_srvcs is
    'This table stores the skilled service and adjudicator response details on PASRR Ids';

comment on column perlss.pasrr_skilled_srvcs.id is 'This column stores the primary key.';
comment on column perlss.pasrr_skilled_srvcs.pasrr_id is 'Displays the ''PASRR ID'' as received from the PASRR Vendor.';
comment on column perlss.pasrr_skilled_srvcs.srvc_name_cd is 'Display the ''Skilled Service'' as received from the PASRR Vendor.  RT:SKILLEDSERVICE_NAME_NONKB';
comment on column perlss.pasrr_skilled_srvcs.start_date is 'Display the ''Start Date'' as received from the PASRR Vendor.';
comment on column perlss.pasrr_skilled_srvcs.end_date is 'Display the ''End Date'' as received from the PASRR Vendor. ';
comment on column perlss.pasrr_skilled_srvcs.clinical_der_cd is 'Display the ''Clinical Determination'' as received from the PASRR Vendor.RT:REVIEW_DECISION.';
comment on column perlss.pasrr_skilled_srvcs.comments is 'Display the ''Rationale'' as received from the PASRR Vendor.';
comment on column perlss.pasrr_skilled_srvcs.archived_dt is 'This column stores info of when the record was archived';
comment on column perlss.pasrr_skilled_srvcs.created_by is 'This column stores info of who created this record';
comment on column perlss.pasrr_skilled_srvcs.created_dt is 'This column stores the information of when the record is created';
comment on column perlss.pasrr_skilled_srvcs.last_modified_by is 'This column stores info of who last updated the record';
comment on column perlss.pasrr_skilled_srvcs.last_modified_dt is 'This column stores the date and time when the record was changed';
comment on column perlss.pasrr_skilled_srvcs.record_version is 'This column stores the record version of the current entry. This is used to keep track of changes and prevent conflicting requests.';

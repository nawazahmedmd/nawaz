--PERLSS-2308

--create table
create table perlss.pasrr_submtr_dtls
(
id	BIGINT	NOT NULL,
pasrr_id	character varying(20)	NOT NULL,
lvl1_submit_dt	date	NULL,
lvl1_submtr_first_name	character varying(20)	NULL,
lvl1_submtr_last_name	character varying(20)	NULL,
lvl1_submitting_facility	character varying(255)	NULL,
lvl1_submitting_facility_address	character varying(100)	NULL,
lvl1_submitting_facility_city	character varying(50)	NULL,
lvl1_submitting_facility_State	character varying(4)	NULL,
lvl1_submitting_facility_zip	character varying(5)	NULL,
archived_dt	timestamp	NULL,
created_by	character varying(20)	NOT NULL,
created_dt	timestamp	NOT NULL,
last_modified_by	character varying(20)	NULL,
last_modified_dt	timestamp	NULL,
record_version	BIGINT	NULL,
constraint pasrr_submtr_dtls_pk primary key (id),
constraint pasrr_submtr_dtls_1fk foreign key (pasrr_id) references perlss.pasrr_rqst (pasrr_id)
)
tablespace pg_default;

alter table perlss.pasrr_submtr_dtls owner to svccldnprdpssrds;

-- adding index on foreign key column
create index pasrr_submtr_dtls_1ix
    on perlss.pasrr_submtr_dtls (pasrr_id)
    tablespace pg_default;

-- table grants
grant select on perlss.pasrr_submtr_dtls to ro_perlss;
grant delete, insert, select, update
    on perlss.pasrr_submtr_dtls
    to rw_perlss;
	
----- THIS SHOULD BE ONLY IMPLEMENTED IN DEV DATABASE. MAKE SURE TO REMOVE/COMMENT IT OUT BEFORE UPLOADING THE DBCR TO BITBUCKET------
--grant delete, insert, select, update
  --  on perlss.pasrr_submtr_dtls
   -- to rw_perlss_dev_developers; 
	
-- tables/column comments
comment on table perlss.pasrr_submtr_dtls is
    'This table stores PASRR submitter detail information';

Comment on column perlss.pasrr_submtr_dtls.id is 'This column stores the primary key';
Comment on column perlss.pasrr_submtr_dtls.pasrr_id is 'This column stores the unique pasrr_id. This is a FK referring to the pasrr_rqst table with the column pasrr_id';
Comment on column perlss.pasrr_submtr_dtls.lvl1_submit_dt is 'This column captures the level 1 letter sent date information';
Comment on column perlss.pasrr_submtr_dtls.lvl1_submtr_first_name is 'This column captures the level 1 submitter last name';
Comment on column perlss.pasrr_submtr_dtls.lvl1_submtr_last_name is 'This column captures the level 1 submitter first name';
Comment on column perlss.pasrr_submtr_dtls.lvl1_submitting_facility is 'This column captures the level 1 submitting facility name';
Comment on column perlss.pasrr_submtr_dtls.lvl1_submitting_facility_address is 'This column captures the level 1 submitting facility address';
Comment on column perlss.pasrr_submtr_dtls.lvl1_submitting_facility_city is 'This column captures the level 1 submitting facility city';
Comment on column perlss.pasrr_submtr_dtls.lvl1_submitting_facility_State is 'This column captures the level 1 submitting facility state RT : STATE';
Comment on column perlss.pasrr_submtr_dtls.lvl1_submitting_facility_zip is 'This column captures the level 1 submitting facility zip code';
Comment on column perlss.pasrr_submtr_dtls.archived_dt is 'This column stores info of when the record was archived';
Comment on column perlss.pasrr_submtr_dtls.created_by is 'This column stores info of who created this record';
Comment on column perlss.pasrr_submtr_dtls.created_dt is 'This column stores the information of when the record is created';
Comment on column perlss.pasrr_submtr_dtls.last_modified_by is 'This column stores info of who last updated the record';
Comment on column perlss.pasrr_submtr_dtls.last_modified_dt is 'This column stores the date and time when the record was changed';
Comment on column perlss.pasrr_submtr_dtls.record_version is 'This column stores the record version of the current entry. This is used to keep track of changes and prevent conflicting requests.';

--PERLSS-2311

--create table
create table perlss.pasrr_loc_dtls
(
id	BIGINT	NOT NULL,
pasrr_id	character varying(20)	NOT NULL,
locreimbursementlevel	character varying(50)	NULL,
loc_referraldate	date	NULL,
loc_referralname	character varying(50)	NULL,
loc_referralfacility	character varying(255)	NULL,
locoutcome	character varying(50)	NULL,
locdeterminationdate	date	NULL,
loc_safetyformrequest	character varying(5)	NULL,
loc_safetyformdeclineddate	date	NULL,
loc_attestationdate	date	NULL,
loc_submittedacuityscore	BIGINT	NULL,
loc_approvedacuityscore	BIGINT	NULL,
loc_functionaldeficitidentified	character varying(5)	NULL,
loc_safetyformreviewed	character varying(5)	NULL,
loc_safetyformoutcome	character varying(50)	NULL,
loc_diagnosisrelevanttoneeds	character varying(30710)	NULL,
loc_rationale	character varying(4253)	NULL,
loc_referralcomments	character varying(25614)	NULL,
archived_dt	timestamp	NULL,
created_by	character varying(20)	NOT NULL,
created_dt	timestamp	NOT NULL,
last_modified_by	character varying(20)	NULL,
last_modified_dt	timestamp	NULL,
record_version	BIGINT	NULL,
constraint pasrr_loc_dtls_pk primary key (id),
constraint pasrr_loc_dtls_1fk foreign key (pasrr_id) references perlss.pasrr_rqst (pasrr_id)
)
tablespace pg_default;

alter table perlss.pasrr_loc_dtls owner to svccldnprdpssrds;

-- adding index on foreign key column
create index pasrr_loc_dtls_1ix
    on perlss.pasrr_loc_dtls (pasrr_id)
    tablespace pg_default;

-- table grants
grant select on perlss.pasrr_loc_dtls to ro_perlss;
grant delete, insert, select, update
    on perlss.pasrr_loc_dtls
    to rw_perlss;
	
----- THIS SHOULD BE ONLY IMPLEMENTED IN DEV DATABASE. MAKE SURE TO REMOVE/COMMENT IT OUT BEFORE UPLOADING THE DBCR TO BITBUCKET------
--grant delete, insert, select, update
  --  on perlss.pasrr_loc_dtls
   -- to rw_perlss_dev_developers; 
	
-- tables/column comments
comment on table perlss.pasrr_loc_dtls is
    'This table stores PASRR loc detail information';

comment on column perlss.pasrr_loc_dtls.id is 'This column stores the primary key';
comment on column perlss.pasrr_loc_dtls.pasrr_id is 'This column stores the unique pasrr_id. This is a FK referring to the pasrr_rqst table with the column pasrr_id';
comment on column perlss.pasrr_loc_dtls.locreimbursementlevel is 'This column captures the loc reimbursement level';
comment on column perlss.pasrr_loc_dtls.loc_referraldate is 'This column captures the loc referral date';
comment on column perlss.pasrr_loc_dtls.loc_referralname is 'This column captures the loc referral name';
comment on column perlss.pasrr_loc_dtls.loc_referralfacility is 'This column captures the loc referral facility name';
comment on column perlss.pasrr_loc_dtls.locoutcome is 'This column captures the loc outcome';
comment on column perlss.pasrr_loc_dtls.locdeterminationdate is 'This column captures the loc determination date';
comment on column perlss.pasrr_loc_dtls.loc_safetyformrequest is 'This column captures the loc safety form request';
comment on column perlss.pasrr_loc_dtls.loc_safetyformdeclineddate is 'This column captures the loc safety form decline date';
comment on column perlss.pasrr_loc_dtls.loc_attestationdate is 'This column captures the loc attestation date';
comment on column perlss.pasrr_loc_dtls.loc_submittedacuityscore is 'This column captures the loc submitted acuity score';
comment on column perlss.pasrr_loc_dtls.loc_approvedacuityscore is 'This column captures the loc approved acuity score';
comment on column perlss.pasrr_loc_dtls.loc_functionaldeficitidentified is 'This column captures the loc functional deficit identified information';
comment on column perlss.pasrr_loc_dtls.loc_safetyformreviewed is 'This column captures the loc safety form reviewed details';
comment on column perlss.pasrr_loc_dtls.loc_safetyformoutcome is 'This column captures the loc safety form outcome';
comment on column perlss.pasrr_loc_dtls.loc_diagnosisrelevanttoneeds is 'This column captures the loc diagnosisrelevanttoneeds';
comment on column perlss.pasrr_loc_dtls.loc_rationale is 'This column captures the loc rationale information';
comment on column perlss.pasrr_loc_dtls.loc_referralcomments is 'This column captures the loc referralcomments';
comment on column perlss.pasrr_loc_dtls.archived_dt is 'This column stores info of when the record was archived';
comment on column perlss.pasrr_loc_dtls.created_by is 'This column stores info of who created this record';
comment on column perlss.pasrr_loc_dtls.created_dt is 'This column stores the information of when the record is created';
comment on column perlss.pasrr_loc_dtls.last_modified_by is 'This column stores info of who last updated the record';
comment on column perlss.pasrr_loc_dtls.last_modified_dt is 'This column stores the date and time when the record was changed';
comment on column perlss.pasrr_loc_dtls.record_version is 'This column stores the record version of the current entry. This is used to keep track of changes and prevent conflicting requests.';

select x.rnk,
           case when enr_grp_cd=new_pae_program then 'Same Program' else 'Diff Program' end as Pgm_flag,
           case when existing_perlss_pae_loc_dcsn_cd=new_pae_loc_dcsn_cd then 'Same LOC' else 'Diff LOC'end as LOC_flag,
           case when enr_start_dt>new_pae_eff_dt then 'PERLSS Enr date is latest than PASRR' 
when  enr_start_dt<new_pae_eff_dt then 'PASRR dates are greater than PERLSS ENR'
when  enr_start_dt=new_pae_eff_dt then 'same date' end as date_comparison,
case when existing_pae_mopd_dt>new_pae_mopd_dt then 'PERLSS MOPD date is latest than PASRR' 
when  existing_pae_mopd_dt<new_pae_mopd_dt then 'PASRR dates are greater than PERLSS MOPD'
when  existing_pae_mopd_dt=new_pae_mopd_dt then 'same MOPD date' end as MOPD_date_comparison,
 case when  lvl2_eff_dt=new_pae_eff_dt then 'Level2 date matches' else 'Date  not matching for  level 2'end as level2_date_comparison,
pop.ssn,pasrr_review_id,
                                 enr.prsn_id EXISTING_PRSN_ID,
           enr.pae_id existing_pae_id,enr_grp_cd existing_pae_program, existing_pae_eff_dt, existing_pae_end_dt,existing_perlss_pae_loc_dcsn_cd,existing_pae_mopd_dt,
           enr.enr_start_dt existing_enr_start_dt,enr.enr_end_dt existing_enr_end_dt,
           lvl2_eff_dt existing_pae_lvl2_eff_dt,lvl2_end_dt existing_pae_lvl2_end_dt,
           task_dtl_desc,entity_type task_entity,new_pae_program,
           new_pae_eff_dt,new_pae_end_dt,new_pae_loc_dcsn_cd,new_pae_mopd_dt,level1outcome,level2outcome,locoutcome,level2determinationdate ,level2determinationeffectivedate ,pop.tmed_num_control_pkey pop_tmed_num_control_pkey,
                      level2determinationdate ,level2determinationeffectivedate ,process_id, nfadmitdate maximus_nfadmitdate,passr_pi__nursingfacilityadmissiondate tmed_nf_admit_dt 
,completed_comments,x.num_control_pk tmed_workflow_num,xml.num_control xml_num,tas.num_control_pkey tmed_sub_num, perlss_sw, 
                                 tas.status tmed_submissions_status,
                                case when x.num_control_pk is null then 'No TMED Workflow' else 'Tmed WORLFLOW Exists' end as tmed_workflow_flag,
                queue, workflow_status,num_control_pk,start_date,
                xml.preenrollment_decision ,preenrollment_comments,
preenrollment_enrollmentdecision, xml.preenrollment_enrollmenteffectivedate ,xml.preenrollment_enrollmentdenialreason ,xml.enrollment_enrollmenteffectivedate ,xml.enrollment_enrollmentdenialreason,
xml.enrollment_decision,xml.enrollment_comments,tpreview_decision ,tpreview_comments,
group3interest_decision  ,group3interest_comments,
vvureviewpasrr_comments ,vvureviewpasrr_decision ,vvureviewpasrr_completedby ,vvureviewpasrr_completedon ,vvureviewpasrr ,
pasrrchanges_decision ,pasrrchanges_comments ,vvureviewpasrr_decision ,group3syncing_decision ,group3syncing_comments,group3syncing_enrollmenteffectivedate ,
group3nfdischarge ,group3nfdischarge_decision, group3nfdischarge_comments ,group3nfdischarge_nfdischargedate ,group3interest_decision ,group3interest_comments ,
group3interest_nfdischargedate ,group3interest_anticipatednfdischarge ,eog_eogdecision ,eog_comments ,eog_patientliability ,eog_patientliability ,xml.eog_medicaideligibilitystatus ,xml.eog_institutionaleligibility ,
xml.eog_ieeffectivedate ,xml.eog_effectivedateofmedicaideligibility ,xml.eog_effectivedateofpatientliability 
from  
(select task_dtl_desc,
case when tt.entity_id in ('802','805','806') then 'MCO'
                      when tt.entity_id = '842' then 'LTSS'
                      when tt.entity_id in ('833','834','838') then 'AAAD'
                      when tt.entity_id = '9999' then 'Default Provider'
                      else 'Provider' end entity_type,
aa.enr_grp_cd new_pae_program,pr.created_by,pr.mopd_dt new_pae_mopd_dt ,
 aa.pae_eff_dt new_pae_eff_dt,aa.pae_end_dt new_pae_end_dt,aa.loc_dcsn_cd new_pae_loc_dcsn_cd,nfadmitdate,a.*  from legacy.pasrr_pae_base_member_pop
 a join legacy.pasrr_events pe  on pe.eventid =a.eventid 
join perlss.pae_rqst  pr  on pr.legacy_id =a.pasrr_review_id::text
join perlss.adj_rqst aa on aa.pae_id=pr.pae_id
join legacy.cnv_task_test_load tt on tt.pae_id=pr.pae_id
where step in('3' ,'5')and trim(tt.created_by) like '%CV%' --and tt.task_dtl_desc <>'Update Facility Living Arrangement'
) pop 
left join legacy.wrk_pasrr_clients wpc on wpc.ssn=pop.ssn and wpc.maximus_reviewid::text =pop.pasrr_review_id::text
left join
(select  queue, workflow_status,num_control_pk,start_date,rnk from(select  rank() OVER (PARTITION BY num_control_pk  ORDER by 
a.start_date desc,a.added_on desc   ) AS rnk,num_control_pk,b.status workflow_status,a.* from legacy.tmed_workflow_path a 
join legacy.tmed_workflow_details b on a.process_id =b.process_id)xo where  rnk=1 
)x on x.num_control_pk=pop.tmed_num_control_pkey
left join legacy.tmed_xml_extract_cv_qlf_no_rec xml on xml.num_control=pop.tmed_num_control_pkey::text
left join legacy.tmed_all_submissions tas on tas.num_control_pkey =pop.tmed_num_control_pkey
left join 
                (select pp.mopd_dt existing_pae_mopd_dt, ca.ssn,pae_eff_dt existing_pae_eff_dt,pae_end_dt existing_pae_end_dt,
                loc_dcsn_cd existing_perlss_pae_loc_dcsn_cd ,lvl2_dcsn_cd ,lvl2_eff_dt,lvl2_end_dt,
                b.*
                from perlss.enr_rqst b 
                join perlss.com_applcnt ca on ca.prsn_id =b.prsn_id 
                join perlss.adj_rqst ar  on ar.pae_id =b.pae_id
                join perlss.pae_rqst pp on pp.pae_id=ar.pae_id
               left  join perlss.adj_pasrr_outcome oo  on ar.adj_id=oo.adj_id
                where b.active_sw ='Y' and  enr_status_cd='ENR' --and  b.enr_grp_cd in ('CG1','CG3')
                and ar.active_sw='Y'
                and enr_id in ( 
      select
            max(enr_id)
      from
            perlss.enr_rqst where created_by <> 'PASRR_CV'
      and (hstry_sw = 'N'
            or hstry_sw is null)
      and active_sw = 'Y'
      group by
            pae_id,
            prsn_id) 
           )enr on pop.ssn=enr.ssn
         where enr.ssn is not  null
and  pop.created_by  like '%PASRR%'  --and pasrr_review_id='835057'
   -- and task_dtl_desc <>'Update Facility Living Arrangement'
order by ssn
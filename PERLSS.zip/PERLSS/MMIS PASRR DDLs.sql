
create table legacy.pasrr_mmis_t_cde_aid
(sak_cde_aid                integer not null 
,cde_aid_category           varchar(2) not null   
,dsc_aid_category           varchar(100) not null 
,ind_diag_in_exclud         varchar(1) not null   
,ind_spec_in_exclud         varchar(1) not null   
,ind_emergency              varchar(1) not null   
,cde_aid_pov_lvl            varchar(3) not null   
,dsc_tnanytime_aid_category varchar(100) not null 
,created_dt timestamp
,sourcefilename varchar(250)
,created_by varchar(50)
);


create table legacy.pasrr_mmis_t_cde_disenroll_reasons
(cde_disenroll_rsn  varchar(2) not null      
,desc_disenroll_rsn varchar(25) not null 
,cde_type           varchar(1) not null      
,ind_letter         varchar(1) not null      
,created_dt timestamp
,sourcefilename varchar(250)
,created_by varchar(50)
);


create table legacy.pasrr_mmis_t_mc_re_sum_elig 
(sak_recip         integer not null    
,dte_effective     int8 not null    
,dte_end           int8 not null    
,sak_pub_hlth      integer not null    
,sak_cde_drvd_mco  integer not null    
,sak_cde_drvd_bho  integer not null    
,sak_cde_aid_prnt  integer not null    
,sak_pgm_elig_prnt int4 not null    
,sak_case          integer not null    
,ind_benefit_plan  varchar(1) not null      
,cde_copay         varchar(2) not null      
,sp_id             varchar(2) not null      
,case_hoh          varchar(9) not null      
,ind_deductible    varchar(1) not null      
,cde_crg           varchar(1) not null      
,ind_pregnancy     varchar(1) not null      
,ind_institutional varchar(1) not null      
,ind_mn            varchar(1) not null      
,dte_last_update   int8 not null    
,ind_dcs                    varchar(1)      
,amt_income                 numeric(10,2) 
,num_fpl                    int4    
,created_dt timestamp
,sourcefilename varchar(250)
,created_by varchar(50)
);


create table legacy.pasrr_mmis_t_pmp_svc_loc  
(sak_pmp_ser_loc  integer not null 
,sak_prov         integer not null 
,cde_service_loc  varchar(1) not null   
,sak_pub_hlth     integer not null 
,sak_prov_pgm     integer not null 
,cde_state_region varchar(2) not null   
,dte_effective    int8 not null 
,dte_end          int8 not null 
,sak_pmp_focus    integer not null 
,num_pho_24_hour   varchar(10)  not null
,num_pho_ext       varchar(4)   not null
,cde_file_format  varchar(1) not null   
,num_act_panel    integer not null 
,ind_autoassign   varchar(1) not null   
,ind_panel_hold   varchar(1) not null   
,ind_active       varchar(1) not null   
,created_dt timestamp
,sourcefilename varchar(250)
,created_by varchar(50)
);


create table legacy.pasrr_mmis_t_pr_nam 
(sak_prov       integer not null    
,sak_short_name int4 not null    
,name           varchar(50) not null     
,ind_name_type  varchar(1) not null      
,nam_title       varchar(15)    not null 
,cde_soundex     varchar(4)      not null
,nam_dba                 varchar(40) 
,created_dt timestamp
,sourcefilename varchar(250)
,created_by varchar(50)
);


create table legacy.pasrr_mmis_t_pr_prov
(sak_prov           integer not null 
,id_provider        varchar(9) not null   
,num_upin           varchar(6) not null   
,ind_on_review      varchar(1) not null   
,ind_owner_interest varchar(1) not null   
,cde_gender         varchar(1) not null   
,dte_birth_prov     int8 not null 
,num_prov_ssn       varchar(9) not null   
,created_dt timestamp
,sourcefilename varchar(250)
,created_by varchar(50)
);

/*
create table legacy.pasrr_mmis_t_pub_hlth_pgm
(
sak_pub_hlth       integer not null      
,cde_pgm_health     varchar(5) not null        
,dsc_pgm_health     varchar(50) not null   
,dsc_pgm_definition varchar(4000) not null 
,ind_recip_only     varchar(1) not null        
,ind_major_pgm      varchar(1) not null        
,ind_stand_alone    varchar(1) not null        
,ind_dual           varchar(1) not null        
,ind_ct_editing     varchar(1) not null        
,ind_copay          varchar(1) not null        
,ind_setup          varchar(1) not null        
,cde_enrollment     varchar(1) not null        
,elig_window_filter varchar(1) not null        
,created_dt timestamp
,sourcefilename varchar(250)
,created_by varchar(50)
);

*/
create table legacy.pasrr_mmis_t_re_aid_elig 
(sak_aid_elig     integer not null 
,sak_recip        integer not null 
,sak_pgm_elig     int4 not null 
,sak_cde_aid      integer not null 
,sak_case         integer not null 
,dte_effective    int8 not null 
,dte_end          int8 not null 
,cde_status1      varchar(1) not null   
,cde_source       varchar(3) not null   
,cde_source_state varchar(1) not null   
,ind_rqst_close   varchar(1) not null   
,dte_added        int8 not null 
,dte_last_update  int8 not null 
,created_dt timestamp
,sourcefilename varchar(250)
,created_by varchar(50)
);


create table legacy.pasrr_mmis_t_re_base
(sak_recip        integer not null    
,id_medicaid      varchar(12) not null     
,nam_last         varchar(20) not null     
,nam_first        varchar(15) not null     
,nam_mid_init     varchar(1) not null      
,adr_street_1     varchar(30) not null     
,adr_street_2     varchar(30) not null     
,adr_city         varchar(18) not null     
,adr_state        varchar(2) not null      
,adr_zip_code     varchar(5) not null      
,adr_zip_code_4   varchar(4) not null      
,cde_addr_source  varchar(3) not null      
,num_latitude      numeric(11,6) not null
,num_longitude     numeric(11,6) not null
,cde_gis_quality  int4 not null    
,num_ssn          varchar(9) not null      
,dte_birth        int8 not null    
,dte_death        int8 not null    
,cde_sex          varchar(1) not null      
,cde_race         varchar(2) not null      
,cde_ethnic       varchar(2) not null      
,cde_marital      varchar(1) not null      
,cde_county       varchar(2) not null      
,cde_office       varchar(1) not null      
,sak_cnty_off_svc integer not null    
,cde_language     varchar(3) not null      
,sak_liv_arng     integer not null    
,ind_mny_grant    varchar(1) not null      
,cde_facility     varchar(3) not null      
,ind_suspect      varchar(1) not null      
,cde_ward_type    varchar(1) not null      
,cde_county_ward  varchar(2) not null      
,sak_cde_phone    integer not null    
,num_phone         varchar(10)    not null 
,sak_add_phone    integer not null    
,num_add_phone     varchar(10)    not null 
,sak_man_excl     integer not null    
,sak_citizen_dsc  integer not null    
,ind_spec_hlth    varchar(1) not null      
,cde_soundex      varchar(4) not null      
,ind_active       varchar(1) not null      
,cde_source       varchar(3) not null      
,cde_source_state varchar(1) not null      
,cde_other_media  varchar(2) not null      
,nam_payee         varchar(35) not null    
,dte_added        int8 not null    
,dte_last_update  int8 not null    
,sak_txt_phone             integer    
,num_txt_phone             varchar(10)     
,email                     varchar(50)     
,created_dt timestamp
,sourcefilename varchar(250)
,created_by varchar(50)
);


create table legacy.pasrr_mmis_t_re_case
(sak_case          integer not null   
,num_case          varchar(12) not null    
,cde_state_cat     varchar(4) not null     
,num_seq           varchar(2) not null     
,qty_case_size     int4 not null   
,qty_num_eligibles int4 not null   
,cde_pov_range     varchar(3) not null     
,amt_income         numeric(8,2) not null
,amt_case_premium   numeric(8,2) not null
,dte_added         int8 not null   
,coinsurance_pct   int4 not null   
,ind_deductible    varchar(1) not null     
,num_fpl                    int4  
,created_dt timestamp
,sourcefilename varchar(250)
,created_by varchar(50)
);


create table legacy.pasrr_mmis_t_re_choices_tracking
(sak_recip    integer not null 
,sak_pgm_elig int4 not null 
,sys_cde      varchar(5) not null   
,created_dt timestamp
,sourcefilename varchar(250)
,created_by varchar(50)
);


create table legacy.pasrr_mmis_t_re_disenroll_reasons
(sak_recip         integer not null 
,sak_pgm_elig      int4 not null 
,cde_disenroll_rsn varchar(2) not null   
,dte_last_update   int8 not null 
,created_dt timestamp
,sourcefilename varchar(250)
,created_by varchar(50)
);


create table legacy.pasrr_mmis_t_re_elig
(sak_recip       integer not null 
,sak_pgm_elig    int4 not null 
,sak_pub_hlth    integer not null 
,dte_effective   int8 not null 
,dte_end         int8 not null 
,cde_status1     varchar(1) not null   
,dte_added       int8 not null 
,dte_last_update int8 not null 
,created_dt timestamp
,sourcefilename varchar(250)
,created_by varchar(50)
);


create table legacy.pasrr_mmis_t_re_loc
 (sak_recip           integer not null 
,sak_short_loc       int4 not null 
,cde_loc             varchar(3) not null   
,sak_prov            integer not null 
,cde_service_loc     varchar(1) not null   
,dte_effective       int8 not null 
,dte_end             int8 not null 
,num_pre_eval        varchar(9) not null   
,cde_source          varchar(3) not null   
,dte_admit           int8 not null 
,cde_admit           varchar(1) not null   
,dte_pat_status      int8 not null 
,cde_pat_status      varchar(2) not null   
,dte_last_change     int8 not null 
,dte_passr                    int8 
,dte_cost_neutrality          int8 
,cde_disability               varchar(2)   
,created_dt timestamp
,sourcefilename varchar(250)
,created_by varchar(50)
);


create table legacy.pasrr_mmis_t_re_multi_address
 (sak_recip          integer not null 
,cde_addr_usage     varchar(2) not null   
,cde_addr_source    varchar(3) not null   
,adr_street_1       varchar(30) not null  
,adr_street_2       varchar(30) not null  
,adr_city           varchar(18) not null  
,adr_state          varchar(2) not null   
,adr_zip_code       varchar(5) not null   
,adr_zip_code_4     varchar(4) not null   
,cde_county         varchar(2) not null   
,num_phone_mco_cont  varchar(10)  not null
,created_dt timestamp
,sourcefilename varchar(250)
,created_by varchar(50)
);


create table legacy.pasrr_mmis_t_re_pat_liab  
(sak_pat_liab     integer not null   
,sak_recip        integer not null   
,dte_effective    int8 not null   
,dte_end          int8 not null   
,amt_patnt_liab    numeric(8,2) not null
,dte_add          int8 not null   
,ind_adjust       varchar(1) not null     
,dte_last_updated int8 not null   
,cde_source       varchar(3) not null     
,created_dt timestamp
,sourcefilename varchar(250)
,created_by varchar(50)
);


create table legacy.pasrr_mmis_t_re_pmp_assign
(sak_re_pmp_assign   integer not null 
,sak_recip           integer not null 
,sak_pgm_elig        int4 not null 
,sak_pmp_ser_loc     integer not null 
,sak_prov_mbr        integer not null 
,cde_service_loc_mbr varchar(1) not null   
,cde_rsn_mc_start    varchar(2) not null   
,cde_rsn_mc_stop     varchar(2) not null   
,sak_mc_ent_add      integer not null 
,dte_added           int8 not null 
,sak_mc_ent_mbr      integer not null 
,dte_prov_mbr_add    int8 not null 
,sak_mc_ent_change   integer not null 
,dte_changed         int8 not null 
,sak_mc_ent_term     integer not null 
,dte_termed          int8 not null 
,cde_source_state    varchar(1) not null   
,dte_last_roster     int8 not null 
,created_dt timestamp
,sourcefilename varchar(250)
,created_by varchar(50)
);


create table legacy.pasrr_mmis_t_re_pmp_reason
(  
cde_rsn_mc_assign  varchar(2) not null   
,dsc_rsn_mc_assign  varchar(100) not null 
,cde_rsn_pmp_assign varchar(1) not null   
,ind_letter         varchar(1) not null   
,cde_aa_cnt         varchar(1) not null   
,int_cnt_change     varchar(1) not null   
,created_dt timestamp
,sourcefilename varchar(250)
,created_by varchar(50)
);


CREATE TABLE legacy.pasrr_mmis_t_pub_hlth_pgm (
	sak_pub_hlth int4 NOT NULL,
	cde_pgm_health varchar(5) NOT NULL,
	dsc_pgm_health varchar(50) NOT NULL,
	dsc_pgm_definition varchar(4000) NOT NULL,
	ind_recip_only varchar(1) NULL,
	ind_major_pgm varchar(1) NULL,
	ind_stand_alone varchar(1) NULL,
	ind_dual varchar(1) NULL,
	ind_ct_editing varchar(1) NULL,
	ind_copay varchar(1) NULL,
	ind_setup varchar(1) NULL,
	cde_enrollment varchar(1) NULL,
	elig_window_filter varchar(1) NULL,
	created_dt timestamp NULL,
	sourcefilename varchar(250) NULL,
	created_by varchar(50) NULL
);
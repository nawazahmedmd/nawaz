select seq, program_cd::varchar(200), category::varchar(200),  task_name, "Daily Count", "Cumulative Count" 
from (
select seq, program_cd::varchar(200), category::varchar(200), null::varchar(200) as task_name,
"Daily Count", "Cumulative Count"  from (
select  case
when category ='Enrollments Authorized' then 1
when category ='PAEs Received' then 2
when category ='Number of PAEs received and started, but not yet adjudicated' then 3
when category ='Adjudicated PAEs received and adjudicated on and after 01/01/2023' then 4
when category ='Adjudicated PAEs (Total Count includes PAEs received prior to 01/01/2023 that were adjudicated in 2023)' then 5
when category ='Referrals Received' then 6
when category ='Referral Decisions Made' then 7
when category ='Transitions Processed' then 8
when category ='Transition Received' then 9
when category ='Appeals Initiated' then 10
when category ='Appeals Closed' then 11
when category ='INV' then 12
when category ='VOL' then 13
when category ='Total Disenrollments Processed' then 14
when category ='Recertifications' then 15
when category ='ECF - Internal Referrals Submitted' then 16
when category ='KB - Internal Referrals Submitted' then 17
when category ='ECF - External Referrals Submitted' then 18
end
as seq, null as program_cd,category,  "Daily Count", "Cumulative Count" 
from 
(
select b.category,case when a."Daily Count">0 then a."Daily Count" else b."Daily Count" end "Daily Count",
case when a."Cumulative Count">0 then a."Cumulative Count" else b."Cumulative Count" end "Cumulative Count"
from 
(select k.category,k."Daily Count" , k."Cumulative Count" 
from (
select distinct b.category, case when a."Daily Count" is null then 0 else a."Daily Count" end  "Daily Count",
b."Cumulative Count"
from 
(select
  'Enrollments Authorized' as "category",
       count(*) as "Daily Count"
from
       perlss.enr_rqst
where
       pae_id in (
       select
             distinct pae_id
       from
             perlss.enr_rqst
       group by
             pae_id,
             prsn_id)
       and enr_status_cd = 'ENR'
       and (hstry_sw = 'N'
             or hstry_sw is null)
       and active_sw = 'Y'
       and (enr_end_dt > (current_date)::date
             or enr_end_dt is null)
       and date_trunc( 'day', auth_dt)::date = (current_date - interval '1 day')::date 
union all
select
--program_cd,
    'PAEs Received' as "category",
    count(*) as "Daily Count"
from
    perlss.pae_rqst pr
inner join perlss.pae_submission ps on
    pr.pae_id = ps.pae_id
left join perlss.aud_fwr_entity afe on
    afe.pae_Id is not null
    and afe.entity_Value is not null
    and afe.pae_Id = ps.pae_Id
    and 
((afe.action = 'UPDATE'
        and afe.entity_value ->> 'revisedPaeSw' = 'Y')
    or afe.action = 'CREATE')
    and afe.entity_Type = 'com.ltss.common.pae.model.PaeSubmission'
    and afe.created_dt::date = (current_date - interval '1 day')::date
where
    --pr.program_cd in('CG1', 'CG2', 'CG3', 'EC4', 'EC5', 'EC6', 'EC7', 'EC8', 'ICF', 'CAC', 'PACE', 'KB',)     and 
    ps.submit_dt::date = (current_date - interval '1 day')::date
union all
--Adjudicated PAE's
select
       'Adjudicated PAEs (Total Count includes PAEs received prior to 01/01/2023 that were adjudicated in 2023)' as "category",
       count(distinct pae_id) as "Daily Count"
from
       perlss.adj_rqst ar
where
       ar.loc_dcsn_cd is not null
       --and active_sw = 'Y' --244--disabled this condition based on action item Tn-229134 confirmed by ROD
       and ar.loc_dcsn_dt::date = (current_date - interval '1 day')::date --updated on Dec 11
       --and ar.loc_dcsn_dt <= (current_date)::date
union all
--Transitions Processed
select
'Transitions Processed' as "category",
       count(*) as "Daily Count"
from
       perlss.tns_rqst tr
where
       status_cd in ('APP', 'DEN', 'WIT','WTH')
	   AND tns_rqst_dt BETWEEN '2022-09-22' AND current_date
       and last_modified_dt::date= (current_date - interval '1 day')::date 
union all 
select
       'Total Disenrollments Processed' as "category",
       count(*) as "Daily Count"
from
       perlss.enr_rqst er
left join perlss.enr_dsnr_dtls edd on
       edd.enr_id = er.enr_id
where	
		er.enr_id in (select max (enr_id) from perlss.enr_rqst er2 group by er2.pae_id) 
		and  er.enr_status_cd = 'DIS'
       and (er.hstry_sw = 'N'
             or er.hstry_sw is null)
       and er.active_sw = 'Y'
       and edd.dis_enr_rsn_cd <> 'DET'
       --and er.AUTH_dt::DATE = extract(year from current_date)
       and date_trunc( 'day', er.auth_dt)::date = (current_date - interval '1 day')::date
       and edd.last_modified_by != 'ADM-CLONERECORD-DLY' 
union all 
--Recertifications
select       
--recrtfctn_dcsn_cd,
       'Recertifications' as "category",
       count(distinct prs.pae_id) as "Daily Count"
from
       perlss.pae_recertification_services prs
--where Date(created_dt) = current_date - 1 
where created_dt::date = (current_date - interval '1 day')::date
and recrtfctn_dcsn_cd='MET' --check with Srikar
group by
       recrtfctn_dcsn_cd
union all 
select
       'Referrals Received' as "category",
       count(REF_ID) as "Daily Count"
from
       perlss.ref_rqst
where
       ref_status != 'DU' --Updated on 05/11/2023
       --and created_dt::date > TO_DATE('20220919', 'YYYYMMDD')
       and 
       created_dt::date = (current_date - interval '1 day')::date--Changed 
                    --and created_dt::date between '09-19-2022'::date and (current_date - interval '1 day')::date
             --and current_date::date
union all 
select
'Appeals Initiated' as "category",
       count(*) as "Daily Count"
from
       perlss.apl_rqst
where
       created_dt::date = (current_date - interval '1 day')::date
union all
select
       edd.dis_enr_type_cd,
       --enr_grp_cd,
       count(*) as count
from
       perlss.enr_rqst er
left join perlss.enr_dsnr_dtls edd on
       edd.enr_id = er.enr_id
where
      er.enr_id in (select max (enr_id) from perlss.enr_rqst er2 group by er2.pae_id)
       and er.enr_status_cd = 'DIS'
       and (er.hstry_sw = 'N'
             or er.hstry_sw is null)
       and er.active_sw = 'Y'
       and edd.dis_enr_rsn_cd <> 'DET'
       --and er.AUTH_dt::DATE = extract(year from current_date)
       and date_trunc( 'day', er.auth_dt)::date = (current_date - interval '1 day')::date
       and edd.last_modified_by != 'ADM-CLONERECORD-DLY'
group by
       edd.dis_enr_type_cd
union all 
select
       'Referral Decisions Made' as "category",
       count(rr.id) as "Daily Count"
from
       perlss.ref_rqst rr
inner join perlss.ref_intake_outcome rio on
       rr.ref_id = rio.ref_id
where
       rio.user_type_cd in ('NRS', 'FNR')
       and rio.nurs_rvw_result_cd is not null
       and rio.last_modified_dt ::date = current_date-1
union all 
select
       'Transition Received' as "category",
       count(*) as "Daily Count"
from
       perlss.tns_rqst
where
       tns_rqst_dt = (current_date - interval '1 day')::date
       union all 
       select 
       'Appeals Closed' as "category",
       count(ar.last_modified_dt) as "Daily Count"
from
perlss.apl_rqst ar 
join perlss.apl_rsltn ars 
on ar.apl_id  = ars.apl_id 
where ar.last_modified_dt::date  = (current_date - interval '1 day')::date 
and ar.apl_status_cd  = 'CD'
--group by ars.resolution_rsn_cd
union all
select 
'Appeals Closed' as "category",
count(*) as "Daily Count"
from
perlss.apl_rqst ar 
where
apl_status_cd = 'CD'
and ar.last_modified_dt::date  = (current_date - interval '1 day')::date 
) a 
right join  
( select
       'Enrollments Authorized' as "category",
       count(distinct pae_id) as "Cumulative Count"
from
       perlss.enr_rqst
where
       pae_id in (
       select
             distinct pae_id
       from
             perlss.enr_rqst
       group by
             pae_id,
             prsn_id)
       and enr_status_cd = 'ENR'
       and (hstry_sw = 'N'
             or hstry_sw is null)
       and active_sw = 'Y'
      and extract(year from auth_dt::date) = extract(year from current_date)--added by me
             and date_trunc( 'day', auth_dt)::date < (current_date::date )  
union all
select
       --program_cd,
       'PAEs Received' as "category",
       count(*) as "Cumulative Count"
from
       perlss.pae_rqst pr
inner join perlss.pae_submission ps on
       pr.pae_id = ps.pae_id
left join perlss.aud_fwr_entity afe on
       afe.pae_Id is not null
       and afe.entity_Value is not null
       and afe.pae_Id = ps.pae_Id
       and 
((afe.action = 'UPDATE'
             and afe.entity_value ->> 'revisedPaeSw' = 'Y')
       or afe.action = 'CREATE')
       and afe.entity_Type = 'com.ltss.common.pae.model.PaeSubmission'
where
       --pr.program_cd in('CG1', 'CG2', 'CG3', 'EC4', 'EC5', 'EC6', 'EC7', 'EC8', 'ICF', 'CAC', 'PACE', 'KB')    and 
       extract(year from ps.submit_dt)= extract(year from current_date)
and ps.submit_dt <= current_date-1     --This is changed after meeeting with Carson and Balaji on 1/9/2023
--group by program_cd
--order by program_cd 
union all    
--Adjudicated PAE's
select
       'Adjudicated PAEs (Total Count includes PAEs received prior to 01/01/2023 that were adjudicated in 2023)' as "category",
       count(distinct pae_id) as "Cumulative Count"
from
       perlss.adj_rqst ar
where
       ar.loc_dcsn_cd is not null
       and active_sw = 'Y'   --disabled this condition based on action item Tn-229134 confirmed by ROD
       and extract(year from ar.loc_dcsn_dt::date) = extract(year from current_date)
       --and ar.loc_dcsn_dt <= (current_date - interval '1 day')::date
       and ar.loc_dcsn_dt::date <= (current_date - interval '1 day')::date
       union all
----Transitions Processed
       select
       'Transitions Processed' as "category",
       count(*) as "Cumulative Count"
from
       perlss.tns_rqst tr
where
       status_cd in ('APP', 'DEN', 'WIT','WTH')
	   and tns_rqst_dt BETWEEN '2022-09-22' AND current_date
--     and last_modified_dt between '2022-09-19 00:00:00' and (current_date - interval '1 day')::date
       and extract(year from last_modified_dt) = extract(year from current_date)
        and last_modified_dt <= (current_date - interval '1 sec')::timestamp
union all
select
       'Total Disenrollments Processed' as "category",
       count(*) as "Cumulative Count"
from
       perlss.enr_rqst er
left join perlss.enr_dsnr_dtls edd on
       edd.enr_id = er.enr_id
where
       er.enr_id in (select max (enr_id) from perlss.enr_rqst er2 group by er2.pae_id)
       and er.enr_status_cd = 'DIS'
       and (er.hstry_sw = 'N'
             or er.hstry_sw is null)
       and er.active_sw = 'Y'
       and edd.dis_enr_rsn_cd <> 'DET'
       and extract(year from er.AUTH_dt::DATE) = extract(year from current_date)
       and date_trunc( 'day', er.auth_dt)::date <= (current_date - interval '1 day')::date
       and edd.last_modified_by != 'ADM-CLONERECORD-DLY' 
       union all
select
       'Recertifications' as "category",
       count(distinct pae_id) as "Cumulative Count"
from
       perlss.pae_recertification_services prs
where
       extract(year from created_dt) = extract(year from current_date)
       --and date(created_dt) <= (current_date - interval '1 day')::date
       and created_dt::date <= (current_date - interval '1 day')::date
       and recrtfctn_dcsn_cd='MET' 
group by
       recrtfctn_dcsn_cd
union all
select 'Appeals Initiated' as "category",
       count(*) as "Cumulative Count" 
from 
perlss.apl_rqst 
where extract(year from created_dt::date) = extract(year from current_date) and created_dt::date  <= (current_date - interval '1 day')::date
union all
select 'Referrals Received' as "category",
       count(REF_ID) as "Cumulative Count"
from perlss.ref_rqst where ref_status != 'DU' --Updated on 05/11/2023
and 
 extract(year from created_dt::date) = extract(year from current_date)
and created_dt::date <= (current_date - interval '1 day')::date--changed
union all
select
       edd.dis_enr_type_cd as category,
       --enr_grp_cd,
       count(*) as "Cumulative Count"
from
       perlss.enr_rqst er
left join perlss.enr_dsnr_dtls edd on
       edd.enr_id = er.enr_id
where
       er.enr_id in (select max (enr_id) from perlss.enr_rqst er2 group by er2.pae_id)
       and er.enr_status_cd = 'DIS'
       and (er.hstry_sw = 'N'
             or er.hstry_sw is null)
       and er.active_sw = 'Y'
       and edd.dis_enr_rsn_cd <> 'DET'
       and extract(year from er.AUTH_dt::DATE) = extract(year from current_date)
       and date_trunc( 'day', er.auth_dt)::date <= (current_date - interval '1 day')::date
       and edd.last_modified_by != 'ADM-CLONERECORD-DLY'
group by
       edd.dis_enr_type_cd
union all 
select
       'Referral Decisions Made' as "category",
       count(rr.id) as "Cumulative Count"
from
       perlss.ref_rqst rr
inner join perlss.ref_intake_outcome rio on
       rr.ref_id = rio.ref_id
where
       rio.user_type_cd in ('NRS', 'FNR')
       and rio.nurs_rvw_result_cd is not null
       and extract(year from rio.created_dt) = extract(year from current_date)
       and rio.last_modified_dt ::date <= current_date-1
union all 
select
       'Transition Received' as "category",
       count(*) as "Cumulative Count"
from
       perlss.tns_rqst
where  extract(year from tns_rqst_dt) = extract(year from current_date) and
       tns_rqst_dt <= and (current_date - interval '1 day')::date
       union all
select  
'Appeals Closed' as "category",
count(*) as "Cumulative Count"
from
perlss.apl_rqst ar 
WHERE
apl_status_cd  = 'CD'
and  extract(year from last_modified_dt) = extract(year from current_date) and
and last_modified_dt <= (current_date - interval '1 sec')::timestamp ) b on a.category =b.category
union all
select b.category, case when a."Daily Count" is null then 0 else a."Daily Count" end  "Daily Count", b."Cumulative Count"
from 
(select
--program_cd,
       'Number of PAEs received and started, but not yet adjudicated' as category,
       count(distinct pr.pae_id) as "Daily Count",
       0 as "Cumulative Count"
from
       perlss.pae_rqst pr
inner join perlss.pae_submission ps on
       pr.pae_id = ps.pae_id
left join perlss.aud_fwr_entity afe on
       afe.pae_Id is not null
       and afe.entity_Value is not null
       and afe.pae_Id = ps.pae_Id
       and 
((afe.action = 'UPDATE'
             and afe.entity_value ->> 'revisedPaeSw' = 'Y')
       or afe.action = 'CREATE')
       and afe.entity_Type = 'com.ltss.common.pae.model.PaeSubmission'
where
       --pr.program_cd in('CG1', 'CG2', 'CG3', 'EC4', 'EC5', 'EC6', 'EC7', 'EC8', 'ICF', 'CAC', 'PACE', 'KB')        and 
       ps.submit_dt::date = (current_date - interval '1 day')::date
       and pr.status_cd = 'AD'
       and ps.created_by not like 'CV%') a
--Cumulative Number of PAEs received and started, but not yet adjudicated
right join     
(select
--program_cd,
       'Number of PAEs received and started, but not yet adjudicated' as "category",
       0 as "Daily Count",
       count(distinct pr.pae_id) as "Cumulative Count"
from
       perlss.pae_rqst pr
inner join perlss.pae_submission ps on
       pr.pae_id = ps.pae_id
left join perlss.aud_fwr_entity afe on
       afe.pae_Id is not null
       and afe.entity_Value is not null
       and afe.pae_Id = ps.pae_Id
       and 
((afe.action = 'UPDATE'
             and afe.entity_value ->> 'revisedPaeSw' = 'Y')
       or afe.action = 'CREATE')
       and afe.entity_Type = 'com.ltss.common.pae.model.PaeSubmission'
where
       --pr.program_cd in('CG1', 'CG2', 'CG3', 'EC4', 'EC5', 'EC6', 'EC7', 'EC8', 'ICF', 'CAC', 'PACE', 'KB')              and 
       extract(year from ps.submit_dt)= extract(year from current_date)
and ps.submit_dt::date <= (current_date - interval '1 day')::date
       and pr.status_cd = 'AD'
       and ps.created_by not like 'CV%' ) b on a.category = b.category
          
union all    

select b.category, case when a."Daily Count" is null then 0 else a."Daily Count" end  "Daily Count", b."Cumulative Count"
from 
(select
       'Adjudicated PAEs received and adjudicated on and after 01/01/2023' as "category",
       count(distinct ar.pae_id) as "Daily Count"
from
       perlss.adj_rqst ar
where
       ar.loc_dcsn_cd is not null
       --and active_sw = 'Y' --244--disabled this condition based on action item Tn-229134 confirmed by ROD
       and ar.loc_dcsn_dt::date = (current_date - interval '1 day')::date)a

right join 
(
SELECT    'Adjudicated PAEs received and adjudicated on and after 01/01/2023' AS "category", count(distinct ar.pae_id) AS "Cumulative Count" 
from perlss.adj_rqst ar INNER JOIN perlss.pae_submission ps on ps.pae_id =ar.pae_id 
where ar.loc_dcsn_cd IS NOT null --and active_sw = 'Y'   --disabled this condition based on action item Tn-229134 confirmed by ROD           
and extract(year from ar.loc_dcsn_dt::date) = extract(year from current_date)
AND
extract(year from ps.submit_dt) = extract(year from current_date) 
and ar.loc_dcsn_dt::date <= (CURRENT_DATE - interval '1 day')::date) b on a.category =b.category



          
union all

select b.category, case when a."Daily Count" is null then 0 else a."Daily Count" end  "Daily Count", b."Cumulative Count"
from
(select "Referrals Recevied" as  category, "Daily Count" from (
select
    case
        when t.external_ref_sw = 'Y' then 'ECF - External Referrals Submitted'
        when t.external_ref_sw = 'KB' then 'KB - Internal Referrals Submitted'
        when t.external_ref_sw = 'ECF' then 'ECF - Internal Referrals Submitted'
    end as "Referrals Recevied",
    t.numCount as "Daily Count"
from
    (
    select
        external_ref_sw,
        count(external_ref_sw) as numCount
    from
        perlss.ref_rqst rr
    where
        rr.external_ref_sw = 'Y' and
        rr.created_dt::date =(current_date - interval '1 day')::date
        and ref_status != 'DU'
    group by
        external_ref_sw
     union all 
    select
        program_cd,
        count(program_cd)
    from
        perlss.ref_rqst rr
    where
        rr.external_ref_sw <> 'Y'
        and rr.created_dt::date =(current_date - interval '1 day')::date
            and ref_status != 'DU'
        group by
            program_cd)t 
            ) a) a
right join 
(select "Referrals Recevied" as category, "Cumulative Count" from (
select
    case
        when t.external_ref_sw = 'Y' then 'ECF - External Referrals Submitted'
        when t.external_ref_sw = 'KB' then 'KB - Internal Referrals Submitted'
        when t.external_ref_sw = 'ECF' then 'ECF - Internal Referrals Submitted'
    end as "Referrals Recevied",
    0 as "Daily Count",
    t.numCount as "Cumulative Count"
from
    (
    select
        external_ref_sw,
        count(external_ref_sw) as numCount
    from
        perlss.ref_rqst rr
    where
        rr.external_ref_sw = 'Y' and
             extract(year from rr.created_dt) = extract(year from current_date)
             and rr.created_dt::date <= (current_date - interval '1 day')::date
        and ref_status != 'DU'
    group by
        external_ref_sw
     union all 
    select
        program_cd,
        count(program_cd)
    from
        perlss.ref_rqst rr
    where
        rr.external_ref_sw <> 'Y'
       and extract(year from rr.created_dt) = extract(year from current_date)
             and rr.created_dt::date <= (current_date - interval '1 day')::date
            and ref_status != 'DU'
        group by
            program_cd)t )a) b on a.category =b.category ) k )a
            right join 
            (select a.category,0 as "Daily Count",0 as "Cumulative Count" from
(select 'Enrollments Authorized' as category union all 
select 'PAEs Received' as category union all 
select 'Number of PAEs received and started, but not yet adjudicated' as category union all 
select 'Adjudicated PAEs received and adjudicated on and after 01/01/2023' as category union all 
select 'Adjudicated PAEs (Total Count includes PAEs received prior to 01/01/2023 that were adjudicated in 2023)' as category union all
select 'Referrals Received' as category union all 
select 'Referral Decisions Made' as category union all 
select 'Transitions Processed' as category union all 
select 'Transition Received' as category union all 
select 'Appeals Initiated' as category union all 
select 'Appeals Closed' as category union all 
select 'INV' as category union all 
select 'VOL' as category union all 
select 'Total Disenrollments Processed' as category union all 
select 'Recertifications' as category union all 
select 'ECF - Internal Referrals Submitted' as category union all 
select 'KB - Internal Referrals Submitted' as category union all 
select 'ECF - External Referrals Submitted' as category )a) b on a.category =b.category)a
union all           
            
select 19 as seq , b.program_cd , 'PAEs Received Details' as "category" ,
case when a."Daily Count">0 then a."Daily Count" else b."Daily Count" end "Daily Count",
case when a."Cumulative Count">0 then a."Cumulative Count" else b."Cumulative Count" end "Cumulative Count" from 
(select  b.program_cd,
case when a."Daily Count" is null then 0 else a."Daily Count" end "Daily Count"  , b."Cumulative Count" from 
(select 
program_cd,
    'PAEs Received Details' as "category",
    Count(*) as "Daily Count",
   null as "Cumulative Count"
from   perlss.pae_rqst pr
inner join perlss.pae_submission ps on
    pr.pae_id = ps.pae_id
left join perlss.aud_fwr_entity afe on
    afe.pae_Id is not null
    and afe.entity_Value is not null
    and afe.pae_Id = ps.pae_Id
    and 
((afe.action = 'UPDATE'
        and afe.entity_value ->> 'revisedPaeSw' = 'Y')
    or afe.action = 'CREATE')
    and afe.entity_Type = 'com.ltss.common.pae.model.PaeSubmission'
    and afe.created_dt::date = (current_date - interval '1 day')::date
where
    pr.program_cd in('CG1', 'CG2', 'CG3', 'EC4', 'EC5', 'EC6', 'EC7', 'EC8', 'ICF', 'CAC', 'PACE', 'KB')    and 
    ps.submit_dt::date = (current_date - interval '1 day')::date
    group by program_cd) a
right join 
    (select  
       program_cd ,
    'PAEs Received Details' as category,
    null::bigint as "Daily Count",
Count(*) as "Cumulative Count"  from perlss.pae_rqst pr 
inner join perlss.pae_submission ps on pr.pae_id  = ps.pae_id  
left join perlss.aud_fwr_entity afe on afe.pae_Id is not null and afe.entity_Value is not null and afe.pae_Id = ps.pae_Id and 
((afe.action='UPDATE' and afe.entity_value ->> 'revisedPaeSw'='Y') or afe.action='CREATE')  and afe.entity_Type='com.ltss.common.pae.model.PaeSubmission'
where extract(year from ps.submit_dt) = extract(year from current_date) and ps.submit_dt <= current_date-1 
group by program_cd) b  on a.program_cd=b.program_cd ) a
right join 
(select  j.program_cd,0 as "Daily Count",0 as "Cumulative Count"
from
(select 'CAC'       as program_cd  union all
select 'CG1'       as program_cd  union all
select 'CG2'       as program_cd  union all
select 'CG3'       as program_cd  union all
select 'EC4'       as program_cd  union all
select 'EC5'       as program_cd  union all
select 'EC6'       as program_cd  union all
select 'EC7'       as program_cd  union all
select 'EC8'       as program_cd  union all
select 'ICF'       as program_cd  union all
select 'KB'       as program_cd  union all
select 'PACE'      as program_cd  
)j) b on a.program_cd=b.program_cd 

union all

select 20 as seq,b.enr_grp_cd , 'PAEs Adjudicated' as "category" ,
case when a."Daily Count">0 then a."Daily Count" else b."Daily Count" end "Daily Count",
case when a."Cumulative Count">0 then a."Cumulative Count" else b."Cumulative Count" end "Cumulative Count" from 
(
select  b.enr_grp_cd ,
case when a."Daily Count" is null then 0 else a."Daily Count" end "Daily Count"  , b."Cumulative Count" from 

(select 
enr_grp_cd,
'Program Adjudicated PAEs' as  category,
       Count(distinct pae_id) as "Daily Count",
       null as "Cumulative Count"
from
       perlss.adj_rqst ar
where
       ar.loc_dcsn_cd is not null
             --and active_sw = 'Y'
       and ar.loc_dcsn_dt::date = (current_date - interval '1 day')::date 
       --and ar.loc_dcsn_dt::date <= (current_date)::date
group by enr_grp_cd) a
right join  
(select 
--enr_grp_cd program_cd,
--'PAEs Adjudicated ' as  category,
       --null::bigint as "Daily Count",
       Count(distinct pae_id) as "Cumulative Count",
	enr_grp_cd
from
     perlss.adj_rqst ar
where
       ar.loc_dcsn_cd is not null
       and active_sw = 'Y'--disabled this condition based on action item Tn-229134 confirmed by ROD
       --and enr_grp_cd in ('CAC','CG1','CG2','CG3','EC4','EC5','EC6','EC7','EC8','ICF','PACE')
       and extract(year from ar.loc_dcsn_dt::date) = extract(year from current_date)
       --and ar.loc_dcsn_dt <= (current_date - interval '1 day')::date
       and ar.loc_dcsn_dt::date <= (current_date - interval '1 day')::date
       group by enr_grp_cd) b on a.enr_grp_cd=b.enr_grp_cd) a
right join 
(select  j.enr_grp_cd,0 as "Daily Count",0 as "Cumulative Count"
from
(select 'CAC'       as enr_grp_cd  union all
select 'CG1'       as enr_grp_cd  union all
select 'CG2'       as enr_grp_cd  union all
select 'CG3'       as enr_grp_cd  union all
select 'EC4'       as enr_grp_cd  union all
select 'EC5'       as enr_grp_cd  union all
select 'EC6'       as enr_grp_cd  union all
select 'EC7'       as enr_grp_cd  union all
select 'EC8'       as enr_grp_cd  union all
select 'ICF'       as enr_grp_cd  union all
--select 'KB'       as program_cd  union all
select 'PACE'      as program_cd  
)j) b on a.enr_grp_cd=b.enr_grp_cd

union all

select 21 as seq,b.program_cd , 'Enrollments Authorized Details' as "category" ,
case when a."Daily Count">0 then a."Daily Count" else b."Daily Count" end "Daily Count",
case when a."Cumulative Count">0 then a."Cumulative Count" else b."Cumulative Count" end "Cumulative Count" from 
(select  b.program_cd,
case when a."Daily Count" is null then 0 else a."Daily Count" end "Daily Count"  , b."Cumulative Count" from 
(select 
        enr_grp_cd as program_cd,
       'Enrollments Authorized Details' as category,
       count(distinct pae_id) as "Daily Count",
       null as "Cumulative Count" 
from
       perlss.enr_rqst
where
       pae_id in (
       select
             distinct pae_id
       from
             perlss.enr_rqst
       group by
             pae_id,
             prsn_id)
       and enr_status_cd = 'ENR'
       --and enr_grp_cd ='CAC'
       and (hstry_sw = 'N'
             or hstry_sw is null)
       and active_sw = 'Y'
       and (enr_end_dt::date > current_date::date
             or enr_end_dt is null)
       and date_trunc( 'day', auth_dt)::date = (current_date - interval '1 day')::date
       group by enr_grp_cd) a 
right join 
--+++++++++++++++++++++++++++++++++++++++++Cumulative Count 
(select 
       enr_grp_cd as program_cd,
       'Enrollments Authorized Details' as category,
       null as "Daily Count",
       count(distinct pae_id) as "Cumulative Count"
from
       perlss.enr_rqst
where
       pae_id in (
       select
             distinct pae_id
       from
             perlss.enr_rqst
       group by
             pae_id,
             prsn_id)
       and enr_status_cd = 'ENR'
--and enr_grp_cd ='CAC'
       and (hstry_sw = 'N'
             or hstry_sw is null)
       and active_sw = 'Y'
       --and (enr_end_dt::date > (current_date)::date 
          --   or enr_end_dt is null)
             and extract(year from auth_dt::date) = extract(year from current_date)--added by me
             and date_trunc( 'day', auth_dt)::date < (current_date::date )
       group by enr_grp_cd ) b on a.program_cd=b.program_cd) a
right join 
(select  j.program_cd,0 as "Daily Count",0 as "Cumulative Count"
from
(select 'CAC'       as program_cd  union all
select 'CG1'       as program_cd  union all
select 'CG2'       as program_cd  union all
select 'CG3'       as program_cd  union all
select 'EC4'       as program_cd  union all
select 'EC5'       as program_cd  union all
select 'EC6'       as program_cd  union all
select 'EC7'       as program_cd  union all
select 'EC8'       as program_cd  union all
select 'ICF'       as program_cd  union all
select 'PACE'       as program_cd  union all
select 'SED'      as program_cd  union all
select 'STW'
)j) b on a.program_cd=b.program_cd 
          
union all
          
          


select 22 as seq,b.dis_enr_rsn_cd , b.category,
case when a."Daily Count">0 then a."Daily Count" else b."Daily Count" end "Daily Count",
case when a."Cumulative Count">0 then a."Cumulative Count" else b."Cumulative Count" end "Cumulative Count" from 
(select  b.dis_enr_rsn_cd,b.category,
case when a."Daily Count" is null then 0 else a."Daily Count" end  "Daily Count", b."Cumulative Count"
from  
(select 
       dis_enr_rsn_cd,
             'Disenrollments' category,
       count(*) as "Daily Count"
from
       perlss.enr_rqst er
left join perlss.enr_dsnr_dtls edd on
       edd.enr_id = er.enr_id
where
       er.enr_id in (select max (enr_id) from perlss.enr_rqst er2 group by er2.pae_id)
       and er.enr_status_cd = 'DIS'
       and (er.hstry_sw = 'N'
             or er.hstry_sw is null)
       and er.active_sw = 'Y'
       and edd.dis_enr_rsn_cd <> 'DET'
       --and er.AUTH_dt::DATE = extract(year from current_date) 
       and date_trunc( 'day', er.auth_dt)::date = (current_date - interval '1 day')::date
       and edd.last_modified_by != 'ADM-CLONERECORD-DLY'
group by
       dis_enr_rsn_cd) a
right join 
----------------------------Cumulative Count Disenrollments       
  (select 
       dis_enr_rsn_cd,
             'Disenrollments' category,
             count(*) as  "Cumulative Count"
from
       perlss.enr_rqst er
left join perlss.enr_dsnr_dtls edd on
       edd.enr_id = er.enr_id
where
       er.enr_id in (select max (enr_id) from perlss.enr_rqst er2 group by er2.pae_id)
       and er.enr_status_cd = 'DIS'
       and (er.hstry_sw = 'N'
             or er.hstry_sw is null)
       and er.active_sw = 'Y'
       and edd.dis_enr_rsn_cd <> 'DET'
       and extract(year from er.AUTH_dt::DATE) = extract(year from current_date) 
       and date_trunc( 'day', er.auth_dt)::date <= (current_date - interval '1 day')::date
       and edd.last_modified_by != 'ADM-CLONERECORD-DLY'
group by
       dis_enr_rsn_cd) b on a.dis_enr_rsn_cd = b.dis_enr_rsn_cd) a
right join 
(select  j.dis_enr_rsn_cd,'Disenrollments' category,0 as "Daily Count",0 as "Cumulative Count"
from
(select 'MDE' as dis_enr_rsn_cd  union all
select 'HOS' as dis_enr_rsn_cd  union all
select 'NFD' as dis_enr_rsn_cd  union all
select 'DEN' as dis_enr_rsn_cd  union all
select 'COS' as dis_enr_rsn_cd  union all
select 'SAF' as dis_enr_rsn_cd  union all
select 'NTC' as dis_enr_rsn_cd  union all
select 'NON' as dis_enr_rsn_cd  union all
select 'STA' as dis_enr_rsn_cd  union all
select 'DCS' as dis_enr_rsn_cd  union all
select 'COT' as dis_enr_rsn_cd  union all
select 'NOS' as dis_enr_rsn_cd  union all
select 'PAY' as dis_enr_rsn_cd  union all
select 'HOM' as dis_enr_rsn_cd  union all
select 'HNF' as dis_enr_rsn_cd  union all
select 'MED' as dis_enr_rsn_cd  union all
select 'PRE' as dis_enr_rsn_cd  union all
select 'OTH' as dis_enr_rsn_cd  union all
select 'DET' as dis_enr_rsn_cd  union all
select 'PEN' as dis_enr_rsn_cd  union all
select 'PED' as dis_enr_rsn_cd  union all
select 'LNK' as dis_enr_rsn_cd  union all
select 'INE' as dis_enr_rsn_cd  union all
select 'SRM' as dis_enr_rsn_cd  union all
select 'SRA' as dis_enr_rsn_cd  union all
select 'NFI' as dis_enr_rsn_cd  union all
select 'NSA' as dis_enr_rsn_cd  union all
select 'TEN' as dis_enr_rsn_cd  union all
select 'CEW' as dis_enr_rsn_cd  union all
select 'SNS' as dis_enr_rsn_cd  union all
select 'NMR' as dis_enr_rsn_cd  union all
select 'NMN' as dis_enr_rsn_cd  union all
select 'KBC' as dis_enr_rsn_cd  union all
select 'VAU' as dis_enr_rsn_cd  union all
select 'MRN' as dis_enr_rsn_cd 
)j) b on a.dis_enr_rsn_cd=b.dis_enr_rsn_cd
          
union all

-------Daily Voluntary/Involuntary
select 23 as seq,b.program_cd, b.category,
case when a."Daily Count">0 then a."Daily Count" else b."Daily Count" end "Daily Count",
case when a."Cumulative Count">0 then a."Cumulative Count" else b."Cumulative Count" end "Cumulative Count" 
from (select  b.program_cd , b.category,
case when a."Daily Count" > 0 then a."Daily Count" else b."Daily Count" end "Daily Count",
b."Cumulative Count"
from
(select 
dis_enr_rsn_cd as program_cd,
edd.dis_enr_type_cd as category,
Count(*) as "Daily Count",
0  as  "Cumulative Count"
from
       perlss.enr_rqst er
left join perlss.enr_dsnr_dtls edd on
       edd.enr_id = er.enr_id
where
       er.enr_id in (select max (enr_id) from perlss.enr_rqst er2 group by er2.pae_id)
       and er.enr_status_cd = 'DIS'
       and (er.hstry_sw = 'N'
             or er.hstry_sw is null)
       and er.active_sw = 'Y'
       and edd.dis_enr_rsn_cd <> 'DET'
       --and er.AUTH_dt::DATE = extract(year from current_date)
       and date_trunc( 'day', er.auth_dt)::date = (current_date - interval '1 day')::date
       and edd.last_modified_by != 'ADM-CLONERECORD-DLY'
group by
       edd.dis_enr_type_cd,
       dis_enr_rsn_cd ) a
right join 
((select dis_enr_rsn_cd as program_cd,
             'VOL' category,
             0 as "Daily Count",
             count(*) as  "Cumulative Count"
from
       perlss.enr_rqst er
left join perlss.enr_dsnr_dtls edd on
       edd.enr_id = er.enr_id
where 
		er.enr_id in (select max (enr_id) from perlss.enr_rqst er2 group by er2.pae_id)
       and er.enr_status_cd = 'DIS'
       and (er.hstry_sw = 'N'
             or er.hstry_sw is null)
       and er.active_sw = 'Y'
       and edd.dis_enr_rsn_cd <> 'DET'
       and extract(year from er.AUTH_dt::DATE) = extract(year from current_date) 
       and date_trunc( 'day', er.auth_dt)::date <= (current_date - interval '1 day')::date
       and edd.last_modified_by != 'ADM-CLONERECORD-DLY'
group by
       dis_enr_rsn_cd)
       union all 
       (select dis_enr_rsn_cd as program_cd,
             'INV' category,
             0 as "Daily Count",
             count(*) as  "Cumulative Count"
from
       perlss.enr_rqst er
left join perlss.enr_dsnr_dtls edd on
       edd.enr_id = er.enr_id
where 
       er.enr_id in (select max (enr_id) from perlss.enr_rqst er2 group by er2.pae_id)
       and er.enr_status_cd = 'DIS'
       and (er.hstry_sw = 'N'
             or er.hstry_sw is null)
       and er.active_sw = 'Y'
       and edd.dis_enr_rsn_cd <> 'DET'
       and extract(year from er.AUTH_dt::DATE) = extract(year from current_date) 
       and date_trunc( 'day', er.auth_dt)::date <= (current_date - interval '1 day')::date
       and edd.last_modified_by != 'ADM-CLONERECORD-DLY'
group by
       dis_enr_rsn_cd)) b on a.category = b.category and a.program_cd=b.program_cd
    ) a
right join 
(select  j.program_cd,j.category,0 as "Daily Count",0 as "Cumulative Count"
from
(select 'MDE' as program_cd,'VOL' as category  union all
select 'HOS' as program_cd,'VOL' as category  union all
select 'NFD' as program_cd,'VOL' as category  union all
select 'DEN' as program_cd,'VOL' as category  union all
select 'COS' as program_cd,'VOL' as category  union all
select 'SAF' as program_cd,'VOL' as category  union all
select 'NTC' as program_cd,'VOL' as category  union all
select 'NON' as program_cd,'VOL' as category  union all
select 'STA' as program_cd,'VOL' as category  union all
select 'DCS' as program_cd,'VOL' as category  union all
select 'COT' as program_cd,'VOL' as category  union all
select 'NOS' as program_cd,'VOL' as category  union all
select 'PAY' as program_cd,'VOL' as category  union all
select 'HOM' as program_cd,'VOL' as category  union all
select 'HNF' as program_cd,'VOL' as category  union all
select 'MED' as program_cd,'VOL' as category  union all
select 'PRE' as program_cd,'VOL' as category  union all
select 'OTH' as program_cd,'VOL' as category  union all
select 'DET' as program_cd,'VOL' as category  union all
select 'PEN' as program_cd,'VOL' as category  union all
select 'PED' as program_cd,'VOL' as category  union all
select 'LNK' as program_cd,'VOL' as category  union all
select 'INE' as program_cd,'VOL' as category  union all
select 'SRM' as program_cd,'VOL' as category  union all
select 'SRA' as program_cd,'VOL' as category  union all
select 'NFI' as program_cd,'VOL' as category  union all
select 'NSA' as program_cd,'VOL' as category  union all
select 'TEN' as program_cd,'VOL' as category  union all
select 'CEW' as program_cd,'VOL' as category  union all
select 'SNS' as program_cd,'VOL' as category  union all
select 'NMR' as program_cd,'VOL' as category  union all
select 'NMN' as program_cd,'VOL' as category  union all
select 'KBC' as program_cd,'VOL' as category  union all
select 'VAU' as program_cd,'VOL' as category  union all
select 'MRN' as program_cd,'VOL' as category  union all
select 'MDE' as program_cd,'INV' as category  union all
select 'HOS' as program_cd,'INV' as category  union all
select 'NFD' as program_cd,'INV' as category  union all
select 'DEN' as program_cd,'INV' as category  union all
select 'COS' as program_cd,'INV' as category  union all
select 'SAF' as program_cd,'INV' as category  union all
select 'NTC' as program_cd,'INV' as category  union all
select 'NON' as program_cd,'INV' as category  union all
select 'STA' as program_cd,'INV' as category  union all
select 'DCS' as program_cd,'INV' as category  union all
select 'COT' as program_cd,'INV' as category  union all
select 'NOS' as program_cd,'INV' as category  union all
select 'PAY' as program_cd,'INV' as category  union all
select 'HOM' as program_cd,'INV' as category  union all
select 'HNF' as program_cd,'INV' as category  union all
select 'MED' as program_cd,'INV' as category  union all
select 'PRE' as program_cd,'INV' as category  union all
select 'OTH' as program_cd,'INV' as category  union all
select 'DET' as program_cd,'INV' as category  union all
select 'PEN' as program_cd,'INV' as category  union all
select 'PED' as program_cd,'INV' as category  union all
select 'LNK' as program_cd,'INV' as category  union all
select 'INE' as program_cd,'INV' as category  union all
select 'SRM' as program_cd,'INV' as category  union all
select 'SRA' as program_cd,'INV' as category  union all
select 'NFI' as program_cd,'INV' as category  union all
select 'NSA' as program_cd,'INV' as category  union all
select 'TEN' as program_cd,'INV' as category  union all
select 'CEW' as program_cd,'INV' as category  union all
select 'SNS' as program_cd,'INV' as category  union all
select 'NMR' as program_cd,'INV' as category  union all
select 'NMN' as program_cd,'INV' as category  union all
select 'KBC' as program_cd,'INV' as category  union all
select 'VAU' as program_cd,'INV' as category  union all
select 'MRN' as program_cd,'INV' as category      
)j) b on a.program_cd=b.program_cd and a.category=b.category
          
union all       
          
 select 24 as seq,b.program_cd, b.category,
case when a."Daily Count">0 then a."Daily Count" else b."Daily Count" end "Daily Count",
case when a."Cumulative Count">0 then a."Cumulative Count" else b."Cumulative Count" end "Cumulative Count" 
from (select  b.program_cd , b.category,
case when a."Daily Count" > 0 then a."Daily Count" else b."Daily Count" end "Daily Count", 
case when a."Cumulative Count" > 0 then a."Cumulative Count" else b."Cumulative Count" end "Cumulative Count"
from
(select  b.dis_enr_rsn_cd as program_cd, b.category as "category" ,
case when a."Daily Count" is null then 0 else a."Daily Count" end "Daily Count"  , 
b."Cumulative Count" from 
(select dis_enr_rsn_cd,
             edd.dis_enr_type_cd ||' Automatic Dis' category,
       count(*) as "Daily Count",
       null as  "Cumulative Count"   
from
    perlss.enr_rqst er
left join perlss.enr_dsnr_dtls edd on
    edd.enr_id = er.enr_id
where er.enr_id in (select max (enr_id) from perlss.enr_rqst er2 group by er2.pae_id)
    and er.enr_status_cd = 'DIS'
    and (er.hstry_sw = 'N'
        or er.hstry_sw is null)
    and er.active_sw = 'Y'
    and edd.dis_enr_rsn_cd <> 'DET'
    --and er.AUTH_dt::DATE = extract(year from current_date)
    and date_trunc( 'day', er.AUTH_dt)::date =(current_date - interval '1 day')::date 
    and (edd.ltss_dscn_cd  is null or exists 
    (select chm.pae_id from perlss.chm_rqst chm 
    join perlss.chm_disenr_dtls cdd on chm.chm_id = cdd.chm_id and chm.chm_type_cd = 'DSER'
    where chm.chm_type_cd = 'DSER' and (cdd.disenr_type_cd = 'VOL' or (cdd.disenr_type_cd = 'INV' and cdd.disenr_rsn_cd in ('DCS','NFD','STA','NON','HOS') )  ) and chm.pae_id = er.pae_id) )
   and edd.last_modified_by != 'ADM-CLONERECORD-DLY'
group by dis_enr_rsn_cd, edd.dis_enr_type_cd) a
right join 
(select  dis_enr_rsn_cd,
             edd.dis_enr_type_cd ||' Automatic Dis' category,
null as "Daily Count",
       count(*) as  "Cumulative Count"  
from
    perlss.enr_rqst er
left join perlss.enr_dsnr_dtls edd on
    edd.enr_id = er.enr_id
where
    er.enr_id in (select max (enr_id) from perlss.enr_rqst er2 group by er2.pae_id)
    and er.enr_status_cd = 'DIS'
    and (er.hstry_sw = 'N'
        or er.hstry_sw is null)
    and er.active_sw = 'Y'
    and edd.dis_enr_rsn_cd <> 'DET'
    and extract(year from er.AUTH_dt::DATE) = extract(year from current_date)
    and date_trunc( 'day', er.AUTH_dt)::date <=(current_date - interval '1 day')::date 
    and (edd.ltss_dscn_cd  is null or exists 
    (select chm.pae_id from perlss.chm_rqst chm 
    join perlss.chm_disenr_dtls cdd on chm.chm_id = cdd.chm_id and chm.chm_type_cd = 'DSER'
    where chm.chm_type_cd = 'DSER' and (cdd.disenr_type_cd = 'VOL' or (cdd.disenr_type_cd = 'INV' and cdd.disenr_rsn_cd in ('DCS','NFD','STA','NON','HOS') )  ) and chm.pae_id = er.pae_id) )
   and edd.last_modified_by != 'ADM-CLONERECORD-DLY'
group by dis_enr_rsn_cd, edd.dis_enr_type_cd ) b on a.dis_enr_rsn_cd=b.dis_enr_rsn_cd and a.category=b.category ) a
right join 
((select dis_enr_rsn_cd as program_cd,
             'VOL Automatic Dis' category,
             0 as "Daily Count",
             0 as  "Cumulative Count"
from
       perlss.enr_rqst er
left join perlss.enr_dsnr_dtls edd on
       edd.enr_id = er.enr_id
where er.enr_id in (select max (enr_id) from perlss.enr_rqst er2 group by er2.pae_id)
       and er.enr_status_cd = 'DIS'
       and (er.hstry_sw = 'N'
             or er.hstry_sw is null)
       and er.active_sw = 'Y'
       and edd.dis_enr_rsn_cd <> 'DET'
       and extract(year from er.AUTH_dt::DATE) = extract(year from current_date) 
       and date_trunc( 'day', er.auth_dt)::date <= (current_date - interval '1 day')::date
       and edd.last_modified_by != 'ADM-CLONERECORD-DLY'
group by
       dis_enr_rsn_cd)
       union all 
       (select dis_enr_rsn_cd as program_cd,
             'INV Automatic Dis' category,
             0 as "Daily Count",
             0 as  "Cumulative Count"
from
       perlss.enr_rqst er
left join perlss.enr_dsnr_dtls edd on
       edd.enr_id = er.enr_id
where er.enr_id in (select max (enr_id) from perlss.enr_rqst er2 group by er2.pae_id)
       and er.enr_status_cd = 'DIS'
       and (er.hstry_sw = 'N'
             or er.hstry_sw is null)
       and er.active_sw = 'Y'
       and edd.dis_enr_rsn_cd <> 'DET'
       and extract(year from er.AUTH_dt::DATE) = extract(year from current_date) 
       and date_trunc( 'day', er.auth_dt)::date <= (current_date - interval '1 day')::date
       and edd.last_modified_by != 'ADM-CLONERECORD-DLY'
group by
       dis_enr_rsn_cd)) b on a.category = b.category and a.program_cd=b.program_cd
           ) a
right join 
(select  j.program_cd,j.category,0 as "Daily Count",0 as "Cumulative Count"
from
(select 'MDE' as program_cd,'VOL Automatic Dis' as category  union all
select 'HOS' as program_cd,'VOL Automatic Dis' as category  union all
select 'NFD' as program_cd,'VOL Automatic Dis' as category  union all
select 'DEN' as program_cd,'VOL Automatic Dis' as category  union all
select 'COS' as program_cd,'VOL Automatic Dis' as category  union all
select 'SAF' as program_cd,'VOL Automatic Dis' as category  union all
select 'NTC' as program_cd,'VOL Automatic Dis' as category  union all
select 'NON' as program_cd,'VOL Automatic Dis' as category  union all
select 'STA' as program_cd,'VOL Automatic Dis' as category  union all
select 'DCS' as program_cd,'VOL Automatic Dis' as category  union all
select 'COT' as program_cd,'VOL Automatic Dis' as category  union all
select 'NOS' as program_cd,'VOL Automatic Dis' as category  union all
select 'PAY' as program_cd,'VOL Automatic Dis' as category  union all
select 'HOM' as program_cd,'VOL Automatic Dis' as category  union all
select 'HNF' as program_cd,'VOL Automatic Dis' as category  union all
select 'MED' as program_cd,'VOL Automatic Dis' as category  union all
select 'PRE' as program_cd,'VOL Automatic Dis' as category  union all
select 'OTH' as program_cd,'VOL Automatic Dis' as category  union all
select 'DET' as program_cd,'VOL Automatic Dis' as category  union all
select 'PEN' as program_cd,'VOL Automatic Dis' as category  union all
select 'PED' as program_cd,'VOL Automatic Dis' as category  union all
select 'LNK' as program_cd,'VOL Automatic Dis' as category  union all
select 'INE' as program_cd,'VOL Automatic Dis' as category  union all
select 'SRM' as program_cd,'VOL Automatic Dis' as category  union all
select 'SRA' as program_cd,'VOL Automatic Dis' as category  union all
select 'NFI' as program_cd,'VOL Automatic Dis' as category  union all
select 'NSA' as program_cd,'VOL Automatic Dis' as category  union all
select 'TEN' as program_cd,'VOL Automatic Dis' as category  union all
select 'CEW' as program_cd,'VOL Automatic Dis' as category  union all
select 'SNS' as program_cd,'VOL Automatic Dis' as category  union all
select 'NMR' as program_cd,'VOL Automatic Dis' as category  union all
select 'NMN' as program_cd,'VOL Automatic Dis' as category  union all
select 'KBC' as program_cd,'VOL Automatic Dis' as category  union all
select 'VAU' as program_cd,'VOL Automatic Dis' as category  union all
select 'MRN' as program_cd,'VOL Automatic Dis' as category  union all
select 'MDE' as program_cd,'INV Automatic Dis' as category  union all
select 'HOS' as program_cd,'INV Automatic Dis' as category  union all
select 'NFD' as program_cd,'INV Automatic Dis' as category  union all
select 'DEN' as program_cd,'INV Automatic Dis' as category  union all
select 'COS' as program_cd,'INV Automatic Dis' as category  union all
select 'SAF' as program_cd,'INV Automatic Dis' as category  union all
select 'NTC' as program_cd,'INV Automatic Dis' as category  union all
select 'NON' as program_cd,'INV Automatic Dis' as category  union all
select 'STA' as program_cd,'INV Automatic Dis' as category  union all
select 'DCS' as program_cd,'INV Automatic Dis' as category  union all
select 'COT' as program_cd,'INV Automatic Dis' as category  union all
select 'NOS' as program_cd,'INV Automatic Dis' as category  union all
select 'PAY' as program_cd,'INV Automatic Dis' as category  union all
select 'HOM' as program_cd,'INV Automatic Dis' as category  union all
select 'HNF' as program_cd,'INV Automatic Dis' as category  union all
select 'MED' as program_cd,'INV Automatic Dis' as category  union all
select 'PRE' as program_cd,'INV Automatic Dis' as category  union all
select 'OTH' as program_cd,'INV Automatic Dis' as category  union all
select 'DET' as program_cd,'INV Automatic Dis' as category  union all
select 'PEN' as program_cd,'INV Automatic Dis' as category  union all
select 'PED' as program_cd,'INV Automatic Dis' as category  union all
select 'LNK' as program_cd,'INV Automatic Dis' as category  union all
select 'INE' as program_cd,'INV Automatic Dis' as category  union all
select 'SRM' as program_cd,'INV Automatic Dis' as category  union all
select 'SRA' as program_cd,'INV Automatic Dis' as category  union all
select 'NFI' as program_cd,'INV Automatic Dis' as category  union all
select 'NSA' as program_cd,'INV Automatic Dis' as category  union all
select 'TEN' as program_cd,'INV Automatic Dis' as category  union all
select 'CEW' as program_cd,'INV Automatic Dis' as category  union all
select 'SNS' as program_cd,'INV Automatic Dis' as category  union all
select 'NMR' as program_cd,'INV Automatic Dis' as category  union all
select 'NMN' as program_cd,'INV Automatic Dis' as category  union all
select 'KBC' as program_cd,'INV Automatic Dis' as category  union all
select 'VAU' as program_cd,'INV Automatic Dis' as category  union all
select 'MRN' as program_cd,'INV Automatic Dis' as category  
)j) b on a.program_cd=b.program_cd and a.category=b.category
 

union all

select 25 as seq,b.program_cd, b.category,
case when a."Daily Count">0 then a."Daily Count" else b."Daily Count" end "Daily Count",
case when a."Cumulative Count">0 then a."Cumulative Count" else b."Cumulative Count" end "Cumulative Count" 
from (select  b.program_cd , b.category,
case when a."Daily Count" > 0 then a."Daily Count" else b."Daily Count" end "Daily Count", 
case when a."Cumulative Count" > 0 then a."Cumulative Count" else b."Cumulative Count" end "Cumulative Count"
from
(select  b.dis_enr_rsn_cd as program_cd,b.category as "category" ,
case when a."Daily Count" is null then 0 else a."Daily Count" end "Daily Count"  , 
b."Cumulative Count" from 
(select dis_enr_rsn_cd,
             edd.dis_enr_type_cd ||' Manual Dis' category,
count(*) as "Daily Count"
from
    perlss.enr_rqst er
left join perlss.enr_dsnr_dtls edd on
    edd.enr_id = er.enr_id
where er.enr_id in (select max (enr_id) from perlss.enr_rqst er2 group by er2.pae_id)
   and  er.enr_status_cd = 'DIS'
    and (er.hstry_sw = 'N'
        or er.hstry_sw is null)
    and er.active_sw = 'Y'
    --and edd.dis_enr_type_cd = 'INV'
    and edd.dis_enr_rsn_cd <> 'DET'
    --and er.AUTH_dt::DATE = extract(year from current_date)
    and date_trunc( 'day', er.AUTH_dt)::date =(current_date - interval '1 day')::date 
    and edd.ltss_dscn_cd  is not null and not exists 
    (select chm.pae_id from perlss.chm_rqst chm 
    join perlss.chm_disenr_dtls cdd on chm.chm_id = cdd.chm_id and chm.chm_type_cd = 'DSER'
    where chm.chm_type_cd = 'DSER' and (cdd.disenr_type_cd = 'VOL' or (cdd.disenr_type_cd = 'INV' and cdd.disenr_rsn_cd in ('DCS','NFD','STA','NON','HOS') )  ) and chm.pae_id = er.pae_id) 
   and edd.last_modified_by != 'ADM-CLONERECORD-DLY'
group by dis_enr_rsn_cd, edd.dis_enr_type_cd) a
right join (
select dis_enr_rsn_cd,
             edd.dis_enr_type_cd ||' Manual Dis' category,
       count(*) as  "Cumulative Count" 
from
    perlss.enr_rqst er
left join perlss.enr_dsnr_dtls edd on
    edd.enr_id = er.enr_id
where er.enr_id in (select max (enr_id) from perlss.enr_rqst er2 group by er2.pae_id)
    and er.enr_status_cd = 'DIS'
    and (er.hstry_sw = 'N'
        or er.hstry_sw is null)
    and er.active_sw = 'Y'
    --and edd.dis_enr_type_cd = 'INV'
    and edd.dis_enr_rsn_cd <> 'DET'
    and extract(year from er.AUTH_dt::DATE) = extract(year from current_date)
    and date_trunc( 'day', er.AUTH_dt)::date <=(current_date - interval '1 day')::date 
    and edd.ltss_dscn_cd  is not null and not exists 
    (select chm.pae_id from perlss.chm_rqst chm 
    join perlss.chm_disenr_dtls cdd on chm.chm_id = cdd.chm_id and chm.chm_type_cd = 'DSER'
    where chm.chm_type_cd = 'DSER' and (cdd.disenr_type_cd = 'VOL' or (cdd.disenr_type_cd = 'INV' and cdd.disenr_rsn_cd in ('DCS','NFD','STA','NON','HOS') )  ) and chm.pae_id = er.pae_id) 
   and edd.last_modified_by != 'ADM-CLONERECORD-DLY'
group by dis_enr_rsn_cd, edd.dis_enr_type_cd) b on a.dis_enr_rsn_cd=b.dis_enr_rsn_cd and a.category=b.category) a
right join
(select dis_enr_rsn_cd as program_cd,
             'INV Manual Dis' category,
             0 as "Daily Count",
             0 as  "Cumulative Count"
from
       perlss.enr_rqst er
left join perlss.enr_dsnr_dtls edd on
       edd.enr_id = er.enr_id
where er.enr_id in (select max (enr_id) from perlss.enr_rqst er2 group by er2.pae_id)

       and er.enr_status_cd = 'DIS'
       and (er.hstry_sw = 'N'
             or er.hstry_sw is null)
       and er.active_sw = 'Y'
       and edd.dis_enr_rsn_cd <> 'DET'
       and extract(year from er.AUTH_dt::DATE) = extract(year from current_date) 
       and date_trunc( 'day', er.auth_dt)::date <= (current_date - interval '1 day')::date
       and edd.last_modified_by != 'ADM-CLONERECORD-DLY'
group by
       dis_enr_rsn_cd
       union all 
       select dis_enr_rsn_cd as program_cd,'VOL Manual Dis' category,
             0 as "Daily Count",
             0 as  "Cumulative Count"
from
       perlss.enr_rqst er
left join perlss.enr_dsnr_dtls edd on
       edd.enr_id = er.enr_id
where
		er.enr_id in (select max (enr_id) from perlss.enr_rqst er2 group by er2.pae_id)
       and er.enr_status_cd = 'DIS'
       and (er.hstry_sw = 'N'
             or er.hstry_sw is null)
       and er.active_sw = 'Y'
       and edd.dis_enr_rsn_cd <> 'DET'
       and extract(year from er.AUTH_dt::DATE) = extract(year from current_date)
       and date_trunc( 'day', er.auth_dt)::date <= (current_date - interval '1 day')::date
       and edd.last_modified_by != 'ADM-CLONERECORD-DLY'
group by
       dis_enr_rsn_cd) b on a.category = b.category and a.program_cd=b.program_cd
           ) a
right join 
(select  j.program_cd,j.category,0 as "Daily Count",0 as "Cumulative Count"
from
(select 'MDE' as program_cd,'VOL Manual Dis' as category  union all
select 'HOS' as program_cd,'VOL Manual Dis' as category  union all
select 'NFD' as program_cd,'VOL Manual Dis' as category  union all
select 'DEN' as program_cd,'VOL Manual Dis' as category  union all
select 'COS' as program_cd,'VOL Manual Dis' as category  union all
select 'SAF' as program_cd,'VOL Manual Dis' as category  union all
select 'NTC' as program_cd,'VOL Manual Dis' as category  union all
select 'NON' as program_cd,'VOL Manual Dis' as category  union all
select 'STA' as program_cd,'VOL Manual Dis' as category  union all
select 'DCS' as program_cd,'VOL Manual Dis' as category  union all
select 'COT' as program_cd,'VOL Manual Dis' as category  union all
select 'NOS' as program_cd,'VOL Manual Dis' as category  union all
select 'PAY' as program_cd,'VOL Manual Dis' as category  union all
select 'HOM' as program_cd,'VOL Manual Dis' as category  union all
select 'HNF' as program_cd,'VOL Manual Dis' as category  union all
select 'MED' as program_cd,'VOL Manual Dis' as category  union all
select 'PRE' as program_cd,'VOL Manual Dis' as category  union all
select 'OTH' as program_cd,'VOL Manual Dis' as category  union all
select 'DET' as program_cd,'VOL Manual Dis' as category  union all
select 'PEN' as program_cd,'VOL Manual Dis' as category  union all
select 'PED' as program_cd,'VOL Manual Dis' as category  union all
select 'LNK' as program_cd,'VOL Manual Dis' as category  union all
select 'INE' as program_cd,'VOL Manual Dis' as category  union all
select 'SRM' as program_cd,'VOL Manual Dis' as category  union all
select 'SRA' as program_cd,'VOL Manual Dis' as category  union all
select 'NFI' as program_cd,'VOL Manual Dis' as category  union all
select 'NSA' as program_cd,'VOL Manual Dis' as category  union all
select 'TEN' as program_cd,'VOL Manual Dis' as category  union all
select 'CEW' as program_cd,'VOL Manual Dis' as category  union all
select 'SNS' as program_cd,'VOL Manual Dis' as category  union all
select 'NMR' as program_cd,'VOL Manual Dis' as category  union all
select 'NMN' as program_cd,'VOL Manual Dis' as category  union all
select 'KBC' as program_cd,'VOL Manual Dis' as category  union all
select 'VAU' as program_cd,'VOL Manual Dis' as category  union all
select 'MRN' as program_cd,'VOL Manual Dis' as category  union all
select 'MDE' as program_cd,'INV Manual Dis' as category  union all
select 'HOS' as program_cd,'INV Manual Dis' as category  union all
select 'NFD' as program_cd,'INV Manual Dis' as category  union all
select 'DEN' as program_cd,'INV Manual Dis' as category  union all
select 'COS' as program_cd,'INV Manual Dis' as category  union all
select 'SAF' as program_cd,'INV Manual Dis' as category  union all
select 'NTC' as program_cd,'INV Manual Dis' as category  union all
select 'NON' as program_cd,'INV Manual Dis' as category  union all
select 'STA' as program_cd,'INV Manual Dis' as category  union all
select 'DCS' as program_cd,'INV Manual Dis' as category  union all
select 'COT' as program_cd,'INV Manual Dis' as category  union all
select 'NOS' as program_cd,'INV Manual Dis' as category  union all
select 'PAY' as program_cd,'INV Manual Dis' as category  union all
select 'HOM' as program_cd,'INV Manual Dis' as category  union all
select 'HNF' as program_cd,'INV Manual Dis' as category  union all
select 'MED' as program_cd,'INV Manual Dis' as category  union all
select 'PRE' as program_cd,'INV Manual Dis' as category  union all
select 'OTH' as program_cd,'INV Manual Dis' as category  union all
select 'DET' as program_cd,'INV Manual Dis' as category  union all
select 'PEN' as program_cd,'INV Manual Dis' as category  union all
select 'PED' as program_cd,'INV Manual Dis' as category  union all
select 'LNK' as program_cd,'INV Manual Dis' as category  union all
select 'INE' as program_cd,'INV Manual Dis' as category  union all
select 'SRM' as program_cd,'INV Manual Dis' as category  union all
select 'SRA' as program_cd,'INV Manual Dis' as category  union all
select 'NFI' as program_cd,'INV Manual Dis' as category  union all
select 'NSA' as program_cd,'INV Manual Dis' as category  union all
select 'TEN' as program_cd,'INV Manual Dis' as category  union all
select 'CEW' as program_cd,'INV Manual Dis' as category  union all
select 'SNS' as program_cd,'INV Manual Dis' as category  union all
select 'NMR' as program_cd,'INV Manual Dis' as category  union all
select 'NMN' as program_cd,'INV Manual Dis' as category  union all
select 'KBC' as program_cd,'INV Manual Dis' as category  union all
select 'VAU' as program_cd,'INV Manual Dis' as category  union all
select 'MRN' as program_cd,'INV Manual Dis' as category     
)j) b on a.program_cd=b.program_cd and a.category=b.category
     


union all

select  
26 as seq,
null as enr_grp_cd,
             'User Details (Unique Users)' as category,
             (select 
count(distinct  user_id) 
from perlss.fwr_session_manager fsm where session_start_dt::date = (current_date - interval '1 day')::date) as "Daily count",
(select  count( distinct  user_id) 
       from perlss.fwr_session_manager fsm where extract(year from session_start_dt) = extract(year from current_date)
       and  session_start_dt::date <= (current_date)::date-1) as  "Cumulative count" 
union all 
select seq, enr_grp_cd, category, sum(DC) as "Daily count",SUM(CC) as "Cumulative count" 
from (
select -- t.task_status_cd, t.count 
27 as seq,
null as enr_grp_cd,
             task_status_cd as category,
count as DC,
       0  as  CC 
from (
select tt.task_status_cd, count(tt.id) as count from perlss.tmg_task tt
where tt.created_dt::date = (current_date - interval '1 day')::date
group by tt.task_status_cd)t  
union  
SELECT 27 as seq,null, 'CL' , 0, 0
union  
SELECT 27 as seq,null, 'IP' , 0, 0
union  
SELECT 27 as seq,null , 'NW', 0, 0
union  
SELECT 27 as seq,null , 'AS', 0, 0
) x
group by seq, enr_grp_cd, category 
union all 
select  28 as seq,
(dmm.created_dt::date)::varchar ,
             'Documents Received by Day' as category,
count (distinct dmm.doc_id) as "Daily count",
       0  as  "Cumulative count" 
 from perlss.doc_module_mapping dmm
inner join perlss.app_doc ad on dmm.doc_id = ad.doc_id 
where (app_pdf_sw = 'N' or app_pdf_sw is null) and ad.delete_sw <> 'Y' 
and dmm.created_dt >= (current_timestamp - INTERVAL '7 DAY')

and dmm.created_by !='CV_282'
and (on_prem_flag is null or on_prem_flag='N')
group by dmm.created_dt::date
union all
--Docs Processed to FileNet:
select  29 as seq, 
(dmm.created_dt::date)::varchar ,
             'Docs Processed to FileNet:' as category,
count (distinct dmm.doc_id) as "Daily count",
       0 as  "Cumulative count" 
       from perlss.doc_module_mapping dmm
inner join perlss.app_doc ad on dmm.doc_id = ad.doc_id 
where (dmm.app_pdf_sw = 'N' or dmm.app_pdf_sw is null )
and dmm.created_dt::date >= (
current_date - INTERVAL '7 DAY') and ad.filenet_upload_sw = 'Y' and ad.delete_sw <> 'Y'
and (on_prem_flag is null or on_prem_flag='N')
and dmm.created_by !='CV_282' 
group by dmm.created_dt::date 
union all 
--Documents Received Total
select  
30 as seq,
null as program_cd,
'Total count of documents received',
0  as  "Daily count",
       count (distinct dmm.doc_id) as   "Cumulative count" 
from perlss.doc_module_mapping dmm
inner join perlss.app_doc ad on dmm.doc_id = ad.doc_id 
where (app_pdf_sw = 'N' or app_pdf_sw is null) and ad.delete_sw <> 'Y' and extract(year from dmm.created_dt)  = extract(year from current_date)
and dmm.created_dt <= (current_date - interval '1 day')::date
and dmm.created_by !='CV_282'
union all 
select 31 as seq, 
null as program_cd, 
REPORTS_CONCEPT, 
count as "Daily Count", 
0 as "Cumulative count"  from (
select  'Total count of documents received in previous day for Referral' as REPORTS_CONCEPT,
count (distinct dmm.doc_id) as  count from perlss.doc_module_mapping dmm where (app_pdf_sw = 'N' or app_pdf_sw is null ) 
and dmm.created_dt::date = (current_date - interval '1 day')::date and ref_id is not null
and dmm.created_by !='CV_282'
union all
select  'Total count of documents received in previous day for PAE' as REPORTS_CONCEPT,
count (distinct dmm.doc_id) as  count from perlss.doc_module_mapping dmm where (app_pdf_sw = 'N' or app_pdf_sw is null ) 
and dmm.created_dt::date = (current_date - interval '1 day')::date and pae_id is not null
and dmm.created_by !='CV_282'
union all
select  'Total count of documents received in previous day for Appeals' as REPORTS_CONCEPT,
count (distinct dmm.doc_id) as  count from perlss.doc_module_mapping dmm where (app_pdf_sw = 'N' or app_pdf_sw is null ) 
and dmm.created_dt::date = (current_date - interval '1 day')::date and apl_id is not null
and dmm.created_by !='CV_282'
union all
select  'Total count of documents received in previous day for Change' as REPORTS_CONCEPT,
count (distinct dmm.doc_id) as  count from perlss.doc_module_mapping dmm where (app_pdf_sw = 'N' or app_pdf_sw is null ) 
and dmm.created_dt::date = (current_date - interval '1 day')::date and chm_id is not null
and dmm.created_by !='CV_282'
union all
select  'Total count of documents received in previous day for Transitions' as REPORTS_CONCEPT,
count (distinct dmm.doc_id) as  count from perlss.doc_module_mapping dmm where (app_pdf_sw = 'N' or app_pdf_sw is null ) 
and dmm.created_dt::date = (current_date - interval '1 day')::date and tns_id is not null
and dmm.created_by !='CV_282') a 

union all 
--1. FILED- NO. OF APPEALS RECEIVED 
--a) Daily : System date - 1 business date
select 
32 as seq,
null as program_cd,
'Number of Appeals Received', count(*)  "Daily count" ,0 as   "Cumulative count"    
 from 
perlss.apl_rqst 
where created_dt::date  = (current_date - interval '1 day')::date 
group by created_dt::date
union all 
--************************************************************************************
select  
33 as seq,
null as program_cd,
'Number of Appeals Resolved',
count(ars.resolution_rsn_cd)  as  "Daily count",
       0 as   "Cumulative count" 
from
perlss.apl_rqst ar 
join perlss.apl_rsltn ars 
on ar.apl_id  = ars.apl_id 
where ar.last_modified_dt::date  = (current_date - interval '1 day')::date 
and ar.apl_status_cd  = 'CD'
union all 
select  
34 as seq,
null as program_cd,
'Number of Appeals Open',
count(*)  as  "Daily count",
       0 as   "Cumulative count" 
from perlss.apl_rqst 
where apl_status_cd != 'CD'
and date(created_dt) <= current_date - 1
union all 
select 35 as seq,
null as program_cd,
'Appeals Scheduled for Hearing ',
count(*)  as  "Daily count",
       0 as   "Cumulative count"  from 
(select ahd.apl_id, ahd.hrng_dt, ahd.created_dt  
from perlss.apl_hrng_dtls ahd
join perlss.apl_rqst ar 
on ahd.apl_id = ar.apl_id 
where ar.apl_status_cd != 'CD'
and date(ahd.created_dt) = current_date - 1
group by ahd.apl_id, ahd.created_dt, ahd.hrng_dt) a 
union all 
select 36 as seq,
null as program_cd,
'Total Appeals Open and Scheduled for Hearing',
count(*)  as  "Daily count",
       0 as   "Cumulative count"  from 
(
select ahd.apl_id, ahd.hrng_dt
from perlss.apl_hrng_dtls ahd
join perlss.apl_rqst ar 
on ahd.apl_id = ar.apl_id 
where ar.apl_status_cd != 'CD'
and date(ahd.hrng_dt) >= current_date 
group by ahd.apl_id, ahd.hrng_dt) a
union all 
select 
37 as seq,
module_cd as program_cd,
task_name,
count  as  "Daily count",
       0 as "Cumulative count"  from  
(select 
       t.module_cd,
       t.task_name,
       sum(t.count) as count 
from
       (
       select
             tt.module_cd,
             ttm.task_name,
             count(tt.id) as count
       from
             perlss.tmg_task tt
       inner join perlss.tmg_doc td on
             tt.input_id = td.input_id
       inner join perlss.tmg_task_master ttm on
             ttm.task_master_id = td.task_master_id
       where
             tt.created_dt::date = (current_date - interval '1 day')::date
       group by
             ttm.task_master_id,tt.module_cd
       union
       select distinct 
             tt.module_cd,
             ttm.task_name,
             0 as count
       from
             perlss.tmg_task tt
       inner join perlss.tmg_doc td on
             tt.input_id = td.input_id
       inner join perlss.tmg_task_master ttm on
             ttm.task_master_id = td.task_master_id
)t group by t.module_cd ,t.task_name) a 
) x
union all 
select 
38 as seq,
entity_name as program_cd,
role_name,
task_name, 
count  as  "Daily count",
       0 as "Cumulative count"  from  
/*All tasks that are Due post Jan 1st confirmed By TOM */
(select
       ttm.task_name,
       sr.role_name,
       so.entity_name,
       count (distinct task_id)
from
       perlss.tmg_task tt
join perlss.tmg_doc td on
       td.input_id = tt.input_id
join perlss.tmg_task_master ttm on
       td.task_master_id = ttm.task_master_id
join perlss.sec_roles sr on
       tt.role_id = sr.role_id
join perlss.sec_organization so on
       tt.entity_id = so.entity_id
where
       tt.task_status_cd != 'CL'
       and tt.due_dt::date <= current_date-1
       and extract(year from tt.due_dt::date)  = extract(year from current_date)
group by
       ttm.task_name,
       sr.role_name,
       so.entity_name
order by
       count (distinct task_id) desc) a
union all 
select 
39 as seq,
doc_type as program_cd,
doc_name,
null as task_name, 
dailycount  as  "Daily count",
       0 as "Cumulative count" 
       from (
select doc_type,doc_name,sum(dailycount) dailycount from (select t.doc_type, t.doc_name, t.count as dailycount from (
select doc_type, count(distinct dmm.doc_id) as count, dm.doc_name
from perlss.doc_module_mapping dmm join perlss.doc_master dm on dm.doc_type_cd = dmm.doc_type
where  dmm.created_dt::date = (current_date - interval '1 day')::date
and dmm.created_by !='CV_282'
group by doc_type, dm.doc_name)t
union 
select distinct doc_type, dm.doc_name, 0 as dailycount
from perlss.doc_module_mapping dmm join perlss.doc_master dm on dm.doc_type_cd = dmm.doc_type)a
group by doc_type,doc_name) a
       order by seq ) x
       union all 
select seq_id as seq, null::varchar(200) as program_cd,operation_name::varchar(200) as category,null::varchar(200) as task_name,daily as "Daily Count",cumulative as "Cumulative Count" from (
select  40 as seq_id , 'Total successful enrollment transactions sent to MMIS' operation_name , 
(select
                
                COUNT(*)
from
                perlss.int_mmis_abp_txn imat
where
                operation_name = 'EnrollPlan'
                and txn_status = 'Y'
                and created_dt   between (current_date-1) and (current_date)
               -- and created_dt   between ('2023-08-09 00:00:00.001') and ('2023-08-10 00:00:00.000')
          -- and created_dt::date    = (current_date - interval '1 day')::date
--group by operation_name
) as daily,
--Total
(select
                ----operation_name,
                COUNT(*)
from
                perlss.int_mmis_abp_txn imat
where
                operation_name = 'EnrollPlan'
                and txn_status = 'Y'
                --and created_dt   between ('2022-9-19 12:00:00.000') and ('2022-12-12 12:00:00.000')
                and extract(year from created_dt ::date) = extract(year from current_date)
               and created_dt::date <=(current_date - interval '1 day')::date 
--group by operation_name
) as cumulative
union all

--Total successful disenrollment transactions sent to MMIS
select  41 as seq_id , 'Total successful disenrollment transactions sent to MMIS' operation_name,
(select
                --operation_name,
                COUNT(*)
from
                perlss.int_mmis_abp_txn imat
where
                operation_name = 'DisEnroll'
                and txn_status = 'Y'
                and created_dt   between (current_date-1) and (current_date)
                --and created_dt::date    = (current_date - interval '1 day')::date
--group by operation_name
) as daily,
--Toatl
               (select
                --operation_name,
                COUNT(*)
from
                perlss.int_mmis_abp_txn imat
where
                operation_name = 'DisEnroll'
                and txn_status = 'Y'
               -- and created_dt   between ('2022-9-19 12:00:00.000') and ('2022-12-8 12:00:00.000')
                and extract(year from created_dt ::date) = extract(year from current_date)
                and created_dt::date <=(current_date - interval '1 day')::date 
--group by operation_name
                ) as cumulative
-----TOTAL MMIS TRANSITIONS
 union all              
               --Daily
select  42 as seq_id , 'Total MMIS Transitions' operation_name , 
 (
select
       --operation_name,
       COUNT(1) as daily
from
       perlss.int_mmis_abp_txn imat
where
       operation_name = 'TransPlan'
       and txn_status = 'Y'
      -- and created_dt::date ='2023-04-02'
        and created_dt between (current_date-1) and (current_date)
       --between ('2022-11-23 12:00:00.000') and ('2022-11-24 12:00:00.000')
--group by        operation_name
) as daily,
      
 --Cumulative
     (
                select
                --operation_name,
                COUNT(*)
from
                perlss.int_mmis_abp_txn imat
where
                operation_name = 'TransPlan'
                and txn_status = 'Y'
               -- and created_dt   between ('2022-9-19 12:00:00.000') and ('2022-12-8 12:00:00.000')
                and extract(year from created_dt ::date) = extract(year from current_date)
                and created_dt::date <=(current_date - interval '1 day')::date 
--group by operation_name
) as cumulative
               
  union all             
               
--Total successful updates sent to MMIS (includes all operations where we send updates)
select  43 as seq_id , 'Total successful updates sent to MMIS' operation_name , 
  (select sum(cnt) from (select
       --operation_name,
       COUNT(*) as cnt
from
       perlss.int_mmis_abp_txn imat
where
       operation_name in ('UpdtExpdtr', 'UpdateCosN', 'UpdateEnrl','ExtndERC', 'LocReasses')
       and txn_status = 'Y'
       and created_dt between (current_date-1) and (current_date)
       --and created_dt::date    = (current_date - interval '1 day')::date
       --group by operation_name
order by cnt desc) a ) as daily ,
      --Total
      (select sum(cnt) from (select
       --operation_name,
       COUNT(*) as cnt
from
       perlss.int_mmis_abp_txn imat
where
       operation_name in ('UpdtExpdtr', 'UpdateCosN', 'UpdateEnrl','ExtndERC', 'LocReasses')
       and txn_status = 'Y'
       and extract(year from created_dt ::date) = extract(year from current_date)
        and created_dt::date <=(current_date - interval '1 day')::date 
       --group by operation_name
order by cnt desc)a ) as cumulative
      ---
union all      
      

--Total successful LOC update transactions sent to TEDs that resulted in an update
  select  44 as seq_id , 'Total successful LOC update transactions sent to TEDS that resulted in an update' operation_name ,  
  (with TXN_STATS as (
select
                itmt.id,
                (itmt.message_data_rsp ->>'status')::int as statusCd,
                (itmt.message_data_rsp)::text as msg
from
                perlss.int_teds_memberdata_txn itmt
where
                int_name = 'Loc Update'
                --and created_dt::date    = (current_date - interval '1 day')::date
               and created_dt between (current_date-1) and (current_date)
)
select
                 count(id)
from
                TXN_STATS
where
                statusCd = 1
                and msg like '%Level of Care information Updated%') as daily,
               
               -----Total
               (with TXN_STATS as (
select
                itmt.id,
                (itmt.message_data_rsp ->>'status')::int as statusCd,
                (itmt.message_data_rsp)::text as msg
from
                perlss.int_teds_memberdata_txn itmt
where
                int_name = 'Loc Update'
                and extract(year from created_dt ::date) = extract(year from current_date)
                and created_dt::date <=(current_date - interval '1 day')::date )
select
                 count(id)
from
                TXN_STATS
where
                statusCd = 1
                and msg like '%Level of Care information Updated%') as cumulative
  union all             
--Total successful FE Update transactions consumed by PERLSS that resulted in a disenrollment
  select  45 as seq_id , 'Total successful FE Update transactions consumed by PERLSS that resulted in a disenrollment' operation_name ,  (select
                COUNT(itmt.*)
from
                perlss.int_teds_memberdata_txn itmt
inner join perlss.enr_rqst er on
                er.prsn_id = itmt.prsn_id
where
                itmt.operation_name = 'FeUpdate'
                and itmt.excp_dtls is null
                and itmt.message_data_rsp::text like '%Update Successful%'
                and er.last_modified_by = 'FEUPDATE'
                and er.enr_status_cd = 'DIS'
                --and er.last_modified_dt::date    = (current_date - interval '1 day')::date
               -- and itmt.created_dt ::date    = (current_date - interval '1 day')::date
                and er.last_modified_dt between (current_date-1) and (current_date)
               and itmt.created_dt between (current_date-1) and (current_date)) as daily,
               
               -----
               
               (select
                COUNT(itmt.*)
from
                perlss.int_teds_memberdata_txn itmt
inner join perlss.enr_rqst er on
                er.prsn_id = itmt.prsn_id
where
                itmt.operation_name = 'FeUpdate'
                and itmt.excp_dtls is null
                and itmt.message_data_rsp::text like '%Update Successful%'
                and er.last_modified_by = 'FEUPDATE'
                and er.enr_status_cd = 'DIS'
                --and er.last_modified_dt between ('2022-11-23 12:00:00.000') and ('2022-11-24 12:00:00.000')
                --and itmt.created_dt between ('2022-11-23 12:00:00.000') and ('2022-11-24 12:00:00.000')
                and extract(year from itmt.created_dt ::date) = extract(year from current_date)
                and er.last_modified_dt::date <=(current_date - interval '1 day')::date 
                and itmt.created_dt::date <=(current_date - interval '1 day')::date ) as cumulative
    union all            
--Total successful FE Update transactions consumed by PERLSS that resulted in a enrollment task creation
  select  46 as seq_id , 'Total successful FE Update transactions consumed by PERLSS that resulted in a enrollment task creation' operation_name ,
  (select
                COUNT(distinct tt.*)
from
                perlss.int_teds_memberdata_txn itmt
inner join perlss.enr_rqst er on
                er.prsn_id = itmt.prsn_id
inner join perlss.tmg_task tt on
                itmt.prsn_id = tt.prsn_id
where
                itmt.operation_name = 'FeUpdate'
                and itmt.excp_dtls is null
                and itmt.message_data_rsp::text like '%Task Created Successfully%'
                and tt.created_by = 'FEUPDATE'
                and tt.task_dtl_desc like '%Create%'
                and itmt.created_dt::date    = (current_date - interval '1 day')::date
                and tt.created_dt ::date    = (current_date - interval '1 day')::date ) as daily,
               --and itmt.created_dt  between ( CURRENT_DATE - INTERVAL '1 day' + INTERVAL '00:00:00.001' SECOND) and  (CURRENT_DATE + INTERVAL '00:00:00.000' second)
               --and tt.created_dt   between ( CURRENT_DATE - INTERVAL '1 day' + INTERVAL '00:00:00.001' SECOND) and  (CURRENT_DATE + INTERVAL '00:00:00.000' second)) as daily,
               
               --
               ( select
                count(distinct tt.*)
from
                perlss.int_teds_memberdata_txn itmt
inner join perlss.enr_rqst er on
                er.prsn_id = itmt.prsn_id
inner join perlss.tmg_task tt on
                itmt.prsn_id = tt.prsn_id
where
                itmt.operation_name = 'FeUpdate'
                and itmt.excp_dtls is null
                and itmt.message_data_rsp::text like '%Task Created Successfully%'
                and tt.created_by = 'FEUPDATE'
                and tt.task_dtl_desc like '%Create%'
                and extract(year from itmt.created_dt ::date) = extract(year from current_date)
                and itmt.created_dt::date <=(current_date - interval '1 day')::date 
                and tt.created_dt::date <=(current_date - interval '1 day')::date) as cumulative
                --and itmt.created_dt between ('2022-11-23 12:00:00.000') and ('2022-11-24 12:00:00.000')
                --and tt.created_dt  between ('2022-11-23 12:00:00.000') and ('2022-11-24 12:00:00.000');
      union all

--Daily Total successful KBLOCUpdate transactions sent to TEDS that resulted in an update
  select  47 as seq_id , 'Total successful KBLOCUpdate transactions sent to TEDS that resulted in an update' operation_name ,  (with TXN_STATS as (
select
                itkt.id,
                (itkt.txn_msg_data_res ->>'status')::int as statusCd,
                (itkt.txn_msg_data_res)::text as msg
from
                perlss.int_teds_kb_txn itkt
where
                int_name = 'KBLocUpdate'
                --and created_dt::date    = (current_date - interval '1 day')::date
                and (created_dt between (current_date-1) and (current_date))
)
select
                 count(id)
from
                TXN_STATS
where
                statusCd = 0
                and msg like '%Transaction processed successfully%') as daily,
------Total
 (with TXN_STATS as (
select
                itkt.id,
                (itkt.txn_msg_data_res ->>'status')::int as statusCd,
                (itkt.txn_msg_data_res)::text as msg
from
                perlss.int_teds_kb_txn itkt
where
                int_name = 'KBLocUpdate'
                and extract(year from created_dt ::date) = extract(year from current_date)
                and created_dt::date <=(current_date - interval '1 day')::date )
select
                 count(id)
from
                TXN_STATS
where
                statusCd = 0
                and msg like '%Transaction processed successfully%') as cumulative
union all

--Daily Total successful KBFE Update transactions consumed by PERLSS that resulted in slots being Unallocated
  select  48 as seq_id , 'Total successful KBFEUpdate transactions consumed by PERLSS that resulted in unallocated slot' operation_name ,  (select
               count (distinct itkt.prsn_id)
from
                perlss.int_teds_kb_txn itkt
inner join perlss.slt_details slt on
                slt.prsn_id = itkt.prsn_id
where
                itkt.operation_name = 'KBFeUpdate'
                and itkt.excp_dtls like '%Successfully updated%'
                and itkt.txn_msg_data_res::text like '%Trigger has been successfully placed in PERLSS%'
                and slt.last_modified_by like '%KBREFSERV%'
                and slt.slt_status_cd = 'UNA'
                --and slt.last_modified_dt::date    = (current_date - interval '1 day')::date
                --and itkt.created_dt ::date    = (current_date - interval '1 day')::date
                and slt.last_modified_dt between (current_date-1) and (current_date)
                and itkt.created_dt between (current_date-1) and (current_date)) as daily,
               
--Total
(select
              count (distinct itkt.prsn_id)
from
                perlss.int_teds_kb_txn itkt
inner join perlss.slt_details slt on
                slt.prsn_id = itkt.prsn_id
where
                itkt.operation_name = 'KBFeUpdate'
                and itkt.excp_dtls like '%Successfully updated%'
                and itkt.txn_msg_data_res::text like '%Trigger has been successfully placed in PERLSS%'
                and slt.last_modified_by like '%KBREFSERV%'
                and slt.slt_status_cd = 'UNA') as cumulative
                --and slt.last_modified_dt::date    = (current_date - interval '1 day')::date
                --and itkt.created_dt ::date    = (current_date - interval '1 day')::date
                --and slt.last_modified_dt between ('2023-08-09 00:00:00.001') and ('2023-08-10 00:00:00.000')
                --and itkt.created_dt between ('2023-08-09 00:00:00.001') and ('2023-08-10 00:00:00.000'); 
   union all             
--Today's successful KBFE Update transactions consumed by PERLSS that resulted in slots being Filled
  select  49 as seq_id , 'Total successful KBFEUpdate transactions consumed by PERLSS that resulted in a filled slot' operation_name ,  (select
                 count (distinct itkt.prsn_id)
from
                perlss.int_teds_kb_txn itkt
inner join perlss.slt_details slt on
                slt.prsn_id = itkt.prsn_id
where
                itkt.operation_name = 'KBFeUpdate'
                and itkt.excp_dtls like '%Successfully updated%'
                and itkt.txn_msg_data_res::text like '%Trigger has been successfully placed in PERLSS%'
                and slt.last_modified_by like '%ADM-SLTAUTO-DLY%'
                and slt.slt_status_cd = 'FIL'
                --and slt.last_modified_dt::date    = (current_date - interval '1 day')::date
                --and itkt.created_dt ::date    = (current_date - interval '1 day')::date
                and slt.last_modified_dt between (current_date-1) and (current_date)
                and itkt.created_dt between (current_date-1) and (current_date)) as daily,
               
--Total  
(select
         count (distinct itkt.prsn_id)
from
                perlss.int_teds_kb_txn itkt
inner join perlss.slt_details slt on
                slt.prsn_id = itkt.prsn_id
where
                itkt.operation_name = 'KBFeUpdate'
                and itkt.excp_dtls like '%Successfully updated%'
                and itkt.txn_msg_data_res::text like '%Trigger has been successfully placed in PERLSS%'
                and slt.last_modified_by like '%ADM-SLTAUTO-DLY%'
                and slt.slt_status_cd = 'FIL' ) as cumulative
                --and er.last_modified_dt::date    = (current_date - interval '1 day')::date
                --and itmt.created_dt ::date    = (current_date - interval '1 day')::date
                --and slt.last_modified_dt between ('2023-08-09 00:00:00.001') and ('2023-08-10 00:00:00.000')
                --and itkt.created_dt between ('2023-08-09 00:00:00.001') and ('2023-08-10 00:00:00.000'); 
    union all 
    select  50 as seq_id , 'Total successful KBReferralSync and KBDuplReferralSync transactions that created a referral' operation_name ,  (with TXN_STATS as (
select
                itkt.id,
                (itkt.txn_msg_data_res ->>'status')::int as statusCd,
                (txn_msg_data_res->>'description') as msg
from
                perlss.int_teds_kb_txn itkt
where
                int_name in ('KBReferralSync','KBDupReferralSync')
                and created_dt::date between (current_date-1) and (current_date))
select
                 count(id)
from
                TXN_STATS
where
                statusCd = 200
                and msg in ('NewTask Created Successfully', 
               'Review Change Task Created Successfully.', 'Duplicate Referral created with active refId.')) as daily,
                
---Total
(with TXN_STATS as (
select
                itkt.id,
                (itkt.txn_msg_data_res ->>'status')::int as statusCd,
                (txn_msg_data_res->>'description') as msg
from
                perlss.int_teds_kb_txn itkt
where
                int_name in ('KBReferralSync','KBDupReferralSync')
                and extract(year from created_dt::date) = extract(year from current_date)
                and created_dt::date <=(current_date - interval '1 day')::date  )
select
                 count(id)
from
                TXN_STATS
where
                statusCd = 200
                and msg in ('NewTask Created Successfully', 
               'Review Change Task Created Successfully.', 'Duplicate Referral created with active refId.')) as cumulative
               union all
--Total successful transactions that create Referrals.
--Daily
  select  51 as seq_id , 'Total successful requests to create referrals' operation_name ,  (with TXN_STATS as (
select
                itkt.id,
                (itkt.txn_msg_data_res ->>'status')::int as statusCd,
                (txn_msg_data_res->>'description') as msg
from
                perlss.int_teds_kb_txn itkt
where
                int_name in ('KBReferralSync','KBDupReferralSync')
                and created_dt::date between (current_date-1) and (current_date))
select
                 count(id)
from
                TXN_STATS
where
                statusCd = 200
                and msg in ('NewTask Created Successfully', 
               'Review Change Task Created Successfully.', 'Duplicate Referral created with active refId.')) as daily,
                
---Total
(with TXN_STATS as (
select
                itkt.id,
                (itkt.txn_msg_data_res ->>'status')::int as statusCd,
                (txn_msg_data_res->>'description') as msg
from
                perlss.int_teds_kb_txn itkt
where
                int_name in ('KBReferralSync','KBDupReferralSync')
                and extract(year from created_dt::date) = extract(year from current_date)
                and created_dt::date <=(current_date - interval '1 day')::date  )
select
                 count(id)
from
                TXN_STATS
where
                statusCd = 200
                and msg in ('NewTask Created Successfully', 
               'Review Change Task Created Successfully.', 'Duplicate Referral created with active refId.')) as cumulative
     union all           
--Total successful Add recipient calls made
  select  52 as seq_id , 'Total successful Add recipient calls made' operation_name ,  (select
                COUNT(*)
from
                perlss.int_mdm_txn imt
where
                operation_name = 'mdmAdd'
                and txn_status = 's'
               --and created_dt::date    = (current_date - interval '1 day')::date
                and created_dt  between (current_date-1) and (current_date)) as daily,
               
 --Total              
               (select
                COUNT(*)
from
                perlss.int_mdm_txn imt
where
                operation_name = 'mdmAdd'
                and txn_status = 's'
                and extract(year from created_dt ::date) = extract(year from current_date)
                and created_dt::date <=(current_date - interval '1 day')::date ) as cumulative
              --and created_dt   between ('2022-9-19 12:00:00.000') and ('2022-12-8 12:00:00.000')
                --and created_dt between ('2022-11-23 12:00:00.000') and ('2022-11-24 12:00:00.000');
   union all
   
  select  53 as seq_id , 'Total Demographic Updates sent to TEDS' operation_name ,  (
with TXN_STATS as (
select
                itmt.id,
                (itmt.message_data_rsp ->>'status')::int as statusCd,
                (itmt.message_data_rsp)::text as msg
from
                perlss.int_teds_memberdata_txn itmt
where
                int_name = 'DemoSyncOutbound'
--and created_dt::date    = (current_date - interval '1 day')::date
               and (created_dt between (current_date-1) and (current_date))
)
select
                 count(id)
from
                TXN_STATS
where
                statusCd = 0
                and msg like '%Successfully Updated Records%') as daily,
               
--Total
(with TXN_STATS as (
select
                itmt.id,
                (itmt.message_data_rsp ->>'status')::int as statusCd,
                (itmt.message_data_rsp)::text as msg
from
                perlss.int_teds_memberdata_txn itmt
where
                int_name = 'DemoSyncOutbound'

                and created_dt::date <=(current_date - interval '1 day')::date 
)
select
                 count(id)
from
                TXN_STATS
where
                statusCd = 0
                and msg like '%Successfully Updated Records%') as cumulative
union all
--Total Successful Demographic Updates received from TEDS
  select  54 as seq_id , 'Total Demographic Updates received from TEDS' operation_name ,  (with TXN_STATS as (
select
                itmt.id,
                (itmt.message_data_rsp ->>'status')::int as statusCd,
                (itmt.message_data_rsp)::text as msg
from
                perlss.int_teds_memberdata_txn itmt
where
                int_name = 'DemoGraphicSync'
--and created_dt::date    = (current_date - interval '1 day')::date
               and (created_dt between (current_date-1) and (current_date))
)
select
                 count(id)
from
                TXN_STATS
where
                statusCd = 200
                and msg like '%Demographic data updated successfully%') as daily,
--Total
(with TXN_STATS as (
select
                itmt.id,
                (itmt.message_data_rsp ->>'status')::int as statusCd,
                (itmt.message_data_rsp)::text as msg
from
                perlss.int_teds_memberdata_txn itmt
where
                int_name = 'DemoGraphicSync'

                and created_dt::date <=(current_date - interval '1 day')::date 

)
select
                 count(id)
from
                TXN_STATS
where
                statusCd = 200
                and msg like '%Demographic data updated successfully%') as cumulative) x
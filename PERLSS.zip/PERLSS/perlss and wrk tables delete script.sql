truncate table legacy.pasrr_base_member_pop; 
truncate table legacy.pasrr_pae_base_member_pop;
truncate table legacy.pasrr_tmed_base_member_pop;
truncate table legacy.pasrr_mmis_base_member_pop; 
truncate table legacy.pasrr_mdm_inputfile_generation;
truncate table legacy.pasrr_wrk_error_log;
truncate table legacy.pasrr_pae_base_member_pop_fload;
truncate table legacy.wrk_pasrr_clients;
delete from legacy.pasrr_mmis_dis;
delete from legacy.pasrr_mmis_enr;

delete from perlss.com_work_flow_analytics 
where task_id in (select task_id from perlss.tmg_task 
where pae_id in (select pae_id from perlss.cnv_task where created_by ='PASRR_CV'));

delete from perlss.tmg_task 
where pae_id in (select pae_id from perlss.cnv_task where created_by ='PASRR_CV');

delete from perlss.tmg_doc
where pae_id in (select pae_id from perlss.cnv_task where created_by ='PASRR_CV');

delete from perlss.cnv_task where created_by = 'PASRR_CV';

delete from perlss.com_comments       where created_by = 'PASRR_CV'; 
delete from perlss.com_notes      where created_by = 'PASRR_CV'; 
DELETE from perlss.com_work_flow_analytics  where PAE_ID in (select PAE_ID from perlss.pae_rqst where created_by = 'PASRR_CV'); 
delete from perlss.com_applcnt_access       where created_by = 'PASRR_CV'; 
delete from perlss.cnv_doc_dtls   where created_by = 'PASRR_CV'; 
delete from perlss.int_pasrr_doc_sync_stg             where created_by = 'PASRR_CV'; 


delete from perlss.enr_bnft where created_by = 'PASRR_CV';
delete from perlss.enr_dsnr_dtls where created_by = 'PASRR_CV';
delete from perlss.enr_patient_lblty_dtls  where created_by = 'PASRR_CV'; 
delete from perlss.enr_financial_elig  where created_by = 'PASRR_CV';
delete from perlss.enr_dtls where created_by = 'PASRR_CV';
delete from perlss.enr_rqst where created_by = 'PASRR_CV';

delete from perlss.adj_pasrr_outcome      where created_by = 'PASRR_CV'; 
delete from perlss.pasrr_addr_dtl where created_by = 'PASRR_CV' ;
delete from perlss.pasrr_skilled_srvcs where created_by = 'PASRR_CV' ;
delete from perlss.pasrr_loc_dtls where created_by = 'PASRR_CV';
delete from perlss.pasrr_outcome_dtls where created_by = 'PASRR_CV'; 
delete from perlss.pasrr_functnl_assmnt where created_by = 'PASRR_CV'; 
delete from perlss.pasrr_submtr_dtls where created_by = 'PASRR_CV';
delete from perlss.pasrr_rqst where created_by = 'PASRR_CV';



delete from perlss.adj_clrfcn_rsn           where created_by = 'PASRR_CV'; 
delete from perlss.adj_functnl_assmnt          where created_by = 'PASRR_CV'; 
delete from perlss.adj_safety_determn       where created_by = 'PASRR_CV'; 
delete from perlss.adj_skilled_srvcs_info       where created_by = 'PASRR_CV'; 
delete from perlss.adj_skilled_srvcs       where created_by = 'PASRR_CV'; 
delete from perlss.adj_dtls   where created_by = 'PASRR_CV'; 
delete from perlss.adj_rqst             where created_by = 'PASRR_CV'; 

delete from perlss.pae_chrnc_med_diagns  where created_by = 'PASRR_CV';
delete from perlss.pae_doc_summary  where created_by = 'PASRR_CV';
delete from perlss.pae_lvng_arrgmnt  where created_by = 'PASRR_CV';
delete from perlss.pae_flow_sequence  where created_by = 'PASRR_CV';
delete from perlss.pae_action where created_by = 'PASRR_CV';
delete from perlss.pae_sis_assessment where created_by = 'PASRR_CV';
delete from perlss.pae_certify_of_assmnt  where created_by = 'PASRR_CV';
delete from perlss.pae_med_diagns_dtls where created_by = 'PASRR_CV'; 
delete from perlss.pae_medical_diagnosis where created_by = 'PASRR_CV';
delete from perlss.pae_program_selection where created_by = 'PASRR_CV';
delete from perlss.pae_skilled_srvc_summary where created_by = 'PASRR_CV';
delete from perlss.pae_activities_medication_dtl             where created_by = 'PASRR_CV'; 
delete from perlss.pae_driver_flow  where created_by = 'PASRR_CV'; 
delete from perlss.pae_med_diagns_dtls where created_by = 'PASRR_CV'; 
delete from perlss.pae_medical_diagnosis where created_by = 'PASRR_CV';
delete from perlss.pae_activities_behavrl_dtl where created_by = 'PASRR_CV'; 
delete from perlss.pae_activities_lvng        where created_by = 'PASRR_CV'; 
delete from perlss.pae_app_addr_dtl           where created_by = 'PASRR_CV'; 
delete from perlss.pae_app_cntct_dtl          where created_by = 'PASRR_CV'; 
delete from perlss.pae_respiratory_care       where created_by = 'PASRR_CV'; 
delete from perlss.pae_safety_deter_form      where created_by = 'PASRR_CV'; 
delete from perlss.pae_safety_deter_sum       where created_by = 'PASRR_CV'; 
delete from perlss.pae_skilled_srvc_dtl       where created_by = 'PASRR_CV'; 
delete from perlss.pae_skilled_srvc_summary   where created_by = 'PASRR_CV'; 
delete from perlss.pae_submission             where created_by = 'PASRR_CV'; 
delete from perlss.pae_rqst                   where created_by = 'PASRR_CV';

delete from perlss.com_applcnt                   where created_by = 'PASRR_CV';
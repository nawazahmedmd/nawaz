-- legacy.pasrr_blob_final definition

-- Drop table

-- DROP TABLE legacy.pasrr_blob_final;

CREATE TABLE legacy.pasrr_blob_final (
	episodeid int4 NULL,
	clientid int4 NULL,
	episodeguid varchar(50) NULL,
	attachmentid int4 NULL,
	attachmenttype varchar(50) NULL,
	mimetype varchar(50) NULL,
	azuredocumentid varchar(50) NULL,
	uploaddate varchar(50) NULL,
	upload_date timestamp NULL,
	filename varchar(100) NULL,
	actual_file_name varchar(200) NULL,
	srcfilename varchar(200) NULL
);

-- legacy.pasrr_demographics definition

-- Drop table

-- DROP TABLE legacy.pasrr_demographics;

CREATE TABLE legacy.pasrr_demographics (
	individualid varchar(36) NULL,
	lastname varchar(20) NULL,
	firstname varchar(20) NULL,
	middleinitial varchar(1) NULL,
	ssn varchar(11) NULL,
	dob date NULL,
	gender varchar(1) NULL,
	created_dt timestamp NULL,
	filename varchar(250) NULL,
	ascendid int8 NULL,
	created_by varchar(50) NULL
);


-- legacy.pasrr_doc definition

-- Drop table

-- DROP TABLE legacy.pasrr_doc;

CREATE TABLE legacy.pasrr_doc (
	eventid varchar(36) NULL,
	filename varchar(255) NULL,
	attachmenttype varchar(30) NULL,
	mimetype varchar(75) NULL,
	filesize varchar(10) NULL,
	created_dt timestamp NULL,
	srcfilename varchar(250) NULL,
	reviewid int8 NULL,
	created_by varchar(50) NULL,
	attatchmentid int8 NULL,
	upload_date varchar(30) NULL,
	upload_date_new timestamp NULL
);


-- legacy.pasrr_events definition

-- Drop table

-- DROP TABLE legacy.pasrr_events;

CREATE TABLE legacy.pasrr_events (
	eventid varchar(36) NULL,
	individualid varchar(36) NULL,
	guardianfirstname varchar(20) NULL,
	guardianlastname varchar(20) NULL,
	guardianaddress varchar(100) NULL,
	guardianaddress2 varchar(100) NULL,
	guardiancity varchar(50) NULL,
	guardianstate varchar(2) NULL,
	guardianzip varchar(5) NULL,
	individualaddress1 varchar(100) NULL,
	individualaddress2 varchar(100) NULL,
	individualcity varchar(50) NULL,
	individualstate varchar(2) NULL,
	individualzip varchar(5) NULL,
	individualcounty varchar(20) NULL,
	payersource varchar(50) NULL,
	hospitaladmitdate date NULL,
	nfadmitdate date NULL,
	reviewtype varchar(50) NULL,
	created_dt timestamp NULL,
	filename varchar(250) NULL,
	admittingfacilityname varchar(255) NULL,
	responsiblepartyfirstname varchar(20) NULL,
	responsiblepartylastname varchar(20) NULL,
	responsiblepartyaddress1 varchar(100) NULL,
	responsiblepartyaddress2 varchar(100) NULL,
	responsiblepartycity varchar(50) NULL,
	responsiblepartystate varchar(2) NULL,
	responsiblepartyzip varchar(5) NULL,
	currentlocation varchar(50) NULL,
	currentlocationfacility varchar(255) NULL,
	currentlocationaddress1 varchar(100) NULL,
	currentlocationaddress2 varchar(100) NULL,
	currentlocationcity varchar(50) NULL,
	currentlocationstate varchar(2) NULL,
	currentlocationzip varchar(5) NULL,
	primarylanguage varchar(50) NULL,
	reviewid int8 NULL,
	created_by varchar(50) NULL
);


-- legacy.pasrr_level_i definition

-- Drop table

-- DROP TABLE legacy.pasrr_level_i;

CREATE TABLE legacy.pasrr_level_i (
	eventid varchar(36) NULL,
	level1outcome varchar(60) NULL,
	level1determinationdate timestamp NULL,
	level1lettertypesent varchar(30) NULL,
	level1submissiondate timestamp NULL,
	level1lettersentdate timestamp NULL,
	level1determinationeffectivedate timestamp NULL,
	level1determinationenddate timestamp NULL,
	level1submitterlastname varchar(20) NULL,
	level1submitterfirstname varchar(20) NULL,
	level1submittingfacility varchar(255) NULL,
	level1submittingfacilityaddress varchar(100) NULL,
	level1submittingfacilitycity varchar(50) NULL,
	level1submittingfacilitystate varchar(2) NULL,
	level1submittingfacilityzip varchar(5) NULL,
	created_dt timestamp NULL,
	filename varchar(250) NULL,
	created_by varchar(50) NULL
);


-- legacy.pasrr_level_ii definition

-- Drop table

-- DROP TABLE legacy.pasrr_level_ii;

CREATE TABLE legacy.pasrr_level_ii (
	eventid varchar(36) NULL,
	level2noticetype varchar(40) NULL,
	level2noticesentdate timestamp NULL,
	level2senttostatedate timestamp NULL,
	level2assessmentdate timestamp NULL,
	level2outcome varchar(50) NULL,
	level2determinationdate timestamp NULL,
	level2determinationeffectivedate timestamp NULL,
	level2determinationenddate timestamp NULL,
	level2specializedservicesdetermination varchar(5) NULL,
	level2skilledserviceapprovedstartdate timestamp NULL,
	level2skilledserviceenddate timestamp NULL,
	leve2approvedstreason varchar(20) NULL,
	level2shorttermdays int4 NULL,
	level2pasrrcondition varchar(10) NULL,
	created_dt timestamp NULL,
	filename varchar(250) NULL,
	level2duetostatedate timestamp NULL,
	expedited varchar(5) NULL,
	assessmentid int8 NULL,
	reconof int8 NULL,
	created_by varchar(50) NULL
);


-- legacy.pasrr_loc definition

-- Drop table

-- DROP TABLE legacy.pasrr_loc;

CREATE TABLE legacy.pasrr_loc (
	eventid varchar(36) NULL,
	locreimbursementlevel varchar(50) NULL,
	referraldate timestamp NULL,
	referralname varchar(50) NULL,
	referralfacility varchar(255) NULL,
	locoutcome varchar(50) NULL,
	locdeterminationdate timestamp NULL,
	safetyformrequest varchar(5) NULL,
	referralcomments varchar(25614) NULL,
	diagnosisrelevanttoneeds varchar(30710) NULL,
	safetyformdeclineddate timestamp NULL,
	rationale varchar(4253) NULL,
	attestationdate timestamp NULL,
	submittedacuityscore int2 NULL,
	approvedacuityscore int2 NULL,
	functionaldeficitidentified varchar(5) NULL,
	safetyformreviewed varchar(5) NULL,
	safetyformoutcome varchar(50) NULL,
	skilledservicesapproved varchar(5) NULL,
	skilledservicesduration int4 NULL,
	adltransfer varchar(20) NULL,
	adltransfercliniciandetermination varchar(20) NULL,
	adltransferclinicianresponse varchar(20) NULL,
	adltransferdenialreason varchar(50) NULL,
	adltransferrationale varchar(1110) NULL,
	adlwalking varchar(20) NULL,
	adlwalkingcliniciandetermination varchar(20) NULL,
	adlwalkingclinicianresponse varchar(20) NULL,
	adlwalkingdenialreason varchar(50) NULL,
	adlwalkingrationale varchar(1110) NULL,
	adlmobility varchar(20) NULL,
	adlmobilitycliniciandetermination varchar(20) NULL,
	adlmobilityclinicianresponse varchar(20) NULL,
	adlmobilitydenialreason varchar(50) NULL,
	adlmobilityrationale varchar(1110) NULL,
	adleating varchar(20) NULL,
	adleatingcliniciandetermination varchar(20) NULL,
	adleatingclinicianresponse varchar(20) NULL,
	adleatingdenialreason varchar(50) NULL,
	adleatingrationale varchar(1214) NULL,
	adltoileting varchar(20) NULL,
	adltoiletingcliniciandetermination varchar(20) NULL,
	adltoiletingclinicianresponse varchar(20) NULL,
	adltoiletingdenialreason varchar(50) NULL,
	adltoiletingrationale varchar(1110) NULL,
	adlincontinentcare varchar(20) NULL,
	adlincontinentcarecliniciandetermination varchar(20) NULL,
	adlincontinentcareclinicianresponse varchar(20) NULL,
	adlincontinentcaredenialreason varchar(50) NULL,
	adlincontinentbowel varchar(5) NULL,
	adlincontinentbladder varchar(5) NULL,
	adlincontinentcarerationale varchar(407) NULL,
	adlcathetercare varchar(20) NULL,
	adlcathetercarecliniciandetermination varchar(20) NULL,
	adlcathetercareclinicianresponse varchar(20) NULL,
	adlcathetercaredenialreason varchar(50) NULL,
	adlcathetercarerationale varchar(345) NULL,
	adlorientation varchar(20) NULL,
	adlorientationcliniciandetermination varchar(20) NULL,
	adlorientationclinicianresponse varchar(20) NULL,
	adlorientationdenialreason varchar(50) NULL,
	adlorientationrationale varchar(853) NULL,
	adlexpressive varchar(20) NULL,
	adlexpressivecliniciandetermination varchar(20) NULL,
	adlexpressiveclinicianresponse varchar(20) NULL,
	adlexpressivedenialreason varchar(50) NULL,
	adlexpressiverationale varchar(444) NULL,
	adlreceptive varchar(20) NULL,
	adlreceptivecliniciandetermination varchar(20) NULL,
	adlreceptiveclinicianresponse varchar(20) NULL,
	adlreceptivedenialreason varchar(50) NULL,
	adlreceptiverationale varchar(813) NULL,
	adlmedsadmin varchar(20) NULL,
	adlmedsadmincliniciandetermination varchar(20) NULL,
	adlmedsadminclinicianresponse varchar(20) NULL,
	adlmedsadmindenialreason varchar(50) NULL,
	adlmedsadminrationale varchar(11025) NULL,
	adlmedsadminnotes varchar(10578) NULL,
	adlbehavior varchar(20) NULL,
	adlbehaviorcliniciandetermination varchar(20) NULL,
	adlbehaviorclinicianresponse varchar(20) NULL,
	adlbehaviordenialreason varchar(50) NULL,
	adlbehaviorrationale varchar(1260) NULL,
	adlbehaviornotes varchar(6487) NULL,
	chronicventilatorservices varchar(5) NULL,
	ventilatorclinicaldetermination varchar(10) NULL,
	ventilatorrationale varchar(3236) NULL,
	trachealsuctioning varchar(5) NULL,
	trachealsuctioningclinicaldetermination varchar(10) NULL,
	trachealsuctioningrationale varchar(3236) NULL,
	woundcaredecubitus varchar(5) NULL,
	woundcaredecubitusstartdate date NULL,
	woundcaredecubitusenddate date NULL,
	woundcaredecubitusclinicaldetermination varchar(10) NULL,
	woundcaredecubitusrationale varchar(3236) NULL,
	woundcareother varchar(5) NULL,
	woundcareotherstartdate date NULL,
	woundcareotherenddate date NULL,
	woundcareotherclinicaldetermination varchar(10) NULL,
	woundcareotherrationale varchar(3236) NULL,
	injectionsinsulin varchar(5) NULL,
	injectionsinsulinstartdate date NULL,
	injectionsinsulinenddate date NULL,
	injectionsinsulinclinicaldetermination varchar(10) NULL,
	injectionsinsulinrationale varchar(3236) NULL,
	injectionsother varchar(5) NULL,
	injectionsotherstartdate date NULL,
	injectionsotherenddate date NULL,
	injectionsotherclinicaldetermination varchar(10) NULL,
	injectionsotherrationale varchar(3236) NULL,
	intravenousfluids varchar(5) NULL,
	intravenousfluidsstartdate date NULL,
	intravenousfluidsenddate date NULL,
	intravenousfluidsclinicaldetermination varchar(10) NULL,
	intravenousfluidsrationale varchar(3236) NULL,
	isolationprecautions varchar(5) NULL,
	isolationprecautionsstartdate date NULL,
	isolationprecautionsenddate date NULL,
	isolationprecautionsclinicaldetermination varchar(10) NULL,
	isolationprecautionsrationale varchar(3236) NULL,
	occupationaltherapy varchar(5) NULL,
	occupationaltherapystartdate date NULL,
	occupationaltherapyenddate date NULL,
	occupationaltherapyclinicaldetermination varchar(10) NULL,
	occupationaltherapyrationale varchar(3236) NULL,
	physicaltherapy varchar(5) NULL,
	physicaltherapystartdate date NULL,
	physicaltherapyenddate date NULL,
	physicaltherapyclinicaldetermination varchar(10) NULL,
	physicaltherapyrationale varchar(3236) NULL,
	catheterostomy varchar(5) NULL,
	catheterostomystartdate date NULL,
	catheterostomyenddate date NULL,
	catheterostomyclinicaldetermination varchar(10) NULL,
	catheterostomyrationale varchar(3236) NULL,
	selfinjection varchar(5) NULL,
	selfinjectionstartdate date NULL,
	selfinjectionenddate date NULL,
	selfinjectionclinicaldetermination varchar(10) NULL,
	selfinjectionrationale varchar(3236) NULL,
	parenteralnutrition varchar(5) NULL,
	parenteralnutritionstartdate date NULL,
	parenteralnutritionenddate date NULL,
	parenteralnutritionclinicaldetermination varchar(10) NULL,
	parenteralnutritionrationale varchar(3236) NULL,
	tubefeeding varchar(5) NULL,
	tubefeedingstartdate date NULL,
	tubefeedingenddate date NULL,
	tubefeedingclinicaldetermination varchar(10) NULL,
	tubefeedingrationale varchar(3236) NULL,
	peritonealdialysis varchar(5) NULL,
	peritonealdialysisstartdate date NULL,
	peritonealdialysisenddate date NULL,
	peritonealdialysisclinicaldetermination varchar(10) NULL,
	peritonealdialysisrationale varchar(3236) NULL,
	pcapump varchar(5) NULL,
	pcapumpstartdate date NULL,
	pcapumpenddate date NULL,
	pcapumpclinicaldetermination varchar(10) NULL,
	pcapumprationale varchar(3236) NULL,
	tracheostomy varchar(5) NULL,
	tracheostomystartdate date NULL,
	tracheostomyenddate date NULL,
	tracheostomyclinicaldetermination varchar(10) NULL,
	tracheostomyrationale varchar(3236) NULL,
	other varchar(5) NULL,
	otherstartdate date NULL,
	otherenddate date NULL,
	otherclinicaldetermination varchar(10) NULL,
	otherrationale varchar(3236) NULL,
	created_dt timestamp NULL,
	filename varchar(250) NULL,
	revisionof int8 NULL,
	created_by varchar(50) NULL
);
CREATE INDEX idx1 ON legacy.pasrr_loc USING btree (eventid);


-- legacy.pasrr_mmis_t_cde_aid definition

-- Drop table

-- DROP TABLE legacy.pasrr_mmis_t_cde_aid;

CREATE TABLE legacy.pasrr_mmis_t_cde_aid (
	sak_cde_aid int4 NOT NULL,
	cde_aid_category varchar(2) NOT NULL,
	dsc_aid_category varchar(100) NOT NULL,
	ind_diag_in_exclud varchar(1) NOT NULL,
	ind_spec_in_exclud varchar(1) NOT NULL,
	ind_emergency varchar(1) NOT NULL,
	cde_aid_pov_lvl varchar(3) NOT NULL,
	dsc_tnanytime_aid_category varchar(100) NOT NULL,
	created_dt timestamp NULL,
	sourcefilename varchar(250) NULL,
	created_by varchar(50) NULL
);


-- legacy.pasrr_mmis_t_cde_disenroll_reasons definition

-- Drop table

-- DROP TABLE legacy.pasrr_mmis_t_cde_disenroll_reasons;

CREATE TABLE legacy.pasrr_mmis_t_cde_disenroll_reasons (
	cde_disenroll_rsn varchar(2) NOT NULL,
	desc_disenroll_rsn varchar(25) NOT NULL,
	cde_type varchar(1) NOT NULL,
	ind_letter varchar(1) NOT NULL,
	created_dt timestamp NULL,
	sourcefilename varchar(250) NULL,
	created_by varchar(50) NULL
);


-- legacy.pasrr_mmis_t_mc_re_sum_elig definition

-- Drop table

-- DROP TABLE legacy.pasrr_mmis_t_mc_re_sum_elig;

CREATE TABLE legacy.pasrr_mmis_t_mc_re_sum_elig (
	sak_recip int4 NOT NULL,
	dte_effective int8 NOT NULL,
	dte_end int8 NOT NULL,
	sak_pub_hlth int4 NOT NULL,
	sak_cde_drvd_mco int4 NOT NULL,
	sak_cde_drvd_bho int4 NOT NULL,
	sak_cde_aid_prnt int4 NOT NULL,
	sak_pgm_elig_prnt int4 NOT NULL,
	sak_case int4 NOT NULL,
	ind_benefit_plan varchar(1) NOT NULL,
	cde_copay varchar(2) NOT NULL,
	sp_id varchar(2) NOT NULL,
	case_hoh varchar(9) NOT NULL,
	ind_deductible varchar(1) NOT NULL,
	cde_crg varchar(1) NOT NULL,
	ind_pregnancy varchar(1) NOT NULL,
	ind_institutional varchar(1) NOT NULL,
	ind_mn varchar(1) NOT NULL,
	dte_last_update int8 NOT NULL,
	ind_dcs varchar(1) NULL,
	amt_income numeric(10, 2) NULL,
	num_fpl int4 NULL,
	created_dt timestamp NULL,
	sourcefilename varchar(250) NULL,
	created_by varchar(50) NULL
);


-- legacy.pasrr_mmis_t_pmp_svc_loc definition

-- Drop table

-- DROP TABLE legacy.pasrr_mmis_t_pmp_svc_loc;

CREATE TABLE legacy.pasrr_mmis_t_pmp_svc_loc (
	sak_pmp_ser_loc int4 NOT NULL,
	sak_prov int4 NOT NULL,
	cde_service_loc varchar(1) NOT NULL,
	sak_pub_hlth int4 NOT NULL,
	sak_prov_pgm int4 NOT NULL,
	cde_state_region varchar(2) NOT NULL,
	dte_effective int8 NOT NULL,
	dte_end int8 NOT NULL,
	sak_pmp_focus int4 NOT NULL,
	num_pho_24_hour varchar(10) NOT NULL,
	num_pho_ext varchar(4) NOT NULL,
	cde_file_format varchar(1) NOT NULL,
	num_act_panel int4 NOT NULL,
	ind_autoassign varchar(1) NOT NULL,
	ind_panel_hold varchar(1) NOT NULL,
	ind_active varchar(1) NOT NULL,
	created_dt timestamp NULL,
	sourcefilename varchar(250) NULL,
	created_by varchar(50) NULL
);


-- legacy.pasrr_mmis_t_pr_nam definition

-- Drop table

-- DROP TABLE legacy.pasrr_mmis_t_pr_nam;

CREATE TABLE legacy.pasrr_mmis_t_pr_nam (
	sak_prov int4 NOT NULL,
	sak_short_name int4 NOT NULL,
	"name" varchar(50) NOT NULL,
	ind_name_type varchar(1) NOT NULL,
	nam_title varchar(15) NOT NULL,
	cde_soundex varchar(4) NOT NULL,
	nam_dba varchar(40) NULL,
	created_dt timestamp NULL,
	sourcefilename varchar(250) NULL,
	created_by varchar(50) NULL
);


-- legacy.pasrr_mmis_t_pr_prov definition

-- Drop table

-- DROP TABLE legacy.pasrr_mmis_t_pr_prov;

CREATE TABLE legacy.pasrr_mmis_t_pr_prov (
	sak_prov int4 NOT NULL,
	id_provider varchar(9) NOT NULL,
	num_upin varchar(6) NOT NULL,
	ind_on_review varchar(1) NOT NULL,
	ind_owner_interest varchar(1) NOT NULL,
	cde_gender varchar(1) NOT NULL,
	dte_birth_prov int8 NOT NULL,
	num_prov_ssn varchar(9) NOT NULL,
	created_dt timestamp NULL,
	sourcefilename varchar(250) NULL,
	created_by varchar(50) NULL
);


-- legacy.pasrr_mmis_t_pub_hlth_pgm definition

-- Drop table

-- DROP TABLE legacy.pasrr_mmis_t_pub_hlth_pgm;

CREATE TABLE legacy.pasrr_mmis_t_pub_hlth_pgm (
	sak_pub_hlth int4 NOT NULL,
	cde_pgm_health varchar(5) NOT NULL,
	dsc_pgm_health varchar(50) NOT NULL,
	dsc_pgm_definition varchar(4000) NOT NULL,
	ind_recip_only varchar(1) NULL,
	ind_major_pgm varchar(1) NULL,
	ind_stand_alone varchar(1) NULL,
	ind_dual varchar(1) NULL,
	ind_ct_editing varchar(1) NULL,
	ind_copay varchar(1) NULL,
	ind_setup varchar(1) NULL,
	cde_enrollment varchar(1) NULL,
	elig_window_filter varchar(1) NULL,
	created_dt timestamp NULL,
	sourcefilename varchar(250) NULL,
	created_by varchar(50) NULL
);


-- legacy.pasrr_mmis_t_re_aid_elig definition

-- Drop table

-- DROP TABLE legacy.pasrr_mmis_t_re_aid_elig;

CREATE TABLE legacy.pasrr_mmis_t_re_aid_elig (
	sak_aid_elig int4 NOT NULL,
	sak_recip int4 NOT NULL,
	sak_pgm_elig int4 NOT NULL,
	sak_cde_aid int4 NOT NULL,
	sak_case int4 NOT NULL,
	dte_effective int8 NOT NULL,
	dte_end int8 NOT NULL,
	cde_status1 varchar(1) NOT NULL,
	cde_source varchar(3) NOT NULL,
	cde_source_state varchar(1) NOT NULL,
	ind_rqst_close varchar(1) NOT NULL,
	dte_added int8 NOT NULL,
	dte_last_update int8 NOT NULL,
	created_dt timestamp NULL,
	sourcefilename varchar(250) NULL,
	created_by varchar(50) NULL
);


-- legacy.pasrr_mmis_t_re_base definition

-- Drop table

-- DROP TABLE legacy.pasrr_mmis_t_re_base;

CREATE TABLE legacy.pasrr_mmis_t_re_base (
	sak_recip int4 NOT NULL,
	id_medicaid varchar(12) NOT NULL,
	nam_last varchar(20) NOT NULL,
	nam_first varchar(15) NOT NULL,
	nam_mid_init varchar(1) NOT NULL,
	adr_street_1 varchar(30) NOT NULL,
	adr_street_2 varchar(30) NOT NULL,
	adr_city varchar(18) NOT NULL,
	adr_state varchar(2) NOT NULL,
	adr_zip_code varchar(5) NOT NULL,
	adr_zip_code_4 varchar(4) NOT NULL,
	cde_addr_source varchar(3) NOT NULL,
	num_latitude numeric(11, 6) NOT NULL,
	num_longitude numeric(11, 6) NOT NULL,
	cde_gis_quality int4 NOT NULL,
	num_ssn varchar(9) NOT NULL,
	dte_birth int8 NOT NULL,
	dte_death int8 NOT NULL,
	cde_sex varchar(1) NOT NULL,
	cde_race varchar(2) NOT NULL,
	cde_ethnic varchar(2) NOT NULL,
	cde_marital varchar(1) NOT NULL,
	cde_county varchar(2) NOT NULL,
	cde_office varchar(1) NOT NULL,
	sak_cnty_off_svc int4 NOT NULL,
	cde_language varchar(3) NOT NULL,
	sak_liv_arng int4 NOT NULL,
	ind_mny_grant varchar(1) NOT NULL,
	cde_facility varchar(3) NOT NULL,
	ind_suspect varchar(1) NOT NULL,
	cde_ward_type varchar(1) NOT NULL,
	cde_county_ward varchar(2) NOT NULL,
	sak_cde_phone int4 NOT NULL,
	num_phone varchar(10) NOT NULL,
	sak_add_phone int4 NOT NULL,
	num_add_phone varchar(10) NOT NULL,
	sak_man_excl int4 NOT NULL,
	sak_citizen_dsc int4 NOT NULL,
	ind_spec_hlth varchar(1) NOT NULL,
	cde_soundex varchar(4) NOT NULL,
	ind_active varchar(1) NOT NULL,
	cde_source varchar(3) NOT NULL,
	cde_source_state varchar(1) NOT NULL,
	cde_other_media varchar(2) NOT NULL,
	nam_payee varchar(35) NOT NULL,
	dte_added int8 NOT NULL,
	dte_last_update int8 NOT NULL,
	sak_txt_phone int4 NULL,
	num_txt_phone varchar(10) NULL,
	email varchar(50) NULL,
	created_dt timestamp NULL,
	sourcefilename varchar(250) NULL,
	created_by varchar(50) NULL
);


-- legacy.pasrr_mmis_t_re_case definition

-- Drop table

-- DROP TABLE legacy.pasrr_mmis_t_re_case;

CREATE TABLE legacy.pasrr_mmis_t_re_case (
	sak_case int4 NOT NULL,
	num_case varchar(12) NOT NULL,
	cde_state_cat varchar(4) NOT NULL,
	num_seq varchar(2) NOT NULL,
	qty_case_size int4 NOT NULL,
	qty_num_eligibles int4 NOT NULL,
	cde_pov_range varchar(3) NOT NULL,
	amt_income numeric(8, 2) NOT NULL,
	amt_case_premium numeric(8, 2) NOT NULL,
	dte_added int8 NOT NULL,
	coinsurance_pct int4 NOT NULL,
	ind_deductible varchar(1) NOT NULL,
	num_fpl int4 NULL,
	created_dt timestamp NULL,
	sourcefilename varchar(250) NULL,
	created_by varchar(50) NULL
);


-- legacy.pasrr_mmis_t_re_choices_tracking definition

-- Drop table

-- DROP TABLE legacy.pasrr_mmis_t_re_choices_tracking;

CREATE TABLE legacy.pasrr_mmis_t_re_choices_tracking (
	sak_recip int4 NOT NULL,
	sak_pgm_elig int4 NOT NULL,
	sys_cde varchar(5) NOT NULL,
	created_dt timestamp NULL,
	sourcefilename varchar(250) NULL,
	created_by varchar(50) NULL
);


-- legacy.pasrr_mmis_t_re_disenroll_reasons definition

-- Drop table

-- DROP TABLE legacy.pasrr_mmis_t_re_disenroll_reasons;

CREATE TABLE legacy.pasrr_mmis_t_re_disenroll_reasons (
	sak_recip int4 NOT NULL,
	sak_pgm_elig int4 NOT NULL,
	cde_disenroll_rsn varchar(2) NOT NULL,
	dte_last_update int8 NOT NULL,
	created_dt timestamp NULL,
	sourcefilename varchar(250) NULL,
	created_by varchar(50) NULL
);


-- legacy.pasrr_mmis_t_re_elig definition

-- Drop table

-- DROP TABLE legacy.pasrr_mmis_t_re_elig;

CREATE TABLE legacy.pasrr_mmis_t_re_elig (
	sak_recip int4 NOT NULL,
	sak_pgm_elig int4 NOT NULL,
	sak_pub_hlth int4 NOT NULL,
	dte_effective int8 NOT NULL,
	dte_end int8 NOT NULL,
	cde_status1 varchar(1) NOT NULL,
	dte_added int8 NOT NULL,
	dte_last_update int8 NOT NULL,
	created_dt timestamp NULL,
	sourcefilename varchar(250) NULL,
	created_by varchar(50) NULL
);


-- legacy.pasrr_mmis_t_re_loc definition

-- Drop table

-- DROP TABLE legacy.pasrr_mmis_t_re_loc;

CREATE TABLE legacy.pasrr_mmis_t_re_loc (
	sak_recip int4 NOT NULL,
	sak_short_loc int4 NOT NULL,
	cde_loc varchar(3) NOT NULL,
	sak_prov int4 NOT NULL,
	cde_service_loc varchar(1) NOT NULL,
	dte_effective int8 NOT NULL,
	dte_end int8 NOT NULL,
	num_pre_eval varchar(9) NOT NULL,
	cde_source varchar(3) NOT NULL,
	dte_admit int8 NOT NULL,
	cde_admit varchar(1) NOT NULL,
	dte_pat_status int8 NOT NULL,
	cde_pat_status varchar(2) NOT NULL,
	dte_last_change int8 NOT NULL,
	dte_passr int8 NULL,
	dte_cost_neutrality int8 NULL,
	cde_disability varchar(2) NULL,
	created_dt timestamp NULL,
	sourcefilename varchar(250) NULL,
	created_by varchar(50) NULL
);


-- legacy.pasrr_mmis_t_re_multi_address definition

-- Drop table

-- DROP TABLE legacy.pasrr_mmis_t_re_multi_address;

CREATE TABLE legacy.pasrr_mmis_t_re_multi_address (
	sak_recip int4 NOT NULL,
	cde_addr_usage varchar(2) NOT NULL,
	cde_addr_source varchar(3) NOT NULL,
	adr_street_1 varchar(30) NOT NULL,
	adr_street_2 varchar(30) NOT NULL,
	adr_city varchar(18) NOT NULL,
	adr_state varchar(2) NOT NULL,
	adr_zip_code varchar(5) NOT NULL,
	adr_zip_code_4 varchar(4) NOT NULL,
	cde_county varchar(2) NOT NULL,
	num_phone_mco_cont varchar(10) NOT NULL,
	created_dt timestamp NULL,
	sourcefilename varchar(250) NULL,
	created_by varchar(50) NULL
);


-- legacy.pasrr_mmis_t_re_pat_liab definition

-- Drop table

-- DROP TABLE legacy.pasrr_mmis_t_re_pat_liab;

CREATE TABLE legacy.pasrr_mmis_t_re_pat_liab (
	sak_pat_liab int4 NOT NULL,
	sak_recip int4 NOT NULL,
	dte_effective int8 NOT NULL,
	dte_end int8 NOT NULL,
	amt_patnt_liab numeric(8, 2) NOT NULL,
	dte_add int8 NOT NULL,
	ind_adjust varchar(1) NOT NULL,
	dte_last_updated int8 NOT NULL,
	cde_source varchar(3) NOT NULL,
	created_dt timestamp NULL,
	sourcefilename varchar(250) NULL,
	created_by varchar(50) NULL
);


-- legacy.pasrr_mmis_t_re_pmp_assign definition

-- Drop table

-- DROP TABLE legacy.pasrr_mmis_t_re_pmp_assign;

CREATE TABLE legacy.pasrr_mmis_t_re_pmp_assign (
	sak_re_pmp_assign int4 NOT NULL,
	sak_recip int4 NOT NULL,
	sak_pgm_elig int4 NOT NULL,
	sak_pmp_ser_loc int4 NOT NULL,
	sak_prov_mbr int4 NOT NULL,
	cde_service_loc_mbr varchar(1) NOT NULL,
	cde_rsn_mc_start varchar(2) NOT NULL,
	cde_rsn_mc_stop varchar(2) NOT NULL,
	sak_mc_ent_add int4 NOT NULL,
	dte_added int8 NOT NULL,
	sak_mc_ent_mbr int4 NOT NULL,
	dte_prov_mbr_add int8 NOT NULL,
	sak_mc_ent_change int4 NOT NULL,
	dte_changed int8 NOT NULL,
	sak_mc_ent_term int4 NOT NULL,
	dte_termed int8 NOT NULL,
	created_dt timestamp NULL,
	sourcefilename varchar(250) NULL,
	created_by varchar(50) NULL,
	cde_source_state varchar(1) NULL,
	dte_last_roster int8 NULL
);


-- legacy.pasrr_mmis_t_re_pmp_reason definition

-- Drop table

-- DROP TABLE legacy.pasrr_mmis_t_re_pmp_reason;

CREATE TABLE legacy.pasrr_mmis_t_re_pmp_reason (
	cde_rsn_mc_assign varchar(2) NOT NULL,
	dsc_rsn_mc_assign varchar(100) NOT NULL,
	cde_rsn_pmp_assign varchar(1) NOT NULL,
	ind_letter varchar(1) NOT NULL,
	cde_aa_cnt varchar(1) NOT NULL,
	int_cnt_change varchar(1) NOT NULL,
	created_dt timestamp NULL,
	sourcefilename varchar(250) NULL,
	created_by varchar(50) NULL
);
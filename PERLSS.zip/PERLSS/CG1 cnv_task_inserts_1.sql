--Review New PASRR PAE task
--An Approved PASRR Level II record is received in PERLSS and is Converted;
--Individual is known to PERLSS and enrolled in an LTSS program then Review new PASRR PAE task will be created
INSERT INTO perlss.cnv_task
(id, task_master_id, prsn_id, pae_id, apl_id, assigned_user_id, due_dt,
role_id, entity_id, prirty_cd, ref_id, task_dtl_desc, last_modified_by,
last_modified_dt, record_version, created_by, created_dt, archived_dt, processed_flag)
select nextval('perlss.hibernate_sequence'), a.task_master_id , a.prsn_id, a.pae_id, NULL, NULL, due_dt,
NULL, NULL, 'LO', NULL, 'Review New PASRR PAE', NULL, 
NULL, 0, a.created_by, a.created_dt, null,'N'  
from (
select distinct 198 as task_master_id  ,p.pae_id , p.prsn_id,p.created_by, p.created_dt,
legacy.fn_add_business_days(to_date(to_char(p.created_dt, 'yyyy-mm-dd'), 'yyyy-mm-dd'),14) due_dt from 
perlss.pae_rqst p 
join legacy.pasrr_pae_base_member_pop pop on pop.pasrr_review_id::text  = p.legacy_id
where p.created_by = 'PASRR_CV' and pop.step in ('3','5','5a') and p.status_cd='AP' 
 and exists(select 1 from perlss.enr_rqst e where e.prsn_id = p.prsn_id 
 and e.enr_status_cd= 'ENR' and created_by <> 'PASRR_CV' and e.enr_grp_cd <> 'CG1'
 and enr_id in  ( 
      select
            max(enr_id)
      from
            perlss.enr_rqst where created_by <> 'PASRR_CV'
      and (hstry_sw = 'N'
            or hstry_sw is null)
      and active_sw = 'Y'
      group by
            pae_id,
            prsn_id))
and not exists(
select 1
from
perlss.tmg_task,
perlss.Tmg_Doc,
perlss.tmg_task_master
where
tmg_task.input_Id = Tmg_Doc.input_Id 
and Tmg_Doc.task_Master_Id = tmg_task_master.task_Master_Id
and tmg_task_master.task_Master_Id in (198)
and tmg_task.pae_id = p.pae_id)
and not exists( select 1 from perlss.cnv_task c where  p.prsn_id = c.prsn_id and p.pae_id = c.pae_id))a;


--Mopd is null Mopd task
INSERT INTO perlss.cnv_task
(id, task_master_id, prsn_id, pae_id, apl_id, assigned_user_id, due_dt,
role_id, entity_id, prirty_cd, ref_id, task_dtl_desc, last_modified_by,
last_modified_dt, record_version, created_by, created_dt, archived_dt, processed_flag)
select nextval('perlss.hibernate_sequence'), a.task_master_id , a.prsn_id, a.pae_id, NULL, NULL, due_dt,
NULL, NULL, 'LO', NULL, 'Enter MOPD', NULL, 
NULL, 0, a.created_by, a.created_dt, null,'N'  
from (
select distinct 74 as task_master_id ,p.pae_id , p.prsn_id,a.created_by, a.created_dt,
legacy.fn_add_business_days(to_date(to_char(a.created_dt, 'yyyy-mm-dd'), 'yyyy-mm-dd'),14) due_dt from 
perlss.pae_rqst p 
join  perlss.adj_rqst a on p.pae_id = a.pae_id and p.prsn_id = a.prsn_id
join legacy.pasrr_pae_base_member_pop pop on pop.pasrr_review_id::text  = p.legacy_id
where p.created_by = 'PASRR_CV' and a.created_by = 'PASRR_CV' and pop.step in ('3','5','5a') 
and a.loc_dcsn_cd in  ('NED','NWE','NSE','NFS','AP') and p.status_cd='AP' 
and  p.mopd_dt is null
and not exists(
select 1
from
perlss.tmg_task,
perlss.Tmg_Doc,
perlss.tmg_task_master
where
tmg_task.input_Id = Tmg_Doc.input_Id 
and Tmg_Doc.task_Master_Id = tmg_task_master.task_Master_Id
and tmg_task_master.task_Master_Id in('74')  
and tmg_task.pae_id = a.pae_id)
and not exists(select 1 from perlss.cnv_task c  where  a.prsn_id = c.prsn_id and a.pae_id = c.pae_id))a;


--2. if MOPD date is not null, MOPD date(nfadmit date) is after to the PAE effective date then Recertification task
INSERT INTO perlss.cnv_task
(id, task_master_id, prsn_id, pae_id, apl_id, assigned_user_id, due_dt,
role_id, entity_id, prirty_cd, ref_id, task_dtl_desc, last_modified_by,
last_modified_dt, record_version, created_by, created_dt, archived_dt, processed_flag)
select nextval('perlss.hibernate_sequence'), a.task_master_id , a.prsn_id, a.pae_id, NULL, NULL, due_dt,
NULL, NULL, 'LO', NULL, 'Complete CHOICES Group 1 Recertification', NULL, 
NULL, 0, a.created_by, a.created_dt, null,'N'  
from (
select distinct 181 as task_master_id ,p.pae_id , p.prsn_id,a.created_by, a.created_dt,a.pae_eff_dt,p.mopd_dt,
legacy.fn_add_business_days(to_date(to_char(a.created_dt, 'yyyy-mm-dd'), 'yyyy-mm-dd'),14) due_dt from 
perlss.pae_rqst p 
join  perlss.adj_rqst a on p.pae_id = a.pae_id and p.prsn_id = a.prsn_id
join legacy.pasrr_pae_base_member_pop pop on pop.pasrr_review_id::text  = p.legacy_id
where p.created_by = 'PASRR_CV' and a.created_by = 'PASRR_CV' and pop.step in ('3','5','5a') 
and a.loc_dcsn_cd in  ('NED','NWE','NSE','NFS','AP') and p.status_cd='AP'
and  p.mopd_dt is not null 
and a.pae_eff_dt::date < p.mopd_dt::date 
and p.mopd_dt::date - a.pae_eff_dt::date>90 
and not exists(
select 1
from
perlss.tmg_task,
perlss.Tmg_Doc,
perlss.tmg_task_master
where
tmg_task.input_Id = Tmg_Doc.input_Id 
and Tmg_Doc.task_Master_Id = tmg_task_master.task_Master_Id
and tmg_task_master.task_Master_Id in('181')  
and tmg_task.pae_id = a.pae_id)
and not exists(select 1 from perlss.cnv_task c  where  a.prsn_id = c.prsn_id and a.pae_id = c.pae_id))a;


----4. if FIN eligibility not present   then PFE task for CG1
INSERT INTO perlss.cnv_task
(id, task_master_id, prsn_id, pae_id, apl_id, assigned_user_id, due_dt,
role_id, entity_id, prirty_cd, ref_id, task_dtl_desc, last_modified_by,
last_modified_dt, record_version, created_by, created_dt, archived_dt, processed_flag)
select nextval('perlss.hibernate_sequence'), a.task_master_id , a.prsn_id, a.pae_id, NULL, NULL, due_dt,
NULL, NULL, 'LO', NULL, 'Pending Financial Eligibility Determination', NULL, 
NULL, 0, a.created_by, a.created_dt, null,'N'  
from (
select distinct 8 as task_master_id  ,p.pae_id , p.prsn_id,a.created_by, a.created_dt,
a.pae_eff_dt::date,
legacy.fn_add_business_days(to_date(to_char(a.created_dt, 'yyyy-mm-dd'), 'yyyy-mm-dd'),14) due_dt from  
perlss.pae_rqst p 
join  perlss.adj_rqst a on p.pae_id = a.pae_id and p.prsn_id = a.prsn_id
join  perlss.com_applcnt ca on ca.prsn_id = p.prsn_id and  ca.active_sw='Y' and file_clearance_sw ='Y'
join legacy.pasrr_pae_base_member_pop pop on pop.pasrr_review_id::text  = p.legacy_id
where p.created_by = 'PASRR_CV' and a.created_by = 'PASRR_CV' and p.status_cd='AP'  and pop.step in ('3','5','5a') 
and not exists (select ssn from (select case when length(ssn)= 8 then '0'||ssn 
when length(ssn) = 7 then '00'||ssn::text else ssn end as ssn from legacy.fe_check  
where coe_id  in ('W01','L02','L01','W02','L03','L04', 'SSI') and (eligibility_end_dt is null or eligibility_end_dt > current_date)) fc where fc.ssn = ca.ssn)
and not exists(
select 1
from
perlss.tmg_task,
perlss.Tmg_Doc,
perlss.tmg_task_master
where
tmg_task.input_Id = Tmg_Doc.input_Id 
and Tmg_Doc.task_Master_Id = tmg_task_master.task_Master_Id
and tmg_task_master.task_Master_Id in (8)
and module_cd = 'ENR'
and tmg_task.pae_id = a.pae_id)
and not exists( select 1 from perlss.cnv_task c where  a.prsn_id = c.prsn_id and a.pae_id = c.pae_id))a;

--4. if FIN eligibility present   then New enrollment  task
INSERT INTO perlss.cnv_task
(id, task_master_id, prsn_id, pae_id, apl_id, assigned_user_id, due_dt,
role_id, entity_id, prirty_cd, ref_id, task_dtl_desc, last_modified_by,
last_modified_dt, record_version, created_by, created_dt, archived_dt, processed_flag)
select nextval('perlss.hibernate_sequence'), a.task_master_id , a.prsn_id, a.pae_id, NULL, NULL, due_dt,
NULL, NULL, 'LO', NULL, 'Complete New Enrollment - CHOICES Group 1', NULL, 
NULL, 0, a.created_by, a.created_dt, null,'N'  
from (
select distinct 58 as task_master_id  ,p.pae_id , p.prsn_id,a.created_by, a.created_dt,
a.pae_eff_dt::date,fc.eligibility_beg_dt::date,
legacy.fn_add_business_days(to_date(to_char(a.created_dt, 'yyyy-mm-dd'), 'yyyy-mm-dd'),14) due_dt from  
perlss.pae_rqst p 
join  perlss.adj_rqst a on p.pae_id = a.pae_id and p.prsn_id = a.prsn_id
join  perlss.com_applcnt ca on ca.prsn_id = p.prsn_id and  ca.active_sw='Y' and file_clearance_sw ='Y'
join legacy.pasrr_pae_base_member_pop pop on pop.pasrr_review_id::text  = p.legacy_id
join legacy.fe_check fc on case when length(fc.ssn)= 8 then '0'||fc.ssn when length(fc.ssn) = 7 then '00'||fc.ssn::text else fc.ssn end= ca.ssn 
where p.created_by = 'PASRR_CV' and a.created_by = 'PASRR_CV' and p.status_cd='AP'  and pop.step in ('3','5','5a') 
 and fc.coe_id  in ('W01','L02','L01','W02','L03','L04', 'SSI')
 and  (fc.eligibility_end_dt is null or fc.eligibility_end_dt > current_date)
--and fc.eligibility_beg_dt::date - a.pae_eff_dt::date  < 90
and not exists(
select 1
from
perlss.tmg_task,
perlss.Tmg_Doc,
perlss.tmg_task_master
where
tmg_task.input_Id = Tmg_Doc.input_Id 
and Tmg_Doc.task_Master_Id = tmg_task_master.task_Master_Id
and tmg_task_master.task_Master_Id in (58)
and module_cd = 'ENR'
and tmg_task.pae_id = a.pae_id)
and not exists( select 1 from perlss.cnv_task c where  a.prsn_id = c.prsn_id and a.pae_id = c.pae_id))a;




--6. no provider ID we create Update facility living arrangement task and either PFE or enrollment task in parallel
INSERT INTO perlss.cnv_task
(id, task_master_id, prsn_id, pae_id, apl_id, assigned_user_id, due_dt,
role_id, entity_id, prirty_cd, ref_id, task_dtl_desc, last_modified_by,
last_modified_dt, record_version, created_by, created_dt, archived_dt, processed_flag)
select nextval('perlss.hibernate_sequence'), a.task_master_id , a.prsn_id, a.pae_id, NULL, NULL, due_dt,
NULL, NULL, 'LO', NULL, 'Update Facility Living Arrangement', NULL, 
NULL, 0, a.created_by, a.created_dt, null,'N'  
from (
select distinct 180 as task_master_id , p.pae_id , p.prsn_id , p.created_by, p.created_dt,
legacy.fn_add_business_days(to_date(to_char(P.created_dt, 'yyyy-mm-dd'), 'yyyy-mm-dd'),14) due_dt
from perlss.pae_rqst p 
join  perlss.pae_lvng_arrgmnt a on p.pae_id = a.pae_id 
join legacy.pasrr_pae_base_member_pop pop on pop.pasrr_review_id::text  = p.legacy_id
where p.created_by = 'PASRR_CV' and a.created_by = 'PASRR_CV' and pop.step in ('3','5','5a') 
and a.provider_id is null  and p.status_cd='AP'  
and  prsn_id not in (select prsn_id from perlss.enr_rqst e 
where e.enr_status_cd= 'ENR' and created_by <> 'PASRR_CV' and enr_grp_cd in ('CG1','CG3')
 and enr_id in  ( 
      select
            max(enr_id)
      from
            perlss.enr_rqst k 
            where created_by <> 'PASRR_CV'  
      and (hstry_sw = 'N'
            or hstry_sw is null)
      and active_sw = 'Y'
      group by
            pae_id,
            prsn_id))
and not exists( select 1 from perlss.cnv_task c where  p.prsn_id = c.prsn_id and P.pae_id = c.pae_id and c.task_master_id=180)
)a;

















--Pending_Eligibility_Check
--added to char before ssn on 2/2 as part of oracle to postgress change
SELECT DISTINCT case when length(to_char(d.ssn)) = 8 then concat('0',d.ssn)
when length(to_char(d.ssn)) = 7 then concat('00',d.ssn) 
else to_char(d.ssn) end ssn FROM IE_APP_ONLINE.ED_ELIGIBILITY ED INNER JOIN IE_APP_ONLINE.DC_ABD_DEEMING_WAIVER_DTLS DC ON ED.MEDICAID_INDV_ID = DC.INDV_ID
inner join ie_app_online.DC_INDV d on d.indv_id = ed.medicaid_indv_id
WHERE
DC.KB_TYPE_CD = 'KB'
AND DC.EFF_END_DT IS NULL
AND TYPE_OF_ASSISTANCE_CD='K03'
AND ed.DELETE_SW='N' AND ed.PAYMENT_END_DT IS NULL
AND CG_STATUS_CD='AP' AND CURRENT_ELIG_IND='A'


--Denied_Eligibility_Check_KA
--added to char before ssn on 2/2 as part of oracle to postgress change
SELECT DISTINCT case when length(to_char(d.ssn)) = 8 then concat('0',d.ssn)
when length(to_char(d.ssn)) = 7 then concat('00',d.ssn) 
else to_char(d.ssn) end ssn FROM IE_APP_ONLINE.ED_ELIGIBILITY ED INNER JOIN IE_APP_ONLINE.DC_ABD_DEEMING_WAIVER_DTLS DC ON ED.MEDICAID_INDV_ID = DC.INDV_ID
inner join ie_app_online.DC_INDV d on d.indv_id = ed.medicaid_indv_id
WHERE
DC.KB_TYPE_CD = 'KA'
AND DC.EFF_END_DT IS NULL
AND TYPE_OF_ASSISTANCE_CD='K01'
AND ed.DELETE_SW='N' AND ed.PAYMENT_END_DT IS NULL
AND CG_STATUS_CD='DN' AND CURRENT_ELIG_IND='A'

--Pending_FE_KA
--added to char before ssn on 2/2 as part of oracle to postgress change
SELECT DISTINCT case when length(to_char(d.ssn)) = 8 then concat('0',d.ssn)
when length(to_char(d.ssn)) = 7 then concat('00',d.ssn)  
else to_char(d.ssn) end ssn FROM IE_APP_ONLINE.ED_ELIGIBILITY ED INNER JOIN IE_APP_ONLINE.DC_ABD_DEEMING_WAIVER_DTLS DC ON ED.MEDICAID_INDV_ID = DC.INDV_ID
inner join ie_app_online.DC_INDV d on d.indv_id = ed.medicaid_indv_id
WHERE
DC.KB_TYPE_CD = 'KA'
AND DC.EFF_END_DT IS NULL
AND TYPE_OF_ASSISTANCE_CD='K01'
AND ed.DELETE_SW='N' AND ed.PAYMENT_END_DT IS NULL
AND CG_STATUS_CD='AP' AND CURRENT_ELIG_IND='A'



--Denied_Eligibility_Check_KA1
--added to char before ssn on 2/2 as part of oracle to postgress change
SELECT DISTINCT case when length(to_char(d.ssn)) = 8 then concat('0',d.ssn)
when length(to_char(d.ssn)) = 7 then concat('00',d.ssn) 
else to_char(d.ssn) end ssn FROM IE_APP_ONLINE.ED_ELIGIBILITY ED INNER JOIN IE_APP_ONLINE.DC_ABD_DEEMING_WAIVER_DTLS DC ON ED.MEDICAID_INDV_ID = DC.INDV_ID
inner join ie_app_online.DC_INDV d on d.indv_id = ed.medicaid_indv_id
WHERE
DC.KB_TYPE_CD = 'KA'
AND DC.EFF_END_DT IS NULL
AND TYPE_OF_ASSISTANCE_CD='K01'
AND ed.DELETE_SW='N' AND ed.PAYMENT_END_DT IS NULL
AND CG_STATUS_CD='DN' AND CURRENT_ELIG_IND='A'



--Pending_FE_KA1
--added to char before ssn on 2/2 as part of oracle to postgress change
SELECT DISTINCT case when length(to_char(d.ssn)) = 8 then concat('0',d.ssn)
when length(to_char(d.ssn)) = 7 then concat('00',d.ssn)  
else to_char(d.ssn) end ssn FROM IE_APP_ONLINE.ED_ELIGIBILITY ED INNER JOIN IE_APP_ONLINE.DC_ABD_DEEMING_WAIVER_DTLS DC ON ED.MEDICAID_INDV_ID = DC.INDV_ID
inner join ie_app_online.DC_INDV d on d.indv_id = ed.medicaid_indv_id
WHERE
DC.KB_TYPE_CD = 'KA'
AND DC.EFF_END_DT IS NULL
AND TYPE_OF_ASSISTANCE_CD='K01'
AND ed.DELETE_SW='N' AND ed.PAYMENT_END_DT IS NULL
AND CG_STATUS_CD='AP' AND CURRENT_ELIG_IND='A'


--Pending_FE_KA2
--added to char before ssn on 2/2 as part of oracle to postgress change
SELECT DISTINCT case when length(to_char(d.ssn)) = 8 then concat('0',d.ssn)
when length(to_char(d.ssn)) = 7 then concat('00',d.ssn) 
else to_char(d.ssn) end ssn
FROM IE_APP_ONLINE.ED_PREMIUM PR
    INNER JOIN IE_APP_ONLINE.ED_ELIGIBILITY ED ON ED.EDG_TRACE_ID=PR.EDG_TRACE_ID AND ED.CASE_NUM=PR.CASE_NUM AND ED.MEDICAID_INDV_ID=PR.INDV_ID
    INNER JOIN IE_APP_ONLINE.ED_VERIFICATION_CHECKLIST VCL ON ED.MEDICAID_INDV_ID = VCL.INDV_ID AND ED.CASE_NUM = VCL.CASE_NUM AND ED.EDG_NUM=VCL.EDG_NUM
    inner join ie_app_online.DC_INDV d on d.indv_id = ed.medicaid_indv_id
WHERE 
    ED.TYPE_OF_ASSISTANCE_CD='K01'
AND ED.CG_STATUS_CD IN ('PP')
AND ED.PAYMENT_END_DT IS NULL AND ED.DELETE_SW='N'
AND ED.CURRENT_ELIG_IND = 'P'
AND VCL.DISPLAY_TYPE_SW = 'Y' 
AND VCL.VCL_TYPE_CD = 'VC151'
--#'VC151' IS FOR INITIAL PAYMENT
--#'VC153' IS FOR BCBSID
AND VCL.DELETE_SW = 'N'
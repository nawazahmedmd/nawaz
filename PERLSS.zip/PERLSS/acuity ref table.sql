create table legacy.xref_srvcs_score as
select distinct value, a.srvc_name_cd , 
case when a.srvc_name_cd in  ('CVS','VNT') then '5'
     when a.srvc_name_cd =  'SMT' then '4'
     when a.srvc_name_cd in  ('TPN','OWC','TRS') then '3'
     when a.srvc_name_cd in ('PED','WCS','TFE') then '2'
     when a.srvc_name_cd in ('INT','PHT','OCT','IOT','ISS','ISP','PCA') then '1'
     when a.srvc_name_cd in ('TCO','TSI') then '0' end::int acuity_score
from perlss.adj_skilled_srvcs a 
left join legacy.xrf_perlss_data b  on a.srvc_name_cd =b.code and name = 'SKILLEDSERVICE_NAME_NONKB'
where a.created_by = 'PASRR_CV'



INSERT INTO legacy.xref_srvcs_score (value,srvc_name_cd,acuity_score) VALUES
	 ('Secretion Management Tracheal Suctioning ','SMT',4),
	 ('PCA Pump','PCA',1),
	 ('Ventilator','VNT',5)
	
CREATE TABLE legacy.xref_srvcs_score (
	value text NULL,
	srvc_name_cd varchar(4) NULL,
	acuity_score int4 NULL
);	
	 
	 
	 
	 INSERT INTO legacy.xref_srvcs_score
(value, srvc_name_cd, acuity_score)
VALUES('Teaching self-injection', 'TSI', 0);
INSERT INTO legacy.xref_srvcs_score
(value, srvc_name_cd, acuity_score)
VALUES('Tube feeding, enteral', 'TFE', 2);
INSERT INTO legacy.xref_srvcs_score
(value, srvc_name_cd, acuity_score)
VALUES('Intravenous fluid administration', 'INT', 1);
INSERT INTO legacy.xref_srvcs_score
(value, srvc_name_cd, acuity_score)
VALUES('Total Parenteral nutrition', 'TPN', 3);
INSERT INTO legacy.xref_srvcs_score
(value, srvc_name_cd, acuity_score)
VALUES('Wound Care for Stage 3 or 4 Decubitus', 'WCS', 2);
INSERT INTO legacy.xref_srvcs_score
(value, srvc_name_cd, acuity_score)
VALUES('Teaching Catheter/Ostomy care', 'TCO', 0);
INSERT INTO legacy.xref_srvcs_score
(value, srvc_name_cd, acuity_score)
VALUES('Occupational Therapy by OT or OT assistant', 'OCT', 1);
INSERT INTO legacy.xref_srvcs_score
(value, srvc_name_cd, acuity_score)
VALUES('Injections, sliding scale insulin', 'ISS', 1);
INSERT INTO legacy.xref_srvcs_score
(value, srvc_name_cd, acuity_score)
VALUES('Physical Therapy by PT or PT assistant', 'PHT', 1);
INSERT INTO legacy.xref_srvcs_score
(value, srvc_name_cd, acuity_score)
VALUES('Chronic Ventilator Service', 'CVS', 5);
INSERT INTO legacy.xref_srvcs_score
(value, srvc_name_cd, acuity_score)
VALUES('Tracheostomy requiring suctioning', 'TRS', 3);
INSERT INTO legacy.xref_srvcs_score
(value, srvc_name_cd, acuity_score)
VALUES('Injections, other: IV, IM', 'IOT', 1);
INSERT INTO legacy.xref_srvcs_score
(value, srvc_name_cd, acuity_score)
VALUES('Complex Wound Care (i.e., infected or dehisced wounds)', 'OWC', 3);
INSERT INTO legacy.xref_srvcs_score
(value, srvc_name_cd, acuity_score)
VALUES('Isolation precautions', 'ISP', 1);
INSERT INTO legacy.xref_srvcs_score
(value, srvc_name_cd, acuity_score)
VALUES('Peritoneal Dialysis', 'PED', 2);
INSERT INTO legacy.xref_srvcs_score
(value, srvc_name_cd, acuity_score)
VALUES('Secretion Management Tracheal Suctioning ', 'SMT', 4);
INSERT INTO legacy.xref_srvcs_score
(value, srvc_name_cd, acuity_score)
VALUES('PCA Pump', 'PCA', 1);
INSERT INTO legacy.xref_srvcs_score
(value, srvc_name_cd, acuity_score)
VALUES('Ventilator', 'VNT', 5);

select 
nextval('perlss.hibernate_sequence') as ID,
 * from (
select distinct 
upper(trim(b.currentlocationaddress1))		addr_line_1
,upper(trim(b.currentlocationaddress2))		addr_line_2
,case when b.NFAdmitDate is not null then b.NFAdmitDate else xm.passr_pi__nursingfacilityadmissiondate::date end	admsn_dt
,case when xm.group3nfdischarge_nfdischargedate is not null then xm.group3nfdischarge_nfdischargedate::date else null end  	anticipated_discharge_dt
,NULL   anticipated_release_dt
,upper(trim(b.currentlocationcity))	city
,NULL  	cnty_cd
,case when b.currentlocation= 'Community setting/home' then 'HOM'
when b.currentlocation= 'Medical Facility ER/ED' then 'MED'
when b.currentlocation= 'Medical Facility Medical Unit' then 'MED'
when b.currentlocation= 'Medical Facility Psychiatric Unit' then 'MEN'
when b.currentlocation= 'Nursing Facility' then 'NFC'
when b.currentlocation= 'Other' then 'OTH'
when b.currentlocation= 'Psychiatric Facility' then 'HLS' end 	curr_lvng_arrgmnt_cd -- changed as per the email from Srikar on 1/24/2025
,'NES'	expctd_discharge_cd
,NULL  	extsn
,NULL  	incarceration_dt
,NULL   intlctl_disable_sw
,NULL  	last_modified_by
,NULL  	last_modified_dt
,NULL   long_term_care_sw
,NULL  	lvng_arrgmnt_desc
,NULL   mental_hlth_sw
,NULL   none_sw
,cmp.org_id	nursing_facility_name_cd
,cmp.org_id	org_id
,cmp.org_id	org_loc_id
,NULL	othr_facility_name
,r.pae_id pae_id
,NULL  	ph_num
,NULL   phychiatric_hosp_sw
,NULL  	phycl_disable_sw
,cmp.provider_id	provider_id
,NULL   	sch_outside_sw
,NULL   	special_sch_sw
,upper(trim(b.currentlocationstate))	state_cd
,upper(trim(b.currentlocationzip))		zip
, r.legacy_id
,'A' as CONVERSION_RUN_STATUS
from  legacy.wrk_pasrr_clients w 
join legacy.pasrr_events b on b.reviewid::bigint  = w.maximus_reviewid::bigint
join legacy.pasrr_pae_base_member_pop pop on w.maximus_reviewid = pop.pasrr_review_id
left join (select  *  from perlss.pae_rqst where  created_by='PASRR_CV') r    on r.legacy_id::text = w.maximus_reviewid::text
left join (select distinct num_control  , group3nfdischarge_nfdischargedate,passr_pi__nursingfacilityadmissiondate from legacy.tmed_xml_extract_cv_qlf_no_rec) xm on xm.num_control::int=pop.tmed_num_control_pkey::int
left join (select *
			from (
			select  distinct  d.reviewid,currentlocationfacility, m.provider_name , m.org_id, m.provider_id,
			row_number() over(partition by d.reviewid  order by m.eff_dt desc) as rnk
			from  (select m.provider_id, m.provider_name , m.org_id,m.npi_id , c.addr_line_1 ,m.eff_dt
			from perlss.com_provider_master m  
			join perlss.com_provider_cntct_dtls c on m.org_id =c.org_id)m
			right join (
			select distinct eventid,reviewid, currentlocationfacility,currentlocationaddress1,
			e.currentlocationcity,currentlocationstate,currentlocationzip
			from legacy.pasrr_events e 
			where currentlocationfacility is not null and payersource ilike '%Medicaid%'  )d
			on (upper(left(m.provider_name,3))=upper(left(d.currentlocationfacility ,3))
			and upper(left (coalesce(addr_line_1,'NA'),5))=upper(left(coalesce(d.currentlocationaddress1,'NA'),5)))
			)a where rnk=1 and provider_name is not null) cmp 
     on cmp.reviewid = b.reviewid      and upper((trim(b.currentlocationfacility)))=upper((trim(cmp.currentlocationfacility)))
where  w.source_system_nm = 'MAXIMUS' and valid_sw= 'Y' and 	xref_valid_sw='Y'  and perlss_sw ='N'
)a where pae_id is not null


--legacy.xref_curr_location_facility_com_provider


update perlss.pae_lvng_arrgmnt a
set  othr_facility_name =  k.othr_facility_name from (
				select distinct a.pae_id , b.legacy_id , 'OTR' nursing_facility_name_cd , 
				CurrentLocationFacility  othr_facility_name
				from perlss.pae_lvng_arrgmnt a 
				join perlss.pae_rqst b on a.pae_id = b.pae_id
				join legacy.pasrr_events c on c.reviewid::text = b.legacy_id::text
				where b.created_by = 'PASRR_CV' 
				and a.provider_id is null and a.curr_lvng_arrgmnt_cd='NFC') k 
where a.pae_id = k.pae_id and a.created_by = 'PASRR_CV';

update perlss.pae_lvng_arrgmnt a
set  nursing_facility_name_cd =  k.nursing_facility_name_cd from (
				select distinct a.pae_id , b.legacy_id , 'OTR' nursing_facility_name_cd , 
				CurrentLocationFacility  othr_facility_name
				from perlss.pae_lvng_arrgmnt a 
				join perlss.pae_rqst b on a.pae_id = b.pae_id
				join legacy.pasrr_events c on c.reviewid::text = b.legacy_id::text
				where b.created_by = 'PASRR_CV' 
				and a.provider_id is null and a.curr_lvng_arrgmnt_cd='NFC') k 
where a.pae_id = k.pae_id and a.created_by = 'PASRR_CV';


update perlss.pae_lvng_arrgmnt a
set  lvng_arrgmnt_desc =  k.currentlocationfacility from (
				select distinct a.pae_id , b.legacy_id , c.currentlocationfacility 
				from perlss.pae_lvng_arrgmnt a 
				join perlss.pae_rqst b on a.pae_id = b.pae_id
				join legacy.pasrr_events c on c.reviewid::text = b.legacy_id::text
				where b.created_by = 'PASRR_CV' and a.org_id is null and a.curr_lvng_arrgmnt_cd<>'NFC') k 
where a.pae_id = k.pae_id and a.created_by = 'PASRR_CV';


update perlss.pae_lvng_arrgmnt 
set lvng_arrgmnt_desc = 'Conversion'
where created_by = 'PASRR_CV'  and curr_lvng_arrgmnt_cd ='OTH';


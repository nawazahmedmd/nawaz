--converted CG2 enrollment , Converted Neg Level1 pasrr  
select a.prsn_id ,a.pae_id from perlss.enr_rqst a where created_by like 'CV%' and enr_grp_cd= 'CG2'
and enr_status_cd ='ENR' and enr_id in  ( 
      select
            max(enr_id)
      from
            perlss.enr_rqst where created_by <> 'PASRR_CV'
      and (hstry_sw = 'N'
            or hstry_sw is null)
      and active_sw = 'Y'
      group by
            pae_id,
            prsn_id)
 and prsn_id in (select prsn_id from perlss.pasrr_rqst where lvl1_outcome_cd ='NEG');
 
  --EC5 at risk enrollment, Not converted , Converted Neg Level1 pasrr         
 select * from perlss.enr_rqst a
 join perlss.pae_rqst b on a.pae_id =b.pae_id
 where a.created_by not like 'CV%' and b.status_cd ='AA' 
 and a.enr_status_cd= 'ENR' --and a.enr_grp_cd ='EC5'
 and a.prsn_id in (select prsn_id from perlss.pasrr_rqst where lvl1_outcome_cd ='NEG');

--Converted KB parta enrollment , level1pasrr neg via interface
slt status -FIL
1017
select * from perlss.slt_details where 1=1-- created_by like 'CV%'
and slt_status_cd ='FIL'
and slt_master_id in (
select slt_master_id from perlss.slt_master where enr_grp_cd ='KBA' and active_sw='Y');

--
--Converted CG2 enrollment ,level11 NF loc via interface
select prsn_id ,pae_id from perlss.enr_rqst a where created_by like 'CV%' and enr_grp_cd= 'CG2'
and enr_status_cd ='ENR' and enr_id in  ( 
      select
            max(enr_id)
      from
            perlss.enr_rqst where created_by <> 'PASRR_CV'
      and (hstry_sw = 'N'
            or hstry_sw is null)
      and active_sw = 'Y'
      group by
            pae_id,
            prsn_id)
 



--5th bucket FA criteria not met for NF LOC or At Risk LOC
select distinct  a.prsn_id,a.pae_id, c.enr_grp_cd,a.status_cd  from perlss.pae_rqst a
join perlss.adj_rqst b on a.pae_id = b.pae_id 
left join perlss.enr_rqst c on c.pae_id = a.pae_id
where a.created_by = 'PASRR_CV' and b.loc_dcsn_cd ='FAC' and a.status_cd ='DN';

--6000068369	PAE200112423

select * from perlss.enr_rqst where pae_id = 'PAE200112423'


--1st bucket Actively Enrolled in CH1 ,NFLOC
select distinct a.prsn_id,a.pae_id, d.grandfathered_sw  from perlss.pae_rqst a
join perlss.adj_rqst b on a.pae_id = b.pae_id 
join perlss.enr_rqst c on a.pae_id = c.pae_id 
left join perlss.enr_dtls d on d.enr_id = c.enr_id 
where a.created_by = 'PASRR_CV' and c.enr_status_cd = 'ENR' and c.created_by = 'PASRR_CV'
and a.status_cd='AP' and c.enr_grp_cd ='CG1'

--2nd bucket Actively Enrolled in CH3 ,Denied NF LOC, Approved At Risk 
select distinct  a.prsn_id,a.pae_id  from perlss.pae_rqst a
join perlss.adj_rqst b on a.pae_id = b.pae_id 
join perlss.enr_rqst c on a.pae_id = c.pae_id 
where a.created_by = 'PASRR_CV' and c.enr_status_cd = 'ENR' and c.created_by = 'PASRR_CV'
and a.status_cd='AA' and c.enr_grp_cd ='CG3'

--4th bucket  Denied NF LOC, Approved At Risk  Pending Financial Eligibility 
select distinct  a.prsn_id,a.pae_id , c.enr_grp_cd  from perlss.pae_rqst a
join perlss.adj_rqst b on a.pae_id = b.pae_id 
left join perlss.enr_rqst c on a.pae_id = c.pae_id 
left join  perlss.com_applcnt ca on ca.prsn_id = a.prsn_id and  ca.active_sw='Y' and file_clearance_sw ='Y'
where a.created_by = 'PASRR_CV' and a.status_cd='AA' and b.loc_dcsn_cd in ('DNF','DWE')
and not exists (select ssn from (select case when length(ssn)= 8 then '0'||ssn 
when length(ssn) = 7 then '00'||ssn::text else ssn end as ssn from legacy.fe_check) fc where fc.ssn = ca.ssn);

--14 bucket PASRR records linked to already transcribed PAE's created by LTSS
select distinct a.pae_id, a.prsn_id from perlss.pasrr_rqst a 
where last_modified_by like '%PASRR_U%';

select distinct a.prsn_id,a.pae_id, b.status_cd, c.enr_grp_cd 
from perlss.pasrr_rqst a 
join perlss.pae_rqst b on a.pae_id =b.pae_id
left join perlss.enr_rqst c on a.pae_id = c.pae_id and a.prsn_id = b.prsn_id
where a.last_modified_by like '%PASRR_U%' and c.enr_grp_cd ='CG1'
and a.pae_id in (select perlss_pae_id from legacy.tmed_pasrr)









select distinct a.prsn_id,a.pae_id, b.status_cd,c.enr_grp_cd 
from perlss.pasrr_rqst a 
join perlss.pae_rqst b on a.pae_id =b.pae_id
join perlss.enr_rqst c on a.pae_id = c.pae_id and a.prsn_id = b.prsn_id
where a.last_modified_by like '%PASRR_U%' and c.enr_grp_cd ='CG1'
and a.pae_id in (select perlss_pae_id from legacy.tmed_pasrr)




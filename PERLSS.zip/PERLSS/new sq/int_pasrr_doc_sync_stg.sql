select
nextval('perlss.hibernate_sequence') as ID,
* from (
select distinct
null	int_txn_id  
,ca.prsn_id	prsn_id  
,ca.prsn_id	indv_id
,'N'	process_flag
,b.episodeguid 	evnt_id
,w.maximus_reviewid	review_id  
,w.maximus_ascendid	ascend_id  
,(lower(azuredocumentid))	file_name
,case when bb.code is not null then bb.code else 'OSD' end	attachment_type  
,'pdf'	mime_type
,null	file_size  
,b.upload_date	upload_dt  
,NULL	ref_id
,'PASRR'	source_sys_nm
,NULL	tns_id
,'A' as CONVERSION_RUN_STATUS
,r.pae_id	pae_id
from  legacy.pasrr_blob_final b
left join legacy.pasrr_base_member_pop  w  on b.episodeid ::bigint  = w.maximus_reviewid::bigint
left join (select * from legacy.xrf_perlss_data where name='PASRR_DOC_TYPE') bb on b.attachmenttype= bb.value
left join (select  *  from perlss.pasrr_rqst where  created_by='PASRR_CV') r    on r.episode_id::text = w.maximus_reviewid::text
left join perlss.com_applcnt ca on w.maximus_ssn=ca.ssn and ca.active_sw='Y' and file_clearance_sw='Y'
)a where prsn_id is not null


--/perlss_caagent/stg/interfaces/TPAES/conv/pdfs/
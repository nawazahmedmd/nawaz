select 
nextval('perlss.hibernate_sequence') as ID,
 * from (
select distinct 
'Conversion'	certifier_name
,'Conversion'	credential
,null 	doc_id
,'CRT'	doc_type_cd
,NULL	last_modified_by
,NULL	last_modified_dt
,NULL	mco_chklst_comments
,NULL	mco_chklst_sw
,NULL 	medicaid_id
,NULL	npi
,NULL	pae_certification_dt
,r.pae_id	pae_id
,NULL	qual_assessor_cd
, r.legacy_id
,'A' as CONVERSION_RUN_STATUS
from  legacy.wrk_pasrr_clients w
left join (select  *  from perlss.pae_rqst where  created_by='PASRR_CV') r    on r.legacy_id::text = w.maximus_reviewid::text
where  w.source_system_nm = 'MAXIMUS' 
and valid_sw= 'Y' and 	xref_valid_sw='Y'  and perlss_sw ='N'
)a where  pae_id is not  null;
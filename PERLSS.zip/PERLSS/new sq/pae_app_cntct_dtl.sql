select 
nextval('perlss.hibernate_sequence') as ID,
 * from (
select distinct 
'N'	act_behalf_applicant_sw
,Null 	cell_ph_num
,'N' as	complete_submit_form_sw
,'N'	contact_sw
,NULL	email_addr
,trim(b.ResponsiblePartyFirstName)	first_name
,case when b.responsiblepartyfirstname is not null then 'Y' else 'N' end get_letters_sw
,'N'	has_legal_rights_sw
,NULL	home_ph_num
,NULL	last_modified_by
,NULL	last_modified_dt
,trim(b.ResponsiblePartylastName)	last_name
,case when upper(b.individualaddress1)<> upper(b.responsiblepartyaddress1)then 'Y' else 'N' END	mail_sw -- confirmed by Srikar/Parvathy on 1/24/2025
,Null	middle_initial
,r.pae_id	pae_id
,'ENG'	pref_lang_letters_cd
,'N'	receive_copies_notices_sw
,'NA'	reltshp_cd
,'N'	sign_app_behalf_appts_sw
,NULL	suffix
,'DSGN'	user_type_cd
,NULL	work_ph_num
,NULL delete_sw
,'A' as CONVERSION_RUN_STATUS
from legacy.wrk_pasrr_clients w 
join legacy.pasrr_events b on b.reviewid::bigint  = w.maximus_reviewid::bigint
left join (select  *  from perlss.pae_rqst where  created_by='PASRR_CV') r    on r.legacy_id::text = w.maximus_reviewid::text
where  w.source_system_nm = 'MAXIMUS' 
and b.responsiblepartyaddress1 is not Null
and valid_sw= 'Y' and 	xref_valid_sw='Y'  and perlss_sw ='N'
)a where pae_id is not null

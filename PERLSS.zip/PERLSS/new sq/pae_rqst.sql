select 
nextval('perlss.hibernate_sequence') as ID,
concat('PAE',nextval('perlss.pae_rqst_0sq')) as PAE_ID,
 * from (
select distinct 
 NULL as 	abandon_parta_sw
,NULL as 	actual_discharge_dt
,'N'	assigned_grp_submit_sw
,case when l2.Level2DeterminationEffectiveDate is not null then l2.Level2DeterminationEffectiveDate 
			else l2.Level2DeterminationDate end  as	begin_dt
,NULL as 	chm_id
,NULL as 	closure_attestation_sw
,NULL as 	closure_rsn_cd
,NULL as 	closure_rsn_desc
,NULL as 	due_dt
,NULL as 	enroll_in_mfp_sw
,NULL as 	grand_region_cd
,CASE WHEN group3interest_decision = 'Interested in Group 3' then 'Y' 
      when group3interest_decision= 'Not Interested in Group 3' then 'N' else null END  as grp3_intrst_sw
,NULL as 	last_modified_by
,NULL as 	last_modified_dt
,b.ReviewID	legacy_id
,NULL as 	mode_cd
,case when xm.passr_pi__nursingfacilityadmissiondate::date is not null then xm.passr_pi__nursingfacilityadmissiondate::date else b.NFAdmitDate end as	mopd_dt
,'N'	new_prsn_sw
,a.ReferralDate as	pae_rqst_dt
,'TMD'	pae_type_cd
,'N'	pdf_generated_sw
,'CG1'	program_cd
, ca.prsn_id as    prsn_id
,NULL as 	reassessment_due_dt
,NULL as 	recrtfctn_due_dt
,NULL as 	ref_id
,NULL as 	rqstd_enr_grp_cd
,NULL as 	ssi_applcatn_status_cd
,NULL as 	submitted_enr_grp_cd
,NULL as 	tmed_id
,NULL as 	tns_id
,Null as	user_id
,'A' as CONVERSION_RUN_STATUS
, upper(l1.level1submittingfacility) as level1submittingfacility
,coalesce(so.entity_id,'9999') as entity_id
,so.entity_name  as entity_name
,so.entity_type
,trim(adj.perlss_pae_status) as final_pae_status
,trim(b.payersource) payersource
,trim(l1.level1outcome) level1outcome
,trim(l2.level2outcome) level2outcome
,trim(l2.level2noticetype) level2noticetype	
,trim(a.locoutcome) locoutcome
,trim(a.safetyformoutcome) safetyformoutcome 
,trim(a.functionaldeficitidentified) functionaldeficitidentified
from legacy.wrk_pasrr_clients w
join legacy.pasrr_events b on w.maximus_reviewid = b.reviewid  
join perlss.com_applcnt ca on ca.ssn::text = w.ssn::text and ca.active_sw='Y'  and ca.file_clearance_sw='Y' 
join legacy.pasrr_pae_base_member_pop pop on w.maximus_reviewid = pop.pasrr_review_id
left join legacy.pasrr_level_i l1 on  b.eventid =l1.eventid 
left join legacy.pasrr_level_ii l2 on  b.eventid =l2.eventid 
left join legacy.pasrr_loc  a on  a.eventid =b.eventid 
left join (select distinct num_control  , group3interest_decision,passr_pi__nursingfacilityadmissiondate from legacy.tmed_xml_extract_cv_qlf_no_rec) xm on xm.num_control::int=pop.tmed_num_control_pkey::int
left join (select a.level1submittingfacility  ,a.perlss_entity_id entity_id , so.entity_type_id, sot.entity_type , so.entity_name 
			from legacy.xref_subfacility_secorg a 
			join perlss.sec_organization so  on (a.perlss_entity_id)= so.entity_id::text
			left join perlss.sec_org_type sot on so.entity_type_id=sot.entity_type_id) so on upper(l1.level1submittingfacility)=upper(so.level1submittingfacility)
left join legacy.wrk_pasrr_pae_status_adj_dcsn adj on (coalesce (trim(upper(b.payersource)),'[NULL]')=coalesce (trim(upper(adj.payersource)),'[NULL]')	and
														coalesce (trim(upper(l1.level1outcome)),'[NULL]')=coalesce (trim(upper(adj.level1outcome)),'[NULL]')	and
														coalesce (trim(upper(l2.level2outcome)),'[NULL]')=coalesce (trim(upper(adj.level2outcome)),'[NULL]')	and
														coalesce (trim(upper(l2.level2noticetype)),'[NULL]')	=coalesce (trim(upper(adj.level2noticetype)),'[NULL]')and
														coalesce (trim(upper(replace(a.locoutcome,' ','')	)),'[NULL]')=coalesce (trim(upper(replace(adj.locoutcome,' ','')	)),'[NULL]')and
														coalesce (trim(upper(a.safetyformoutcome)),'[NULL]')=coalesce (trim(upper(adj.safetyformoutcome)),'[NULL]')and
														coalesce (trim(upper(a.functionaldeficitidentified)),'[NULL]')=coalesce (trim(upper(adj.functionaldeficitidentified)),'[NULL]'))
where  w.source_system_nm = 'MAXIMUS'
and valid_sw= 'Y' and 	xref_valid_sw='Y' and perlss_sw ='N'
)a





































select distinct completed_comments,tmed_num_control_pkey ,pasrr_review_id
from legacy.tmed_xml_extract_cv_qlf_no_rec a
join legacy.pasrr_pae_base_member_pop b on a.num_control::text = b.tmed_num_control_pkey ::text
join perlss.pae_rqst c on c.legacy_id::text = b.pasrr_review_id::text
where preenrollment_comments ilike '%MOPD%' and c.mopd_dt is null and c.created_by ='PASRR_CV'
and preenrollment_comments not in ('over 90 days no Admit date/MOPD',
'over 90 days - no MOPD','Updated admit date and MOPD sent through email from D Goodrum',
'no admit/MOPD entered - over 90 days');

update perlss.pae_rqst set mopd_dt = '2022-01-12' where legacy_id = '539040' and created_by = 'PASRR_CV' AND mopd_dt is null;
update perlss.pae_rqst set mopd_dt = '2026-03-28' where legacy_id = '640182' and created_by = 'PASRR_CV' AND mopd_dt is null;
update perlss.pae_rqst set mopd_dt = '2022-03-20' where legacy_id = '536518' and created_by = 'PASRR_CV' AND mopd_dt is null;
update perlss.pae_rqst set mopd_dt = '2022-11-01' where legacy_id = '554675' and created_by = 'PASRR_CV' AND mopd_dt is null;
update perlss.pae_rqst set mopd_dt = '2020-04-01' where legacy_id = '338885' and created_by = 'PASRR_CV' AND mopd_dt is null;
update perlss.pae_rqst set mopd_dt = '2020-12-04' where legacy_id = '412317' and created_by = 'PASRR_CV' AND mopd_dt is null;
update perlss.pae_rqst set mopd_dt = '2021-01-31' where legacy_id = '414926' and created_by = 'PASRR_CV' AND mopd_dt is null;
update perlss.pae_rqst set mopd_dt = '2020-12-23' where legacy_id = '408662' and created_by = 'PASRR_CV' AND mopd_dt is null;
update perlss.pae_rqst set mopd_dt = '2019-04-02' where legacy_id = '228620' and created_by = 'PASRR_CV' AND mopd_dt is null;
update perlss.pae_rqst set mopd_dt = '2020-06-16' where legacy_id = '362178' and created_by = 'PASRR_CV' AND mopd_dt is null;
update perlss.pae_rqst set mopd_dt = '2019-06-06' where legacy_id = '252509' and created_by = 'PASRR_CV' AND mopd_dt is null;
update perlss.pae_rqst set mopd_dt = '2020-05-21' where legacy_id = '354339' and created_by = 'PASRR_CV' AND mopd_dt is null;
update perlss.pae_rqst set mopd_dt = '2019-08-21' where legacy_id = '259810' and created_by = 'PASRR_CV' AND mopd_dt is null;
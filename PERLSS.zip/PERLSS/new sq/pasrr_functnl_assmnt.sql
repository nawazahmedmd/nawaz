select distinct
pasrr_id
, 'TRAN' ADLTransfer
, 'MOBL' ADLWalking
, 'MOBW' ADLMobility
, 'EATG' ADLEating
, 'TLTG' ADLToileting
, 'TLTI' ADLIncontinentCare
, 'TLTC' ADLCatheterCare
, 'ORNT' ADLOrientation
, 'ECOM' ADLExpressive
, 'RCOM' ADLReceptive
, 'MEDC' ADLMedsAdmin
, 'BHVR' ADLBehavior
,trim(ADLTransferDenialReason) ADLTransferDenialReason
,trim(ADLWalkingDenialReason) ADLWalkingDenialReason
,trim(ADLMobilityDenialReason) ADLMobilityDenialReason
,trim(ADLEatingDenialReason) ADLEatingDenialReason
,trim(ADLToiletingDenialReason) ADLToiletingDenialReason
,trim(ADLIncontinentCareDenialReason) ADLIncontinentCareDenialReason
,trim(ADLCatheterCareDenialReason) ADLCatheterCareDenialReason
,trim(ADLOrientationDenialReason) ADLOrientationDenialReason
,trim(ADLExpressiveDenialReason) ADLExpressiveDenialReason
,trim(ADLReceptiveDenialReason) ADLReceptiveDenialReason
,trim(ADLMedsAdminDenialReason) ADLMedsAdminDenialReason
,trim(ADLBehaviorDenialReason) ADLBehaviorDenialReason
,trim(ADLTransferClinicianResponse) ADLTransferClinicianResponse
,trim(ADLWalkingClinicianResponse) ADLWalkingClinicianResponse
,trim(ADLMobilityClinicianResponse) ADLMobilityClinicianResponse
,trim(ADLEatingClinicianResponse) ADLEatingClinicianResponse
,trim(ADLToiletingClinicianResponse) ADLToiletingClinicianResponse
,trim(ADLIncontinentCareClinicianResponse) ADLIncontinentCareClinicianResponse
,trim(ADLCatheterCareClinicianResponse) ADLCatheterCareClinicianResponse
,trim(ADLOrientationClinicianResponse) ADLOrientationClinicianResponse
,trim(ADLExpressiveClinicianResponse) ADLExpressiveClinicianResponse
,trim(ADLReceptiveClinicianResponse) ADLReceptiveClinicianResponse
,trim(ADLMedsAdminClinicianResponse) ADLMedsAdminClinicianResponse
,trim(ADLBehaviorClinicianResponse) ADLBehaviorClinicianResponse
,trim(ADLTransferClinicianDetermination) ADLTransferClinicianDetermination
,trim(ADLWalkingClinicianDetermination) ADLWalkingClinicianDetermination
,trim(ADLMobilityClinicianDetermination) ADLMobilityClinicianDetermination
,trim(ADLEatingClinicianDetermination) ADLEatingClinicianDetermination
,trim(ADLToiletingClinicianDetermination) ADLToiletingClinicianDetermination
,trim(ADLIncontinentCareClinicianDetermination) ADLIncontinentCareClinicianDetermination
,trim(ADLCatheterCareClinicianDetermination) ADLCatheterCareClinicianDetermination
,trim(ADLOrientationClinicianDetermination) ADLOrientationClinicianDetermination
,trim(ADLExpressiveClinicianDetermination) ADLExpressiveClinicianDetermination
,trim(ADLReceptiveClinicianDetermination) ADLReceptiveClinicianDetermination
,trim(ADLMedsAdminClinicianDetermination) ADLMedsAdminClinicianDetermination
,trim(ADLBehaviorClinicianDetermination) ADLBehaviorClinicianDetermination
,trim(ADLTransferRationale) ADLTransferRationale
,trim(ADLWalkingRationale) ADLWalkingRationale
,trim(ADLMobilityRationale) ADLMobilityRationale
,trim(ADLEatingRationale) ADLEatingRationale
,trim(ADLToiletingRationale) ADLToiletingRationale
,trim(ADLIncontinentCareRationale) ADLIncontinentCareRationale
,trim(ADLCatheterCareRationale) ADLCatheterCareRationale
,trim(ADLOrientationRationale) ADLOrientationRationale
,trim(ADLExpressiveRationale) ADLExpressiveRationale
,trim(ADLReceptiveRationale) ADLReceptiveRationale
,trim(ADLMedsAdminRationale) ADLMedsAdminRationale
,trim(ADLBehaviorRationale) ADLBehaviorRationale
,trim(ADLTransfer) ADLTransfer_sbmtr_rsp
,trim(ADLWalking) ADLWalking_sbmtr_rsp
,trim(ADLMobility) ADLMobility_sbmtr_rsp
,trim(ADLEating) ADLEating_sbmtr_rsp
,trim(ADLToileting) ADLToileting_sbmtr_rsp
,trim(ADLIncontinentCare) ADLIncontinent_sbmtr_rsp
,trim(ADLCatheterCare) ADLCatheterCare_sbmtr_rsp
,trim(ADLOrientation) ADLOrientation_sbmtr_rsp
,trim(ADLExpressive) ADLExpressive_sbmtr_rsp
,trim(ADLReceptive) ADLReceptive_sbmtr_rsp
,trim(ADLMedsAdmin) ADLMedsAdmin_sbmtr_rsp
,trim(ADLBehavior) ADLBehavior_sbmtr_rsp
,ADLMedsAdminNotes
,adlbehaviornotes
--select count(1)
from legacy.pasrr_events b   
join legacy.pasrr_loc a on  b.eventid::text = a.eventid::text   
join legacy.pasrr_base_member_pop w on b.reviewid::bigint  = w.maximus_reviewid::bigint
left join perlss.pasrr_rqst r  on r.episode_id ::text = b.reviewid::text and r.created_by  = 'PASRR_CV'
where r.pasrr_id is not null
select 
nextval('perlss.hibernate_sequence') as ID,
 * from (
select distinct 
'Conversion'	beh_intrvntn
,'Conversion'	beh_type
,NULL	last_modified_by
,NULL	last_modified_dt
,r.pae_id as	pae_id
,'A' as CONVERSION_RUN_STATUS
,lv.id as pae_activities_lvng_id
from  legacy.wrk_pasrr_clients w   
left join (select  *  from perlss.pae_rqst where  created_by='PASRR_CV') r    on r.legacy_id::text = w.maximus_reviewid::text 
left join perlss.pae_activities_lvng lv on lv.pae_id = r.pae_id
where  w.source_system_nm = 'MAXIMUS' 
and valid_sw= 'Y' and 	xref_valid_sw='Y'  and perlss_sw ='N'
)a
where pae_id is not null
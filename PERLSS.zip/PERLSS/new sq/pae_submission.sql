select 
nextval('perlss.hibernate_sequence') as ID,
 * from (
select distinct 
NULL	cea_determn_cd
,'N'	cea_sw
,NULL	certificate_dt
,NULL	comments
,NULL	last_modified_by
,NULL	last_modified_dt
,r.pae_id as	pae_id
,'N'	pae_recrtfctn_ack_sw
,NULL	pae_recrtfctn_sw
,'N'	revised_pae_sw
,coalesce(so.user_id,'CV_282') as	signature
,a.ReferralDate	submit_dt
,'OTH'	who_submitting_cd
, r.legacy_id
,'A' as CONVERSION_RUN_STATUS
--select count(1)
from legacy.wrk_pasrr_clients w 
join legacy.pasrr_events b on b.reviewid::bigint  = w.maximus_reviewid::bigint
left join legacy.pasrr_level_i l1 on  b.eventid =l1.eventid 
left join legacy.pasrr_loc  a on  a.eventid =b.eventid 
left join (select  *  from perlss.pae_rqst where  created_by='PASRR_CV') r    on r.legacy_id::text = w.maximus_reviewid::text
left join (select distinct so.entity_id, entity_type,so.entity_name ,sp.user_id , first_name , last_name, a.level1submittingfacility 
			from perlss.sec_org_type sot 
			 join perlss.sec_organization so on so.entity_type_id = sot.entity_type_id 
			 join perlss.sec_user_organization suo on suo.entity_id = so.entity_id
			 join perlss.sec_user_profile sp on sp.user_id = suo.user_id
			 join legacy.xref_subfacility_secorg a on  a.perlss_entity_id= so.entity_id::text) so 
			on upper(l1.level1submittingfacility)=upper(so.level1submittingfacility) 
			AND upper((trim(l1.level1submitterfirstname) || trim(l1.level1submitterlastname)))=upper((trim(so.first_name) ||trim(so.last_name)))
where  w.source_system_nm = 'MAXIMUS' 
and valid_sw= 'Y' and 	xref_valid_sw='Y'  and perlss_sw ='N'
)a where  pae_id is not  null
select distinct 
r.pasrr_id pasrr_id
,TO_CHAR(WoundCareDecubitusStartDate,'YYYYMMDD') as WoundCareDecubitusStartDate
,TO_CHAR(WoundCareOtherStartDate,'YYYYMMDD') as WoundCareOtherStartDate
,TO_CHAR(InjectionsInsulinStartDate,'YYYYMMDD') InjectionsInsulinStartDate
,TO_CHAR(InjectionsOtherStartDate,'YYYYMMDD') InjectionsOtherStartDate
,TO_CHAR(IntravenousFluidsStartDate,'YYYYMMDD') IntravenousFluidsStartDate
,TO_CHAR(IsolationPrecautionsStartDate,'YYYYMMDD') IsolationPrecautionsStartDate
,TO_CHAR(OccupationalTherapyStartDate,'YYYYMMDD') OccupationalTherapyStartDate
,TO_CHAR(PhysicalTherapyStartDate,'YYYYMMDD') PhysicalTherapyStartDate
,TO_CHAR(CatheterOstomyStartDate,'YYYYMMDD') CatheterOstomyStartDate
,TO_CHAR(SelfInjectionStartDate,'YYYYMMDD') SelfInjectionStartDate
,TO_CHAR(ParenteralNutritionStartDate,'YYYYMMDD') ParenteralNutritionStartDate
,TO_CHAR(TubeFeedingStartDate,'YYYYMMDD') TubeFeedingStartDate
,TO_CHAR(PeritonealDialysisStartDate,'YYYYMMDD') PeritonealDialysisStartDate
,TO_CHAR(PCAPumpStartDate,'YYYYMMDD') PCAPumpStartDate
,TO_CHAR(TracheostomyStartDate,'YYYYMMDD') TracheostomyStartDate
,TO_CHAR(WoundCareDecubitusEndDate,'YYYYMMDD') WoundCareDecubitusEndDate
,TO_CHAR(WoundCareOtherEndDate,'YYYYMMDD') WoundCareOtherEndDate
,TO_CHAR(InjectionsInsulinEndDate,'YYYYMMDD') InjectionsInsulinEndDate
,TO_CHAR(InjectionsOtherEndDate,'YYYYMMDD') InjectionsOtherEndDate
,TO_CHAR(IntravenousFluidsEndDate,'YYYYMMDD') IntravenousFluidsEndDate
,TO_CHAR(IsolationPrecautionsEndDate,'YYYYMMDD') IsolationPrecautionsEndDate
,TO_CHAR(OccupationalTherapyEndDate,'YYYYMMDD') OccupationalTherapyEndDate
,TO_CHAR(PhysicalTherapyEndDate,'YYYYMMDD') PhysicalTherapyEndDate
,TO_CHAR(CatheterOstomyEndDate,'YYYYMMDD') CatheterOstomyEndDate
,TO_CHAR(SelfInjectionEndDate,'YYYYMMDD') SelfInjectionEndDate
,TO_CHAR(ParenteralNutritionEndDate,'YYYYMMDD') ParenteralNutritionEndDate
,TO_CHAR(TubeFeedingEndDate,'YYYYMMDD') TubeFeedingEndDate
,TO_CHAR(PeritonealDialysisEndDate,'YYYYMMDD') PeritonealDialysisEndDate
,TO_CHAR(PCAPumpEndDate,'YYYYMMDD') PCAPumpEndDate
,TO_CHAR(TracheostomyEndDate,'YYYYMMDD')	TracheostomyEndDate
,'WCS'	WoundCareDecubitus
,'OWC'	WoundCareOther
,'ISS'	InjectionsInsulin
,'IOT'	InjectionsOther
,'INT'	IntravenousFluids
,'ISP'	IsolationPrecautions
,'OCT'	OccupationalTherapy
,'PHT'	PhysicalTherapy
,'TCO'	CatheterOstomy
,'TSI'	SelfInjection
,'TPN'	ParenteralNutrition
,'TFE'	TubeFeeding
,'PED'	PeritonealDialysis
,'PCA'	PCAPump
,'TRS'	Tracheostomy
,WoundCareDecubitusClinicalDetermination
,WoundCareOtherClinicalDetermination
,InjectionsInsulinClinicalDetermination
,InjectionsOtherClinicalDetermination
,IntravenousFluidsClinicalDetermination
,IsolationPrecautionsClinicalDetermination
,OccupationalTherapyClinicalDetermination
,PhysicalTherapyClinicalDetermination
,CatheterOstomyClinicalDetermination
,SelfInjectionClinicalDetermination
,ParenteralNutritionClinicalDetermination
,TubeFeedingClinicalDetermination
, PeritonealDialysisClinicalDetermination
,PCAPumpClinicalDetermination
,TracheostomyClinicalDetermination
,WoundCareDecubitusrationale
,WoundCareOtherrationale
,InjectionsInsulinrationale
,InjectionsOtherrationale
,IntravenousFluidsrationale
,IsolationPrecautionsrationale
,OccupationalTherapyrationale
,PhysicalTherapyrationale
,CatheterOstomyrationale
,SelfInjectionrationale
,ParenteralNutritionrationale
,TubeFeedingrationale
,PeritonealDialysisrationale
,PCAPumprationale
,Tracheostomyrationale 
from legacy.pasrr_events b 
join legacy.pasrr_base_member_pop w on b.reviewid::bigint  = w.maximus_reviewid::bigint
left join legacy.pasrr_loc a on  b.eventid::text = a.eventid::text
left join perlss.pasrr_rqst r  on r.episode_id ::text = b.reviewid::text and r.created_by  = 'PASRR_CV'
where r.pasrr_id is not null;
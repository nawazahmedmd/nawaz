select 
nextval('perlss.hibernate_sequence') as ID,
 * from (
 --flow to insert individual address as MA
select distinct 
'USAD'	addr_format_cd
,upper(trim(b.IndividualAddress1))	addr_line_1
,upper(trim(b.IndividualAddress2))	addr_line_2
,'MA'	addr_type_cd
,upper(trim(b.IndividualCity))	city
,case when upper(trim(b.IndividualState))<> 'TN' then '999' else upper(trim(b.IndividualCounty)) end  cnty_cd
,NULL	last_modified_by
,NULL	last_modified_dt
,'Y'	mail_addr_sw---- confirmed by Srikar/Parvathy on 1/24/2025
,NULL	military_po_cd
,NULL	military_state_cd
,r.pae_id  	pae_id
,upper(trim(b.IndividualState))	state_cd
,'APPL'	user_type_cd
,NULL	validated_addr_cd
,trim(b.IndividualZip)	zip
,NULL	zip_extsn
,'A' as CONVERSION_RUN_STATUS
, NULL as delete_sw
from legacy.wrk_pasrr_clients w 
join legacy.pasrr_events b on b.reviewid::bigint  = w.maximus_reviewid::bigint
left join (select  *  from perlss.pae_rqst where  created_by='PASRR_CV') r    on r.legacy_id::text = w.maximus_reviewid::text
where  w.source_system_nm = 'MAXIMUS' 
and valid_sw= 'Y' and 	xref_valid_sw='Y'  and perlss_sw ='N'
union 
 --flow to insert indIvidual address as PA
select distinct 
'USAD'	addr_format_cd
,upper(trim(b.IndividualAddress1))	addr_line_1
,upper(trim(b.IndividualAddress2))	addr_line_2
,'PA'	addr_type_cd
,upper(trim(b.IndividualCity))	city
,case when upper(trim(b.IndividualState))<> 'TN' then '999' else upper(trim(b.IndividualCounty)) end  cnty_cd
,NULL	last_modified_by
,NULL	last_modified_dt
,'Y'	mail_addr_sw ---- confirmed by Srikar/Parvathy on 1/24/2025
,NULL	military_po_cd
,NULL	military_state_cd
,r.pae_id  	pae_id
,upper(trim(b.IndividualState))	state_cd
,'APPL'	user_type_cd
,NULL	validated_addr_cd
,trim(b.IndividualZip)	zip
,NULL	zip_extsn
,'A' as CONVERSION_RUN_STATUS
,NULL as delete_sw
--select count(1)
from legacy.wrk_pasrr_clients w 
join legacy.pasrr_events b on b.reviewid::bigint  = w.maximus_reviewid::bigint
left join (select  *  from perlss.pae_rqst where  created_by='PASRR_CV') r    on r.legacy_id::text = w.maximus_reviewid::text   
where  w.source_system_nm = 'MAXIMUS' 
and valid_sw= 'Y' and 	xref_valid_sw='Y'  and perlss_sw ='N'
union 
 --flow to insert designee address as MA
select distinct 
'USAD'	addr_format_cd
,upper(trim(b.responsiblepartyaddress1))	addr_line_1
,upper(trim(b.responsiblepartyaddress2))	addr_line_2
,'MA'	addr_type_cd
,upper(trim(b.ResponsiblePartyCity))	city
,case when upper(trim(b.ResponsiblePartyState))<> 'TN' then '999' else Null end  cnty_cd
,NULL	last_modified_by
,NULL	last_modified_dt
,case when (upper(b.individualaddress1)= upper(b.responsiblepartyaddress1) then 'Y' else 'N' end	mail_addr_sw
,NULL	military_po_cd
,NULL	military_state_cd
,r.pae_id  	pae_id
,upper(trim(b.ResponsiblePartyState))	state_cd
,'DSGN'	user_type_cd
,NULL	validated_addr_cd
,trim(b.ResponsiblePartyZip)	zip
,NULL	zip_extsn
,'A' as CONVERSION_RUN_STATUS
,NULL as delete_sw
--select count(1)
from legacy.wrk_pasrr_clients w 
join legacy.pasrr_events b on b.reviewid::bigint  = w.maximus_reviewid::bigint
left join (select  *  from perlss.pae_rqst where  created_by='PASRR_CV') r    on r.legacy_id::text = w.maximus_reviewid::text
where  w.source_system_nm = 'MAXIMUS' 
and b.responsiblepartyaddress1 is not Null
and valid_sw= 'Y' and 	xref_valid_sw='Y'  and perlss_sw ='N'
)a where pae_id is not null;





select 
nextval('perlss.hibernate_sequence') as ID,
 * from (
 select distinct 
null::timestamp as archived_dt,
a.locreimbursementlevel,
referraldate,
referralname,
a.locoutcome,
a.locdeterminationdate,
safetyformrequest,
safetyformdeclineddate,
attestationdate,
submittedacuityscore,
approvedacuityscore,
functionaldeficitidentified,
safetyformreviewed,
safetyformoutcome,
diagnosisrelevanttoneeds,
rationale,
referralcomments,
referralfacility,
SkilledServicesDuration,
pr.pasrr_id ,	
'0' as record_version,
'A' as CONVERSION_RUN_STATUS,
 null as  last_modified_by,
 null as last_modified_dt
--select count(1)
from legacy.pasrr_events b   
join legacy.pasrr_loc a on  b.eventid::text = a.eventid::text   
join legacy.pasrr_base_member_pop w on b.reviewid::bigint  = w.maximus_reviewid::bigint
left join perlss.pasrr_rqst pr  on pr.episode_id ::text = b.reviewid::text and pr.created_by  = 'PASRR_CV'
where pr.pasrr_id is not null
)a
select 
nextval('perlss.hibernate_sequence') as ID,
 * from (
SELECT DISTINCT 
null as apl_indctr_sw,
b.PERLSS_INDV_ID, 
e.enr_id,
a.sak_recip as sak_recip, 
'' as dual_member_indctr_sw,
a.DSC_PGM_HEALTH,
a.NUM_SSN,
a.DTE_EFFECTIVE as ctgry_elig_begin_dt,
a.DTE_END as ctgry_elig_end_dt, 
trb.SAK_LIV_ARNG, 
T_RE_DISENROLL_REASONS.CDE_DISENROLL_RSN, 
T_CDE_DISENROLL_REASONS.DESC_DISENROLL_RSN ,
--T_RE_LIV_ARNG.CDE_LIV_ARNG
ca.prsn_id,
ca.first_name,
ca.last_name,
ca.middle_initial,
ca.dob_dt,
ca.ssn,
ca.gender_cd,
'A' as CONVERSION_RUN_STATUS,
null::timestamp as archived_dt,
null as  last_modified_by,
null as last_modified_dt,
fe.coe_desc,
fe.coe_id
--select count(1)
from (select dte_effective::varchar::date as o_dte_effective,dte_end::varchar::date as o_dte_end ,loc_dte_effective::varchar::date as o_loc_dte_effective,
loc_dte_end::varchar::date as o_loc_dte_end,dte_last_update::varchar::date as o_dte_last_update,* from legacy.pasrr_mmis_base_member_pop  )a 
join (select  * from legacy.wrk_pasrr_clients where  source_system_nm='MMIS') b  on  b.ssn=a.num_ssn and a.sak_recip::varchar(25)=b.sak_recip  and trim(a.num_pre_eval) =trim(b.mmis_pae_id)
join legacy.pasrr_tmed_base_member_pop tm on num_control_pkey::varchar(25) =trim(a.num_pre_eval)
join (select  *  from legacy.pasrr_pae_base_member_pop pae )pae on pae.pasrr_review_id::varchar(25)=trim(tm.tmed_ascend_id)
join (select  *  from perlss.pae_rqst where  created_by='PASRR_CV') p  on trim(legacy_id)=pae.pasrr_review_id::varchar(25)
join (select  *  from perlss.enr_rqst where  created_by='PASRR_CV' and enr_status_cd in ('DIS','ENR')) e  on p.pae_id=e.pae_id
JOIN legacy.pasrr_mmis_t_re_base trb ON trb.SAK_RECIP=a.SAK_RECIP
 --join legacy.pasrr_mmis_t on trim(T_RE_LIV_ARNG.SAK_LIV_ARNG)=trim(b.sak_liv_arng)
 join perlss.com_applcnt ca on ca.ssn=a.num_ssn and ca.active_sw ='Y' and file_clearance_sw='Y'
 left join (
select * from legacy.fe_check 
where coe_id  in ('W01','L02','L01','W02','L03','L04', 'SSI')
and (eligibility_end_dt is null or eligibility_end_dt > current_date)) fe on ca.ssn = fe.ssn
 left JOIN ( select  * from (select   ROW_NUMBER() OVER(PARTITION BY sak_recip
        ORDER BY DTE_LAST_UPDATE DESC
    ) row_num, dr.* from legacy.pasrr_mmis_t_re_disenroll_reasons dr )dr1 where  row_num=1 ) t_re_disenroll_reasons  ON a.SAK_RECIP=t_re_disenroll_reasons.SAK_RECIP
and t_re_disenroll_reasons.SAK_PGM_ELIG=a.SAK_PGM_ELIG
left JOIN legacy.pasrr_mmis_t_cde_disenroll_reasons t_cde_disenroll_reasons ON t_cde_disenroll_reasons.CDE_DISENROLL_RSN=t_re_disenroll_reasons.CDE_DISENROLL_RSN
 where   
 b.VALID_SW ='Y' AND b.XREF_VALID_SW = 'Y' 
and b.perlss_sw ='N'
) a
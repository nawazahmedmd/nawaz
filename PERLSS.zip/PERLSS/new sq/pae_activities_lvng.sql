select 
nextval('perlss.hibernate_sequence') as ID,
 * from (
select distinct 
  case when trim(ADLIncontinentBowel) is not null OR trim(ADLIncontinentCare) is not null then 'Y' else 'N' end	applcnt_incont_sw
, case when trim(ADLBehavior)	= 'Always' then 'AL'
       when trim(ADLBehavior)	= 'Usually' then 'US'
       when trim(ADLBehavior)	= 'Usually Not' then 'UN'
       when trim(ADLBehavior)	= 'Never' then 'NE'	end beh_problem_cd
, case when trim(ADLCatheterCare) = 'Always' then 'AL'
       when trim(ADLCatheterCare) = 'Usually' then 'US'
       when trim(ADLCatheterCare) = 'Usually Not' then 'UN'
       when trim(ADLCatheterCare) = 'Never' then 'NE' end	cath_ost_whithout_help_cd
, case when trim(CatheterOstomy)  = 'True' then 'Y' 
       when trim(CatheterOstomy) = 'False' then 'N' end	catheter_ostomy_sw
, case when trim(ADLExpressive) = 'Always' then 'AL'
       when trim(ADLExpressive) = 'Usually' then 'US'
       when trim(ADLExpressive) = 'Usually Not' then 'UN'
       when trim(ADLExpressive) = 'Never' then 'NE' end	communicate_wants_cd
, case when trim(ADLEating)	= 'Always' then 'AL'
       when trim(ADLEating)	= 'Usually' then 'US'
       when trim(ADLEating)	= 'Usually Not' then 'UN'
       when trim(ADLEating)	= 'Never' then 'NE' end	eat_without_help_cd
, case when trim(ADLReceptive) = 'Always' then 'AL'
       when trim(ADLReceptive) = 'Usually' then 'US'
       when trim(ADLReceptive) = 'Usually Not' then 'UN'
       when trim(ADLReceptive) = 'Never'then 'NE' end	follow_instructions_cd
, case when trim(ADLIncontinentBladder) = 'True' then 'BL' 
       when trim(ADLIncontinentBowel) = 'True' then 'BO' end 	incont_type_cd
, case when trim(ADLIncontinentCare)	= 'Always' then 'AL'
       when trim(ADLIncontinentCare)	= 'Usually' then 'US'
       when trim(ADLIncontinentCare)	= 'Usually Not' then 'UN'
       when trim(ADLIncontinentCare)	= 'Never' then 'NE' end	incont_without_help_cd
, NULL	last_modified_by
, NULL	last_modified_dt
, Case when trim(ADLOrientation)	= 'Always' then 'AL'
       when trim(ADLOrientation)	= 'Usually' then 'US'
       when trim(ADLOrientation)	= 'Usually Not' then 'UN'
       when trim(ADLOrientation)	= 'Never' then 'NE' end	orientation_prsn_place_cd
,r.pae_id 	pae_id
,case when trim(ADLMedsAdmin)	='Always' then 'AL'
	   when trim(ADLMedsAdmin)	='Usually' then 'US'
	   when trim(ADLMedsAdmin)	='Usually Not' then 'UN'
	   when trim(ADLMedsAdmin)	='Never' then 'NE' end self_admt_medication_cd 
, case when trim(ADLToileting)	='Always' then 'AL'
	   when trim(ADLToileting)	='Usually' then 'US'
	   when trim(ADLToileting)	='Usually Not' then 'UN'
	   when trim(ADLToileting)	='Never' then 'NE' end 	toilet_without_help_cd
, a.SubmittedAcuityScore	total_submitted_fa_acuity_score
, case when trim(ADLTransfer)	= 'Always' then 'AL'
	   when trim(ADLTransfer)	= 'Usually' then 'US'
       when trim(ADLTransfer)	= 'Usually Not' then 'UN'
       when trim(ADLTransfer)	= 'Never' then 'NE' end	trnsfr_without_help_cd
, case when trim(ADLWalking)= 'Always' then 'AL'
       when trim(ADLWalking)= 'Usually' then 'US'
       when trim(ADLWalking)= 'Usually Not' then 'UN'
       when trim(ADLWalking)= 'Never' then 'NE' end	walk_without_help_cd
, case when trim(ADLMobility)	= 'Always' then 'AL'
       when trim(ADLMobility)	= 'Usually' then 'US'
       when trim(ADLMobility)	= 'Usually Not' then 'UN'
       when trim(ADLMobility)	= 'Never' then 'NE' end	wheelchair_capable_cd
,'A' as CONVERSION_RUN_STATUS
--select count(1)
from  legacy.wrk_pasrr_clients w  
join legacy.pasrr_events b on b.reviewid::bigint  = w.maximus_reviewid::bigint
left join legacy.pasrr_loc a on  b.eventid::text = a.eventid::text
left join (select  *  from perlss.pae_rqst where  created_by='PASRR_CV') r    on r.legacy_id::text = w.maximus_reviewid::text
where  w.source_system_nm = 'MAXIMUS' 
and valid_sw= 'Y' and 	xref_valid_sw='Y'  and perlss_sw ='N'
)a
where  pae_id is not  null
select 
--nextval('perlss.hibernate_sequence') as ID,
 * from (
select distinct 
	case when a.ChronicVentilatorServices='True' and a.ventilatorclinicaldetermination = 'Approved'
      and ch.eff_date is not null then ch.eff_date else null end chrnc_req_start_dt
,case when a.ChronicVentilatorServices='True' and a.ventilatorclinicaldetermination = 'Approved'
    then ch.end_date  else null end	  chrnc_req_end_dt
,case when a.ChronicVentilatorServices='True' and a.ventilatorclinicaldetermination = 'Approved' 
           then 'Y' else 'N' end	chrnc_ventilator_sw
,NULL	last_modified_by
,NULL	last_modified_dt
,r.pae_id pae_id
,case when a.TrachealSuctioning='True' and a.trachealsuctioningclinicaldetermination = 'Approved'
    then tr.end_date  else null end	tracheal_req_end_dt
,case when a.TrachealSuctioning='True' and a.trachealsuctioningclinicaldetermination = 'Approved'
      and tr.eff_date is not null then tr.eff_date else null end tracheal_req_start_dt
,case when a.TrachealSuctioning='True' and a.trachealsuctioningclinicaldetermination = 'Approved' then 'Y' 
      else 'N' end	tracheal_suction_sw
,'A' as CONVERSION_RUN_STATUS
from legacy.wrk_pasrr_clients w 
join legacy.pasrr_events b on b.reviewid::bigint  = w.maximus_reviewid::bigint
left join legacy.pasrr_loc a on  b.eventid::text = a.eventid::text
left join (select  *  from perlss.pae_rqst where  created_by='PASRR_CV') r    on r.legacy_id::text = w.maximus_reviewid::text
left join
(select a.* , 
case when final_days is not null then eff_date +   final_days  
     when final_days is null and ventilatorrationale like '180%' then eff_date + 180
     when final_days is null  then '2299-12-31'::date
     end end_date
from (select a.*, case when vent_days is not null then vent_days 
                 when vent_days is null and vent_months_days is not null then vent_months_days else null end::int final_days
from (select eventid,	chronicventilatorservices,	ventilatorclinicaldetermination	,ventilatorrationale, eff_date,
vent_days ::bigint as vent_days, vent_months::bigint * 30  vent_months_days
from (select eventid,	chronicventilatorservices,	ventilatorclinicaldetermination	,ventilatorrationale,  eff_date,
case when days_pos = 0  then null
else  trim(replace(right(left(trim(ventilatorrationale), strpos(trim(ventilatorrationale), 'days') - 1),4),'(',''))  end vent_days,
case when months_pos = 0 then null
else trim(replace(right(left(trim(ventilatorrationale), strpos(trim(ventilatorrationale), 'months') - 1),2),'(',''))  end vent_months
from 
(select a.eventid ,chronicventilatorservices  , 
ventilatorclinicaldetermination ,ventilatorrationale,strpos(trim(ventilatorrationale), 'months') as months_pos,
strpos(trim(ventilatorrationale), 'days') as days_pos, 
case when c.level2determinationeffectivedate is not null then c.level2determinationeffectivedate::date
   else  c.level2determinationdate::date end eff_date
from  legacy.pasrr_events b
join legacy.pasrr_loc  a on  a.eventid =b.eventid
join legacy.pasrr_level_ii c on b.eventid = c.eventid
and b.payersource like '%Medicaid%'
where chronicventilatorservices = 'True'
and ventilatorclinicaldetermination = 'Approved'
and level2determinationdate is not null
) a ) a ) a ) a) ch on a.eventid =ch.eventid 
left join 
(select a.* , 
case when final_days is not null then eff_date +   final_days  
     when final_days is null and trachealsuctioningrationale like '180%' then eff_date + 180
     when final_days is null  then '2299-12-31'::date end end_date
from (select a.*, case when vent_days is not null then vent_days 
                 when vent_days is null and vent_months_days is not null then vent_months_days else null end::int final_days
from (select eventid,	trachealsuctioning,	trachealsuctioningclinicaldetermination	,trachealsuctioningrationale, eff_date,
vent_days ::bigint as vent_days, vent_months::bigint * 30  vent_months_days
from (select eventid,	trachealsuctioning,	trachealsuctioningclinicaldetermination	,trachealsuctioningrationale,  eff_date,
case when days_pos = 0  then null
else  trim(replace(right(left(trim(trachealsuctioningrationale), strpos(trim(trachealsuctioningrationale), 'days') - 1),4),'(',''))  end vent_days,
case when months_pos = 0 then null
else trim(replace(right(left(trim(trachealsuctioningrationale), strpos(trim(trachealsuctioningrationale), 'months') - 1),2),'(',''))  end vent_months
from 
(select a.eventid ,trachealsuctioning  , 
trachealsuctioningclinicaldetermination ,trachealsuctioningrationale,strpos(trim(trachealsuctioningrationale), 'months') as months_pos,
strpos(trim(trachealsuctioningrationale), 'days') as days_pos, 
case when c.level2determinationeffectivedate is not null then c.level2determinationeffectivedate::date
   else  c.level2determinationdate::date end eff_date
from  legacy.pasrr_events b
join legacy.pasrr_loc  a on  a.eventid =b.eventid
join legacy.pasrr_level_ii c on b.eventid = c.eventid
and b.payersource like '%Medicaid%'
where trachealsuctioning = 'True'
and trachealsuctioningclinicaldetermination = 'Approved'
and level2determinationdate is not null
) a ) a ) a ) a) tr on a.eventid =tr.eventid
where  w.source_system_nm = 'MAXIMUS' 
and valid_sw= 'Y' and 	xref_valid_sw='Y'  and perlss_sw ='N'
)a where pae_id is not null
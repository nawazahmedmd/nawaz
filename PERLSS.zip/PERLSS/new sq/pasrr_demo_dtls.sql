select 
nextval('perlss.hibernate_sequence') as ID,
 * from (
select distinct a.pasrr_id 
,b.ssn 
,b.last_name 
,b.first_name 
,b.gender_cd 
,b.dob_dt 
,b.middle_initial
,NULL	last_modified_by
,NULL	last_modified_dt
--,'A' as CONVERSION_RUN_STATUS
from perlss.pasrr_rqst  a
join perlss.com_applcnt b on a.prsn_id = b.prsn_id 
where a.created_by = 'PASRR_CV'
)a
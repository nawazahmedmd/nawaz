select distinct
r.pae_id pae_id
, 'TRAN' ADLTransfer
, 'MOBL' ADLWalking
, 'MOBW' ADLMobility
, 'EATG' ADLEating
, 'TLTG' ADLToileting
, 'TLTI' ADLIncontinentCare
, 'TLTC' ADLCatheterCare
, 'ORNT' ADLOrientation
, 'ECOM' ADLExpressive
, 'RCOM' ADLReceptive
, 'MEDC' ADLMedsAdmin
, 'BHVR' ADLBehavior
, 'WCS'	WoundCareDecubitus
, 'OWC'	WoundCareOther
, 'ISS'	InjectionsInsulin
, 'IOT'	InjectionsOther
, 'INT'	IntravenousFluids
, 'ISP'	IsolationPrecautions
, 'OCT'	OccupationalTherapy
, 'PHT'	PhysicalTherapy
, 'TCO'	CatheterOstomy
, 'TSI'	SelfInjection
, 'TPN'	ParenteralNutrition
, 'TFE'	TubeFeeding
, 'PED'	PeritonealDialysis
, 'PCA'	PCAPump
, 'TRS'	Tracheostomy
,trim(WoundCareDecubitusrationale) WoundCareDecubitusrationale
,trim(WoundCareOtherrationale) WoundCareOtherrationale
,trim(InjectionsInsulinrationale) InjectionsInsulinrationale
,trim(InjectionsOtherrationale) InjectionsOtherrationale
,trim(IntravenousFluidsrationale) IntravenousFluidsrationale
,trim(IsolationPrecautionsrationale) IsolationPrecautionsrationale
,trim(OccupationalTherapyrationale) OccupationalTherapyrationale
,trim(PhysicalTherapyrationale) PhysicalTherapyrationale
,trim(CatheterOstomyrationale) CatheterOstomyrationale
,trim(SelfInjectionrationale) SelfInjectionrationale
,trim(ParenteralNutritionrationale) ParenteralNutritionrationale
,trim(TubeFeedingrationale) TubeFeedingrationale
,trim(PeritonealDialysisrationale) PeritonealDialysisrationale
,trim(PCAPumprationale) PCAPumprationale
,trim(Tracheostomyrationale) Tracheostomyrationale
,trim(ADLTransferRationale) ADLTransferRationale
,trim(ADLWalkingRationale) ADLWalkingRationale
,trim(ADLMobilityRationale) ADLMobilityRationale
,trim(ADLEatingRationale) ADLEatingRationale
,trim(ADLToiletingRationale) ADLToiletingRationale
,trim(ADLIncontinentCareRationale) ADLIncontinentCareRationale
,trim(ADLCatheterCareRationale) ADLCatheterCareRationale
,trim(ADLOrientationRationale) ADLOrientationRationale
,trim(ADLExpressiveRationale) ADLExpressiveRationale
,trim(ADLReceptiveRationale) ADLReceptiveRationale
,trim(ADLMedsAdminRationale) ADLMedsAdminRationale
,trim(ADLBehaviorRationale) ADLBehaviorRationale
,ca.prsn_id
,r.entity_id
--select count(1)
from legacy.pasrr_events b    
join legacy.wrk_pasrr_clients w on b.reviewid::bigint  = w.maximus_reviewid::bigint 
left join legacy.pasrr_loc a on b.eventid  = a.eventid
left join (select  *  from perlss.pae_rqst where  created_by='PASRR_CV') r   on r.legacy_id::text = w.maximus_reviewid::text
left join (select distinct ssn, prsn_id from perlss.com_applcnt where active_sw='Y' and file_clearance_sw='Y') ca on ca.ssn::text = w.ssn::text 
where  w.source_system_nm = 'MAXIMUS' 
and valid_sw= 'Y' and 	xref_valid_sw='Y' and perlss_sw ='N'
and r.pae_id is not null;

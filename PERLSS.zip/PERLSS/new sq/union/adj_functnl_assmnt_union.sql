select 
nextval('perlss.hibernate_sequence') as ID,
 * from (
 select distinct 
 k.* 
,Null 	apl_acuity_score_num
,Null 	apl_approval_cd
,Null 	apl_comment
,NULL	apl_denial_cd
,Null 	audit_acuity_score_num
,Null 	audit_approval_cd
,Null 	audit_comment
,Null 	audit_denial_cd
,NULL	last_modified_by
,NULL	last_modified_dt
,NULL rn_acuity_score_num
,NULL	rn_comment
,NULL sbmttr_acuity_score_num
,NULL	sbmttr_cap_need_rsp_cd
,'A' as CONVERSION_RUN_STATUS
from
 (select a.*, 
 case when rn_action_cd= 'A' then sbmttr_rsp_cd else null end rn_approval_cd
 from (select r.adj_id adj_id,
 a.ADLTransferRationale	comments
 , 'TRAN' functnl_measure_cd
, case when a.ADLTransferClinicianDetermination= 'Denied'  then 'D'
	   when a.ADLTransferClinicianDetermination= 'Approved'  then 'A'
	   when a.ADLTransferClinicianDetermination= 'Partially Approved'  then 'P' end rn_action_cd
, case when a.ADLTransferDenialReason= 'Submitted documentation is conflicting'  then 'CON'
	   when a.ADLTransferDenialReason= 'Submitted documentation is contradictory'  then 'COT'
	   when a.ADLTransferDenialReason= 'Insufficient documentation to support this deficit'  then 'INS'
	    when a.ADLTransferDenialReason= 'NNo documentation to support this deficit' then 'NOD'
		when a.ADLTransferDenialReason= 'Other' then 'OTH' 		end	rn_denial_cd
, case when trim(ADLTransferClinicianResponse)	= 'Always' then 'AL'
	   when trim(ADLTransferClinicianResponse)	= 'Usually' then 'US'
       when trim(ADLTransferClinicianResponse)	= 'Usually Not' then 'UN'
       when trim(ADLTransferClinicianResponse)	= 'Never' then 'NE' end	sbmttr_rsp_cd
,  case when trim(ADLTransferClinicianResponse)	= 'Always' then 'AL'
	   when trim(ADLTransferClinicianResponse)	= 'Usually' then 'US'
       when trim(ADLTransferClinicianResponse)	= 'Usually Not' then 'UN'
       when trim(ADLTransferClinicianResponse)	= 'Never' then 'NE' end	sbmttr_acuity_cd
from  perlss.pae_rqst p
join perlss.adj_rqst r on p.pae_id=r.pae_id
join legacy.wrk_pasrr_clients w on p.legacy_id::text = w.maximus_reviewid::text 
join legacy.pasrr_events b on b.reviewid::bigint  = w.maximus_reviewid::bigint 
join legacy.pasrr_loc a on b.eventid  = a.eventid
where  w.source_system_nm = 'MAXIMUS' 
and valid_sw= 'Y' and 	xref_valid_sw='Y'
and r.created_by  = 'CV_'|| (select CNV_RUN_NUM from legacy.wrk_conversion_run where cnv_run_status = 'A')) a
union 
 select a.*,
 case when rn_action_cd= 'A' then sbmttr_rsp_cd else null end rn_approval_cd
 from (select r.adj_id adj_id,
 a.ADLWalkingRationale	comments
 , 'MOBT' functnl_measure_cd
, case when a.ADLWalkingClinicianDetermination= 'Denied'  then 'D'
	   when a.ADLWalkingClinicianDetermination= 'Approved'  then 'A'
	   when a.ADLWalkingClinicianDetermination= 'Partially Approved'  then 'P'
	     end rn_action_cd
, case when a.ADLWalkingDenialReason= 'Submitted documentation is conflicting'  then 'CON'
	   when a.ADLWalkingDenialReason= 'Submitted documentation is contradictory'  then 'COT'
	   when a.ADLWalkingDenialReason= 'Insufficient documentation to support this deficit'  then 'INS'
	    when a.ADLWalkingDenialReason= 'NNo documentation to support this deficit' then 'NOD'
		when a.ADLWalkingDenialReason= 'Other' then 'OTH' 		end	rn_denial_cd
, case when trim(ADLWalkingClinicianResponse)	= 'Always' then 'AL'
	   when trim(ADLWalkingClinicianResponse)	= 'Usually' then 'US'
       when trim(ADLWalkingClinicianResponse)	= 'Usually Not' then 'UN'
       when trim(ADLWalkingClinicianResponse)	= 'Never' then 'NE' end	sbmttr_rsp_cd
,  case when trim(ADLWalkingClinicianResponse)	= 'Always' then 'AL'
	   when trim(ADLWalkingClinicianResponse)	= 'Usually' then 'US'
       when trim(ADLWalkingClinicianResponse)	= 'Usually Not' then 'UN'
       when trim(ADLWalkingClinicianResponse)	= 'Never' then 'NE' end	sbmttr_acuity_cd
from  perlss.pae_rqst p
join perlss.adj_rqst r on p.pae_id=r.pae_id
join legacy.wrk_pasrr_clients w on p.legacy_id::text = w.maximus_reviewid::text 
join legacy.pasrr_events b on b.reviewid::bigint  = w.maximus_reviewid::bigint 
join legacy.pasrr_loc a on b.eventid  = a.eventid
where  w.source_system_nm = 'MAXIMUS' 
and valid_sw= 'Y' and 	xref_valid_sw='Y'
and r.created_by  = 'CV_'|| (select CNV_RUN_NUM from legacy.wrk_conversion_run where cnv_run_status = 'A')) a
union
select a.*,
 case when rn_action_cd= 'A' then sbmttr_rsp_cd else null end rn_approval_cd
 from (select r.adj_id adj_id,
 a.ADLMobilityRationale	comments
 , 'MOBW' functnl_measure_cd
, case when a.ADLMobilityClinicianDetermination= 'Denied'  then 'D'
	   when a.ADLMobilityClinicianDetermination= 'Approved'  then 'A'
	   when a.ADLMobilityClinicianDetermination= 'Partially Approved'  then 'P'
	     end rn_action_cd
, case when a.ADLMobilityDenialReason= 'Submitted documentation is conflicting'  then 'CON'
	   when a.ADLMobilityDenialReason= 'Submitted documentation is contradictory'  then 'COT'
	   when a.ADLMobilityDenialReason= 'Insufficient documentation to support this deficit'  then 'INS'
	    when a.ADLMobilityDenialReason= 'NNo documentation to support this deficit' then 'NOD'
		when a.ADLMobilityDenialReason= 'Other' then 'OTH' 		end	rn_denial_cd
, case when trim(ADLMobilityClinicianResponse)	= 'Always' then 'AL'
	   when trim(ADLMobilityClinicianResponse)	= 'Usually' then 'US'
       when trim(ADLMobilityClinicianResponse)	= 'Usually Not' then 'UN'
       when trim(ADLMobilityClinicianResponse)	= 'Never' then 'NE' end	sbmttr_rsp_cd
,  case when trim(ADLMobilityClinicianResponse)	= 'Always' then 'AL'
	   when trim(ADLMobilityClinicianResponse)	= 'Usually' then 'US'
       when trim(ADLMobilityClinicianResponse)	= 'Usually Not' then 'UN'
       when trim(ADLMobilityClinicianResponse)	= 'Never' then 'NE' end	sbmttr_acuity_cd
from  perlss.pae_rqst p
join perlss.adj_rqst r on p.pae_id=r.pae_id
join legacy.wrk_pasrr_clients w on p.legacy_id::text = w.maximus_reviewid::text 
join legacy.pasrr_events b on b.reviewid::bigint  = w.maximus_reviewid::bigint 
join legacy.pasrr_loc a on b.eventid  = a.eventid
where  w.source_system_nm = 'MAXIMUS' 
and valid_sw= 'Y' and 	xref_valid_sw='Y'
and r.created_by  = 'CV_'|| (select CNV_RUN_NUM from legacy.wrk_conversion_run where cnv_run_status = 'A')) a
union
select a.*,
 case when rn_action_cd= 'A' then sbmttr_rsp_cd else null end rn_approval_cd
 from (select r.adj_id adj_id,
 a.ADLEatingRationale	comments
 , 'EATG' functnl_measure_cd
, case when a.ADLEatingClinicianDetermination= 'Denied'  then 'D'
	   when a.ADLEatingClinicianDetermination= 'Approved'  then 'A'
	   when a.ADLEatingClinicianDetermination= 'Partially Approved'  then 'P'
	     end rn_action_cd
, case when a.ADLEatingDenialReason= 'Submitted documentation is conflicting'  then 'CON'
	   when a.ADLEatingDenialReason= 'Submitted documentation is contradictory'  then 'COT'
	   when a.ADLEatingDenialReason= 'Insufficient documentation to support this deficit'  then 'INS'
	    when a.ADLEatingDenialReason= 'NNo documentation to support this deficit' then 'NOD'
		when a.ADLEatingDenialReason= 'Other' then 'OTH' 		end	rn_denial_cd
, case when trim(ADLEatingClinicianResponse)	= 'Always' then 'AL'
	   when trim(ADLEatingClinicianResponse)	= 'Usually' then 'US'
       when trim(ADLEatingClinicianResponse)	= 'Usually Not' then 'UN'
       when trim(ADLEatingClinicianResponse)	= 'Never' then 'NE' end	sbmttr_rsp_cd
,  case when trim(ADLEatingClinicianResponse)	= 'Always' then 'AL'
	   when trim(ADLEatingClinicianResponse)	= 'Usually' then 'US'
       when trim(ADLEatingClinicianResponse)	= 'Usually Not' then 'UN'
       when trim(ADLEatingClinicianResponse)	= 'Never' then 'NE' end	sbmttr_acuity_cd
from  perlss.pae_rqst p
join perlss.adj_rqst r on p.pae_id=r.pae_id
join legacy.wrk_pasrr_clients w on p.legacy_id::text = w.maximus_reviewid::text 
join legacy.pasrr_events b on b.reviewid::bigint  = w.maximus_reviewid::bigint 
join legacy.pasrr_loc a on b.eventid  = a.eventid
where  w.source_system_nm = 'MAXIMUS' 
and valid_sw= 'Y' and 	xref_valid_sw='Y'
and r.created_by  = 'CV_'|| (select CNV_RUN_NUM from legacy.wrk_conversion_run where cnv_run_status = 'A')) a
union
select a.*,
 case when rn_action_cd= 'A' then sbmttr_rsp_cd else null end rn_approval_cd
 from (select r.adj_id adj_id,
 a.ADLToiletingRationale	comments
 , 'TLTG' functnl_measure_cd
, case when a.ADLToiletingClinicianDetermination= 'Denied'  then 'D'
	   when a.ADLToiletingClinicianDetermination= 'Approved'  then 'A'
	   when a.ADLToiletingClinicianDetermination= 'Partially Approved'  then 'P'
	     end rn_action_cd
, case when a.ADLToiletingDenialReason= 'Submitted documentation is conflicting'  then 'CON'
	   when a.ADLToiletingDenialReason= 'Submitted documentation is contradictory'  then 'COT'
	   when a.ADLToiletingDenialReason= 'Insufficient documentation to support this deficit'  then 'INS'
	    when a.ADLToiletingDenialReason= 'NNo documentation to support this deficit' then 'NOD'
		when a.ADLToiletingDenialReason= 'Other' then 'OTH' 		end	rn_denial_cd
, case when trim(ADLToiletingClinicianResponse)	= 'Always' then 'AL'
	   when trim(ADLToiletingClinicianResponse)	= 'Usually' then 'US'
       when trim(ADLToiletingClinicianResponse)	= 'Usually Not' then 'UN'
       when trim(ADLToiletingClinicianResponse)	= 'Never' then 'NE' end	sbmttr_rsp_cd
,  case when trim(ADLToiletingClinicianResponse)	= 'Always' then 'AL'
	   when trim(ADLToiletingClinicianResponse)	= 'Usually' then 'US'
       when trim(ADLToiletingClinicianResponse)	= 'Usually Not' then 'UN'
       when trim(ADLToiletingClinicianResponse)	= 'Never' then 'NE' end	sbmttr_acuity_cd
from  perlss.pae_rqst p
join perlss.adj_rqst r on p.pae_id=r.pae_id
join legacy.wrk_pasrr_clients w on p.legacy_id::text = w.maximus_reviewid::text 
join legacy.pasrr_events b on b.reviewid::bigint  = w.maximus_reviewid::bigint 
join legacy.pasrr_loc a on b.eventid  = a.eventid
where  w.source_system_nm = 'MAXIMUS' 
and valid_sw= 'Y' and 	xref_valid_sw='Y'
and r.created_by  = 'CV_'|| (select CNV_RUN_NUM from legacy.wrk_conversion_run where cnv_run_status = 'A')) a
union
select a.*,
 case when rn_action_cd= 'A' then sbmttr_rsp_cd else null end rn_approval_cd
 from (select r.adj_id adj_id,
 a.ADLIncontinentCareRationale	comments
 , 'TLTI' functnl_measure_cd
, case when a.ADLIncontinentCareClinicianDetermination= 'Denied'  then 'D'
	   when a.ADLIncontinentCareClinicianDetermination= 'Approved'  then 'A'
	   when a.ADLIncontinentCareClinicianDetermination= 'Partially Approved'  then 'P'
	     end rn_action_cd
, case when a.ADLIncontinentCareDenialReason= 'Submitted documentation is conflicting'  then 'CON'
	   when a.ADLIncontinentCareDenialReason= 'Submitted documentation is contradictory'  then 'COT'
	   when a.ADLIncontinentCareDenialReason= 'Insufficient documentation to support this deficit'  then 'INS'
	    when a.ADLIncontinentCareDenialReason= 'NNo documentation to support this deficit' then 'NOD'
		when a.ADLIncontinentCareDenialReason= 'Other' then 'OTH' 		end	rn_denial_cd
, case when trim(ADLIncontinentCareClinicianResponse)	= 'Always' then 'AL'
	   when trim(ADLIncontinentCareClinicianResponse)	= 'Usually' then 'US'
       when trim(ADLIncontinentCareClinicianResponse)	= 'Usually Not' then 'UN'
       when trim(ADLIncontinentCareClinicianResponse)	= 'Never' then 'NE' end	sbmttr_rsp_cd
,  case when trim(ADLIncontinentCareClinicianResponse)	= 'Always' then 'AL'
	   when trim(ADLIncontinentCareClinicianResponse)	= 'Usually' then 'US'
       when trim(ADLIncontinentCareClinicianResponse)	= 'Usually Not' then 'UN'
       when trim(ADLIncontinentCareClinicianResponse)	= 'Never' then 'NE' end	sbmttr_acuity_cd
from  perlss.pae_rqst p
join perlss.adj_rqst r on p.pae_id=r.pae_id
join legacy.wrk_pasrr_clients w on p.legacy_id::text = w.maximus_reviewid::text 
join legacy.pasrr_events b on b.reviewid::bigint  = w.maximus_reviewid::bigint 
join legacy.pasrr_loc a on b.eventid  = a.eventid
where  w.source_system_nm = 'MAXIMUS' 
and valid_sw= 'Y' and 	xref_valid_sw='Y'
and r.created_by  = 'CV_'|| (select CNV_RUN_NUM from legacy.wrk_conversion_run where cnv_run_status = 'A')) a
union
select a.*,
 case when rn_action_cd= 'A' then sbmttr_rsp_cd else null end rn_approval_cd
 from (select r.adj_id adj_id,
 a.ADLCatheterCareRationale	comments
 , 'TLTC' functnl_measure_cd
, case when a.ADLCatheterCareClinicianDetermination= 'Denied'  then 'D'
	   when a.ADLCatheterCareClinicianDetermination= 'Approved'  then 'A'
	   when a.ADLCatheterCareClinicianDetermination= 'Partially Approved'  then 'P'
	     end rn_action_cd
, case when a.ADLCatheterCareDenialReason= 'Submitted documentation is conflicting'  then 'CON'
	   when a.ADLCatheterCareDenialReason= 'Submitted documentation is contradictory'  then 'COT'
	   when a.ADLCatheterCareDenialReason= 'Insufficient documentation to support this deficit'  then 'INS'
	    when a.ADLCatheterCareDenialReason= 'NNo documentation to support this deficit' then 'NOD'
		when a.ADLCatheterCareDenialReason= 'Other' then 'OTH' 		end	rn_denial_cd
, case when trim(ADLCatheterCareClinicianResponse)	= 'Always' then 'AL'
	   when trim(ADLCatheterCareClinicianResponse)	= 'Usually' then 'US'
       when trim(ADLCatheterCareClinicianResponse)	= 'Usually Not' then 'UN'
       when trim(ADLCatheterCareClinicianResponse)	= 'Never' then 'NE' end	sbmttr_rsp_cd
,  case when trim(ADLCatheterCareClinicianResponse)	= 'Always' then 'AL'
	   when trim(ADLCatheterCareClinicianResponse)	= 'Usually' then 'US'
       when trim(ADLCatheterCareClinicianResponse)	= 'Usually Not' then 'UN'
       when trim(ADLCatheterCareClinicianResponse)	= 'Never' then 'NE' end	sbmttr_acuity_cd
from  perlss.pae_rqst p
join perlss.adj_rqst r on p.pae_id=r.pae_id
join legacy.wrk_pasrr_clients w on p.legacy_id::text = w.maximus_reviewid::text 
join legacy.pasrr_events b on b.reviewid::bigint  = w.maximus_reviewid::bigint 
join legacy.pasrr_loc a on b.eventid  = a.eventid
where  w.source_system_nm = 'MAXIMUS' 
and valid_sw= 'Y' and 	xref_valid_sw='Y'
and r.created_by  = 'CV_'|| (select CNV_RUN_NUM from legacy.wrk_conversion_run where cnv_run_status = 'A')) a
union
select a.*,
 case when rn_action_cd= 'A' then sbmttr_rsp_cd else null end rn_approval_cd
 from (select r.adj_id adj_id,
 a.ADLOrientationRationale	comments
 , 'ORNT' functnl_measure_cd
, case when a.ADLOrientationClinicianDetermination= 'Denied'  then 'D'
	   when a.ADLOrientationClinicianDetermination= 'Approved'  then 'A'
	   when a.ADLOrientationClinicianDetermination= 'Partially Approved'  then 'P'
	     end rn_action_cd
, case when a.ADLOrientationDenialReason= 'Submitted documentation is conflicting'  then 'CON'
	   when a.ADLOrientationDenialReason= 'Submitted documentation is contradictory'  then 'COT'
	   when a.ADLOrientationDenialReason= 'Insufficient documentation to support this deficit'  then 'INS'
	    when a.ADLOrientationDenialReason= 'NNo documentation to support this deficit' then 'NOD'
		when a.ADLOrientationDenialReason= 'Other' then 'OTH' 		end	rn_denial_cd
, case when trim(ADLOrientationClinicianResponse)	= 'Always' then 'AL'
	   when trim(ADLOrientationClinicianResponse)	= 'Usually' then 'US'
       when trim(ADLOrientationClinicianResponse)	= 'Usually Not' then 'UN'
       when trim(ADLOrientationClinicianResponse)	= 'Never' then 'NE' end	sbmttr_rsp_cd
,  case when trim(ADLOrientationClinicianResponse)	= 'Always' then 'AL'
	   when trim(ADLOrientationClinicianResponse)	= 'Usually' then 'US'
       when trim(ADLOrientationClinicianResponse)	= 'Usually Not' then 'UN'
       when trim(ADLOrientationClinicianResponse)	= 'Never' then 'NE' end	sbmttr_acuity_cd
from  perlss.pae_rqst p
join perlss.adj_rqst r on p.pae_id=r.pae_id
join legacy.wrk_pasrr_clients w on p.legacy_id::text = w.maximus_reviewid::text 
join legacy.pasrr_events b on b.reviewid::bigint  = w.maximus_reviewid::bigint 
join legacy.pasrr_loc a on b.eventid  = a.eventid
where  w.source_system_nm = 'MAXIMUS' 
and valid_sw= 'Y' and 	xref_valid_sw='Y'
and r.created_by  = 'CV_'|| (select CNV_RUN_NUM from legacy.wrk_conversion_run where cnv_run_status = 'A')) a
union
select a.*,
 case when rn_action_cd= 'A' then sbmttr_rsp_cd else null end rn_approval_cd
 from (select r.adj_id adj_id,
 a.ADLExpressiveRationale	comments
 , 'ECOM' functnl_measure_cd
, case when a.ADLExpressiveClinicianDetermination= 'Denied'  then 'D'
	   when a.ADLExpressiveClinicianDetermination= 'Approved'  then 'A'
	   when a.ADLExpressiveClinicianDetermination= 'Partially Approved'  then 'P'
	     end rn_action_cd
, case when a.ADLExpressiveDenialReason= 'Submitted documentation is conflicting'  then 'CON'
	   when a.ADLExpressiveDenialReason= 'Submitted documentation is contradictory'  then 'COT'
	   when a.ADLExpressiveDenialReason= 'Insufficient documentation to support this deficit'  then 'INS'
	    when a.ADLExpressiveDenialReason= 'NNo documentation to support this deficit' then 'NOD'
		when a.ADLExpressiveDenialReason= 'Other' then 'OTH' 		end	rn_denial_cd
, case when trim(ADLExpressiveClinicianResponse)	= 'Always' then 'AL'
	   when trim(ADLExpressiveClinicianResponse)	= 'Usually' then 'US'
       when trim(ADLExpressiveClinicianResponse)	= 'Usually Not' then 'UN'
       when trim(ADLExpressiveClinicianResponse)	= 'Never' then 'NE' end	sbmttr_rsp_cd
,  case when trim(ADLExpressiveClinicianResponse)	= 'Always' then 'AL'
	   when trim(ADLExpressiveClinicianResponse)	= 'Usually' then 'US'
       when trim(ADLExpressiveClinicianResponse)	= 'Usually Not' then 'UN'
       when trim(ADLExpressiveClinicianResponse)	= 'Never' then 'NE' end	sbmttr_acuity_cd
from  perlss.pae_rqst p
join perlss.adj_rqst r on p.pae_id=r.pae_id
join legacy.wrk_pasrr_clients w on p.legacy_id::text = w.maximus_reviewid::text 
join legacy.pasrr_events b on b.reviewid::bigint  = w.maximus_reviewid::bigint 
join legacy.pasrr_loc a on b.eventid  = a.eventid
where  w.source_system_nm = 'MAXIMUS' 
and valid_sw= 'Y' and 	xref_valid_sw='Y'
and r.created_by  = 'CV_'|| (select CNV_RUN_NUM from legacy.wrk_conversion_run where cnv_run_status = 'A')) a
union
select a.*,
 case when rn_action_cd= 'A' then sbmttr_rsp_cd else null end rn_approval_cd
 from (select r.adj_id adj_id,
 a.ADLReceptiveRationale	comments
 , 'RCOM' functnl_measure_cd
, case when a.ADLReceptiveClinicianDetermination= 'Denied'  then 'D'
	   when a.ADLReceptiveClinicianDetermination= 'Approved'  then 'A'
	   when a.ADLReceptiveClinicianDetermination= 'Partially Approved'  then 'P'
	    end rn_action_cd
, case when a.ADLReceptiveDenialReason= 'Submitted documentation is conflicting'  then 'CON'
	   when a.ADLReceptiveDenialReason= 'Submitted documentation is contradictory'  then 'COT'
	   when a.ADLReceptiveDenialReason= 'Insufficient documentation to support this deficit'  then 'INS'
	    when a.ADLReceptiveDenialReason= 'NNo documentation to support this deficit' then 'NOD'
		when a.ADLReceptiveDenialReason= 'Other' then 'OTH' 		end	rn_denial_cd
, case when trim(ADLReceptiveClinicianResponse)	= 'Always' then 'AL'
	   when trim(ADLReceptiveClinicianResponse)	= 'Usually' then 'US'
       when trim(ADLReceptiveClinicianResponse)	= 'Usually Not' then 'UN'
       when trim(ADLReceptiveClinicianResponse)	= 'Never' then 'NE' end	sbmttr_rsp_cd
,  case when trim(ADLReceptiveClinicianResponse)	= 'Always' then 'AL'
	   when trim(ADLReceptiveClinicianResponse)	= 'Usually' then 'US'
       when trim(ADLReceptiveClinicianResponse)	= 'Usually Not' then 'UN'
       when trim(ADLReceptiveClinicianResponse)	= 'Never' then 'NE' end	sbmttr_acuity_cd
from  perlss.pae_rqst p
join perlss.adj_rqst r on p.pae_id=r.pae_id
join legacy.wrk_pasrr_clients w on p.legacy_id::text = w.maximus_reviewid::text 
join legacy.pasrr_events b on b.reviewid::bigint  = w.maximus_reviewid::bigint 
join legacy.pasrr_loc a on b.eventid  = a.eventid
where  w.source_system_nm = 'MAXIMUS' 
and valid_sw= 'Y' and 	xref_valid_sw='Y'
and r.created_by  = 'CV_'|| (select CNV_RUN_NUM from legacy.wrk_conversion_run where cnv_run_status = 'A')) a
union
select a.*,
 case when rn_action_cd= 'A' then sbmttr_rsp_cd else null end rn_approval_cd
 from (select r.adj_id adj_id,
 a.ADLMedsAdminRationale	comments
 , 'MEDC' functnl_measure_cd
, case when a.ADLMedsAdminClinicianDetermination= 'Denied'  then 'D'
	   when a.ADLMedsAdminClinicianDetermination= 'Approved'  then 'A'
	   when a.ADLMedsAdminClinicianDetermination= 'Partially Approved'  then 'P'
	     end rn_action_cd
, case when a.ADLMedsAdminDenialReason= 'Submitted documentation is conflicting'  then 'CON'
	   when a.ADLMedsAdminDenialReason= 'Submitted documentation is contradictory'  then 'COT'
	   when a.ADLMedsAdminDenialReason= 'Insufficient documentation to support this deficit'  then 'INS'
	    when a.ADLMedsAdminDenialReason= 'NNo documentation to support this deficit' then 'NOD'
		when a.ADLMedsAdminDenialReason= 'Other' then 'OTH' 		end	rn_denial_cd
, case when trim(ADLMedsAdminClinicianResponse)	= 'Always' then 'AL'
	   when trim(ADLMedsAdminClinicianResponse)	= 'Usually' then 'US'
       when trim(ADLMedsAdminClinicianResponse)	= 'Usually Not' then 'UN'
       when trim(ADLMedsAdminClinicianResponse)	= 'Never' then 'NE' end	sbmttr_rsp_cd
,  case when trim(ADLMedsAdminClinicianResponse)	= 'Always' then 'AL'
	   when trim(ADLMedsAdminClinicianResponse)	= 'Usually' then 'US'
       when trim(ADLMedsAdminClinicianResponse)	= 'Usually Not' then 'UN'
       when trim(ADLMedsAdminClinicianResponse)	= 'Never' then 'NE' end	sbmttr_acuity_cd
from  perlss.pae_rqst p
join perlss.adj_rqst r on p.pae_id=r.pae_id
join legacy.wrk_pasrr_clients w on p.legacy_id::text = w.maximus_reviewid::text 
join legacy.pasrr_events b on b.reviewid::bigint  = w.maximus_reviewid::bigint 
join legacy.pasrr_loc a on b.eventid  = a.eventid
where  w.source_system_nm = 'MAXIMUS' 
and valid_sw= 'Y' and 	xref_valid_sw='Y'
and r.created_by  = 'CV_'|| (select CNV_RUN_NUM from legacy.wrk_conversion_run where cnv_run_status = 'A')) a
union
select a.*,
 case when rn_action_cd= 'A' then sbmttr_rsp_cd else null end rn_approval_cd
 from (select r.adj_id adj_id,
 a.ADLBehaviorRationale	comments
 , 'BHVR' functnl_measure_cd
, case when a.ADLBehaviorClinicianDetermination= 'Denied'  then 'D'
	   when a.ADLBehaviorClinicianDetermination= 'Approved'  then 'A'
	   when a.ADLBehaviorClinicianDetermination= 'Partially Approved'  then 'P'
	     end rn_action_cd
, case when a.ADLBehaviorDenialReason= 'Submitted documentation is conflicting'  then 'CON'
	   when a.ADLBehaviorDenialReason= 'Submitted documentation is contradictory'  then 'COT'
	   when a.ADLBehaviorDenialReason= 'Insufficient documentation to support this deficit'  then 'INS'
	    when a.ADLBehaviorDenialReason= 'NNo documentation to support this deficit' then 'NOD'
		when a.ADLBehaviorDenialReason= 'Other' then 'OTH' 		end	rn_denial_cd
, case when trim(ADLBehaviorClinicianResponse)	= 'Always' then 'AL'
	   when trim(ADLBehaviorClinicianResponse)	= 'Usually' then 'US'
       when trim(ADLBehaviorClinicianResponse)	= 'Usually Not' then 'UN'
       when trim(ADLBehaviorClinicianResponse)	= 'Never' then 'NE' end	sbmttr_rsp_cd
,  case when trim(ADLBehaviorClinicianResponse)	= 'Always' then 'AL'
	   when trim(ADLBehaviorClinicianResponse)	= 'Usually' then 'US'
       when trim(ADLBehaviorClinicianResponse)	= 'Usually Not' then 'UN'
       when trim(ADLBehaviorClinicianResponse)	= 'Never' then 'NE' end	sbmttr_acuity_cd
from  perlss.pae_rqst p
join perlss.adj_rqst r on p.pae_id=r.pae_id
join legacy.wrk_pasrr_clients w on p.legacy_id::text = w.maximus_reviewid::text 
join legacy.pasrr_events b on b.reviewid::bigint  = w.maximus_reviewid::bigint 
join legacy.pasrr_loc a on b.eventid  = a.eventid
where  w.source_system_nm = 'MAXIMUS' 
and valid_sw= 'Y' and 	xref_valid_sw='Y'
and r.created_by  = 'CV_'|| (select CNV_RUN_NUM from legacy.wrk_conversion_run where cnv_run_status = 'A')) a) k 
)a

select 
nextval('perlss.hibernate_sequence') as ID,
 * from (
select distinct 
l1.Level1LetterTypeSent	 	lvl1_Letter_Type_Sent
,case when b.payersource = 'Medicaid Pending' then 'AP'
	  when b.payersource = 'Medicaid' then 'MD'
	  when b.payersource = 'PACE-Medicaid' then 'MD'
	  when b.payersource = 'PACE-Medicaid Pending' then 'AP' end	payor_src_cd
,b.HospitalAdmitDate		hos_admit_dt
,b.NFAdmitDate		nf_admit_dt
,b.ReviewType		review_type
,b.PrimaryLanguage		prim_lang
,l1.Level1LetterSentDate	 	lvl1_letter_sent_dt
,w.maximus_ascendid		ascendid
,l2.Level2NoticeType	 	lvl2_notice_type
,l2.Level2NoticeSentDate	 	lvl2_notice_sent_dt
,l2.Level2SentToStateDate	 	lvl2_Sent_To_State_dt
,l2.Level2AssessmentDate	 	lvl2_Assessment_dt
,l2.Level2SpecializedServicesDetermination	 	lvl2_specialized_services_dtr
,l2.leve2approvedstreason	 	lvl2_approved_str
,l2.Level2ShortTermDays	 	lvl2_Short_Term_Days
,l2.Level2PASRRCondition	 	lvl2_pasrr_condition
,l2.Level2DueToStateDate	 	lvl2_due_dt
,r.lvl2_outcome_cd 
,NULL	last_modified_by
,NULL	last_modified_dt
,r.pasrr_id pasrr_id
,case when l2.Level2ShortTermDays is not null then 'STS' else null end passr_action_cd
,case when l2.Level2ShortTermDays is not null then L2.level2determinationdate::DATE else null end short_stay_dt
,w.assessmentid	
,w.reconof as reconof_assessmentid
from legacy.pasrr_events b 
join legacy.pasrr_base_member_pop w on b.reviewid::bigint  = w.maximus_reviewid::bigint
left join legacy.pasrr_loc a on  b.eventid::text = a.eventid::text
left join legacy.pasrr_level_i l1 on  b.eventid =l1.eventid 
left join legacy.pasrr_level_ii l2 on  b.eventid =l2.eventid
left join perlss.pasrr_rqst r  on r.episode_id ::text = b.reviewid::text and r.created_by  = 'PASRR_CV'
where r.pasrr_id is not null
)a
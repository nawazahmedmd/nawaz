--PASRR-Transitions_62--ECF5 At-Risk Enrollment – NOT Converted--Converted Level I Neg PASRR
--com_applcnt
INSERT INTO perlss.com_applcnt
(id, prsn_id, first_name, middle_initial, last_name, suffix, dob_dt, ssn, alias_name_sw, alias_first_name, alias_middle_initial, alias_last_name, alias_suffix, gender_cd, active_sw, file_clearance_sw, ssn_aval_sw, dsgn_sw, inter_sw, interprt_lang, created_by, created_dt, last_modified_by, last_modified_dt, record_version, archived_dt, dod_dt, email_addr, cell_ph_num, home_ph_num, work_ph_num, pref_ph_type_cd, pref_lang_letters_cd, new_person_sw, american_sign_lang_cd, pref_lang_spkn_cd)
VALUES(nextval('perlss.hibernate_sequence'), nextval('perlss.com_applcnt_0sq'), 'MR', 'L', 'BEAN', NULL, '1965-04-07', '394819381', 'N', NULL, NULL, NULL, NULL, 'F', 'Y', 'Y', 'N', 'N', 'N', 'EN', 'PASRR_CV', '2025-01-28 10:33:42.633', NULL, NULL, 0, NULL, NULL, NULL, '6155820251', NULL, NULL, NULL, 'ENG', 'N', NULL, NULL);
INSERT INTO perlss.com_applcnt
(id, prsn_id, first_name, middle_initial, last_name, suffix, dob_dt, ssn, alias_name_sw, alias_first_name, alias_middle_initial, alias_last_name, alias_suffix, gender_cd, active_sw, file_clearance_sw, ssn_aval_sw, dsgn_sw, inter_sw, interprt_lang, created_by, created_dt, last_modified_by, last_modified_dt, record_version, archived_dt, dod_dt, email_addr, cell_ph_num, home_ph_num, work_ph_num, pref_ph_type_cd, pref_lang_letters_cd, new_person_sw, american_sign_lang_cd, pref_lang_spkn_cd)
VALUES(nextval('perlss.hibernate_sequence'), nextval('perlss.com_applcnt_0sq'), 'TEST', 'A', 'PETER', NULL, '1966-11-29', '396816381', 'N', NULL, NULL, NULL, NULL, 'F', 'Y', 'Y', 'N', 'N', 'N', NULL, 'PASRR_CV', '2025-01-28 10:33:42.633', NULL, NULL, 0, NULL, NULL, NULL, '4233010115', NULL, NULL, NULL, 'ENG', 'N', NULL, NULL);

--pae_rqst
INSERT INTO perlss.pae_rqst
(id, pae_id, pdf_generated_sw, new_prsn_sw, program_cd, pae_rqst_dt, entity_type, grand_region_cd, user_id, recrtfctn_due_dt, ssi_applcatn_status_cd, submitted_enr_grp_cd, rqstd_enr_grp_cd, assigned_grp_submit_sw, grp3_intrst_sw, actual_discharge_dt, mopd_dt, begin_dt, closure_rsn_cd, closure_rsn_desc, closure_attestation_sw, due_dt, mode_cd, status_cd, archived_dt, created_by, created_dt, last_modified_by, last_modified_dt, record_version, pae_type_cd, ref_id, tmed_id, tns_id, prsn_id, legacy_id, entity_id, enroll_in_mfp_sw, chm_id, abandon_parta_sw, reassessment_due_dt)
VALUES(nextval('perlss.hibernate_sequence'), concat('PAE',nextval('perlss.pae_rqst_0sq')), 'Y', 'N', 'CG1', '2023-11-27 11:40:00.000', 'Nursing Facilities', NULL, NULL, NULL, NULL, NULL, NULL, 'N', 'Y', NULL, '2023-10-26 00:00:00.000', '2023-12-01', NULL, NULL, NULL, NULL, NULL, 'AA', NULL, 'PASRR_CV', '2025-01-13 00:00:00.000', 'CNV_PAEPDF_ADHOC', '2025-01-29 14:37:34.188', 1, 'TMD', NULL, NULL, NULL, 4450000013, '712634', 986, NULL, NULL, NULL, NULL);
INSERT INTO perlss.pae_rqst
(id, pae_id, pdf_generated_sw, new_prsn_sw, program_cd, pae_rqst_dt, entity_type, grand_region_cd, user_id, recrtfctn_due_dt, ssi_applcatn_status_cd, submitted_enr_grp_cd, rqstd_enr_grp_cd, assigned_grp_submit_sw, grp3_intrst_sw, actual_discharge_dt, mopd_dt, begin_dt, closure_rsn_cd, closure_rsn_desc, closure_attestation_sw, due_dt, mode_cd, status_cd, archived_dt, created_by, created_dt, last_modified_by, last_modified_dt, record_version, pae_type_cd, ref_id, tmed_id, tns_id, prsn_id, legacy_id, entity_id, enroll_in_mfp_sw, chm_id, abandon_parta_sw, reassessment_due_dt)
VALUES(nextval('perlss.hibernate_sequence'),concat('PAE',nextval('perlss.pae_rqst_0sq')), 'Y', 'N', 'CG1', '2022-09-07 12:21:00.000', 'Nursing Facilities', NULL, NULL, NULL, NULL, NULL, NULL, 'N', 'Y', NULL, '2022-09-01 00:00:00.000', '2022-09-13', NULL, NULL, NULL, NULL, NULL, 'AA', NULL, 'PASRR_CV', '2025-01-13 00:00:00.000', 'CNV_PAEPDF_ADHOC', '2025-01-29 14:35:33.295', 1, 'TMD', NULL, NULL, NULL, 4450000016, '578742', 1008, NULL, NULL, NULL, NULL);


--pae_app_addr_dtl
INSERT INTO perlss.pae_app_addr_dtl
(id, pae_id, addr_format_cd, user_type_cd, addr_line_1, addr_line_2, city, state_cd, zip, zip_extsn, cnty_cd, military_po_cd, military_state_cd, addr_type_cd, validated_addr_cd, mail_addr_sw, created_dt, last_modified_by, last_modified_dt, record_version, archived_dt, created_by, delete_sw)
VALUES(nextval('perlss.hibernate_sequence'), 'PAE200113114', 'USAD', 'APPL', '1033 Demonbreun St', 'APT 917', 'NASHVILLE', 'TN', '372023', NULL, '019', NULL, NULL, 'MA', NULL, 'Y', '2025-01-13 00:00:00.000', NULL, NULL, 0, NULL, 'PASRR_CV', NULL);
INSERT INTO perlss.pae_app_addr_dtl
(id, pae_id, addr_format_cd, user_type_cd, addr_line_1, addr_line_2, city, state_cd, zip, zip_extsn, cnty_cd, military_po_cd, military_state_cd, addr_type_cd, validated_addr_cd, mail_addr_sw, created_dt, last_modified_by, last_modified_dt, record_version, archived_dt, created_by, delete_sw)
VALUES(nextval('perlss.hibernate_sequence'), 'PAE200113114', 'USAD', 'APPL', '1033 Demonbreun St', 'APT 917', 'NASHVILLE', 'TN', '372023', NULL, '019', NULL, NULL, 'PA', NULL, 'Y', '2025-01-13 00:00:00.000', NULL, NULL, 0, NULL, 'PASRR_CV', NULL);
INSERT INTO perlss.pae_app_addr_dtl
(id, pae_id, addr_format_cd, user_type_cd, addr_line_1, addr_line_2, city, state_cd, zip, zip_extsn, cnty_cd, military_po_cd, military_state_cd, addr_type_cd, validated_addr_cd, mail_addr_sw, created_dt, last_modified_by, last_modified_dt, record_version, archived_dt, created_by, delete_sw)
VALUES(nextval('perlss.hibernate_sequence'), 'PAE200112853', 'USAD', 'APPL', '1033 Demonbreun St', '720', 'NASHVILLE', 'TN', '372023', NULL, '033', NULL, NULL, 'MA', NULL, 'Y', '2025-01-13 00:00:00.000', NULL, NULL, 0, NULL, 'PASRR_CV', NULL);
INSERT INTO perlss.pae_app_addr_dtl
(id, pae_id, addr_format_cd, user_type_cd, addr_line_1, addr_line_2, city, state_cd, zip, zip_extsn, cnty_cd, military_po_cd, military_state_cd, addr_type_cd, validated_addr_cd, mail_addr_sw, created_dt, last_modified_by, last_modified_dt, record_version, archived_dt, created_by, delete_sw)
VALUES(nextval('perlss.hibernate_sequence'), 'PAE200112853', 'USAD', 'APPL', '1033 Demonbreun St', '720', 'NASHVILLE', 'TN', '372023', NULL, '033', NULL, NULL, 'PA', NULL, 'Y', '2025-01-13 00:00:00.000', NULL, NULL, 0, NULL, 'PASRR_CV', NULL);

--pae_lvng_arrgmnt
INSERT INTO perlss.pae_lvng_arrgmnt
(id, pae_id, curr_lvng_arrgmnt_cd, lvng_arrgmnt_desc, nursing_facility_name_cd, addr_line_1, addr_line_2, city, state_cd, zip, extsn, cnty_cd, ph_num, long_term_care_sw, phychiatric_hosp_sw, mental_hlth_sw, special_sch_sw, intlctl_disable_sw, phycl_disable_sw, none_sw, sch_outside_sw, admsn_dt, expctd_discharge_cd, anticipated_discharge_dt, incarceration_dt, anticipated_release_dt, created_dt, last_modified_by, last_modified_dt, record_version, archived_dt, created_by, othr_facility_name, org_id, org_loc_id, provider_id)
VALUES(nextval('perlss.hibernate_sequence'), 'PAE200113114', 'NFC', NULL, '214', '1033 Demonbreun St', NULL, 'NASHVILLE', 'TN', '37215', NULL, '019', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '2023-10-26', 'NES', NULL, NULL, NULL, '2025-01-13 00:00:00.000', NULL, NULL, 0, NULL, 'PASRR_CV', NULL, 214, 214, 'Q053983');
INSERT INTO perlss.pae_lvng_arrgmnt
(id, pae_id, curr_lvng_arrgmnt_cd, lvng_arrgmnt_desc, nursing_facility_name_cd, addr_line_1, addr_line_2, city, state_cd, zip, extsn, cnty_cd, ph_num, long_term_care_sw, phychiatric_hosp_sw, mental_hlth_sw, special_sch_sw, intlctl_disable_sw, phycl_disable_sw, none_sw, sch_outside_sw, admsn_dt, expctd_discharge_cd, anticipated_discharge_dt, incarceration_dt, anticipated_release_dt, created_dt, last_modified_by, last_modified_dt, record_version, archived_dt, created_by, othr_facility_name, org_id, org_loc_id, provider_id)
VALUES(nextval('perlss.hibernate_sequence'), 'PAE200112853', 'NFC', NULL, '76', '1033 Demonbreun St', NULL, 'NASHVILLE', 'TN', '37421', NULL, '033', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '2022-09-01', 'NES', '2022-12-05', NULL, NULL, '2025-01-13 00:00:00.000', NULL, NULL, 0, NULL, 'PASRR_CV', NULL, 76, 76, '7440081');

--pae_submission
INSERT INTO perlss.pae_submission
(id, pae_id, who_submitting_cd, signature, "comments", pae_recrtfctn_sw, pae_recrtfctn_ack_sw, created_dt, last_modified_by, last_modified_dt, record_version, archived_dt, created_by, cea_determn_cd, certificate_dt, submit_dt, revised_pae_sw, cea_sw)
VALUES(nextval('perlss.hibernate_sequence'), 'PAE200113114', 'OTH', 'CV_402', NULL, NULL, 'N', '2025-01-13 00:00:00.000', NULL, NULL, 0, NULL, 'PASRR_CV', NULL, NULL, '2023-11-27 11:40:00.000', 'N', 'N');
INSERT INTO perlss.pae_submission
(id, pae_id, who_submitting_cd, signature, "comments", pae_recrtfctn_sw, pae_recrtfctn_ack_sw, created_dt, last_modified_by, last_modified_dt, record_version, archived_dt, created_by, cea_determn_cd, certificate_dt, submit_dt, revised_pae_sw, cea_sw)
VALUES(nextval('perlss.hibernate_sequence'), 'PAE200112853', 'OTH', 'CV_402', NULL, NULL, 'N', '2025-01-13 00:00:00.000', NULL, NULL, 0, NULL, 'PASRR_CV', NULL, NULL, '2022-09-07 12:21:00.000', 'N', 'N');

--pae_activities_lvng
INSERT INTO perlss.pae_activities_lvng
(id, pae_id, trnsfr_without_help_cd, walk_without_help_cd, eat_without_help_cd, wheelchair_capable_cd, toilet_without_help_cd, applcnt_incont_sw, incont_type_cd, incont_without_help_cd, catheter_ostomy_sw, cath_ost_whithout_help_cd, orientation_prsn_place_cd, communicate_wants_cd, follow_instructions_cd, self_admt_medication_cd, beh_problem_cd, created_dt, last_modified_by, last_modified_dt, record_version, archived_dt, created_by, total_submitted_fa_acuity_score)
VALUES(nextval('perlss.hibernate_sequence'), 'PAE200113114', 'NE', 'NE', 'US', 'NE', 'NE', 'Y', 'BL', 'NE', 'N', NULL, 'AL', 'AL', 'AL', 'AL', 'UN', '2025-01-13 00:00:00.000', 'CV-ACTY-SCORE', '2025-01-29 09:52:30.474', 1, NULL, 'PASRR_CV', 9);
INSERT INTO perlss.pae_activities_lvng
(id, pae_id, trnsfr_without_help_cd, walk_without_help_cd, eat_without_help_cd, wheelchair_capable_cd, toilet_without_help_cd, applcnt_incont_sw, incont_type_cd, incont_without_help_cd, catheter_ostomy_sw, cath_ost_whithout_help_cd, orientation_prsn_place_cd, communicate_wants_cd, follow_instructions_cd, self_admt_medication_cd, beh_problem_cd, created_dt, last_modified_by, last_modified_dt, record_version, archived_dt, created_by, total_submitted_fa_acuity_score)
VALUES(nextval('perlss.hibernate_sequence'), 'PAE200112853', 'NE', 'NE', 'AL', 'NE', 'NE', 'Y', NULL, NULL, 'N', NULL, 'AL', 'AL', 'AL', 'AL', 'NE', '2025-01-13 00:00:00.000', 'CV-ACTY-SCORE', '2025-01-29 09:52:27.693', 1, NULL, 'PASRR_CV', 6);

--pae_program_selection
INSERT INTO perlss.pae_program_selection
(id, pae_id, program_type_cd, program_rqst_dt, choices_grp_3_sw, actual_discharge_dt, created_dt, last_modified_by, last_modified_dt, record_version, archived_dt, created_by)
VALUES(nextval('perlss.hibernate_sequence'), 'PAE200113114', 'CG1', '2023-11-27', 'N', NULL, '2025-01-13 00:00:00.000', NULL, NULL, 0, NULL, 'PASRR_CV');
INSERT INTO perlss.pae_program_selection
(id, pae_id, program_type_cd, program_rqst_dt, choices_grp_3_sw, actual_discharge_dt, created_dt, last_modified_by, last_modified_dt, record_version, archived_dt, created_by)
VALUES(nextval('perlss.hibernate_sequence'), 'PAE200112853', 'CG1', '2022-09-07', 'N', NULL, '2025-01-13 00:00:00.000', NULL, NULL, 0, NULL, 'PASRR_CV');


--pae_driver_flow
INSERT INTO perlss.pae_driver_flow
(id, program_cd, next_page, curr_page, pae_id, created_by, created_dt, last_modified_dt, record_version)
VALUES(nextval('perlss.hibernate_sequence'), 'CG1', 'PPSPS', 'PPSRR', 'PAE200113114', 'PASRR_CV', '2025-01-13 00:00:00.000', '2025-01-13 00:00:00.000', NULL);
INSERT INTO perlss.pae_driver_flow
(id, program_cd, next_page, curr_page, pae_id, created_by, created_dt, last_modified_dt, record_version)
VALUES(nextval('perlss.hibernate_sequence'), 'CG1', 'PPSPS', 'PPSRR', 'PAE200112853', 'PASRR_CV', '2025-01-13 00:00:00.000', '2025-01-13 00:00:00.000', NULL);

--pae_certify_of_assmnt
INSERT INTO perlss.pae_certify_of_assmnt
(id, pae_id, pae_crtfctn_dt, certifier_of_accuracy, credentials_cd, created_dt, last_modified_by, last_modified_dt, record_version, archived_dt, created_by, qualified_assessor_dtl, qualified_assessor_name, credential, certifier_name)
VALUES(nextval('perlss.hibernate_sequence'), 'PAE200113114', '2023-11-22', '', NULL, '2025-01-13 00:00:00.000', NULL, NULL, 0, NULL, 'PASRR_CV', '', 'Green Hills Health & Rehab', 'Conversion', 'Conversion');
INSERT INTO perlss.pae_certify_of_assmnt
(id, pae_id, pae_crtfctn_dt, certifier_of_accuracy, credentials_cd, created_dt, last_modified_by, last_modified_dt, record_version, archived_dt, created_by, qualified_assessor_dtl, qualified_assessor_name, credential, certifier_name)
VALUES(nextval('perlss.hibernate_sequence'), 'PAE200112853', '2022-09-02', '', NULL, '2025-01-13 00:00:00.000', NULL, NULL, 0, NULL, 'PASRR_CV', '', 'The Health Ctr @ Standifer Place 1', 'Conversion', 'Conversion');

--pae_medical_diagnosis
INSERT INTO perlss.pae_medical_diagnosis
(id, pae_id, intlctl_dis_sw, psyclgcl_eval_sw, lvl_intlctl_disblty_cd, iq_test_score, iq_test_dt, iq_test_type_desc, chrnc_diagns_sw, trgt_popltn_diagns_cd, doc_dtls_desc, created_dt, last_modified_by, last_modified_dt, record_version, archived_dt, created_by, id_diagns_doc_sw, iq_score_avail_sw, iq_score_nottest_sw, iq_score_not_avail_sw)
VALUES(nextval('perlss.hibernate_sequence'), 'PAE200113114', NULL, NULL, '', NULL, NULL, NULL, 'Y', NULL, NULL, '2025-01-13 00:00:00.000', NULL, NULL, 0, NULL, 'PASRR_CV', NULL, NULL, NULL, NULL);
INSERT INTO perlss.pae_medical_diagnosis
(id, pae_id, intlctl_dis_sw, psyclgcl_eval_sw, lvl_intlctl_disblty_cd, iq_test_score, iq_test_dt, iq_test_type_desc, chrnc_diagns_sw, trgt_popltn_diagns_cd, doc_dtls_desc, created_dt, last_modified_by, last_modified_dt, record_version, archived_dt, created_by, id_diagns_doc_sw, iq_score_avail_sw, iq_score_nottest_sw, iq_score_not_avail_sw)
VALUES(nextval('perlss.hibernate_sequence'), 'PAE200112853', NULL, NULL, '', NULL, NULL, NULL, 'Y', NULL, NULL, '2025-01-13 00:00:00.000', NULL, NULL, 0, NULL, 'PASRR_CV', NULL, NULL, NULL, NULL);

--pae_med_diagns_dtls
INSERT INTO perlss.pae_med_diagns_dtls
(id, med_diagns_cd, othr_med_diagns, persist_6_months_sw, expctd_12_months_sw, primary_diagns_sw, created_dt, last_modified_by, last_modified_dt, record_version, archived_dt, created_by, pae_diagns_id)
VALUES(nextval('perlss.hibernate_sequence'), 'OT', 'LOAD, TEST (2017985)  :  2nd Floor 205 - B   PRIMARY GENERALIZED (OSTEO)ARTHRITIS (M15.0)	  10/13/23		Primary	Admitting Dx (#69)		   REPEATED FALLS (R29.6)	  10/13/23		Secondary 1			   CEREBRAL INFARCTION, UNSPECIFIED (I63.9)	  10/13/23		Secondary 2			   ESSENTIAL (PRIMARY) HYPERTENSION (I10)	  10/13/23		Secondary 3			   CONTRACTURE, LEFT HAND (M24.542)	  11/9/23		Secondary Diagnosis (3)			   TYPE 2 DIABETES MELLITUS WITHOUT COMPLICATIONS (E11.9)	  10/13/23		Secondary 4			   UNSPECIFIED ATRIAL FIBRILLATION (I48.91)	  10/13/23		Secondary 5			   SPINAL STENOSIS, CERVICAL REGION (M48.02)	  10/13/23		Secondary 6			   CHRONIC OBSTRUCTIVE PULMONARY DISEASE, UNSPECIFIED (J44.9)	  10/13/23		Secondary 7			   SCHIZOPHRENIA, UNSPECIFIED (F20.9)	  10/16/23		Secondary Diagnosis (7)	Present on Admission		   DEPRESSION, UNSPECIFIED (F32.A)	  10/13/23		Secondary 9+			   GASTRO-ESOPHAGEAL REFLUX DISEASE WITHOUT ESOPHAGITIS (K21.9)	  10/13/23		Secondary 9+			   HEMIPLEGIA AND HEMIPARESIS FOLLOWING CEREBRAL INFARCTION AFFECTING UNSPECIFIED SIDE (I69.359)	  10/13/23		Secondary 9+			   TOBACCO USE (Z72.0)	  10/13/23		Secondary 9+', NULL, NULL, NULL, '2025-01-13 00:00:00.000', NULL, NULL, 0, NULL, 'PASRR_CV', 1847878188);
INSERT INTO perlss.pae_med_diagns_dtls
(id, med_diagns_cd, othr_med_diagns, persist_6_months_sw, expctd_12_months_sw, primary_diagns_sw, created_dt, last_modified_by, last_modified_dt, record_version, archived_dt, created_by, pae_diagns_id)
VALUES(nextval('perlss.hibernate_sequence'), 'OT', 'MVC with traumatic SAH, multiple fractures, hypothyroidism, COPD, HTN, depression, bipolar, PTSD, morbid obesity, poly substance abuse (cocaine, meth) NWB BLE and LUE with cast', NULL, NULL, NULL, '2025-01-13 00:00:00.000', NULL, NULL, 0, NULL, 'PASRR_CV', 1847877927);

--pae_chrnc_med_diagns
INSERT INTO perlss.pae_chrnc_med_diagns
(id, med_diagns_cd, created_dt, last_modified_by, last_modified_dt, record_version, archived_dt, created_by, pae_diagns_id)
VALUES(nextval('perlss.hibernate_sequence'), 'OT', '2025-01-13 00:00:00.000', NULL, NULL, 0, NULL, 'PASRR_CV', 1847878188);
INSERT INTO perlss.pae_chrnc_med_diagns
(id, med_diagns_cd, created_dt, last_modified_by, last_modified_dt, record_version, archived_dt, created_by, pae_diagns_id)
VALUES(nextval('perlss.hibernate_sequence'), 'OT', '2025-01-13 00:00:00.000', NULL, NULL, 0, NULL, 'PASRR_CV', 1847877927);


--pae_skilled_srvc_summary
(id, pae_id, need_skilled_srvcs_sw, need_respiratory_care_sw, created_dt, last_modified_by, last_modified_dt, record_version, archived_dt, created_by, dsnt_need_srvcs_sw, total_submitted_skilled_srvcs_acuity_score)
VALUES(nextval('perlss.hibernate_sequence'), 'PAE200113114', 'Y', 'N', '2025-01-13 00:00:00.000', 'CV-ACTY-SCORE', '2025-01-29 09:52:30.745', 1, NULL, 'PASRR_CV', 'N', 1);
INSERT INTO perlss.pae_skilled_srvc_summary
(id, pae_id, need_skilled_srvcs_sw, need_respiratory_care_sw, created_dt, last_modified_by, last_modified_dt, record_version, archived_dt, created_by, dsnt_need_srvcs_sw, total_submitted_skilled_srvcs_acuity_score)
VALUES(nextval('perlss.hibernate_sequence'), 'PAE200112853', 'N', 'N', '2025-01-13 00:00:00.000', NULL, NULL, 0, NULL, 'PASRR_CV', 'Y', NULL);

--pae_safety_deter_sum
INSERT INTO perlss.pae_safety_deter_sum
(id, pae_id, req_safety_con_sw, nf_srvc_sw, hcbs_srvc_sw, tenncare_qualified_assessor_sw, created_dt, last_modified_by, last_modified_dt, record_version, archived_dt, created_by)
VALUES(nextval('perlss.hibernate_sequence'), 'PAE200113114', 'N', 'Y', 'N', 'N', '2025-01-13 00:00:00.000', NULL, NULL, 0, NULL, 'PASRR_CV');
INSERT INTO perlss.pae_safety_deter_sum
(id, pae_id, req_safety_con_sw, nf_srvc_sw, hcbs_srvc_sw, tenncare_qualified_assessor_sw, created_dt, last_modified_by, last_modified_dt, record_version, archived_dt, created_by)
VALUES(nextval('perlss.hibernate_sequence'), 'PAE200112853', 'N', 'Y', 'N', 'N', '2025-01-13 00:00:00.000', NULL, NULL, 0, NULL, 'PASRR_CV');

--pae_respiratory_care
INSERT INTO perlss.pae_respiratory_care
(id, pae_id, chrnc_ventilator_sw, chrnc_req_start_dt, chrnc_req_end_dt, tracheal_suction_sw, tracheal_req_start_dt, tracheal_req_end_dt, created_dt, last_modified_by, last_modified_dt, record_version, archived_dt, created_by)
VALUES(nextval('perlss.hibernate_sequence'), 'PAE200113114', 'N', NULL, NULL, 'N', NULL, NULL, '2025-01-13 00:00:00.000', NULL, NULL, 0, NULL, 'PASRR_CV');
INSERT INTO perlss.pae_respiratory_care
(id, pae_id, chrnc_ventilator_sw, chrnc_req_start_dt, chrnc_req_end_dt, tracheal_suction_sw, tracheal_req_start_dt, tracheal_req_end_dt, created_dt, last_modified_by, last_modified_dt, record_version, archived_dt, created_by)
VALUES(nextval('perlss.hibernate_sequence'), 'PAE200112853', 'N', NULL, NULL, 'N', NULL, NULL, '2025-01-13 00:00:00.000', NULL, NULL, 0, NULL, 'PASRR_CV');

--pae_doc_summary
INSERT INTO perlss.pae_doc_summary
(id, pae_id, certifier_name, qual_assessor_cd, credential, pae_certification_dt, doc_id, doc_type_cd, npi, medicaid_id, created_dt, last_modified_by, last_modified_dt, record_version, archived_dt, created_by, mco_chklst_sw, mco_chklst_comments, cicp_sw, cicp_comments)
VALUES(nextval('perlss.hibernate_sequence'), 'PAE200113114', 'Conversion', NULL, 'Conversion', NULL, NULL, 'CRT', NULL, NULL, '2025-01-13 00:00:00.000', NULL, NULL, 0, NULL, 'PASRR_CV', NULL, NULL, NULL, NULL);
INSERT INTO perlss.pae_doc_summary
(id, pae_id, certifier_name, qual_assessor_cd, credential, pae_certification_dt, doc_id, doc_type_cd, npi, medicaid_id, created_dt, last_modified_by, last_modified_dt, record_version, archived_dt, created_by, mco_chklst_sw, mco_chklst_comments, cicp_sw, cicp_comments)
VALUES(nextval('perlss.hibernate_sequence'), 'PAE200112853', 'Conversion', NULL, 'Conversion', NULL, NULL, 'CRT', NULL, NULL, '2025-01-13 00:00:00.000', NULL, NULL, 0, NULL, 'PASRR_CV', NULL, NULL, NULL, NULL);


--pae_action
INSERT INTO perlss.pae_action
(id, pae_id, pae_action_cd, entity_type, archived_dt, created_by, created_dt, last_modified_by, last_modified_dt, record_version, start_dt, end_dt, user_id, entity_id, rqstextension_sw)
VALUES(nextval('perlss.hibernate_sequence'), 'PAE200113114', 'SUB', NULL, NULL, 'PASRR_CV', '2025-01-13 00:00:00.000', NULL, NULL, 0, '2023-11-27', NULL, 'CV_402', NULL, NULL);
INSERT INTO perlss.pae_action
(id, pae_id, pae_action_cd, entity_type, archived_dt, created_by, created_dt, last_modified_by, last_modified_dt, record_version, start_dt, end_dt, user_id, entity_id, rqstextension_sw)
VALUES(nextval('perlss.hibernate_sequence'), 'PAE200112853', 'SUB', NULL, NULL, 'PASRR_CV', '2025-01-13 00:00:00.000', NULL, NULL, 0, '2022-09-07', NULL, 'CV_402', NULL, NULL);

--pae_activities_behavrl_dtl
INSERT INTO perlss.pae_activities_behavrl_dtl
(id, pae_id, pae_activities_lvng_id, beh_type, beh_intrvntn, created_dt, last_modified_by, last_modified_dt, record_version, archived_dt, created_by)
VALUES(nextval('perlss.hibernate_sequence'), 'PAE200113114', 1847867749, 'Conversion', 'Conversion', '2025-01-13 00:00:00.000', NULL, NULL, 0, NULL, 'PASRR_CV');
INSERT INTO perlss.pae_activities_behavrl_dtl
(id, pae_id, pae_activities_lvng_id, beh_type, beh_intrvntn, created_dt, last_modified_by, last_modified_dt, record_version, archived_dt, created_by)
VALUES(nextval('perlss.hibernate_sequence'), 'PAE200112853', 1847867139, 'Conversion', 'Conversion', '2025-01-13 00:00:00.000', NULL, NULL, 0, NULL, 'PASRR_CV');


--pae_sis_assessment
INSERT INTO perlss.pae_sis_assessment
(id, pae_id, sis_assmnt_comment, sis_outcome_cd, reason_dtl, sis_day_srvc_sw, sis_residential_srvc_sw, sis_pa_srvc_sw, created_by, created_dt, last_modified_by, last_modified_dt, record_version, archived_dt, sis_assmnt_doc_upload_dt, rsn_cd, othr_rsn_txt)
VALUES(nextval('perlss.hibernate_sequence'), 'PAE200113114', '', NULL, '', NULL, NULL, NULL, 'PASRR_CV', '2025-01-13 00:00:00.000', NULL, NULL, 0, NULL, NULL, NULL, '');
INSERT INTO perlss.pae_sis_assessment
(id, pae_id, sis_assmnt_comment, sis_outcome_cd, reason_dtl, sis_day_srvc_sw, sis_residential_srvc_sw, sis_pa_srvc_sw, created_by, created_dt, last_modified_by, last_modified_dt, record_version, archived_dt, sis_assmnt_doc_upload_dt, rsn_cd, othr_rsn_txt)
VALUES(nextval('perlss.hibernate_sequence'), 'PAE200112853', '', NULL, '', NULL, NULL, NULL, 'PASRR_CV', '2025-01-13 00:00:00.000', NULL, NULL, 0, NULL, NULL, NULL, '');


--pae_safety_deter_form
INSERT INTO perlss.pae_safety_deter_form
(id, pae_id, acuity_scr_5_less_8_sw, intlctl_disblty_sw, intel_dis_mala_index12_sw, acuity_scr_2beh_sw, acuity_scr_3orinet_sw, acuity_scr_3mobility_trnsfr_sw, acuity_scr_2toileting_sw, chng_phycl_behavrl_sw, chng_phycl_behavrl_primary_care_sw, rcnt_fall_sw, rcnt_emrgnt_hospital_admsn_sw, self_negli_sw, rcnt_discharge_sw, cmpx_chrnc_sw, mco_determn_grp5_sw, no_criteria_met_grp5_sw, mco_determn_grp3_sw, no_criteria_met_grp3_sw, donot_believe_sw, do_believe_sw, req_applcnt_sw, credentials_cd, created_dt, last_modified_by, last_modified_dt, record_version, archived_dt, created_by, icap_score, qualified_assessor_name, qualified_assessor_id, do_believe_at_risk_sw, credential, choices_member_enrolled_sw, post_acute_inptnt_sw, app_resdce_cd, app_resdce_oth_txt, resdce_unable_desc, dis_mala_comments, atstn_dt, name_atstn, intlctl_disblty_icap_sw)
VALUES(nextval('perlss.hibernate_sequence'), 'PAE200113114', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '2025-01-13 00:00:00.000', NULL, NULL, 0, NULL, 'PASRR_CV', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL);
INSERT INTO perlss.pae_safety_deter_form
(id, pae_id, acuity_scr_5_less_8_sw, intlctl_disblty_sw, intel_dis_mala_index12_sw, acuity_scr_2beh_sw, acuity_scr_3orinet_sw, acuity_scr_3mobility_trnsfr_sw, acuity_scr_2toileting_sw, chng_phycl_behavrl_sw, chng_phycl_behavrl_primary_care_sw, rcnt_fall_sw, rcnt_emrgnt_hospital_admsn_sw, self_negli_sw, rcnt_discharge_sw, cmpx_chrnc_sw, mco_determn_grp5_sw, no_criteria_met_grp5_sw, mco_determn_grp3_sw, no_criteria_met_grp3_sw, donot_believe_sw, do_believe_sw, req_applcnt_sw, credentials_cd, created_dt, last_modified_by, last_modified_dt, record_version, archived_dt, created_by, icap_score, qualified_assessor_name, qualified_assessor_id, do_believe_at_risk_sw, credential, choices_member_enrolled_sw, post_acute_inptnt_sw, app_resdce_cd, app_resdce_oth_txt, resdce_unable_desc, dis_mala_comments, atstn_dt, name_atstn, intlctl_disblty_icap_sw)
VALUES(nextval('perlss.hibernate_sequence'), 'PAE200112853', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '2025-01-13 00:00:00.000', NULL, NULL, 0, NULL, 'PASRR_CV', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL);

--pae_skilled_srvc_dtl
INSERT INTO perlss.pae_skilled_srvc_dtl
(id, pae_id, program_cd, section_type_cd, rqstd_start_dt, rqstd_end_dt, created_dt, last_modified_by, last_modified_dt, record_version, archived_dt, created_by)
VALUES(nextval('perlss.hibernate_sequence'), 'PAE200113114', 'CG1', 'OCT', '2023-11-27', '2023-01-11', '2025-01-13 00:00:00.000', NULL, NULL, 0, NULL, 'PASRR_CV');
INSERT INTO perlss.pae_skilled_srvc_dtl
(id, pae_id, program_cd, section_type_cd, rqstd_start_dt, rqstd_end_dt, created_dt, last_modified_by, last_modified_dt, record_version, archived_dt, created_by)
VALUES(nextval('perlss.hibernate_sequence'), 'PAE200113114', 'CG1', 'PHT', '2023-11-27', '2024-01-02', '2025-01-13 00:00:00.000', NULL, NULL, 0, NULL, 'PASRR_CV');


--pae_flow_sequence
INSERT INTO perlss.pae_flow_sequence
(id, pae_id, page_id, "module", visited_sw, completed_sw, req_sw, inactive_sw, created_by, created_dt, last_modified_dt, record_version, sum_sw)
VALUES(nextval('perlss.hibernate_sequence'), 'PAE200113114', 'PPWEL', 'PERDE', 'Y', 'Y', 'Y', NULL, 'PASRR_CV', '2025-01-13 00:00:00.000', '2025-01-13 00:00:00.000', NULL, NULL);
INSERT INTO perlss.pae_flow_sequence
(id, pae_id, page_id, "module", visited_sw, completed_sw, req_sw, inactive_sw, created_by, created_dt, last_modified_dt, record_version, sum_sw)
VALUES(nextval('perlss.hibernate_sequence'), 'PAE200113114', 'PPPAI', 'PERDE', 'Y', 'Y', 'Y', NULL, 'PASRR_CV', '2025-01-13 00:00:00.000', '2025-01-13 00:00:00.000', NULL, NULL);
INSERT INTO perlss.pae_flow_sequence
(id, pae_id, page_id, "module", visited_sw, completed_sw, req_sw, inactive_sw, created_by, created_dt, last_modified_dt, record_version, sum_sw)
VALUES(nextval('perlss.hibernate_sequence'), 'PAE200113114', 'PPPCI', 'PERDE', 'Y', 'Y', 'Y', NULL, 'PASRR_CV', '2025-01-13 00:00:00.000', '2025-01-13 00:00:00.000', NULL, NULL);
INSERT INTO perlss.pae_flow_sequence
(id, pae_id, page_id, "module", visited_sw, completed_sw, req_sw, inactive_sw, created_by, created_dt, last_modified_dt, record_version, sum_sw)
VALUES(nextval('perlss.hibernate_sequence'), 'PAE200113114', 'PPPLA', 'PERDE', 'Y', 'Y', 'Y', NULL, 'PASRR_CV', '2025-01-13 00:00:00.000', '2025-01-13 00:00:00.000', NULL, NULL);
INSERT INTO perlss.pae_flow_sequence
(id, pae_id, page_id, "module", visited_sw, completed_sw, req_sw, inactive_sw, created_by, created_dt, last_modified_dt, record_version, sum_sw)
VALUES(nextval('perlss.hibernate_sequence'), 'PAE200113114', 'PPPSP', 'PRORE', 'Y', 'Y', 'Y', NULL, 'PASRR_CV', '2025-01-13 00:00:00.000', '2025-01-13 00:00:00.000', NULL, 'N');
INSERT INTO perlss.pae_flow_sequence
(id, pae_id, page_id, "module", visited_sw, completed_sw, req_sw, inactive_sw, created_by, created_dt, last_modified_dt, record_version, sum_sw)
VALUES(nextval('perlss.hibernate_sequence'), 'PAE200113114', 'PPDDS', 'PAEDI', 'Y', 'Y', 'Y', NULL, 'PASRR_CV', '2025-01-13 00:00:00.000', '2025-01-13 00:00:00.000', NULL, 'Y');
INSERT INTO perlss.pae_flow_sequence
(id, pae_id, page_id, "module", visited_sw, completed_sw, req_sw, inactive_sw, created_by, created_dt, last_modified_dt, record_version, sum_sw)
VALUES(nextval('perlss.hibernate_sequence'), 'PAE200113114', 'PPDMD', 'PAEDI', 'Y', 'Y', 'Y', NULL, 'PASRR_CV', '2025-01-13 00:00:00.000', '2025-01-13 00:00:00.000', NULL, 'N');
INSERT INTO perlss.pae_flow_sequence
(id, pae_id, page_id, "module", visited_sw, completed_sw, req_sw, inactive_sw, created_by, created_dt, last_modified_dt, record_version, sum_sw)
VALUES(nextval('perlss.hibernate_sequence'), 'PAE200113114', 'PPFFA', 'PAEFU', 'Y', 'Y', 'Y', NULL, 'PASRR_CV', '2025-01-13 00:00:00.000', '2025-01-13 00:00:00.000', NULL, 'Y');
INSERT INTO perlss.pae_flow_sequence
(id, pae_id, page_id, "module", visited_sw, completed_sw, req_sw, inactive_sw, created_by, created_dt, last_modified_dt, record_version, sum_sw)
VALUES(nextval('perlss.hibernate_sequence'), 'PAE200113114', 'PPFAD', 'PAEFU', 'Y', 'Y', 'Y', NULL, 'PASRR_CV', '2025-01-13 00:00:00.000', '2025-01-13 00:00:00.000', NULL, 'N');
INSERT INTO perlss.pae_flow_sequence
(id, pae_id, page_id, "module", visited_sw, completed_sw, req_sw, inactive_sw, created_by, created_dt, last_modified_dt, record_version, sum_sw)
VALUES(nextval('perlss.hibernate_sequence'), 'PAE200113114', 'PPFAO', 'PAEFU', 'Y', 'Y', 'Y', NULL, 'PASRR_CV', '2025-01-13 00:00:00.000', '2025-01-13 00:00:00.000', NULL, 'N');
INSERT INTO perlss.pae_flow_sequence
(id, pae_id, page_id, "module", visited_sw, completed_sw, req_sw, inactive_sw, created_by, created_dt, last_modified_dt, record_version, sum_sw)
VALUES(nextval('perlss.hibernate_sequence'), 'PAE200113114', 'PPSSS', 'PAESK', 'Y', 'Y', 'Y', NULL, 'PASRR_CV', '2025-01-13 00:00:00.000', '2025-01-13 00:00:00.000', NULL, 'Y');
INSERT INTO perlss.pae_flow_sequence
(id, pae_id, page_id, "module", visited_sw, completed_sw, req_sw, inactive_sw, created_by, created_dt, last_modified_dt, record_version, sum_sw)
VALUES(nextval('perlss.hibernate_sequence'), 'PAE200113114', 'PPSSD', 'PAESK', 'Y', 'Y', 'Y', NULL, 'PASRR_CV', '2025-01-13 00:00:00.000', '2025-01-13 00:00:00.000', NULL, 'N');
INSERT INTO perlss.pae_flow_sequence
(id, pae_id, page_id, "module", visited_sw, completed_sw, req_sw, inactive_sw, created_by, created_dt, last_modified_dt, record_version, sum_sw)
VALUES(nextval('perlss.hibernate_sequence'), 'PAE200113114', 'PPSSE', 'PAESK', 'Y', 'Y', 'Y', NULL, 'PASRR_CV', '2025-01-13 00:00:00.000', '2025-01-13 00:00:00.000', NULL, 'N');
INSERT INTO perlss.pae_flow_sequence
(id, pae_id, page_id, "module", visited_sw, completed_sw, req_sw, inactive_sw, created_by, created_dt, last_modified_dt, record_version, sum_sw)
VALUES(nextval('perlss.hibernate_sequence'), 'PAE200113114', 'PPSDS', 'PAESA', 'Y', 'Y', 'Y', NULL, 'PASRR_CV', '2025-01-13 00:00:00.000', '2025-01-13 00:00:00.000', NULL, 'Y');
INSERT INTO perlss.pae_flow_sequence
(id, pae_id, page_id, "module", visited_sw, completed_sw, req_sw, inactive_sw, created_by, created_dt, last_modified_dt, record_version, sum_sw)
VALUES(nextval('perlss.hibernate_sequence'), 'PAE200113114', 'PPSDF', 'PAESA', 'Y', 'Y', 'N', NULL, 'PASRR_CV', '2025-01-13 00:00:00.000', '2025-01-13 00:00:00.000', NULL, 'N');
INSERT INTO perlss.pae_flow_sequence
(id, pae_id, page_id, "module", visited_sw, completed_sw, req_sw, inactive_sw, created_by, created_dt, last_modified_dt, record_version, sum_sw)
VALUES(nextval('perlss.hibernate_sequence'), 'PAE200113114', 'PPSFH', 'PAESA', 'Y', 'Y', 'N', NULL, 'PASRR_CV', '2025-01-13 00:00:00.000', '2025-01-13 00:00:00.000', NULL, 'N');
INSERT INTO perlss.pae_flow_sequence
(id, pae_id, page_id, "module", visited_sw, completed_sw, req_sw, inactive_sw, created_by, created_dt, last_modified_dt, record_version, sum_sw)
VALUES(nextval('perlss.hibernate_sequence'), 'PAE200113114', 'PPSDD', 'PAESP', 'Y', 'Y', 'Y', NULL, 'PASRR_CV', '2025-01-13 00:00:00.000', '2025-01-13 00:00:00.000', NULL, 'Y');
INSERT INTO perlss.pae_flow_sequence
(id, pae_id, page_id, "module", visited_sw, completed_sw, req_sw, inactive_sw, created_by, created_dt, last_modified_dt, record_version, sum_sw)
VALUES(nextval('perlss.hibernate_sequence'), 'PAE200113114', 'PPSPS', 'PAESU', 'Y', 'Y', 'Y', NULL, 'PASRR_CV', '2025-01-13 00:00:00.000', '2025-01-13 00:00:00.000', NULL, 'Y');
INSERT INTO perlss.pae_flow_sequence
(id, pae_id, page_id, "module", visited_sw, completed_sw, req_sw, inactive_sw, created_by, created_dt, last_modified_dt, record_version, sum_sw)
VALUES(nextval('perlss.hibernate_sequence'), 'PAE200113114', 'PPSRR', 'PAESU', 'Y', 'Y', 'Y', NULL, 'PASRR_CV', '2025-01-13 00:00:00.000', '2025-01-13 00:00:00.000', NULL, 'N');
INSERT INTO perlss.pae_flow_sequence
(id, pae_id, page_id, "module", visited_sw, completed_sw, req_sw, inactive_sw, created_by, created_dt, last_modified_dt, record_version, sum_sw)
VALUES(nextval('perlss.hibernate_sequence'), 'PAE200112853', 'PPWEL', 'PERDE', 'Y', 'Y', 'Y', NULL, 'PASRR_CV', '2025-01-13 00:00:00.000', '2025-01-13 00:00:00.000', NULL, NULL);
INSERT INTO perlss.pae_flow_sequence
(id, pae_id, page_id, "module", visited_sw, completed_sw, req_sw, inactive_sw, created_by, created_dt, last_modified_dt, record_version, sum_sw)
VALUES(nextval('perlss.hibernate_sequence'), 'PAE200112853', 'PPPAI', 'PERDE', 'Y', 'Y', 'Y', NULL, 'PASRR_CV', '2025-01-13 00:00:00.000', '2025-01-13 00:00:00.000', NULL, NULL);
INSERT INTO perlss.pae_flow_sequence
(id, pae_id, page_id, "module", visited_sw, completed_sw, req_sw, inactive_sw, created_by, created_dt, last_modified_dt, record_version, sum_sw)
VALUES(nextval('perlss.hibernate_sequence'), 'PAE200112853', 'PPPCI', 'PERDE', 'Y', 'Y', 'Y', NULL, 'PASRR_CV', '2025-01-13 00:00:00.000', '2025-01-13 00:00:00.000', NULL, NULL);
INSERT INTO perlss.pae_flow_sequence
(id, pae_id, page_id, "module", visited_sw, completed_sw, req_sw, inactive_sw, created_by, created_dt, last_modified_dt, record_version, sum_sw)
VALUES(nextval('perlss.hibernate_sequence'), 'PAE200112853', 'PPPLA', 'PERDE', 'Y', 'Y', 'Y', NULL, 'PASRR_CV', '2025-01-13 00:00:00.000', '2025-01-13 00:00:00.000', NULL, NULL);
INSERT INTO perlss.pae_flow_sequence
(id, pae_id, page_id, "module", visited_sw, completed_sw, req_sw, inactive_sw, created_by, created_dt, last_modified_dt, record_version, sum_sw)
VALUES(nextval('perlss.hibernate_sequence'), 'PAE200112853', 'PPPSP', 'PRORE', 'Y', 'Y', 'Y', NULL, 'PASRR_CV', '2025-01-13 00:00:00.000', '2025-01-13 00:00:00.000', NULL, 'N');
INSERT INTO perlss.pae_flow_sequence
(id, pae_id, page_id, "module", visited_sw, completed_sw, req_sw, inactive_sw, created_by, created_dt, last_modified_dt, record_version, sum_sw)
VALUES(nextval('perlss.hibernate_sequence'), 'PAE200112853', 'PPDDS', 'PAEDI', 'Y', 'Y', 'Y', NULL, 'PASRR_CV', '2025-01-13 00:00:00.000', '2025-01-13 00:00:00.000', NULL, 'Y');
INSERT INTO perlss.pae_flow_sequence
(id, pae_id, page_id, "module", visited_sw, completed_sw, req_sw, inactive_sw, created_by, created_dt, last_modified_dt, record_version, sum_sw)
VALUES(nextval('perlss.hibernate_sequence'), 'PAE200112853', 'PPDMD', 'PAEDI', 'Y', 'Y', 'Y', NULL, 'PASRR_CV', '2025-01-13 00:00:00.000', '2025-01-13 00:00:00.000', NULL, 'N');
INSERT INTO perlss.pae_flow_sequence
(id, pae_id, page_id, "module", visited_sw, completed_sw, req_sw, inactive_sw, created_by, created_dt, last_modified_dt, record_version, sum_sw)
VALUES(nextval('perlss.hibernate_sequence'), 'PAE200112853', 'PPFFA', 'PAEFU', 'Y', 'Y', 'Y', NULL, 'PASRR_CV', '2025-01-13 00:00:00.000', '2025-01-13 00:00:00.000', NULL, 'Y');
INSERT INTO perlss.pae_flow_sequence
(id, pae_id, page_id, "module", visited_sw, completed_sw, req_sw, inactive_sw, created_by, created_dt, last_modified_dt, record_version, sum_sw)
VALUES(nextval('perlss.hibernate_sequence'), 'PAE200112853', 'PPFAD', 'PAEFU', 'Y', 'Y', 'Y', NULL, 'PASRR_CV', '2025-01-13 00:00:00.000', '2025-01-13 00:00:00.000', NULL, 'N');
INSERT INTO perlss.pae_flow_sequence
(id, pae_id, page_id, "module", visited_sw, completed_sw, req_sw, inactive_sw, created_by, created_dt, last_modified_dt, record_version, sum_sw)
VALUES(nextval('perlss.hibernate_sequence'), 'PAE200112853', 'PPFAO', 'PAEFU', 'Y', 'Y', 'Y', NULL, 'PASRR_CV', '2025-01-13 00:00:00.000', '2025-01-13 00:00:00.000', NULL, 'N');
INSERT INTO perlss.pae_flow_sequence
(id, pae_id, page_id, "module", visited_sw, completed_sw, req_sw, inactive_sw, created_by, created_dt, last_modified_dt, record_version, sum_sw)
VALUES(nextval('perlss.hibernate_sequence'), 'PAE200112853', 'PPSSS', 'PAESK', 'Y', 'Y', 'Y', NULL, 'PASRR_CV', '2025-01-13 00:00:00.000', '2025-01-13 00:00:00.000', NULL, 'Y');
INSERT INTO perlss.pae_flow_sequence
(id, pae_id, page_id, "module", visited_sw, completed_sw, req_sw, inactive_sw, created_by, created_dt, last_modified_dt, record_version, sum_sw)
VALUES(nextval('perlss.hibernate_sequence'), 'PAE200112853', 'PPSSD', 'PAESK', 'Y', 'Y', 'N', NULL, 'PASRR_CV', '2025-01-13 00:00:00.000', '2025-01-13 00:00:00.000', NULL, 'N');
INSERT INTO perlss.pae_flow_sequence
(id, pae_id, page_id, "module", visited_sw, completed_sw, req_sw, inactive_sw, created_by, created_dt, last_modified_dt, record_version, sum_sw)
VALUES(nextval('perlss.hibernate_sequence'), 'PAE200112853', 'PPSSE', 'PAESK', 'Y', 'Y', 'N', NULL, 'PASRR_CV', '2025-01-13 00:00:00.000', '2025-01-13 00:00:00.000', NULL, 'N');
INSERT INTO perlss.pae_flow_sequence
(id, pae_id, page_id, "module", visited_sw, completed_sw, req_sw, inactive_sw, created_by, created_dt, last_modified_dt, record_version, sum_sw)
VALUES(nextval('perlss.hibernate_sequence'), 'PAE200112853', 'PPSDS', 'PAESA', 'Y', 'Y', 'Y', NULL, 'PASRR_CV', '2025-01-13 00:00:00.000', '2025-01-13 00:00:00.000', NULL, 'Y');
INSERT INTO perlss.pae_flow_sequence
(id, pae_id, page_id, "module", visited_sw, completed_sw, req_sw, inactive_sw, created_by, created_dt, last_modified_dt, record_version, sum_sw)
VALUES(nextval('perlss.hibernate_sequence'), 'PAE200112853', 'PPSDF', 'PAESA', 'Y', 'Y', 'N', NULL, 'PASRR_CV', '2025-01-13 00:00:00.000', '2025-01-13 00:00:00.000', NULL, 'N');
INSERT INTO perlss.pae_flow_sequence
(id, pae_id, page_id, "module", visited_sw, completed_sw, req_sw, inactive_sw, created_by, created_dt, last_modified_dt, record_version, sum_sw)
VALUES(nextval('perlss.hibernate_sequence'), 'PAE200112853', 'PPSFH', 'PAESA', 'Y', 'Y', 'N', NULL, 'PASRR_CV', '2025-01-13 00:00:00.000', '2025-01-13 00:00:00.000', NULL, 'N');
INSERT INTO perlss.pae_flow_sequence
(id, pae_id, page_id, "module", visited_sw, completed_sw, req_sw, inactive_sw, created_by, created_dt, last_modified_dt, record_version, sum_sw)
VALUES(nextval('perlss.hibernate_sequence'), 'PAE200112853', 'PPSDD', 'PAESP', 'Y', 'Y', 'Y', NULL, 'PASRR_CV', '2025-01-13 00:00:00.000', '2025-01-13 00:00:00.000', NULL, 'Y');
INSERT INTO perlss.pae_flow_sequence
(id, pae_id, page_id, "module", visited_sw, completed_sw, req_sw, inactive_sw, created_by, created_dt, last_modified_dt, record_version, sum_sw)
VALUES(nextval('perlss.hibernate_sequence'), 'PAE200112853', 'PPSPS', 'PAESU', 'Y', 'Y', 'Y', NULL, 'PASRR_CV', '2025-01-13 00:00:00.000', '2025-01-13 00:00:00.000', NULL, 'Y');
INSERT INTO perlss.pae_flow_sequence
(id, pae_id, page_id, "module", visited_sw, completed_sw, req_sw, inactive_sw, created_by, created_dt, last_modified_dt, record_version, sum_sw)
VALUES(nextval('perlss.hibernate_sequence'), 'PAE200112853', 'PPSRR', 'PAESU', 'Y', 'Y', 'Y', NULL, 'PASRR_CV', '2025-01-13 00:00:00.000', '2025-01-13 00:00:00.000', NULL, 'N');


INSERT INTO perlss.adj_rqst
(id, pae_id, adj_due_dt, adj_status_cd, assigned_user_id, pdf_generated_sw, override_sw, apl_override_sw, enr_grp_cd, loc_dcsn_cd, pae_eff_dt, pae_end_dt, recrtfctn_waive_sw, recrtfctn_due_dt, last_modified_by, last_modified_dt, record_version, created_by, created_dt, archived_dt, tns_id, prsn_id, loc_status_cd, active_sw, pae_exp_dt, adj_id, override_adj_id, entity_id, recrtfctn_status_cd, reassessment_due_dt, pae_expiration_lifted_sw, loc_dcsn_dt, adj_dcsn_dt)
VALUES(nextval('perlss.hibernate_sequence'), 'PAE200113114', '2023-12-04', 'CO', NULL, 'Y', 'N', 'N', 'CG3', 'DNF', '2023-12-01', NULL, NULL, NULL, 'CNV_ADJPDF_ADHOC', '2025-01-31 12:16:57.026', 2, 'PASRR_CV', '2025-01-13 00:00:00.000', NULL, NULL, 4450000013, NULL, 'Y', NULL, nextval('perlss.adj_rqst_0sq'), NULL, 986, NULL, '2023-11-27 11:40:20.000', 'N', '2023-12-01 10:56:00.000', NULL);
INSERT INTO perlss.adj_rqst
(id, pae_id, adj_due_dt, adj_status_cd, assigned_user_id, pdf_generated_sw, override_sw, apl_override_sw, enr_grp_cd, loc_dcsn_cd, pae_eff_dt, pae_end_dt, recrtfctn_waive_sw, recrtfctn_due_dt, last_modified_by, last_modified_dt, record_version, created_by, created_dt, archived_dt, tns_id, prsn_id, loc_status_cd, active_sw, pae_exp_dt, adj_id, override_adj_id, entity_id, recrtfctn_status_cd, reassessment_due_dt, pae_expiration_lifted_sw, loc_dcsn_dt, adj_dcsn_dt)
VALUES(nextval('perlss.hibernate_sequence'), 'PAE200112853', '2022-09-14', 'CO', NULL, 'Y', 'N', 'N', 'CG3', 'DNF', '2022-09-13', NULL, NULL, NULL, 'CNV_ADJPDF_ADHOC', '2025-01-31 12:16:51.840', 2, 'PASRR_CV', '2025-01-13 00:00:00.000', NULL, NULL, 4450000016, NULL, 'Y', NULL, nextval('perlss.adj_rqst_0sq'), NULL, 1008, NULL, '2022-09-07 12:21:50.000', 'N', '2022-09-12 16:53:00.000', NULL);


INSERT INTO perlss.adj_dtls
(id, adj_id, trgt_popltn_phy_diagns_sw, trgt_popltn_qual_fun_sw, trgt_popltn_not_meet_sw, sis_assmnt_req_sw, sis_lvl_of_need_cd, "comments", last_modified_by, last_modified_dt, record_version, created_by, created_dt, archived_dt, tp_id_sw, tp_dd_sw, lon_chng_sw, erc_chng_sw, cea_approved_sw, cost_cap_excp_approved_amt, cost_cap_excp_eff_dt, review_dcsn_cd, total_assessed_acty_score, total_assessed_rn_acty_score, total_assessed_apl_acty_score, total_assessed_aud_acty_score, total_adj_skilled_srvcs_acuity_score, total_submitted_skilled_srvcs_acuity_score, total_adj_acuity_score, cic_completed_sw, lon_dcsn_cd, case_ratio_cd, temp_lon_sw, total_acuity_score, total_apl_acuity_score, total_audit_acuity_score)
VALUES(nextval('perlss.hibernate_sequence'), 100111457, 'N', 'N', 'Y', 'N', NULL, NULL, 'CV-ACTY-SCORE', '2025-01-31 10:12:15.453', 2, 'PASRR_CV', '2025-01-13 00:00:00.000', NULL, NULL, NULL, 'N', 'N', NULL, NULL, NULL, NULL, 9, 7, NULL, NULL, 0, 1, 7, NULL, NULL, NULL, 'N', 7, 0, NULL);
INSERT INTO perlss.adj_dtls
(id, adj_id, trgt_popltn_phy_diagns_sw, trgt_popltn_qual_fun_sw, trgt_popltn_not_meet_sw, sis_assmnt_req_sw, sis_lvl_of_need_cd, "comments", last_modified_by, last_modified_dt, record_version, created_by, created_dt, archived_dt, tp_id_sw, tp_dd_sw, lon_chng_sw, erc_chng_sw, cea_approved_sw, cost_cap_excp_approved_amt, cost_cap_excp_eff_dt, review_dcsn_cd, total_assessed_acty_score, total_assessed_rn_acty_score, total_assessed_apl_acty_score, total_assessed_aud_acty_score, total_adj_skilled_srvcs_acuity_score, total_submitted_skilled_srvcs_acuity_score, total_adj_acuity_score, cic_completed_sw, lon_dcsn_cd, case_ratio_cd, temp_lon_sw, total_acuity_score, total_apl_acuity_score, total_audit_acuity_score)
VALUES(nextval('perlss.hibernate_sequence'), 100111196, 'N', 'N', 'Y', 'N', NULL, NULL, 'CV-ACTY-SCORE', '2025-01-31 10:12:10.267', 4, 'PASRR_CV', '2025-01-13 00:00:00.000', NULL, NULL, NULL, 'N', 'N', NULL, NULL, NULL, NULL, 6, 6, NULL, NULL, 0, 0, 6, NULL, NULL, NULL, 'N', 6, 0, NULL);

INSERT INTO perlss.adj_functnl_assmnt
(id, adj_id, functnl_measure_cd, sbmttr_rsp_cd, sbmttr_cap_need_rsp_cd, sbmttr_acuity_cd, sbmttr_acuity_score_num, rn_action_cd, rn_approval_cd, rn_denial_cd, rn_comment, rn_acuity_score_num, apl_approval_cd, apl_denial_cd, apl_comment, apl_acuity_score_num, audit_approval_cd, audit_denial_cd, audit_comment, audit_acuity_score_num, "comments", last_modified_by, last_modified_dt, record_version, created_by, created_dt, archived_dt)
VALUES(nextval('perlss.hibernate_sequence'), 100111457, 'TRAN', 'NE', NULL, 'NE', NULL, 'A', 'NE', NULL, NULL, 4, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'CV-ACTY-SCORE', '2025-01-30 12:07:20.843', 1, 'PASRR_CV', '2025-01-13 00:00:00.000', NULL);
INSERT INTO perlss.adj_functnl_assmnt
(id, adj_id, functnl_measure_cd, sbmttr_rsp_cd, sbmttr_cap_need_rsp_cd, sbmttr_acuity_cd, sbmttr_acuity_score_num, rn_action_cd, rn_approval_cd, rn_denial_cd, rn_comment, rn_acuity_score_num, apl_approval_cd, apl_denial_cd, apl_comment, apl_acuity_score_num, audit_approval_cd, audit_denial_cd, audit_comment, audit_acuity_score_num, "comments", last_modified_by, last_modified_dt, record_version, created_by, created_dt, archived_dt)
VALUES(nextval('perlss.hibernate_sequence'), 100111457, 'MOBL', 'NE', NULL, 'NE', NULL, 'A', 'NE', NULL, NULL, 3, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'CV-ACTY-SCORE', '2025-01-30 12:07:20.847', 1, 'PASRR_CV', '2025-01-13 00:00:00.000', NULL);
INSERT INTO perlss.adj_functnl_assmnt
(id, adj_id, functnl_measure_cd, sbmttr_rsp_cd, sbmttr_cap_need_rsp_cd, sbmttr_acuity_cd, sbmttr_acuity_score_num, rn_action_cd, rn_approval_cd, rn_denial_cd, rn_comment, rn_acuity_score_num, apl_approval_cd, apl_denial_cd, apl_comment, apl_acuity_score_num, audit_approval_cd, audit_denial_cd, audit_comment, audit_acuity_score_num, "comments", last_modified_by, last_modified_dt, record_version, created_by, created_dt, archived_dt)
VALUES(nextval('perlss.hibernate_sequence'), 100111457, 'MOBW', 'NE', NULL, 'NE', NULL, 'A', 'NE', NULL, NULL, 3, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'CV-ACTY-SCORE', '2025-01-30 12:07:20.851', 1, 'PASRR_CV', '2025-01-13 00:00:00.000', NULL);
INSERT INTO perlss.adj_functnl_assmnt
(id, adj_id, functnl_measure_cd, sbmttr_rsp_cd, sbmttr_cap_need_rsp_cd, sbmttr_acuity_cd, sbmttr_acuity_score_num, rn_action_cd, rn_approval_cd, rn_denial_cd, rn_comment, rn_acuity_score_num, apl_approval_cd, apl_denial_cd, apl_comment, apl_acuity_score_num, audit_approval_cd, audit_denial_cd, audit_comment, audit_acuity_score_num, "comments", last_modified_by, last_modified_dt, record_version, created_by, created_dt, archived_dt)
VALUES(nextval('perlss.hibernate_sequence'), 100111457, 'EATG', 'US', NULL, 'US', NULL, 'D', NULL, 'COT', NULL, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'CV-ACTY-SCORE', '2025-01-30 12:07:20.855', 1, 'PASRR_CV', '2025-01-13 00:00:00.000', NULL);
INSERT INTO perlss.adj_functnl_assmnt
(id, adj_id, functnl_measure_cd, sbmttr_rsp_cd, sbmttr_cap_need_rsp_cd, sbmttr_acuity_cd, sbmttr_acuity_score_num, rn_action_cd, rn_approval_cd, rn_denial_cd, rn_comment, rn_acuity_score_num, apl_approval_cd, apl_denial_cd, apl_comment, apl_acuity_score_num, audit_approval_cd, audit_denial_cd, audit_comment, audit_acuity_score_num, "comments", last_modified_by, last_modified_dt, record_version, created_by, created_dt, archived_dt)
VALUES(nextval('perlss.hibernate_sequence'), 100111457, 'TLTG', 'NE', NULL, 'NE', NULL, 'P', NULL, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'This is indicated by the submitted documentation.', 'CV-ACTY-SCORE', '2025-01-30 12:07:20.859', 1, 'PASRR_CV', '2025-01-13 00:00:00.000', NULL);
INSERT INTO perlss.adj_functnl_assmnt
(id, adj_id, functnl_measure_cd, sbmttr_rsp_cd, sbmttr_cap_need_rsp_cd, sbmttr_acuity_cd, sbmttr_acuity_score_num, rn_action_cd, rn_approval_cd, rn_denial_cd, rn_comment, rn_acuity_score_num, apl_approval_cd, apl_denial_cd, apl_comment, apl_acuity_score_num, audit_approval_cd, audit_denial_cd, audit_comment, audit_acuity_score_num, "comments", last_modified_by, last_modified_dt, record_version, created_by, created_dt, archived_dt)
VALUES(nextval('perlss.hibernate_sequence'), 100111457, 'TLTI', 'NE', NULL, 'NE', NULL, 'A', 'NE', NULL, NULL, 3, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'CV-ACTY-SCORE', '2025-01-30 12:07:20.863', 1, 'PASRR_CV', '2025-01-13 00:00:00.000', NULL);
INSERT INTO perlss.adj_functnl_assmnt
(id, adj_id, functnl_measure_cd, sbmttr_rsp_cd, sbmttr_cap_need_rsp_cd, sbmttr_acuity_cd, sbmttr_acuity_score_num, rn_action_cd, rn_approval_cd, rn_denial_cd, rn_comment, rn_acuity_score_num, apl_approval_cd, apl_denial_cd, apl_comment, apl_acuity_score_num, audit_approval_cd, audit_denial_cd, audit_comment, audit_acuity_score_num, "comments", last_modified_by, last_modified_dt, record_version, created_by, created_dt, archived_dt)
VALUES(nextval('perlss.hibernate_sequence'), 100111457, 'TLTC', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'CV-ACTY-SCORE', '2025-01-30 12:07:20.867', 1, 'PASRR_CV', '2025-01-13 00:00:00.000', NULL);
INSERT INTO perlss.adj_functnl_assmnt
(id, adj_id, functnl_measure_cd, sbmttr_rsp_cd, sbmttr_cap_need_rsp_cd, sbmttr_acuity_cd, sbmttr_acuity_score_num, rn_action_cd, rn_approval_cd, rn_denial_cd, rn_comment, rn_acuity_score_num, apl_approval_cd, apl_denial_cd, apl_comment, apl_acuity_score_num, audit_approval_cd, audit_denial_cd, audit_comment, audit_acuity_score_num, "comments", last_modified_by, last_modified_dt, record_version, created_by, created_dt, archived_dt)
VALUES(nextval('perlss.hibernate_sequence'), 100111457, 'ORNT', 'AL', NULL, 'AL', NULL, 'A', 'AL', NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'CV-ACTY-SCORE', '2025-01-30 12:07:20.871', 1, 'PASRR_CV', '2025-01-13 00:00:00.000', NULL);
INSERT INTO perlss.adj_functnl_assmnt
(id, adj_id, functnl_measure_cd, sbmttr_rsp_cd, sbmttr_cap_need_rsp_cd, sbmttr_acuity_cd, sbmttr_acuity_score_num, rn_action_cd, rn_approval_cd, rn_denial_cd, rn_comment, rn_acuity_score_num, apl_approval_cd, apl_denial_cd, apl_comment, apl_acuity_score_num, audit_approval_cd, audit_denial_cd, audit_comment, audit_acuity_score_num, "comments", last_modified_by, last_modified_dt, record_version, created_by, created_dt, archived_dt)
VALUES(nextval('perlss.hibernate_sequence'), 100111457, 'ECOM', 'AL', NULL, 'AL', NULL, 'A', 'AL', NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'CV-ACTY-SCORE', '2025-01-30 12:07:20.875', 1, 'PASRR_CV', '2025-01-13 00:00:00.000', NULL);
INSERT INTO perlss.adj_functnl_assmnt
(id, adj_id, functnl_measure_cd, sbmttr_rsp_cd, sbmttr_cap_need_rsp_cd, sbmttr_acuity_cd, sbmttr_acuity_score_num, rn_action_cd, rn_approval_cd, rn_denial_cd, rn_comment, rn_acuity_score_num, apl_approval_cd, apl_denial_cd, apl_comment, apl_acuity_score_num, audit_approval_cd, audit_denial_cd, audit_comment, audit_acuity_score_num, "comments", last_modified_by, last_modified_dt, record_version, created_by, created_dt, archived_dt)
VALUES(nextval('perlss.hibernate_sequence'), 100111457, 'RCOM', 'AL', NULL, 'AL', NULL, 'A', 'AL', NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'CV-ACTY-SCORE', '2025-01-30 12:07:20.879', 1, 'PASRR_CV', '2025-01-13 00:00:00.000', NULL);
INSERT INTO perlss.adj_functnl_assmnt
(id, adj_id, functnl_measure_cd, sbmttr_rsp_cd, sbmttr_cap_need_rsp_cd, sbmttr_acuity_cd, sbmttr_acuity_score_num, rn_action_cd, rn_approval_cd, rn_denial_cd, rn_comment, rn_acuity_score_num, apl_approval_cd, apl_denial_cd, apl_comment, apl_acuity_score_num, audit_approval_cd, audit_denial_cd, audit_comment, audit_acuity_score_num, "comments", last_modified_by, last_modified_dt, record_version, created_by, created_dt, archived_dt)
VALUES(nextval('perlss.hibernate_sequence'), 100111457, 'MEDC', 'US', NULL, 'US', NULL, 'A', 'US', NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'CV-ACTY-SCORE', '2025-01-30 12:07:20.882', 1, 'PASRR_CV', '2025-01-13 00:00:00.000', NULL);
INSERT INTO perlss.adj_functnl_assmnt
(id, adj_id, functnl_measure_cd, sbmttr_rsp_cd, sbmttr_cap_need_rsp_cd, sbmttr_acuity_cd, sbmttr_acuity_score_num, rn_action_cd, rn_approval_cd, rn_denial_cd, rn_comment, rn_acuity_score_num, apl_approval_cd, apl_denial_cd, apl_comment, apl_acuity_score_num, audit_approval_cd, audit_denial_cd, audit_comment, audit_acuity_score_num, "comments", last_modified_by, last_modified_dt, record_version, created_by, created_dt, archived_dt)
VALUES(nextval('perlss.hibernate_sequence'), 100111457, 'BHVR', 'UN', NULL, 'UN', NULL, 'D', NULL, 'COT', NULL, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'CV-ACTY-SCORE', '2025-01-30 12:07:20.886', 1, 'PASRR_CV', '2025-01-13 00:00:00.000', NULL);
INSERT INTO perlss.adj_functnl_assmnt
(id, adj_id, functnl_measure_cd, sbmttr_rsp_cd, sbmttr_cap_need_rsp_cd, sbmttr_acuity_cd, sbmttr_acuity_score_num, rn_action_cd, rn_approval_cd, rn_denial_cd, rn_comment, rn_acuity_score_num, apl_approval_cd, apl_denial_cd, apl_comment, apl_acuity_score_num, audit_approval_cd, audit_denial_cd, audit_comment, audit_acuity_score_num, "comments", last_modified_by, last_modified_dt, record_version, created_by, created_dt, archived_dt)
VALUES(nextval('perlss.hibernate_sequence'), 100111196, 'TRAN', 'NE', NULL, 'NE', NULL, 'A', 'NE', NULL, NULL, 4, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'CV-ACTY-SCORE', '2025-01-30 12:07:18.360', 1, 'PASRR_CV', '2025-01-13 00:00:00.000', NULL);
INSERT INTO perlss.adj_functnl_assmnt
(id, adj_id, functnl_measure_cd, sbmttr_rsp_cd, sbmttr_cap_need_rsp_cd, sbmttr_acuity_cd, sbmttr_acuity_score_num, rn_action_cd, rn_approval_cd, rn_denial_cd, rn_comment, rn_acuity_score_num, apl_approval_cd, apl_denial_cd, apl_comment, apl_acuity_score_num, audit_approval_cd, audit_denial_cd, audit_comment, audit_acuity_score_num, "comments", last_modified_by, last_modified_dt, record_version, created_by, created_dt, archived_dt)
VALUES(nextval('perlss.hibernate_sequence'), 100111196, 'MOBL', 'NE', NULL, 'NE', NULL, 'A', 'NE', NULL, NULL, 3, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'CV-ACTY-SCORE', '2025-01-30 12:07:18.365', 1, 'PASRR_CV', '2025-01-13 00:00:00.000', NULL);
INSERT INTO perlss.adj_functnl_assmnt
(id, adj_id, functnl_measure_cd, sbmttr_rsp_cd, sbmttr_cap_need_rsp_cd, sbmttr_acuity_cd, sbmttr_acuity_score_num, rn_action_cd, rn_approval_cd, rn_denial_cd, rn_comment, rn_acuity_score_num, apl_approval_cd, apl_denial_cd, apl_comment, apl_acuity_score_num, audit_approval_cd, audit_denial_cd, audit_comment, audit_acuity_score_num, "comments", last_modified_by, last_modified_dt, record_version, created_by, created_dt, archived_dt)
VALUES(nextval('perlss.hibernate_sequence'), 100111196, 'MOBW', 'NE', NULL, 'NE', NULL, 'A', 'NE', NULL, NULL, 3, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'CV-ACTY-SCORE', '2025-01-30 12:07:18.369', 1, 'PASRR_CV', '2025-01-13 00:00:00.000', NULL);
INSERT INTO perlss.adj_functnl_assmnt
(id, adj_id, functnl_measure_cd, sbmttr_rsp_cd, sbmttr_cap_need_rsp_cd, sbmttr_acuity_cd, sbmttr_acuity_score_num, rn_action_cd, rn_approval_cd, rn_denial_cd, rn_comment, rn_acuity_score_num, apl_approval_cd, apl_denial_cd, apl_comment, apl_acuity_score_num, audit_approval_cd, audit_denial_cd, audit_comment, audit_acuity_score_num, "comments", last_modified_by, last_modified_dt, record_version, created_by, created_dt, archived_dt)
VALUES(nextval('perlss.hibernate_sequence'), 100111196, 'EATG', 'AL', NULL, 'AL', NULL, 'A', 'AL', NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'CV-ACTY-SCORE', '2025-01-30 12:07:18.373', 1, 'PASRR_CV', '2025-01-13 00:00:00.000', NULL);
INSERT INTO perlss.adj_functnl_assmnt
(id, adj_id, functnl_measure_cd, sbmttr_rsp_cd, sbmttr_cap_need_rsp_cd, sbmttr_acuity_cd, sbmttr_acuity_score_num, rn_action_cd, rn_approval_cd, rn_denial_cd, rn_comment, rn_acuity_score_num, apl_approval_cd, apl_denial_cd, apl_comment, apl_acuity_score_num, audit_approval_cd, audit_denial_cd, audit_comment, audit_acuity_score_num, "comments", last_modified_by, last_modified_dt, record_version, created_by, created_dt, archived_dt)
VALUES(nextval('perlss.hibernate_sequence'), 100111196, 'TLTG', 'NE', NULL, 'NE', NULL, 'A', 'NE', NULL, NULL, 2, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'CV-ACTY-SCORE', '2025-01-30 12:07:18.376', 1, 'PASRR_CV', '2025-01-13 00:00:00.000', NULL);
INSERT INTO perlss.adj_functnl_assmnt
(id, adj_id, functnl_measure_cd, sbmttr_rsp_cd, sbmttr_cap_need_rsp_cd, sbmttr_acuity_cd, sbmttr_acuity_score_num, rn_action_cd, rn_approval_cd, rn_denial_cd, rn_comment, rn_acuity_score_num, apl_approval_cd, apl_denial_cd, apl_comment, apl_acuity_score_num, audit_approval_cd, audit_denial_cd, audit_comment, audit_acuity_score_num, "comments", last_modified_by, last_modified_dt, record_version, created_by, created_dt, archived_dt)
VALUES(nextval('perlss.hibernate_sequence'), 100111196, 'TLTI', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'CV-ACTY-SCORE', '2025-01-30 12:07:18.380', 1, 'PASRR_CV', '2025-01-13 00:00:00.000', NULL);
INSERT INTO perlss.adj_functnl_assmnt
(id, adj_id, functnl_measure_cd, sbmttr_rsp_cd, sbmttr_cap_need_rsp_cd, sbmttr_acuity_cd, sbmttr_acuity_score_num, rn_action_cd, rn_approval_cd, rn_denial_cd, rn_comment, rn_acuity_score_num, apl_approval_cd, apl_denial_cd, apl_comment, apl_acuity_score_num, audit_approval_cd, audit_denial_cd, audit_comment, audit_acuity_score_num, "comments", last_modified_by, last_modified_dt, record_version, created_by, created_dt, archived_dt)
VALUES(nextval('perlss.hibernate_sequence'), 100111196, 'TLTC', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'CV-ACTY-SCORE', '2025-01-30 12:07:18.384', 1, 'PASRR_CV', '2025-01-13 00:00:00.000', NULL);
INSERT INTO perlss.adj_functnl_assmnt
(id, adj_id, functnl_measure_cd, sbmttr_rsp_cd, sbmttr_cap_need_rsp_cd, sbmttr_acuity_cd, sbmttr_acuity_score_num, rn_action_cd, rn_approval_cd, rn_denial_cd, rn_comment, rn_acuity_score_num, apl_approval_cd, apl_denial_cd, apl_comment, apl_acuity_score_num, audit_approval_cd, audit_denial_cd, audit_comment, audit_acuity_score_num, "comments", last_modified_by, last_modified_dt, record_version, created_by, created_dt, archived_dt)
VALUES(nextval('perlss.hibernate_sequence'), 100111196, 'ORNT', 'AL', NULL, 'AL', NULL, 'A', 'AL', NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'CV-ACTY-SCORE', '2025-01-30 12:07:18.388', 1, 'PASRR_CV', '2025-01-13 00:00:00.000', NULL);
INSERT INTO perlss.adj_functnl_assmnt
(id, adj_id, functnl_measure_cd, sbmttr_rsp_cd, sbmttr_cap_need_rsp_cd, sbmttr_acuity_cd, sbmttr_acuity_score_num, rn_action_cd, rn_approval_cd, rn_denial_cd, rn_comment, rn_acuity_score_num, apl_approval_cd, apl_denial_cd, apl_comment, apl_acuity_score_num, audit_approval_cd, audit_denial_cd, audit_comment, audit_acuity_score_num, "comments", last_modified_by, last_modified_dt, record_version, created_by, created_dt, archived_dt)
VALUES(nextval('perlss.hibernate_sequence'), 100111196, 'ECOM', 'AL', NULL, 'AL', NULL, 'A', 'AL', NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'CV-ACTY-SCORE', '2025-01-30 12:07:18.393', 1, 'PASRR_CV', '2025-01-13 00:00:00.000', NULL);
INSERT INTO perlss.adj_functnl_assmnt
(id, adj_id, functnl_measure_cd, sbmttr_rsp_cd, sbmttr_cap_need_rsp_cd, sbmttr_acuity_cd, sbmttr_acuity_score_num, rn_action_cd, rn_approval_cd, rn_denial_cd, rn_comment, rn_acuity_score_num, apl_approval_cd, apl_denial_cd, apl_comment, apl_acuity_score_num, audit_approval_cd, audit_denial_cd, audit_comment, audit_acuity_score_num, "comments", last_modified_by, last_modified_dt, record_version, created_by, created_dt, archived_dt)
VALUES(nextval('perlss.hibernate_sequence'), 100111196, 'RCOM', 'AL', NULL, 'AL', NULL, 'A', 'AL', NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'CV-ACTY-SCORE', '2025-01-30 12:07:18.397', 1, 'PASRR_CV', '2025-01-13 00:00:00.000', NULL);
INSERT INTO perlss.adj_functnl_assmnt
(id, adj_id, functnl_measure_cd, sbmttr_rsp_cd, sbmttr_cap_need_rsp_cd, sbmttr_acuity_cd, sbmttr_acuity_score_num, rn_action_cd, rn_approval_cd, rn_denial_cd, rn_comment, rn_acuity_score_num, apl_approval_cd, apl_denial_cd, apl_comment, apl_acuity_score_num, audit_approval_cd, audit_denial_cd, audit_comment, audit_acuity_score_num, "comments", last_modified_by, last_modified_dt, record_version, created_by, created_dt, archived_dt)
VALUES(nextval('perlss.hibernate_sequence'), 100111196, 'MEDC', 'AL', NULL, 'AL', NULL, 'A', 'AL', NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'CV-ACTY-SCORE', '2025-01-30 12:07:18.401', 1, 'PASRR_CV', '2025-01-13 00:00:00.000', NULL);
INSERT INTO perlss.adj_functnl_assmnt
(id, adj_id, functnl_measure_cd, sbmttr_rsp_cd, sbmttr_cap_need_rsp_cd, sbmttr_acuity_cd, sbmttr_acuity_score_num, rn_action_cd, rn_approval_cd, rn_denial_cd, rn_comment, rn_acuity_score_num, apl_approval_cd, apl_denial_cd, apl_comment, apl_acuity_score_num, audit_approval_cd, audit_denial_cd, audit_comment, audit_acuity_score_num, "comments", last_modified_by, last_modified_dt, record_version, created_by, created_dt, archived_dt)
VALUES(nextval('perlss.hibernate_sequence'), 100111196, 'BHVR', 'NE', NULL, 'NE', NULL, 'A', 'NE', NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'CV-ACTY-SCORE', '2025-01-30 12:07:18.405', 1, 'PASRR_CV', '2025-01-13 00:00:00.000', NULL);


INSERT INTO perlss.adj_skilled_srvcs
(id, adj_id, srvc_name_cd, rqst_eff_dt, rqst_end_dt, approved_eff_dt, approved_end_dt, acuity_score, adjctor_rsp_cd, tracheal_scrn_req_sw, "comments", created_dt, created_by, last_modified_by, last_modified_dt, record_version, archived_dt)
VALUES(nextval('perlss.hibernate_sequence'), 100111457, 'OCT', '2023-11-27', '2023-01-11', NULL, NULL, 0, 'D', 'N', 'Medicaid level of care is not met.', '2025-01-13 00:00:00.000', 'PASRR_CV', NULL, NULL, 0, NULL);
INSERT INTO perlss.adj_skilled_srvcs
(id, adj_id, srvc_name_cd, rqst_eff_dt, rqst_end_dt, approved_eff_dt, approved_end_dt, acuity_score, adjctor_rsp_cd, tracheal_scrn_req_sw, "comments", created_dt, created_by, last_modified_by, last_modified_dt, record_version, archived_dt)
VALUES(nextval('perlss.hibernate_sequence'), 100111457, 'PHT', '2023-11-27', '2024-01-02', NULL, NULL, 0, 'D', 'N', 'Medicaid level of care is not met.', '2025-01-13 00:00:00.000', 'PASRR_CV', NULL, NULL, 0, NULL);


INSERT INTO perlss.adj_pasrr_outcome
(id, adj_id, lvl1_submit_dt, payor_src_cd, lvl1_dcsn_cd, lvl1_dcsn_dt, lvl2_dcsn_cd, lvl2_eff_dt, lvl2_end_dt, created_dt, created_by, last_modified_by, last_modified_dt, record_version, archived_dt, pasrr_id, source_cd, type_cd, lvl1_eff_dt, lvl1_end_dt, lvl2_dcsn_dt, link_sw, episode_id)
VALUES(nextval('perlss.hibernate_sequence'), 100111457, '2023-11-21', 'MD', 'REF', '2023-11-22', 'DEN', '2023-12-01', NULL, '2025-01-13 00:00:00.000', 'PASRR_CV', NULL, NULL, 0, NULL, 'PSR100594369', 'CNV', 'T', '2023-11-22', NULL, '2023-12-01', 'Y', '712634');
INSERT INTO perlss.adj_pasrr_outcome
(id, adj_id, lvl1_submit_dt, payor_src_cd, lvl1_dcsn_cd, lvl1_dcsn_dt, lvl2_dcsn_cd, lvl2_eff_dt, lvl2_end_dt, created_dt, created_by, last_modified_by, last_modified_dt, record_version, archived_dt, pasrr_id, source_cd, type_cd, lvl1_eff_dt, lvl1_end_dt, lvl2_dcsn_dt, link_sw, episode_id)
VALUES(nextval('perlss.hibernate_sequence'), 100111196, '2022-09-02', 'AP', 'REF', '2022-09-02', 'DEN', '2022-09-13', NULL, '2025-01-13 00:00:00.000', 'PASRR_CV', NULL, NULL, 0, NULL, 'PSR100594378', 'CNV', 'T', '2022-09-02', NULL, '2022-09-13', 'Y', '578742');


INSERT INTO perlss.adj_safety_determn
(id, adj_id, ltss_safety_dcsn_cd, safety_assmnt_req_sw, "comments", created_dt, created_by, last_modified_by, last_modified_dt, record_version, archived_dt)
VALUES(nextval('perlss.hibernate_sequence'), 100111457, 'CV', 'N', 'Uploaded the  Safety doc from Maximus', '2025-01-13 00:00:00.000', 'PASRR_CV', NULL, NULL, 0, NULL);
INSERT INTO perlss.adj_safety_determn
(id, adj_id, ltss_safety_dcsn_cd, safety_assmnt_req_sw, "comments", created_dt, created_by, last_modified_by, last_modified_dt, record_version, archived_dt)
VALUES(nextval('perlss.hibernate_sequence'), 100111196, 'CV', 'N', 'Uploaded the  Safety doc from Maximus', '2025-01-13 00:00:00.000', 'PASRR_CV', NULL, NULL, 0, NULL);


INSERT INTO perlss.adj_skilled_srvcs_info
(id, adj_id, "comments", last_modified_by, last_modified_dt, record_version, created_by, created_dt, archived_dt)
VALUES(nextval('perlss.hibernate_sequence'), 100111457, NULL, NULL, NULL, 0, 'PASRR_CV', '2025-01-13 00:00:00.000', NULL);
INSERT INTO perlss.adj_skilled_srvcs_info
(id, adj_id, "comments", last_modified_by, last_modified_dt, record_version, created_by, created_dt, archived_dt)
VALUES(nextval('perlss.hibernate_sequence'), 100111196, NULL, NULL, NULL, 0, 'PASRR_CV', '2025-01-13 00:00:00.000', NULL);


INSERT INTO perlss.adj_clrfcn_rsn
(id, created_dt, created_by, last_modified_by, last_modified_dt, record_version, archived_dt, rsn_flag_sw, rsn_cd, rsn_type_cd, adj_id, clrfcn_comment_txt)
VALUES(nextval('perlss.hibernate_sequence'), '2025-01-13 00:00:00.000', 'PASRR_CV', NULL, NULL, 0, NULL, 'Y', 'NA', 'NA', 100111457, NULL);
INSERT INTO perlss.adj_clrfcn_rsn
(id, created_dt, created_by, last_modified_by, last_modified_dt, record_version, archived_dt, rsn_flag_sw, rsn_cd, rsn_type_cd, adj_id, clrfcn_comment_txt)
VALUES(nextval('perlss.hibernate_sequence'), '2025-01-13 00:00:00.000', 'PASRR_CV', NULL, NULL, 0, NULL, 'Y', 'NA', 'NA', 100111196, NULL);


INSERT INTO perlss.pasrr_rqst
(id, prsn_id, pasrr_id, episode_id, status_cd, source_cd, pae_id, type_cd, txn_id, rqst_sw, lvl1_outcome_cd, rqst_dt, lvl1_deter_dt, lvl1_eff_dt, lvl1_end_dt, lvl2_outcome_cd, lvl2_deter_dt, lvl2_eff_dt, lvl2_end_dt, expedited_sw, revsn_of_pasrr_id, submit_dt, due_dt, archived_dt, created_by, created_dt, last_modified_by, last_modified_dt, record_version, lookup_update_sw, nt_update_sw)
VALUES(nextval('perlss.hibernate_sequence'), 4450000013, concat('PSR',nextval('perlss.pasrr_rqst_0sq')), '680039', 'CO', 'CNV', NULL, 'O', NULL, 'N', 'NEG', NULL, '2023-08-11', '2023-08-11', NULL, NULL, NULL, NULL, NULL, NULL, NULL, '2023-08-11', NULL, NULL, 'PASRR_CV', '2025-01-13 00:00:00.000', NULL, NULL, 0, 'Y', 'Y');
INSERT INTO perlss.pasrr_rqst
(id, prsn_id, pasrr_id, episode_id, status_cd, source_cd, pae_id, type_cd, txn_id, rqst_sw, lvl1_outcome_cd, rqst_dt, lvl1_deter_dt, lvl1_eff_dt, lvl1_end_dt, lvl2_outcome_cd, lvl2_deter_dt, lvl2_eff_dt, lvl2_end_dt, expedited_sw, revsn_of_pasrr_id, submit_dt, due_dt, archived_dt, created_by, created_dt, last_modified_by, last_modified_dt, record_version, lookup_update_sw, nt_update_sw)
VALUES(nextval('perlss.hibernate_sequence'), 4450000016, concat('PSR',nextval('perlss.pasrr_rqst_0sq')), '576265', 'CO', 'CNV', NULL, 'O', NULL, 'N', 'NEG', NULL, '2022-08-25', '2022-08-25', NULL, NULL, NULL, NULL, NULL, NULL, NULL, '2022-08-24', NULL, NULL, 'PASRR_CV', '2025-01-13 00:00:00.000', NULL, NULL, 0, 'Y', 'Y');

INSERT INTO perlss.pasrr_demo_dtls
(id, pasrr_id, last_name, middle_initial, first_name, dob_dt, ssn, gender_cd, archived_dt, created_by, created_dt, last_modified_by, last_modified_dt, record_version)
VALUES(1848019147, 'PSR100594365', 'MR', 'L', 'BEAN', '1965-04-07', '394819381', 'F', NULL, 'PASRR_CV', '2025-01-13 00:00:00.000', NULL, NULL, 0);
INSERT INTO perlss.pasrr_demo_dtls
(id, pasrr_id, last_name, middle_initial, first_name, dob_dt, ssn, gender_cd, archived_dt, created_by, created_dt, last_modified_by, last_modified_dt, record_version)
VALUES(1848020638, 'PSR100594377', 'TEST', 'A', 'PETER', '1966-11-29', '396816381', 'F', NULL, 'PASRR_CV', '2025-01-13 00:00:00.000', NULL, NULL, 0);



INSERT INTO perlss.pasrr_submtr_dtls
(id, pasrr_id, lvl1_submit_dt, lvl1_submtr_first_name, lvl1_submtr_last_name, lvl1_submitting_facility, lvl1_submitting_facility_address, lvl1_submitting_facility_city, lvl1_submitting_facility_state, lvl1_submitting_facility_zip, archived_dt, created_by, created_dt, last_modified_by, last_modified_dt, record_version)
VALUES(nextval('perlss.hibernate_sequence'), 'PSR100594365', '2023-08-11', 'XXXX', 'XXXX', 'Trevecca Health Care Ctr', '1033 Demonbreun St', 'Nashville', 'TN', '37203', NULL, 'PASRR_CV', '2025-01-13 00:00:00.000', NULL, NULL, 0);
INSERT INTO perlss.pasrr_submtr_dtls
(id, pasrr_id, lvl1_submit_dt, lvl1_submtr_first_name, lvl1_submtr_last_name, lvl1_submitting_facility, lvl1_submitting_facility_address, lvl1_submitting_facility_city, lvl1_submitting_facility_state, lvl1_submitting_facility_zip, archived_dt, created_by, created_dt, last_modified_by, last_modified_dt, record_version)
VALUES(nextval('perlss.hibernate_sequence'), 'PSR100594377', '2022-08-24', 'XXXX', 'XXXX', 'Erlanger Medical Center', '1033 Demonbreun St', 'Nashville', 'TN', '37203', NULL, 'PASRR_CV', '2025-01-13 00:00:00.000', NULL, NULL, 0);


INSERT INTO perlss.pasrr_outcome_dtls
(id, pasrr_id, payor_src_cd, hos_admit_dt, nf_admit_dt, review_type, prim_lang, ascendid, lvl1_letter_sent_dt, lvl1_letter_type_sent, lvl2_notice_type, lvl2_notice_sent_dt, lvl2_sent_to_state_dt, lvl2_assessment_dt, lvl2_specialized_services_dtr, lvl2_approved_str, lvl2_short_term_days, lvl2_pasrr_condition, lvl2_due_dt, archived_dt, created_by, created_dt, last_modified_by, last_modified_dt, record_version, passr_action_cd, short_stay_dt, pasrr_comment, assmnt_id, recon_of_assmnt_id)
VALUES(nextval('perlss.hibernate_sequence'), 'PSR100594365', 'MD', '2023-07-21', '2023-08-11', 'Preadmission', 'English', '513532', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'PASRR_CV', '2025-01-13 00:00:00.000', NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL);
INSERT INTO perlss.pasrr_outcome_dtls
(id, pasrr_id, payor_src_cd, hos_admit_dt, nf_admit_dt, review_type, prim_lang, ascendid, lvl1_letter_sent_dt, lvl1_letter_type_sent, lvl2_notice_type, lvl2_notice_sent_dt, lvl2_sent_to_state_dt, lvl2_assessment_dt, lvl2_specialized_services_dtr, lvl2_approved_str, lvl2_short_term_days, lvl2_pasrr_condition, lvl2_due_dt, archived_dt, created_by, created_dt, last_modified_by, last_modified_dt, record_version, passr_action_cd, short_stay_dt, pasrr_comment, assmnt_id, recon_of_assmnt_id)
VALUES(nextval('perlss.hibernate_sequence'), 'PSR100594377', 'MD', '2022-08-05', '2022-08-25', 'Preadmission', NULL, '44494', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'PASRR_CV', '2025-01-13 00:00:00.000', NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL);


INSERT INTO perlss.pasrr_addr_dtl
(id, pasrr_id, first_name, middle_name, last_name, suffix, user_type_cd, addr_line_1, addr_line_2, city, state_cd, zip, zip_extsn, cnty_cd, current_location, current_location_facility, admtng_facility_name, archived_dt, created_by, created_dt, last_modified_by, last_modified_dt, record_version)
VALUES(nextval('perlss.hibernate_sequence'), 'PSR100594365', '', NULL, '', NULL, 'APPL', '1033 Demonbreun St', '917', 'Nashville', 'TN', '37203', NULL, '', 'Medical Facility Medical Unit', 'Tri-Star Southern Hills Medical Center', 'Trevecca Health Care Ctr', NULL, 'PASRR_CV', '2025-01-13 00:00:00.000', NULL, NULL, 0);
INSERT INTO perlss.pasrr_addr_dtl
(id, pasrr_id, first_name, middle_name, last_name, suffix, user_type_cd, addr_line_1, addr_line_2, city, state_cd, zip, zip_extsn, cnty_cd, current_location, current_location_facility, admtng_facility_name, archived_dt, created_by, created_dt, last_modified_by, last_modified_dt, record_version)
VALUES(nextval('perlss.hibernate_sequence'), 'PSR100594365', '', NULL, '', NULL, 'CL', '1033 Demonbreun St', NULL, 'Nashville', 'TN', '37203', NULL, '', 'Medical Facility Medical Unit', 'Tri-Star Southern Hills Medical Center', 'Trevecca Health Care Ctr', NULL, 'PASRR_CV', '2025-01-13 00:00:00.000', NULL, NULL, 0);
INSERT INTO perlss.pasrr_addr_dtl
(id, pasrr_id, first_name, middle_name, last_name, suffix, user_type_cd, addr_line_1, addr_line_2, city, state_cd, zip, zip_extsn, cnty_cd, current_location, current_location_facility, admtng_facility_name, archived_dt, created_by, created_dt, last_modified_by, last_modified_dt, record_version)
VALUES(nextval('perlss.hibernate_sequence'), 'PSR100594377', '', NULL, '', NULL, 'APPL', '1033 Demonbreun St', '720', 'NASHVILLE', 'TN', '37203', NULL, '', 'Medical Facility Medical Unit', 'Erlanger Medical Center', NULL, NULL, 'PASRR_CV', '2025-01-13 00:00:00.000', NULL, NULL, 0);
INSERT INTO perlss.pasrr_addr_dtl
(id, pasrr_id, first_name, middle_name, last_name, suffix, user_type_cd, addr_line_1, addr_line_2, city, state_cd, zip, zip_extsn, cnty_cd, current_location, current_location_facility, admtng_facility_name, archived_dt, created_by, created_dt, last_modified_by, last_modified_dt, record_version)
VALUES(nextval('perlss.hibernate_sequence'), 'PSR100594377', '', NULL, '', NULL, 'CL', '1033 Demonbreun St', NULL, 'NASHVILLE', 'TN', '37203', NULL, '', 'Medical Facility Medical Unit', 'Erlanger Medical Center', NULL, NULL, 'PASRR_CV', '2025-01-13 00:00:00.000', NULL, NULL, 0);



INSERT INTO perlss.enr_rqst
(id, enr_grp_cd, enr_status_cd, auth_dt, assigned_user_id, created_dt, created_by, last_modified_by, last_modified_dt, record_version, archived_dt, enr_id, auth_status_cd, enr_start_dt, enr_end_dt, enr_denial_rsn_cd, tns_id, override_sw, apl_override_sw, dis_enr_dt, active_sw, cob_sw, hstry_sw, pae_id, prsn_id, auth_id, src_enr_id, tracking_cd, enr_dcsn_dt, withdraw_rsn_cd)
VALUES(nextval('perlss.hibernate_sequence'), 'CG3', 'ENR', '2024-01-18 00:00:00.000', NULL, '2025-01-13 00:00:00.000', 'PASRR_CV', NULL, NULL, 0, NULL, nextval('perlss.enr_rqst_0sq'), 'APP', '2023-12-09', '2299-12-31', NULL, NULL, NULL, NULL, NULL, 'Y', NULL, NULL, 'PAE200113114', 4450000013, NULL, NULL, NULL, '2023-12-09 00:00:00.000', NULL);
INSERT INTO perlss.enr_rqst
(id, enr_grp_cd, enr_status_cd, auth_dt, assigned_user_id, created_dt, created_by, last_modified_by, last_modified_dt, record_version, archived_dt, enr_id, auth_status_cd, enr_start_dt, enr_end_dt, enr_denial_rsn_cd, tns_id, override_sw, apl_override_sw, dis_enr_dt, active_sw, cob_sw, hstry_sw, pae_id, prsn_id, auth_id, src_enr_id, tracking_cd, enr_dcsn_dt, withdraw_rsn_cd)
VALUES(nextval('perlss.hibernate_sequence'), 'CG3', 'ENR', '2023-02-13 00:00:00.000', NULL, '2025-01-13 00:00:00.000', 'PASRR_CV', NULL, NULL, 0, NULL, nextval('perlss.enr_rqst_0sq'), 'APP', '2022-12-05', '2299-12-31', NULL, NULL, NULL, NULL, NULL, 'Y', NULL, NULL, 'PAE200112853', 4450000016, NULL, NULL, NULL, '2022-09-13 00:00:00.000', NULL);


INSERT INTO perlss.enr_dtls
(id, enr_id, auth_status_cd, cob_start_dt, cob_end_dt, enr_denial_rsn_cd, "comments", created_dt, created_by, last_modified_by, last_modified_dt, record_version, archived_dt, grandfathered_sw, mfp_denial_criteria, end_type_cd, end_rsn_cd)
VALUES(nextval('perlss.hibernate_sequence'), 100199192, 'APP', '2023-12-09', '2299-12-31', NULL, NULL, '2025-01-13 00:00:00.000', 'PASRR_CV', NULL, NULL, 0, NULL, 'N', NULL, NULL, NULL);
INSERT INTO perlss.enr_dtls
(id, enr_id, auth_status_cd, cob_start_dt, cob_end_dt, enr_denial_rsn_cd, "comments", created_dt, created_by, last_modified_by, last_modified_dt, record_version, archived_dt, grandfathered_sw, mfp_denial_criteria, end_type_cd, end_rsn_cd)
VALUES(nextval('perlss.hibernate_sequence'), 100199059, 'APP', '2022-12-05', '2299-12-31', NULL, NULL, '2025-01-13 00:00:00.000', 'PASRR_CV', NULL, NULL, 0, NULL, 'N', NULL, NULL, NULL);


INSERT INTO perlss.enr_bnft
(id, enr_id, enr_bnft_type_cd, enr_bnft_grp_cd, enr_bnft_amt, enr_bnft_eff_dt, enr_bnft_end_dt, created_dt, last_modified_by, last_modified_dt, record_version, archived_dt, created_by, lon_cd)
VALUES(nextval('perlss.hibernate_sequence'), 100199192, NULL, 'BSAM', 19764.0, '2023-12-09', '2299-12-31', '2025-01-13 00:00:00.000', NULL, NULL, 0, NULL, 'PASRR_CV', NULL);
INSERT INTO perlss.enr_bnft
(id, enr_id, enr_bnft_type_cd, enr_bnft_grp_cd, enr_bnft_amt, enr_bnft_eff_dt, enr_bnft_end_dt, created_dt, last_modified_by, last_modified_dt, record_version, archived_dt, created_by, lon_cd)
VALUES(nextval('perlss.hibernate_sequence'), 100199059, NULL, 'BSAM', 19764.0, '2022-12-05', '2299-12-31', '2025-01-13 00:00:00.000', NULL, NULL, 0, NULL, 'PASRR_CV', NULL);


INSERT INTO perlss.enr_financial_elig
(id, enr_id, created_dt, created_by, last_modified_by, last_modified_dt, record_version, archived_dt, indv_id, lvng_arrgmnt_type_cd, penalty_end_dt, penalty_sw, penalty_start_dt, dob_dt, first_name, last_name, gender_cd, ssn, middle_initial, primary_indv_id, dual_member_sw, update_from_link_sw, prsn_id, dual_member_indctr_sw, apl_indctr_sw, ctgry_elig_desc, ctgry_elig_begin_dt, ctgry_elig_end_dt, termntn_rsn, ctgry_elig_cd, denial_sw, denial_ctgry_elig, auth_dt, denial_rsn, appeal_filed_sw, ssi_trn_active_sw, ssi_trn_begin_dt)
VALUES(nextval('perlss.hibernate_sequence'), 100199192, '2025-01-13 00:00:00.000', 'PASRR_CV', NULL, NULL, 0, NULL, 4450000013, NULL, NULL, NULL, NULL, '1965-04-07', 'MR', 'BEAN', 'F', '394819381', 'L', NULL, NULL, NULL, 4450000013, '', NULL, NULL, '2023-12-09', '2299-12-31', NULL, 'CG3', NULL, NULL, NULL, NULL, NULL, NULL, NULL);
INSERT INTO perlss.enr_financial_elig
(id, enr_id, created_dt, created_by, last_modified_by, last_modified_dt, record_version, archived_dt, indv_id, lvng_arrgmnt_type_cd, penalty_end_dt, penalty_sw, penalty_start_dt, dob_dt, first_name, last_name, gender_cd, ssn, middle_initial, primary_indv_id, dual_member_sw, update_from_link_sw, prsn_id, dual_member_indctr_sw, apl_indctr_sw, ctgry_elig_desc, ctgry_elig_begin_dt, ctgry_elig_end_dt, termntn_rsn, ctgry_elig_cd, denial_sw, denial_ctgry_elig, auth_dt, denial_rsn, appeal_filed_sw, ssi_trn_active_sw, ssi_trn_begin_dt)
VALUES(nextval('perlss.hibernate_sequence'), 100199059, '2025-01-13 00:00:00.000', 'PASRR_CV', NULL, NULL, 0, NULL, 4450000016, NULL, NULL, NULL, NULL, '1966-11-29', 'TEST', 'PETER', 'F', '396816381', 'A', NULL, NULL, NULL, 4450000016, '', NULL, NULL, '2022-12-05', '2299-12-31', NULL, 'CG3', NULL, NULL, NULL, NULL, NULL, NULL, NULL);


INSERT INTO perlss.enr_patient_lblty_dtls
(id, financial_elig_id, patient_lblty_start_dt, patient_lblty_end_dt, amt, created_dt, created_by, last_modified_by, last_modified_dt, record_version, archived_dt, patient_lblty)
VALUES(nextval('perlss.hibernate_sequence'), 1848088692, '2012-07-06', '2299-12-31', 0, '2025-01-13 00:00:00.000', 'PASRR_CV', NULL, NULL, 0, NULL, NULL);
INSERT INTO perlss.enr_patient_lblty_dtls
(id, financial_elig_id, patient_lblty_start_dt, patient_lblty_end_dt, amt, created_dt, created_by, last_modified_by, last_modified_dt, record_version, archived_dt, patient_lblty)
VALUES(nextval('perlss.hibernate_sequence'), 1848088695, '2023-12-01', '2299-12-31', 0, '2025-01-13 00:00:00.000', 'PASRR_CV', NULL, NULL, 0, NULL, NULL);





INSERT INTO perlss.com_comments
(id, ref_id, pae_id, apl_id, tns_id, chm_id, type_cd, "comments", entity_id, page_id, prsn_id, created_by, created_dt, last_modified_by, last_modified_dt, record_version, archived_dt, enr_id, erc_ref_id, erc_assmnt_id, episode_id)
VALUES(1848029051, NULL, 'PAE200113114', NULL, NULL, NULL, 'TLTG', 'This is indicated by the submitted documentation.', 986, 'PPFAD', 4450000013, 'PASRR_CV', '2025-01-13 00:00:00.000', NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL);
INSERT INTO perlss.com_comments
(id, ref_id, pae_id, apl_id, tns_id, chm_id, type_cd, "comments", entity_id, page_id, prsn_id, created_by, created_dt, last_modified_by, last_modified_dt, record_version, archived_dt, enr_id, erc_ref_id, erc_assmnt_id, episode_id)
VALUES(1848029052, NULL, 'PAE200113114', NULL, NULL, NULL, NULL, 'Medicaid level of care is not met.', 986, 'PPSSD', 4450000013, 'PASRR_CV', '2025-01-13 00:00:00.000', NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL);
INSERT INTO perlss.com_comments
(id, ref_id, pae_id, apl_id, tns_id, chm_id, type_cd, "comments", entity_id, page_id, prsn_id, created_by, created_dt, last_modified_by, last_modified_dt, record_version, archived_dt, enr_id, erc_ref_id, erc_assmnt_id, episode_id)
VALUES(1848029053, NULL, 'PAE200113114', NULL, NULL, NULL, NULL, 'Medicaid level of care is not met.', 986, 'PPSSD', 4450000013, 'PASRR_CV', '2025-01-13 00:00:00.000', NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL);

INSERT INTO perlss.com_notes
(id, pae_id, ref_id, apl_id, notes_type_cd, notes_comments, created_by, created_dt, last_modified_by, last_modified_dt, record_version, archived_dt, erc_ref_id, erc_assmnt_id, episode_id)
VALUES(1848028374, 'PAE200113114', NULL, NULL, 'GNR', 'Records converted on01/13/2025', 'PASRR_CV', '2025-01-13 00:00:00.000', NULL, NULL, 0, NULL, NULL, NULL, NULL);
INSERT INTO perlss.com_notes
(id, pae_id, ref_id, apl_id, notes_type_cd, notes_comments, created_by, created_dt, last_modified_by, last_modified_dt, record_version, archived_dt, erc_ref_id, erc_assmnt_id, episode_id)
VALUES(1848027743, 'PAE200112853', NULL, NULL, 'GNR', 'Records converted on01/13/2025', 'PASRR_CV', '2025-01-13 00:00:00.000', NULL, NULL, 0, NULL, NULL, NULL, NULL);







INSERT INTO perlss.com_applcnt_access
(id, pae_id, ref_id, prsn_id, entity_cd, eff_begin_dt, eff_end_dt, active_sw, created_dt, last_modified_by, last_modified_dt, record_version, archived_dt, created_by, entity_type_cd, assigned_mco_sw, entity_id)
VALUES(1848087698, 'PAE200113114', NULL, 4450000013, '5', '2023-12-01', NULL, 'Y', '2025-01-28 16:59:00.733', NULL, NULL, 0, NULL, 'PASRR_CV', 'NF', NULL, 986);
INSERT INTO perlss.com_applcnt_access
(id, pae_id, ref_id, prsn_id, entity_cd, eff_begin_dt, eff_end_dt, active_sw, created_dt, last_modified_by, last_modified_dt, record_version, archived_dt, created_by, entity_type_cd, assigned_mco_sw, entity_id)
VALUES(1848087719, 'PAE200113114', NULL, 4450000013, '4', '2015-01-01', '2299-12-31', 'Y', '2025-01-28 16:59:00.733', NULL, NULL, 0, NULL, 'PASRR_CV', 'MCO', 'Y', 805);
INSERT INTO perlss.com_applcnt_access
(id, pae_id, ref_id, prsn_id, entity_cd, eff_begin_dt, eff_end_dt, active_sw, created_dt, last_modified_by, last_modified_dt, record_version, archived_dt, created_by, entity_type_cd, assigned_mco_sw, entity_id)
VALUES(1848087762, 'PAE200112853', NULL, 4450000016, '5', '2022-09-13', NULL, 'Y', '2025-01-28 16:59:00.733', NULL, NULL, 0, NULL, 'PASRR_CV', 'NF', NULL, 1008);
INSERT INTO perlss.com_applcnt_access
(id, pae_id, ref_id, prsn_id, entity_cd, eff_begin_dt, eff_end_dt, active_sw, created_dt, last_modified_by, last_modified_dt, record_version, archived_dt, created_by, entity_type_cd, assigned_mco_sw, entity_id)
VALUES(1848087853, 'PAE200112853', NULL, 4450000016, '4', '2019-10-25', '2299-12-31', 'Y', '2025-01-28 16:59:00.733', NULL, NULL, 0, NULL, 'PASRR_CV', 'MCO', 'Y', 805);

select  concat(nextval('perlss.enr_rqst_0sq')) as enr_ID,
nextval('perlss.hibernate_sequence') as ID,
* from (
select 
'A' as CONVERSION_RUN_STATUS,tm.num_control_pkey,pae.pasrr_review_id,pae_id,prsn_id,
a.*, trim(c.sys_cde) as sys_cde
from (select dte_effective::varchar::date as o_dte_effective,dte_end::varchar::date as o_dte_end ,loc_dte_effective::varchar::date as o_loc_dte_effective,
loc_dte_end::varchar::date as o_loc_dte_end,dte_last_update::varchar::date as o_dte_last_update,* from legacy.pasrr_mmis_base_member_pop  where  type='ENR')a 
join (select  * from legacy.wrk_pasrr_clients where  source_system_nm='MMIS'  and valid_sw='Y' and xref_valid_sw='Y' and perlss_sw ='N') b  on  b.ssn=a.num_ssn and a.sak_recip::varchar(25)=b.sak_recip  and trim(a.num_pre_eval) =trim(b.mmis_pae_id)
 --left  join (select  * from perlss.com_applcnt where active_sw ='Y' and file_clearance_sw='Y') ca on ca.ssn=a.num_ssn
join legacy.pasrr_tmed_base_member_pop tm on num_control_pkey::varchar(25) =trim(a.num_pre_eval)
join (select  *  from legacy.pasrr_pae_base_member_pop pae where step='1'  )pae on pae.pasrr_review_id::varchar(25)=trim(tm.tmed_ascend_id)
left join (select  *  from perlss.pae_rqst where  created_by='PASRR_CV') p  on trim(legacy_id)=pae.pasrr_review_id::varchar(25)
left join legacy.pasrr_mmis_t_re_choices_tracking  C on c.sak_recip = a.sak_recip and c.sak_pgm_elig = a.sak_pgm_elig
where   exists(select 1 from perlss.com_applcnt ca where  ca.ssn=a.num_ssn)
union all
select 
'A' as CONVERSION_RUN_STATUS,tm.num_control_pkey,pae.pasrr_review_id,pae_id,prsn_id,
a.*, trim(c.sys_cde) as sys_cde
from (select  dte_effective::varchar::date as o_dte_effective,dte_end::varchar::date as o_dte_end ,loc_dte_effective::varchar::date as o_loc_dte_effective,
loc_dte_end::varchar::date as o_loc_dte_end,dte_last_update::varchar::date as o_dte_last_update,* from legacy.pasrr_mmis_base_member_pop  where  type='DIS')a 
join (select  * from legacy.wrk_pasrr_clients where  source_system_nm='MMIS'  and valid_sw='Y' and xref_valid_sw='Y' and perlss_sw ='N') b  on  b.ssn=a.num_ssn and a.sak_recip::varchar(25)=b.sak_recip  and trim(a.num_pre_eval) =trim(b.mmis_pae_id)
join legacy.pasrr_tmed_base_member_pop tm on num_control_pkey::varchar(25) =trim(a.num_pre_eval)
join (select  *  from legacy.pasrr_pae_base_member_pop pae where step='2'  )pae on pae.pasrr_review_id::varchar(25)=trim(tm.tmed_ascend_id)
left join (select  *  from perlss.pae_rqst where  created_by='PASRR_CV') p  on trim(legacy_id)=pae.pasrr_review_id::varchar(25)
left join legacy.pasrr_mmis_t_re_choices_tracking  C on c.sak_recip = a.sak_recip and c.sak_pgm_elig = a.sak_pgm_elig
where   exists(select 1 from perlss.com_applcnt ca where  ca.ssn=a.num_ssn) 
)enr  where  pae_id is not  null
select 
nextval('perlss.hibernate_sequence') as ID,
 * from (
 SELECT
a.prsn_id,  a.financial_elig_id, a.dte_effective, a.dte_end, 
a.amt_patnt_liab, a.mmis_pae_id,CONVERSION_RUN_STATUS,
archived_dt,last_modified_by,last_modified_dt from (
SELECT  ca.prsn_id, 
a.sak_recip as sak_recip, 
T_RE_PAT_LIAB.DTE_EFFECTIVE, 
T_RE_PAT_LIAB.DTE_END,
T_RE_PAT_LIAB.AMT_PATNT_LIAB , 
trim(b.mmis_pae_id) as MMIS_PAE_ID 
,efe.id as financial_elig_id
, a.NUM_SSN 
, 'A' as CONVERSION_RUN_STATUS
,null::timestamp as archived_dt
,null as  last_modified_by
,null as last_modified_dt
---select wrk_mmis_base_member_pop.NUM_SSN--, count(1)
--select count(1) 
from (select dte_effective::varchar::date as o_dte_effective,dte_end::varchar::date as o_dte_end ,loc_dte_effective::varchar::date as o_loc_dte_effective,
loc_dte_end::varchar::date as o_loc_dte_end,dte_last_update::varchar::date as o_dte_last_update,* from legacy.pasrr_mmis_base_member_pop  )a 
join (select  * from legacy.wrk_pasrr_clients where  source_system_nm='MMIS') b  on  b.ssn=a.num_ssn and a.sak_recip::varchar(25)=b.sak_recip  and trim(a.num_pre_eval) =trim(b.mmis_pae_id)
join legacy.pasrr_tmed_base_member_pop tm on num_control_pkey::varchar(25) =trim(a.num_pre_eval)
join (select  *  from legacy.pasrr_pae_base_member_pop pae where step in ('1','2')  )pae on pae.pasrr_review_id::varchar(25)=trim(tm.tmed_ascend_id)
left join (select  *  from perlss.pae_rqst where  created_by='PASRR_CV') p  on trim(legacy_id)=pae.pasrr_review_id::varchar(25)
left join (select  *  from perlss.enr_rqst where  created_by='PASRR_CV') e  on p.pae_id=e.pae_id
join (select * from perlss.enr_financial_elig  where  created_by='PASRR_CV') efe on efe.enr_id=e.enr_id
join perlss.com_applcnt ca on  ca.prsn_id=p.prsn_id
left join (select * from (
select T_RE_PAT_LIAB.*,ROW_NUMBER() OVER (PARTITION BY T_RE_PAT_LIAB.SAK_RECIP ORDER BY T_RE_PAT_LIAB.DTE_END DESC) AS RNM from 
legacy.pasrr_mmis_T_RE_PAT_LIAB  T_RE_PAT_LIAB)T_RE_PAT_LIAB
where RNM = 1)T_RE_PAT_LIAB ON T_RE_PAT_LIAB.SAK_RECIP=a.SAK_RECIP
 where  b.VALID_SW ='Y' AND b.XREF_VALID_SW = 'Y' and b.perlss_sw ='N' )a)a
 --where dte_effective is null;





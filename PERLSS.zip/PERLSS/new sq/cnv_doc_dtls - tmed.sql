select
nextval('perlss.hibernate_sequence') as ID,
* from (
select  distinct
NULL	apl_id
,case
	when f.file_name='SummaryOfFindings.pdf' then 'OSD'
	when f.file_name='LOC.pdf' then 'EFA' else 'OSD' End  doc_type_cd
, f.filenet_guid	file_name
,ca.first_name	first_name
,NULL	folder_name
,NULL	kb_fn_id
,NULL	last_modified_by
,NULL	last_modified_dt
,f.upload_ts as archived_dt
,ca.last_name	last_name
,NULL	notice_type
,NULL	notice_type_cd
,r.pae_id	pae_id
,'N'	processed_flag
,ca.prsn_id	prsn_id
,NULL	ref_id
,'PASRR'	source_sys_nm
,NULL	tns_id
,'A' as CONVERSION_RUN_STATUS
from legacy.pasrr_pae_base_member_pop a
join legacy.pasrr_tmed_base_member_pop b on a.tmed_num_control_pkey = b.num_control_pkey
join legacy.wrk_pasrr_clients w  on a.pasrr_review_id::bigint  = w.maximus_reviewid::bigint
join (select  *  from perlss.pasrr_rqst ) r    on r.episode_id::text = w.maximus_reviewid::text
join legacy.tmed_attachment f on a.tmed_num_control_pkey = f.screen_id
left join perlss.com_applcnt ca on w.ssn=ca.ssn and active_sw='Y' and file_clearance_sw= 'Y'
where
w.source_system_nm = 'MAXIMUS'
--and valid_sw= 'Y' and 	xref_valid_sw='Y'
and perlss_sw ='N'
)a
select 
nextval('perlss.hibernate_sequence') as ID,
 * from (
 select distinct 
	 a.enr_id
	,'BSAM' as  enr_bnft_grp_cd
	,Null as enr_bnft_type_cd
	,a.enr_start_dt enr_bnft_eff_dt
	,a.enr_end_dt enr_bnft_end_dt
	,CASE when a.enr_grp_cd ='CG1' then 0 
		  when enr_grp_cd ='CG3' then 19764 end  enr_bnft_amt
	,Null	lon_cd
	,NULL	last_modified_by
	,NULL	last_modified_dt
	,'A'   CONVERSION_RUN_STATUS
from perlss.enr_rqst a
where  created_by = 'PASRR_CV'
union 
select distinct
     er.enr_id 
	,'ADON' as enr_bnft_grp_cd
	,ass.srvc_name_cd as enr_bnft_type_cd
	,er.enr_start_dt as enr_bnft_eff_dt
	,er.enr_end_Dt as enr_bnft_end_Dt
	,CASE when ass.srvc_name_cd ='SMT' then  58900
         when ass.srvc_name_cd ='CVS' then 130900 end  as enr_bnft_amt
	,Null	lon_cd
	,NULL	last_modified_by
	,NULL	last_modified_dt
	,'A'   CONVERSION_RUN_STATUS
from
	perlss.adj_rqst ar
join perlss.enr_rqst er on	ar.pae_id = er.pae_id
join perlss.com_applcnt ca on	ca.prsn_id = er.prsn_id
inner join perlss.adj_skilled_srvcs ass on	ass.adj_id = ar.adj_id
--inner join legacy.perlss_reference_data prd on	prd.code = ass.srvc_name_cd
inner join legacy.pasrr_mmis_base_member_pop wmbmp on	wmbmp.num_ssn = ca.ssn
where er.created_by='PASRR_CV' and 	er.enr_grp_cd = 'CG1'
	and ass.srvc_name_cd in ('SMT', 'CVS')
	--and prd.name = 'ENROLLMENT_ADDON_AMOUNT'
	and ltrim(rtrim(wmbmp.cde_pgm_health)) = 'CH1B'
)a;






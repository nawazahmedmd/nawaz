select 
nextval('perlss.hibernate_sequence') as ID,
 * from (
select distinct 
Null	actual_discharge_dt
,'N'	choices_grp_3_sw
,NULL	last_modified_by
,NULL	last_modified_dt
,r.pae_id pae_id
,coalesce(r.pae_rqst_dt   , '2022-09-17') as program_rqst_dt
, r.program_cd	program_type_cd
, r.legacy_id
,'A' as CONVERSION_RUN_STATUS
from   legacy.wrk_pasrr_clients w 
left join (select  *  from perlss.pae_rqst where  created_by='PASRR_CV') r    on r.legacy_id::text = w.maximus_reviewid::text
where  w.source_system_nm = 'MAXIMUS' 
and valid_sw= 'Y' and 	xref_valid_sw='Y'  and perlss_sw ='N'
)a where pae_id is not null
select 
nextval('perlss.hibernate_sequence') as ID,
concat('PSR',nextval('perlss.pasrr_rqst_0sq')) as PSR_ID,
 * from (
select distinct 
 ca.prsn_id	 	prsn_id
,b.reviewid	 	episode_id
,'CO'	status_cd
,'CNV'	source_cd
,'N'	rqst_sw
,r.pae_id	 	pae_id
,NULL	txn_id
,null	type_cd
,l1.Level1Outcome	lvl1_outcome_cd
,NULL	rqst_dt
,l1.Level1DeterminationDate	 	lvl1_deter_dt
,case when l1.Level1DeterminationEffectiveDate is not null then l1.Level1DeterminationEffectiveDate
			else l1.Level1DeterminationDate end	 	lvl1_eff_dt
,l1.Level1DeterminationEndDate	 	lvl1_end_dt
,l2.Level2Outcome	lvl2_outcome_cd
,l2.Level2DeterminationDate	 	lvl2_deter_dt
,case when l2.Level2DeterminationEffectiveDate is not null then l2.Level2DeterminationEffectiveDate 
			else l2.Level2DeterminationDate end	 	lvl2_eff_dt
,l2.Level2DeterminationEndDate	 	lvl2_end_dt
,case when expedited='True' then 'Y' when  expedited='False' then 'N' END	expedited_sw
,Null	 	revsn_of_pasrr_id
,l1.Level1SubmissionDate	submsn_dt
,l2.level2duetostatedate	due_dt
,NULL	last_modified_by
,NULL	last_modified_dt
,l2.reconof
,l2.assessmentid
,case when pop.loc_revisionof='0' then Null else pop.loc_revisionof end loc_revisionof 
from legacy.pasrr_events b
join legacy.pasrr_base_member_pop pop on b.eventid = pop.eventid 
left join (select distinct ssn, prsn_id from perlss.com_applcnt 
where active_sw='Y' and file_clearance_sw='Y') ca on ca.ssn::text = pop.maximus_ssn::text
left join legacy.pasrr_level_i l1 on  b.eventid =l1.eventid 
left join legacy.pasrr_level_ii l2 on  b.eventid =l2.eventid 
left join legacy.pasrr_loc  a on  a.eventid =b.eventid 
left join (select  distinct legacy_id,pae_id, prsn_id  from perlss.pae_rqst where  created_by='PASRR_CV') r  
on r.legacy_id::text = pop.maximus_reviewid::text
)a where a.prsn_id is not  null;




select 
 * from (
select distinct 
r.pae_id pae_id
,TO_CHAR(WoundCareDecubitusStartDate,'YYYYMMDD') as WoundCareDecubitusStartDate
,TO_CHAR(WoundCareOtherStartDate,'YYYYMMDD') as WoundCareOtherStartDate
,TO_CHAR(InjectionsInsulinStartDate,'YYYYMMDD') InjectionsInsulinStartDate
,TO_CHAR(InjectionsOtherStartDate,'YYYYMMDD') InjectionsOtherStartDate
,TO_CHAR(IntravenousFluidsStartDate,'YYYYMMDD') IntravenousFluidsStartDate
,TO_CHAR(IsolationPrecautionsStartDate,'YYYYMMDD') IsolationPrecautionsStartDate
,TO_CHAR(OccupationalTherapyStartDate,'YYYYMMDD') OccupationalTherapyStartDate
,TO_CHAR(PhysicalTherapyStartDate,'YYYYMMDD') PhysicalTherapyStartDate
,TO_CHAR(CatheterOstomyStartDate,'YYYYMMDD') CatheterOstomyStartDate
,TO_CHAR(SelfInjectionStartDate,'YYYYMMDD') SelfInjectionStartDate
,TO_CHAR(ParenteralNutritionStartDate,'YYYYMMDD') ParenteralNutritionStartDate
,TO_CHAR(TubeFeedingStartDate,'YYYYMMDD') TubeFeedingStartDate
,TO_CHAR(PeritonealDialysisStartDate,'YYYYMMDD') PeritonealDialysisStartDate
,TO_CHAR(PCAPumpStartDate,'YYYYMMDD') PCAPumpStartDate
,TO_CHAR(TracheostomyStartDate,'YYYYMMDD') TracheostomyStartDate
,TO_CHAR(WoundCareDecubitusEndDate,'YYYYMMDD') WoundCareDecubitusEndDate
,TO_CHAR(WoundCareOtherEndDate,'YYYYMMDD') WoundCareOtherEndDate
,TO_CHAR(InjectionsInsulinEndDate,'YYYYMMDD') InjectionsInsulinEndDate
,TO_CHAR(InjectionsOtherEndDate,'YYYYMMDD') InjectionsOtherEndDate
,TO_CHAR(IntravenousFluidsEndDate,'YYYYMMDD') IntravenousFluidsEndDate
,TO_CHAR(IsolationPrecautionsEndDate,'YYYYMMDD') IsolationPrecautionsEndDate
,TO_CHAR(OccupationalTherapyEndDate,'YYYYMMDD') OccupationalTherapyEndDate
,TO_CHAR(PhysicalTherapyEndDate,'YYYYMMDD') PhysicalTherapyEndDate
,TO_CHAR(CatheterOstomyEndDate,'YYYYMMDD') CatheterOstomyEndDate
,TO_CHAR(SelfInjectionEndDate,'YYYYMMDD') SelfInjectionEndDate
,TO_CHAR(ParenteralNutritionEndDate,'YYYYMMDD') ParenteralNutritionEndDate
,TO_CHAR(TubeFeedingEndDate,'YYYYMMDD') TubeFeedingEndDate
,TO_CHAR(PeritonealDialysisEndDate,'YYYYMMDD') PeritonealDialysisEndDate
,TO_CHAR(PCAPumpEndDate,'YYYYMMDD') PCAPumpEndDate
,TO_CHAR(TracheostomyEndDate,'YYYYMMDD')	TracheostomyEndDate
,'WCS'	WoundCareDecubitus
,'OWC'	WoundCareOther
,'ISS'	InjectionsInsulin
,'IOT'	InjectionsOther
,'INT'	IntravenousFluids
,'ISP'	IsolationPrecautions
,'OCT'	OccupationalTherapy
,'PHT'	PhysicalTherapy
,'TCO'	CatheterOstomy
,'TSI'	SelfInjection
,'TPN'	ParenteralNutrition
,'TFE'	TubeFeeding
,'PED'	PeritonealDialysis
,'PCA'	PCAPump
,'TRS'	Tracheostomy
--select count(1)
from legacy.pasrr_events b 
join legacy.wrk_pasrr_clients w on b.reviewid::bigint  = w.maximus_reviewid::bigint
left join (select  *  from perlss.pae_rqst where  created_by='PASRR_CV') r    on r.legacy_id::text = w.maximus_reviewid::text
left join legacy.pasrr_loc a on  b.eventid::text = a.eventid::text
where  w.source_system_nm = 'MAXIMUS' 
and valid_sw= 'Y' and 	xref_valid_sw='Y'   and perlss_sw ='N'
)a where pae_id is not null;




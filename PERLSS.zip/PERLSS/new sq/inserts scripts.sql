--com_applcnt
INSERT INTO perlss.com_applcnt
(id, prsn_id, first_name, middle_initial, last_name, suffix, dob_dt, ssn, alias_name_sw, alias_first_name, alias_middle_initial, alias_last_name, alias_suffix, gender_cd, active_sw, file_clearance_sw, ssn_aval_sw, dsgn_sw, inter_sw, interprt_lang, created_by, created_dt, last_modified_by, last_modified_dt, record_version, archived_dt, dod_dt, email_addr, cell_ph_num, home_ph_num, work_ph_num, pref_ph_type_cd, pref_lang_letters_cd, new_person_sw, american_sign_lang_cd, pref_lang_spkn_cd)
VALUES(62295, 6000016806, 'tom', 'A', 'test', NULL, '1962-06-01', '309680618', 'N', NULL, NULL, NULL, NULL, 'M', 'Y', 'Y', 'N', 'Y', 'N', 'EN', 'CV_1', '2022-09-17 00:00:00.000', NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'ENG', 'N', NULL, NULL);
INSERT INTO perlss.com_applcnt
(id, prsn_id, first_name, middle_initial, last_name, suffix, dob_dt, ssn, alias_name_sw, alias_first_name, alias_middle_initial, alias_last_name, alias_suffix, gender_cd, active_sw, file_clearance_sw, ssn_aval_sw, dsgn_sw, inter_sw, interprt_lang, created_by, created_dt, last_modified_by, last_modified_dt, record_version, archived_dt, dod_dt, email_addr, cell_ph_num, home_ph_num, work_ph_num, pref_ph_type_cd, pref_lang_letters_cd, new_person_sw, american_sign_lang_cd, pref_lang_spkn_cd)
VALUES(70260, 6000025750, 'Virat', 'W', 'Kohli', NULL, '1989-12-26', '351849313', 'N', NULL, NULL, NULL, NULL, 'M', 'Y', 'Y', 'N', 'Y', 'N', 'EN', 'CV_1', '2022-09-17 00:00:00.000', NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'ENG', 'N', NULL, NULL);
INSERT INTO perlss.com_applcnt
(id, prsn_id, first_name, middle_initial, last_name, suffix, dob_dt, ssn, alias_name_sw, alias_first_name, alias_middle_initial, alias_last_name, alias_suffix, gender_cd, active_sw, file_clearance_sw, ssn_aval_sw, dsgn_sw, inter_sw, interprt_lang, created_by, created_dt, last_modified_by, last_modified_dt, record_version, archived_dt, dod_dt, email_addr, cell_ph_num, home_ph_num, work_ph_num, pref_ph_type_cd, pref_lang_letters_cd, new_person_sw, american_sign_lang_cd, pref_lang_spkn_cd)
VALUES(103899, 6000048526, 'rohit', 'C', 'sharma', NULL, '1999-10-13', '412878566', 'N', NULL, NULL, NULL, NULL, 'M', 'Y', 'Y', 'N', 'Y', 'N', 'EN', 'CV_1', '2022-09-17 00:00:00.000', NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'ENG', 'N', NULL, NULL);




--pae_rqst
INSERT INTO perlss.pae_rqst
(id, pae_id, pdf_generated_sw, new_prsn_sw, program_cd, pae_rqst_dt, entity_type, grand_region_cd, user_id, recrtfctn_due_dt, ssi_applcatn_status_cd, submitted_enr_grp_cd, rqstd_enr_grp_cd, assigned_grp_submit_sw, grp3_intrst_sw, actual_discharge_dt, mopd_dt, begin_dt, closure_rsn_cd, closure_rsn_desc, closure_attestation_sw, due_dt, mode_cd, status_cd, archived_dt, created_by, created_dt, last_modified_by, last_modified_dt, record_version, pae_type_cd, ref_id, tmed_id, tns_id, prsn_id, legacy_id, entity_id, enroll_in_mfp_sw, chm_id, abandon_parta_sw, reassessment_due_dt)
VALUES(1847853430, 'PAE200113846', 'Y', 'N', 'CG1', '2024-10-29 12:06:00.000', 'Nursing Facilities', NULL, NULL, NULL, NULL, NULL, NULL, 'N', NULL, NULL, '2024-10-17 00:00:00.000', '2024-11-04', NULL, NULL, NULL, NULL, NULL, 'AA', NULL, 'PASRR_CV', '2025-01-13 00:00:00.000', 'CNV_PAEPDF_ADHOC', '2025-01-29 14:45:53.552', 1, 'TMD', NULL, NULL, NULL, 6000016806, '829521', 30045, NULL, NULL, NULL, NULL);
INSERT INTO perlss.pae_rqst
(id, pae_id, pdf_generated_sw, new_prsn_sw, program_cd, pae_rqst_dt, entity_type, grand_region_cd, user_id, recrtfctn_due_dt, ssi_applcatn_status_cd, submitted_enr_grp_cd, rqstd_enr_grp_cd, assigned_grp_submit_sw, grp3_intrst_sw, actual_discharge_dt, mopd_dt, begin_dt, closure_rsn_cd, closure_rsn_desc, closure_attestation_sw, due_dt, mode_cd, status_cd, archived_dt, created_by, created_dt, last_modified_by, last_modified_dt, record_version, pae_type_cd, ref_id, tmed_id, tns_id, prsn_id, legacy_id, entity_id, enroll_in_mfp_sw, chm_id, abandon_parta_sw, reassessment_due_dt)
VALUES(1847853657, 'PAE200114073', 'Y', 'N', 'CG1', '2024-12-19 12:24:00.000', 'MCO', NULL, NULL, NULL, NULL, NULL, NULL, 'N', NULL, NULL, '2024-12-27 00:00:00.000', '2024-12-23', NULL, NULL, NULL, NULL, NULL, 'AP', NULL, 'PASRR_CV', '2025-01-13 00:00:00.000', 'CNV_PAEPDF_ADHOC', '2025-01-29 14:45:04.903', 1, 'TMD', NULL, NULL, NULL, 6000025750, '845573', 802, NULL, NULL, NULL, NULL);
INSERT INTO perlss.pae_rqst
(id, pae_id, pdf_generated_sw, new_prsn_sw, program_cd, pae_rqst_dt, entity_type, grand_region_cd, user_id, recrtfctn_due_dt, ssi_applcatn_status_cd, submitted_enr_grp_cd, rqstd_enr_grp_cd, assigned_grp_submit_sw, grp3_intrst_sw, actual_discharge_dt, mopd_dt, begin_dt, closure_rsn_cd, closure_rsn_desc, closure_attestation_sw, due_dt, mode_cd, status_cd, archived_dt, created_by, created_dt, last_modified_by, last_modified_dt, record_version, pae_type_cd, ref_id, tmed_id, tns_id, prsn_id, legacy_id, entity_id, enroll_in_mfp_sw, chm_id, abandon_parta_sw, reassessment_due_dt)
VALUES(1847852908, 'PAE200113324', 'Y', 'N', 'CG1', '2024-05-28 09:23:00.000', NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'N', NULL, NULL, '2024-03-12 00:00:00.000', '2024-06-03', NULL, NULL, NULL, NULL, NULL, 'AP', NULL, 'PASRR_CV', '2025-01-13 00:00:00.000', 'CNV_PAEPDF_ADHOC', '2025-01-29 14:39:20.912', 1, 'TMD', NULL, NULL, NULL, 6000048526, '775479', 9999, NULL, NULL, NULL, NULL);

--pae_app_addr_dtl
INSERT INTO perlss.pae_app_addr_dtl
(id, pae_id, addr_format_cd, user_type_cd, addr_line_1, addr_line_2, city, state_cd, zip, zip_extsn, cnty_cd, military_po_cd, military_state_cd, addr_type_cd, validated_addr_cd, mail_addr_sw, created_dt, last_modified_by, last_modified_dt, record_version, archived_dt, created_by, delete_sw)
VALUES(1847862180, 'PAE200113846', 'USAD', 'APPL', '1113 E MOORE ST', NULL, 'TULLAHOMA', 'TN', '37388', NULL, '016', NULL, NULL, 'MA', NULL, 'Y', '2025-01-13 00:00:00.000', NULL, NULL, 0, NULL, 'PASRR_CV', NULL);
INSERT INTO perlss.pae_app_addr_dtl
(id, pae_id, addr_format_cd, user_type_cd, addr_line_1, addr_line_2, city, state_cd, zip, zip_extsn, cnty_cd, military_po_cd, military_state_cd, addr_type_cd, validated_addr_cd, mail_addr_sw, created_dt, last_modified_by, last_modified_dt, record_version, archived_dt, created_by, delete_sw)
VALUES(1847862354, 'PAE200113846', 'USAD', 'APPL', '1113 E MOORE ST', NULL, 'TULLAHOMA', 'TN', '37388', NULL, '016', NULL, NULL, 'PA', NULL, 'Y', '2025-01-13 00:00:00.000', NULL, NULL, 0, NULL, 'PASRR_CV', NULL);
INSERT INTO perlss.pae_app_addr_dtl
(id, pae_id, addr_format_cd, user_type_cd, addr_line_1, addr_line_2, city, state_cd, zip, zip_extsn, cnty_cd, military_po_cd, military_state_cd, addr_type_cd, validated_addr_cd, mail_addr_sw, created_dt, last_modified_by, last_modified_dt, record_version, archived_dt, created_by, delete_sw)
VALUES(1847861162, 'PAE200114073', 'USAD', 'APPL', '16 HUNTERS RIDGE DR', NULL, 'FAYETTEVILLE', 'TN', '37334', NULL, '052', NULL, NULL, 'PA', NULL, 'Y', '2025-01-13 00:00:00.000', NULL, NULL, 0, NULL, 'PASRR_CV', NULL);
INSERT INTO perlss.pae_app_addr_dtl
(id, pae_id, addr_format_cd, user_type_cd, addr_line_1, addr_line_2, city, state_cd, zip, zip_extsn, cnty_cd, military_po_cd, military_state_cd, addr_type_cd, validated_addr_cd, mail_addr_sw, created_dt, last_modified_by, last_modified_dt, record_version, archived_dt, created_by, delete_sw)
VALUES(1847862525, 'PAE200114073', 'USAD', 'APPL', '16 HUNTERS RIDGE DR', NULL, 'FAYETTEVILLE', 'TN', '37334', NULL, '052', NULL, NULL, 'MA', NULL, 'Y', '2025-01-13 00:00:00.000', NULL, NULL, 0, NULL, 'PASRR_CV', NULL);
INSERT INTO perlss.pae_app_addr_dtl
(id, pae_id, addr_format_cd, user_type_cd, addr_line_1, addr_line_2, city, state_cd, zip, zip_extsn, cnty_cd, military_po_cd, military_state_cd, addr_type_cd, validated_addr_cd, mail_addr_sw, created_dt, last_modified_by, last_modified_dt, record_version, archived_dt, created_by, delete_sw)
VALUES(1847861937, 'PAE200113324', 'USAD', 'APPL', '8312 W SHEEPNECK RD', NULL, 'MT PLEASANT', 'TN', '38474', NULL, '058', NULL, NULL, 'MA', NULL, 'Y', '2025-01-13 00:00:00.000', NULL, NULL, 0, NULL, 'PASRR_CV', NULL);
INSERT INTO perlss.pae_app_addr_dtl
(id, pae_id, addr_format_cd, user_type_cd, addr_line_1, addr_line_2, city, state_cd, zip, zip_extsn, cnty_cd, military_po_cd, military_state_cd, addr_type_cd, validated_addr_cd, mail_addr_sw, created_dt, last_modified_by, last_modified_dt, record_version, archived_dt, created_by, delete_sw)
VALUES(1847862578, 'PAE200113324', 'USAD', 'APPL', '8312 W SHEEPNECK RD', NULL, 'MT PLEASANT', 'TN', '38474', NULL, '058', NULL, NULL, 'PA', NULL, 'Y', '2025-01-13 00:00:00.000', NULL, NULL, 0, NULL, 'PASRR_CV', NULL);



--pae_lvng_arrgmnt
INSERT INTO perlss.pae_lvng_arrgmnt
(id, pae_id, curr_lvng_arrgmnt_cd, lvng_arrgmnt_desc, nursing_facility_name_cd, addr_line_1, addr_line_2, city, state_cd, zip, extsn, cnty_cd, ph_num, long_term_care_sw, phychiatric_hosp_sw, mental_hlth_sw, special_sch_sw, intlctl_disable_sw, phycl_disable_sw, none_sw, sch_outside_sw, admsn_dt, expctd_discharge_cd, anticipated_discharge_dt, incarceration_dt, anticipated_release_dt, created_dt, last_modified_by, last_modified_dt, record_version, archived_dt, created_by, othr_facility_name, org_id, org_loc_id, provider_id)
VALUES(1847910626, 'PAE200113846', 'MED', 'Vanderbilt Tullahoma Harton', NULL, '1801 NORTH JACKSON ST.', NULL, 'TULLAHOMA', 'TN', '37388', NULL, '016', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '2024-10-17', 'NES', NULL, NULL, NULL, '2025-01-13 00:00:00.000', NULL, NULL, 0, NULL, 'PASRR_CV', NULL, NULL, NULL, NULL);
INSERT INTO perlss.pae_lvng_arrgmnt
(id, pae_id, curr_lvng_arrgmnt_cd, lvng_arrgmnt_desc, nursing_facility_name_cd, addr_line_1, addr_line_2, city, state_cd, zip, extsn, cnty_cd, ph_num, long_term_care_sw, phychiatric_hosp_sw, mental_hlth_sw, special_sch_sw, intlctl_disable_sw, phycl_disable_sw, none_sw, sch_outside_sw, admsn_dt, expctd_discharge_cd, anticipated_discharge_dt, incarceration_dt, anticipated_release_dt, created_dt, last_modified_by, last_modified_dt, record_version, archived_dt, created_by, othr_facility_name, org_id, org_loc_id, provider_id)
VALUES(1847910606, 'PAE200114073', 'OTH', 'Conversion', NULL, '16 HUNTERS RIDGE DR', NULL, 'FAYETTEVILLE', 'TN', '37334', NULL, '052', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '2024-12-27', 'NES', NULL, NULL, NULL, '2025-01-13 00:00:00.000', NULL, NULL, 0, NULL, 'PASRR_CV', NULL, NULL, NULL, NULL);
INSERT INTO perlss.pae_lvng_arrgmnt
(id, pae_id, curr_lvng_arrgmnt_cd, lvng_arrgmnt_desc, nursing_facility_name_cd, addr_line_1, addr_line_2, city, state_cd, zip, extsn, cnty_cd, ph_num, long_term_care_sw, phychiatric_hosp_sw, mental_hlth_sw, special_sch_sw, intlctl_disable_sw, phycl_disable_sw, none_sw, sch_outside_sw, admsn_dt, expctd_discharge_cd, anticipated_discharge_dt, incarceration_dt, anticipated_release_dt, created_dt, last_modified_by, last_modified_dt, record_version, archived_dt, created_by, othr_facility_name, org_id, org_loc_id, provider_id)
VALUES(1847910436, 'PAE200113324', 'NFC', NULL, '307', '1245 E COLLEGE ST', NULL, 'PULASKI', 'TN', '38478', NULL, '028', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '2024-03-12', 'NES', NULL, NULL, NULL, '2025-01-13 00:00:00.000', NULL, NULL, 0, NULL, 'PASRR_CV', NULL, 307, 307, '7440296');


--pae_submission
INSERT INTO perlss.pae_submission
(id, pae_id, who_submitting_cd, signature, "comments", pae_recrtfctn_sw, pae_recrtfctn_ack_sw, created_dt, last_modified_by, last_modified_dt, record_version, archived_dt, created_by, cea_determn_cd, certificate_dt, submit_dt, revised_pae_sw, cea_sw)
VALUES(1847865164, 'PAE200113846', 'OTH', 'CV_402', NULL, NULL, 'N', '2025-01-13 00:00:00.000', NULL, NULL, 0, NULL, 'PASRR_CV', NULL, NULL, '2024-10-29 12:06:00.000', 'N', 'N');
INSERT INTO perlss.pae_submission
(id, pae_id, who_submitting_cd, signature, "comments", pae_recrtfctn_sw, pae_recrtfctn_ack_sw, created_dt, last_modified_by, last_modified_dt, record_version, archived_dt, created_by, cea_determn_cd, certificate_dt, submit_dt, revised_pae_sw, cea_sw)
VALUES(1847865391, 'PAE200114073', 'OTH', 'TNT7530', NULL, NULL, 'N', '2025-01-13 00:00:00.000', NULL, NULL, 0, NULL, 'PASRR_CV', NULL, NULL, '2024-12-19 12:24:00.000', 'N', 'N');
INSERT INTO perlss.pae_submission
(id, pae_id, who_submitting_cd, signature, "comments", pae_recrtfctn_sw, pae_recrtfctn_ack_sw, created_dt, last_modified_by, last_modified_dt, record_version, archived_dt, created_by, cea_determn_cd, certificate_dt, submit_dt, revised_pae_sw, cea_sw)
VALUES(1847864642, 'PAE200113324', 'OTH', 'CV_402', NULL, NULL, 'N', '2025-01-13 00:00:00.000', NULL, NULL, 0, NULL, 'PASRR_CV', NULL, NULL, '2024-05-28 09:23:00.000', 'N', 'N');


--pae_activities_lvng
INSERT INTO perlss.pae_activities_lvng
(id, pae_id, trnsfr_without_help_cd, walk_without_help_cd, eat_without_help_cd, wheelchair_capable_cd, toilet_without_help_cd, applcnt_incont_sw, incont_type_cd, incont_without_help_cd, catheter_ostomy_sw, cath_ost_whithout_help_cd, orientation_prsn_place_cd, communicate_wants_cd, follow_instructions_cd, self_admt_medication_cd, beh_problem_cd, created_dt, last_modified_by, last_modified_dt, record_version, archived_dt, created_by, total_submitted_fa_acuity_score)
VALUES(1847867056, 'PAE200113846', 'US', 'UN', 'AL', 'UN', 'UN', 'Y', 'BL', 'NE', 'N', NULL, 'UN', 'AL', 'AL', 'AL', 'NE', '2025-01-13 00:00:00.000', 'CV-ACTY-SCORE', '2025-01-29 09:51:26.381', 1, NULL, 'PASRR_CV', 8);
INSERT INTO perlss.pae_activities_lvng
(id, pae_id, trnsfr_without_help_cd, walk_without_help_cd, eat_without_help_cd, wheelchair_capable_cd, toilet_without_help_cd, applcnt_incont_sw, incont_type_cd, incont_without_help_cd, catheter_ostomy_sw, cath_ost_whithout_help_cd, orientation_prsn_place_cd, communicate_wants_cd, follow_instructions_cd, self_admt_medication_cd, beh_problem_cd, created_dt, last_modified_by, last_modified_dt, record_version, archived_dt, created_by, total_submitted_fa_acuity_score)
VALUES(1847867230, 'PAE200114073', 'NE', 'AL', 'NE', NULL, 'NE', 'Y', 'BL', 'NE', 'N', NULL, 'AL', 'AL', 'AL', 'AL', 'NE', '2025-01-13 00:00:00.000', 'CV-ACTY-SCORE', '2025-01-29 09:52:12.966', 1, NULL, 'PASRR_CV', 11);
INSERT INTO perlss.pae_activities_lvng
(id, pae_id, trnsfr_without_help_cd, walk_without_help_cd, eat_without_help_cd, wheelchair_capable_cd, toilet_without_help_cd, applcnt_incont_sw, incont_type_cd, incont_without_help_cd, catheter_ostomy_sw, cath_ost_whithout_help_cd, orientation_prsn_place_cd, communicate_wants_cd, follow_instructions_cd, self_admt_medication_cd, beh_problem_cd, created_dt, last_modified_by, last_modified_dt, record_version, archived_dt, created_by, total_submitted_fa_acuity_score)
VALUES(1847866879, 'PAE200113324', 'NE', 'NE', 'US', 'NE', 'NE', 'Y', 'BL', 'NE', 'N', 'NE', 'AL', 'AL', 'NE', 'AL', 'NE', '2025-01-13 00:00:00.000', 'CV-ACTY-SCORE', '2025-01-29 09:48:38.100', 1, NULL, 'PASRR_CV', 9);


--perlss.pae_program_selection
INSERT INTO perlss.pae_program_selection
(id, pae_id, program_type_cd, program_rqst_dt, choices_grp_3_sw, actual_discharge_dt, created_dt, last_modified_by, last_modified_dt, record_version, archived_dt, created_by)
VALUES(1847866458, 'PAE200113846', 'CG1', '2024-10-29', 'N', NULL, '2025-01-13 00:00:00.000', NULL, NULL, 0, NULL, 'PASRR_CV');
INSERT INTO perlss.pae_program_selection
(id, pae_id, program_type_cd, program_rqst_dt, choices_grp_3_sw, actual_discharge_dt, created_dt, last_modified_by, last_modified_dt, record_version, archived_dt, created_by)
VALUES(1847866685, 'PAE200114073', 'CG1', '2024-12-19', 'N', NULL, '2025-01-13 00:00:00.000', NULL, NULL, 0, NULL, 'PASRR_CV');
INSERT INTO perlss.pae_program_selection
(id, pae_id, program_type_cd, program_rqst_dt, choices_grp_3_sw, actual_discharge_dt, created_dt, last_modified_by, last_modified_dt, record_version, archived_dt, created_by)
VALUES(1847865936, 'PAE200113324', 'CG1', '2024-05-28', 'N', NULL, '2025-01-13 00:00:00.000', NULL, NULL, 0, NULL, 'PASRR_CV');

--pae_driver_flow
INSERT INTO perlss.pae_driver_flow
(id, program_cd, next_page, curr_page, pae_id, created_by, created_dt, last_modified_dt, record_version)
VALUES(1847904770, 'CG1', 'PPSPS', 'PPSRR', 'PAE200113846', 'PASRR_CV', '2025-01-13 00:00:00.000', '2025-01-13 00:00:00.000', NULL);
INSERT INTO perlss.pae_driver_flow
(id, program_cd, next_page, curr_page, pae_id, created_by, created_dt, last_modified_dt, record_version)
VALUES(1847909310, 'CG1', 'PPSPS', 'PPSRR', 'PAE200114073', 'PASRR_CV', '2025-01-13 00:00:00.000', '2025-01-13 00:00:00.000', NULL);
INSERT INTO perlss.pae_driver_flow
(id, program_cd, next_page, curr_page, pae_id, created_by, created_dt, last_modified_dt, record_version)
VALUES(1847894330, 'CG1', 'PPSPS', 'PPSRR', 'PAE200113324', 'PASRR_CV', '2025-01-13 00:00:00.000', '2025-01-13 00:00:00.000', NULL);

--pae_certify_of_assmnt
INSERT INTO perlss.pae_certify_of_assmnt
(id, pae_id, pae_crtfctn_dt, certifier_of_accuracy, credentials_cd, created_dt, last_modified_by, last_modified_dt, record_version, archived_dt, created_by, qualified_assessor_dtl, qualified_assessor_name, credential, certifier_name)
VALUES(1847882002, 'PAE200113846', '2024-10-15', '', NULL, '2025-01-13 00:00:00.000', NULL, NULL, 0, NULL, 'PASRR_CV', '', NULL, 'Conversion', 'Conversion');
INSERT INTO perlss.pae_certify_of_assmnt
(id, pae_id, pae_crtfctn_dt, certifier_of_accuracy, credentials_cd, created_dt, last_modified_by, last_modified_dt, record_version, archived_dt, created_by, qualified_assessor_dtl, qualified_assessor_name, credential, certifier_name)
VALUES(1847882039, 'PAE200114073', '2024-12-16', '', NULL, '2025-01-13 00:00:00.000', NULL, NULL, 0, NULL, 'PASRR_CV', '', 'Wellpoint', 'Conversion', 'Conversion');
INSERT INTO perlss.pae_certify_of_assmnt
(id, pae_id, pae_crtfctn_dt, certifier_of_accuracy, credentials_cd, created_dt, last_modified_by, last_modified_dt, record_version, archived_dt, created_by, qualified_assessor_dtl, qualified_assessor_name, credential, certifier_name)
VALUES(1847882608, 'PAE200113324', '2024-05-23', '', NULL, '2025-01-13 00:00:00.000', NULL, NULL, 0, NULL, 'PASRR_CV', '', 'AHC Meadowbrook', 'Conversion', 'Conversion');

--pae_medical_diagnosis
INSERT INTO perlss.pae_medical_diagnosis
(id, pae_id, intlctl_dis_sw, psyclgcl_eval_sw, lvl_intlctl_disblty_cd, iq_test_score, iq_test_dt, iq_test_type_desc, chrnc_diagns_sw, trgt_popltn_diagns_cd, doc_dtls_desc, created_dt, last_modified_by, last_modified_dt, record_version, archived_dt, created_by, id_diagns_doc_sw, iq_score_avail_sw, iq_score_nottest_sw, iq_score_not_avail_sw)
VALUES(1847878920, 'PAE200113846', NULL, NULL, '', NULL, NULL, NULL, 'Y', NULL, NULL, '2025-01-13 00:00:00.000', NULL, NULL, 0, NULL, 'PASRR_CV', NULL, NULL, NULL, NULL);
INSERT INTO perlss.pae_medical_diagnosis
(id, pae_id, intlctl_dis_sw, psyclgcl_eval_sw, lvl_intlctl_disblty_cd, iq_test_score, iq_test_dt, iq_test_type_desc, chrnc_diagns_sw, trgt_popltn_diagns_cd, doc_dtls_desc, created_dt, last_modified_by, last_modified_dt, record_version, archived_dt, created_by, id_diagns_doc_sw, iq_score_avail_sw, iq_score_nottest_sw, iq_score_not_avail_sw)
VALUES(1847879147, 'PAE200114073', NULL, NULL, '', NULL, NULL, NULL, 'Y', NULL, NULL, '2025-01-13 00:00:00.000', NULL, NULL, 0, NULL, 'PASRR_CV', NULL, NULL, NULL, NULL);
INSERT INTO perlss.pae_medical_diagnosis
(id, pae_id, intlctl_dis_sw, psyclgcl_eval_sw, lvl_intlctl_disblty_cd, iq_test_score, iq_test_dt, iq_test_type_desc, chrnc_diagns_sw, trgt_popltn_diagns_cd, doc_dtls_desc, created_dt, last_modified_by, last_modified_dt, record_version, archived_dt, created_by, id_diagns_doc_sw, iq_score_avail_sw, iq_score_nottest_sw, iq_score_not_avail_sw)
VALUES(1847878398, 'PAE200113324', NULL, NULL, '', NULL, NULL, NULL, 'Y', NULL, NULL, '2025-01-13 00:00:00.000', NULL, NULL, 0, NULL, 'PASRR_CV', NULL, NULL, NULL, NULL);

--pae_chrnc_med_diagns
INSERT INTO perlss.pae_chrnc_med_diagns
(id, med_diagns_cd, created_dt, last_modified_by, last_modified_dt, record_version, archived_dt, created_by, pae_diagns_id)
VALUES(1847881508, 'OT', '2025-01-13 00:00:00.000', NULL, NULL, 0, NULL, 'PASRR_CV', 1847878920);
INSERT INTO perlss.pae_chrnc_med_diagns
(id, med_diagns_cd, created_dt, last_modified_by, last_modified_dt, record_version, archived_dt, created_by, pae_diagns_id)
VALUES(1847880986, 'OT', '2025-01-13 00:00:00.000', NULL, NULL, 0, NULL, 'PASRR_CV', 1847878398);
INSERT INTO perlss.pae_chrnc_med_diagns
(id, med_diagns_cd, created_dt, last_modified_by, last_modified_dt, record_version, archived_dt, created_by, pae_diagns_id)
VALUES(1847881735, 'OT', '2025-01-13 00:00:00.000', NULL, NULL, 0, NULL, 'PASRR_CV', 1847879147);


--pae_chrnc_med_diagns
INSERT INTO perlss.pae_chrnc_med_diagns
(id, med_diagns_cd, created_dt, last_modified_by, last_modified_dt, record_version, archived_dt, created_by, pae_diagns_id)
VALUES(1847881508, 'OT', '2025-01-13 00:00:00.000', NULL, NULL, 0, NULL, 'PASRR_CV', 1847878920);
INSERT INTO perlss.pae_chrnc_med_diagns
(id, med_diagns_cd, created_dt, last_modified_by, last_modified_dt, record_version, archived_dt, created_by, pae_diagns_id)
VALUES(1847880986, 'OT', '2025-01-13 00:00:00.000', NULL, NULL, 0, NULL, 'PASRR_CV', 1847878398);
INSERT INTO perlss.pae_chrnc_med_diagns
(id, med_diagns_cd, created_dt, last_modified_by, last_modified_dt, record_version, archived_dt, created_by, pae_diagns_id)
VALUES(1847881735, 'OT', '2025-01-13 00:00:00.000', NULL, NULL, 0, NULL, 'PASRR_CV', 1847879147);

--pae_skilled_srvc_summary
INSERT INTO perlss.pae_skilled_srvc_summary
(id, pae_id, need_skilled_srvcs_sw, need_respiratory_care_sw, created_dt, last_modified_by, last_modified_dt, record_version, archived_dt, created_by, dsnt_need_srvcs_sw, total_submitted_skilled_srvcs_acuity_score)
VALUES(1847871339, 'PAE200113846', 'Y', 'N', '2025-01-13 00:00:00.000', 'CV-ACTY-SCORE', '2025-01-29 09:51:26.806', 1, NULL, 'PASRR_CV', 'N', 3);
INSERT INTO perlss.pae_skilled_srvc_summary
(id, pae_id, need_skilled_srvcs_sw, need_respiratory_care_sw, created_dt, last_modified_by, last_modified_dt, record_version, archived_dt, created_by, dsnt_need_srvcs_sw, total_submitted_skilled_srvcs_acuity_score)
VALUES(1847871028, 'PAE200114073', 'N', 'N', '2025-01-13 00:00:00.000', NULL, NULL, 0, NULL, 'PASRR_CV', 'Y', NULL);
INSERT INTO perlss.pae_skilled_srvc_summary
(id, pae_id, need_skilled_srvcs_sw, need_respiratory_care_sw, created_dt, last_modified_by, last_modified_dt, record_version, archived_dt, created_by, dsnt_need_srvcs_sw, total_submitted_skilled_srvcs_acuity_score)
VALUES(1847870512, 'PAE200113324', 'N', 'N', '2025-01-13 00:00:00.000', NULL, NULL, 0, NULL, 'PASRR_CV', 'Y', NULL);

--pae_safety_deter_sum
INSERT INTO perlss.pae_safety_deter_sum
(id, pae_id, req_safety_con_sw, nf_srvc_sw, hcbs_srvc_sw, tenncare_qualified_assessor_sw, created_dt, last_modified_by, last_modified_dt, record_version, archived_dt, created_by)
VALUES(1847875744, 'PAE200113846', 'Y', 'N', 'N', 'N', '2025-01-13 00:00:00.000', NULL, NULL, 0, NULL, 'PASRR_CV');
INSERT INTO perlss.pae_safety_deter_sum
(id, pae_id, req_safety_con_sw, nf_srvc_sw, hcbs_srvc_sw, tenncare_qualified_assessor_sw, created_dt, last_modified_by, last_modified_dt, record_version, archived_dt, created_by)
VALUES(1847876585, 'PAE200114073', 'N', 'Y', 'N', 'N', '2025-01-13 00:00:00.000', NULL, NULL, 0, NULL, 'PASRR_CV');
INSERT INTO perlss.pae_safety_deter_sum
(id, pae_id, req_safety_con_sw, nf_srvc_sw, hcbs_srvc_sw, tenncare_qualified_assessor_sw, created_dt, last_modified_by, last_modified_dt, record_version, archived_dt, created_by)
VALUES(1847875503, 'PAE200113324', 'Y', 'N', 'N', 'N', '2025-01-13 00:00:00.000', NULL, NULL, 0, NULL, 'PASRR_CV');


--pae_respiratory_care
INSERT INTO perlss.pae_respiratory_care
(id, pae_id, chrnc_ventilator_sw, chrnc_req_start_dt, chrnc_req_end_dt, tracheal_suction_sw, tracheal_req_start_dt, tracheal_req_end_dt, created_dt, last_modified_by, last_modified_dt, record_version, archived_dt, created_by)
VALUES(1847872450, 'PAE200113846', 'N', NULL, NULL, 'N', NULL, NULL, '2025-01-13 00:00:00.000', NULL, NULL, 0, NULL, 'PASRR_CV');
INSERT INTO perlss.pae_respiratory_care
(id, pae_id, chrnc_ventilator_sw, chrnc_req_start_dt, chrnc_req_end_dt, tracheal_suction_sw, tracheal_req_start_dt, tracheal_req_end_dt, created_dt, last_modified_by, last_modified_dt, record_version, archived_dt, created_by)
VALUES(1847872677, 'PAE200114073', 'N', NULL, NULL, 'N', NULL, NULL, '2025-01-13 00:00:00.000', NULL, NULL, 0, NULL, 'PASRR_CV');
INSERT INTO perlss.pae_respiratory_care
(id, pae_id, chrnc_ventilator_sw, chrnc_req_start_dt, chrnc_req_end_dt, tracheal_suction_sw, tracheal_req_start_dt, tracheal_req_end_dt, created_dt, last_modified_by, last_modified_dt, record_version, archived_dt, created_by)
VALUES(1847871931, 'PAE200113324', 'N', NULL, NULL, 'N', NULL, NULL, '2025-01-13 00:00:00.000', NULL, NULL, 0, NULL, 'PASRR_CV');


--pae_doc_summary
INSERT INTO perlss.pae_doc_summary
(id, pae_id, certifier_name, qual_assessor_cd, credential, pae_certification_dt, doc_id, doc_type_cd, npi, medicaid_id, created_dt, last_modified_by, last_modified_dt, record_version, archived_dt, created_by, mco_chklst_sw, mco_chklst_comments, cicp_sw, cicp_comments)
VALUES(1847873744, 'PAE200113846', 'Conversion', NULL, 'Conversion', NULL, NULL, 'CRT', NULL, NULL, '2025-01-13 00:00:00.000', NULL, NULL, 0, NULL, 'PASRR_CV', NULL, NULL, NULL, NULL);
INSERT INTO perlss.pae_doc_summary
(id, pae_id, certifier_name, qual_assessor_cd, credential, pae_certification_dt, doc_id, doc_type_cd, npi, medicaid_id, created_dt, last_modified_by, last_modified_dt, record_version, archived_dt, created_by, mco_chklst_sw, mco_chklst_comments, cicp_sw, cicp_comments)
VALUES(1847873971, 'PAE200114073', 'Conversion', NULL, 'Conversion', NULL, NULL, 'CRT', NULL, NULL, '2025-01-13 00:00:00.000', NULL, NULL, 0, NULL, 'PASRR_CV', NULL, NULL, NULL, NULL);
INSERT INTO perlss.pae_doc_summary
(id, pae_id, certifier_name, qual_assessor_cd, credential, pae_certification_dt, doc_id, doc_type_cd, npi, medicaid_id, created_dt, last_modified_by, last_modified_dt, record_version, archived_dt, created_by, mco_chklst_sw, mco_chklst_comments, cicp_sw, cicp_comments)
VALUES(1847873222, 'PAE200113324', 'Conversion', NULL, 'Conversion', NULL, NULL, 'CRT', NULL, NULL, '2025-01-13 00:00:00.000', NULL, NULL, 0, NULL, 'PASRR_CV', NULL, NULL, NULL, NULL);

--pae_action
INSERT INTO perlss.pae_action
(id, pae_id, pae_action_cd, entity_type, archived_dt, created_by, created_dt, last_modified_by, last_modified_dt, record_version, start_dt, end_dt, user_id, entity_id, rqstextension_sw)
VALUES(1847877621, 'PAE200113846', 'SUB', NULL, NULL, 'PASRR_CV', '2025-01-13 00:00:00.000', NULL, NULL, 0, '2024-10-29', NULL, 'CV_402', NULL, NULL);
INSERT INTO perlss.pae_action
(id, pae_id, pae_action_cd, entity_type, archived_dt, created_by, created_dt, last_modified_by, last_modified_dt, record_version, start_dt, end_dt, user_id, entity_id, rqstextension_sw)
VALUES(1847877848, 'PAE200114073', 'SUB', 'MCO', NULL, 'PASRR_CV', '2025-01-13 00:00:00.000', NULL, NULL, 0, '2024-12-19', NULL, 'TNT7530', 802, NULL);
INSERT INTO perlss.pae_action
(id, pae_id, pae_action_cd, entity_type, archived_dt, created_by, created_dt, last_modified_by, last_modified_dt, record_version, start_dt, end_dt, user_id, entity_id, rqstextension_sw)
VALUES(1847877104, 'PAE200113324', 'SUB', NULL, NULL, 'PASRR_CV', '2025-01-13 00:00:00.000', NULL, NULL, 0, '2024-05-28', NULL, 'CV_402', NULL, NULL);


--pae_activities_behavrl_dtl
INSERT INTO perlss.pae_activities_behavrl_dtl
(id, pae_id, pae_activities_lvng_id, beh_type, beh_intrvntn, created_dt, last_modified_by, last_modified_dt, record_version, archived_dt, created_by)
VALUES(1847869046, 'PAE200113846', 1847867056, 'Conversion', 'Conversion', '2025-01-13 00:00:00.000', NULL, NULL, 0, NULL, 'PASRR_CV');
INSERT INTO perlss.pae_activities_behavrl_dtl
(id, pae_id, pae_activities_lvng_id, beh_type, beh_intrvntn, created_dt, last_modified_by, last_modified_dt, record_version, archived_dt, created_by)
VALUES(1847869273, 'PAE200114073', 1847867230, 'Conversion', 'Conversion', '2025-01-13 00:00:00.000', NULL, NULL, 0, NULL, 'PASRR_CV');
INSERT INTO perlss.pae_activities_behavrl_dtl
(id, pae_id, pae_activities_lvng_id, beh_type, beh_intrvntn, created_dt, last_modified_by, last_modified_dt, record_version, archived_dt, created_by)
VALUES(1847868524, 'PAE200113324', 1847866879, 'Conversion', 'Conversion', '2025-01-13 00:00:00.000', NULL, NULL, 0, NULL, 'PASRR_CV');

--pae_sis_assessment
INSERT INTO perlss.pae_sis_assessment
(id, pae_id, sis_assmnt_comment, sis_outcome_cd, reason_dtl, sis_day_srvc_sw, sis_residential_srvc_sw, sis_pa_srvc_sw, created_by, created_dt, last_modified_by, last_modified_dt, record_version, archived_dt, sis_assmnt_doc_upload_dt, rsn_cd, othr_rsn_txt)
VALUES(1847884096, 'PAE200113846', '', NULL, '', NULL, NULL, NULL, 'PASRR_CV', '2025-01-13 00:00:00.000', NULL, NULL, 0, NULL, NULL, NULL, '');
INSERT INTO perlss.pae_sis_assessment
(id, pae_id, sis_assmnt_comment, sis_outcome_cd, reason_dtl, sis_day_srvc_sw, sis_residential_srvc_sw, sis_pa_srvc_sw, created_by, created_dt, last_modified_by, last_modified_dt, record_version, archived_dt, sis_assmnt_doc_upload_dt, rsn_cd, othr_rsn_txt)
VALUES(1847884323, 'PAE200114073', '', NULL, '', NULL, NULL, NULL, 'PASRR_CV', '2025-01-13 00:00:00.000', NULL, NULL, 0, NULL, NULL, NULL, '');
INSERT INTO perlss.pae_sis_assessment
(id, pae_id, sis_assmnt_comment, sis_outcome_cd, reason_dtl, sis_day_srvc_sw, sis_residential_srvc_sw, sis_pa_srvc_sw, created_by, created_dt, last_modified_by, last_modified_dt, record_version, archived_dt, sis_assmnt_doc_upload_dt, rsn_cd, othr_rsn_txt)
VALUES(1847883574, 'PAE200113324', '', NULL, '', NULL, NULL, NULL, 'PASRR_CV', '2025-01-13 00:00:00.000', NULL, NULL, 0, NULL, NULL, NULL, '');

--pae_safety_deter_form
INSERT INTO perlss.pae_safety_deter_form
(id, pae_id, acuity_scr_5_less_8_sw, intlctl_disblty_sw, intel_dis_mala_index12_sw, acuity_scr_2beh_sw, acuity_scr_3orinet_sw, acuity_scr_3mobility_trnsfr_sw, acuity_scr_2toileting_sw, chng_phycl_behavrl_sw, chng_phycl_behavrl_primary_care_sw, rcnt_fall_sw, rcnt_emrgnt_hospital_admsn_sw, self_negli_sw, rcnt_discharge_sw, cmpx_chrnc_sw, mco_determn_grp5_sw, no_criteria_met_grp5_sw, mco_determn_grp3_sw, no_criteria_met_grp3_sw, donot_believe_sw, do_believe_sw, req_applcnt_sw, credentials_cd, created_dt, last_modified_by, last_modified_dt, record_version, archived_dt, created_by, icap_score, qualified_assessor_name, qualified_assessor_id, do_believe_at_risk_sw, credential, choices_member_enrolled_sw, post_acute_inptnt_sw, app_resdce_cd, app_resdce_oth_txt, resdce_unable_desc, dis_mala_comments, atstn_dt, name_atstn, intlctl_disblty_icap_sw)
VALUES(1847875038, 'PAE200113846', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '2025-01-13 00:00:00.000', NULL, NULL, 0, NULL, 'PASRR_CV', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL);
INSERT INTO perlss.pae_safety_deter_form
(id, pae_id, acuity_scr_5_less_8_sw, intlctl_disblty_sw, intel_dis_mala_index12_sw, acuity_scr_2beh_sw, acuity_scr_3orinet_sw, acuity_scr_3mobility_trnsfr_sw, acuity_scr_2toileting_sw, chng_phycl_behavrl_sw, chng_phycl_behavrl_primary_care_sw, rcnt_fall_sw, rcnt_emrgnt_hospital_admsn_sw, self_negli_sw, rcnt_discharge_sw, cmpx_chrnc_sw, mco_determn_grp5_sw, no_criteria_met_grp5_sw, mco_determn_grp3_sw, no_criteria_met_grp3_sw, donot_believe_sw, do_believe_sw, req_applcnt_sw, credentials_cd, created_dt, last_modified_by, last_modified_dt, record_version, archived_dt, created_by, icap_score, qualified_assessor_name, qualified_assessor_id, do_believe_at_risk_sw, credential, choices_member_enrolled_sw, post_acute_inptnt_sw, app_resdce_cd, app_resdce_oth_txt, resdce_unable_desc, dis_mala_comments, atstn_dt, name_atstn, intlctl_disblty_icap_sw)
VALUES(1847875265, 'PAE200114073', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '2025-01-13 00:00:00.000', NULL, NULL, 0, NULL, 'PASRR_CV', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL);
INSERT INTO perlss.pae_safety_deter_form
(id, pae_id, acuity_scr_5_less_8_sw, intlctl_disblty_sw, intel_dis_mala_index12_sw, acuity_scr_2beh_sw, acuity_scr_3orinet_sw, acuity_scr_3mobility_trnsfr_sw, acuity_scr_2toileting_sw, chng_phycl_behavrl_sw, chng_phycl_behavrl_primary_care_sw, rcnt_fall_sw, rcnt_emrgnt_hospital_admsn_sw, self_negli_sw, rcnt_discharge_sw, cmpx_chrnc_sw, mco_determn_grp5_sw, no_criteria_met_grp5_sw, mco_determn_grp3_sw, no_criteria_met_grp3_sw, donot_believe_sw, do_believe_sw, req_applcnt_sw, credentials_cd, created_dt, last_modified_by, last_modified_dt, record_version, archived_dt, created_by, icap_score, qualified_assessor_name, qualified_assessor_id, do_believe_at_risk_sw, credential, choices_member_enrolled_sw, post_acute_inptnt_sw, app_resdce_cd, app_resdce_oth_txt, resdce_unable_desc, dis_mala_comments, atstn_dt, name_atstn, intlctl_disblty_icap_sw)
VALUES(1847874516, 'PAE200113324', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '2025-01-13 00:00:00.000', NULL, NULL, 0, NULL, 'PASRR_CV', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL);


--pae_skilled_srvc_dtl
INSERT INTO perlss.pae_skilled_srvc_dtl
(id, pae_id, program_cd, section_type_cd, rqstd_start_dt, rqstd_end_dt, created_dt, last_modified_by, last_modified_dt, record_version, archived_dt, created_by)
VALUES(1847869936, 'PAE200113846', 'CG1', 'OWC', '2024-10-10', '2024-11-08', '2025-01-13 00:00:00.000', NULL, NULL, 0, NULL, 'PASRR_CV');
INSERT INTO perlss.pae_skilled_srvc_dtl
(id, pae_id, program_cd, section_type_cd, rqstd_start_dt, rqstd_end_dt, created_dt, last_modified_by, last_modified_dt, record_version, archived_dt, created_by)
VALUES(1847869937, 'PAE200113846', 'CG1', 'PHT', '2024-10-12', '2024-11-08', '2025-01-13 00:00:00.000', NULL, NULL, 0, NULL, 'PASRR_CV');

--adj_rqst
INSERT INTO perlss.adj_rqst
(id, pae_id, adj_due_dt, adj_status_cd, assigned_user_id, pdf_generated_sw, override_sw, apl_override_sw, enr_grp_cd, loc_dcsn_cd, pae_eff_dt, pae_end_dt, recrtfctn_waive_sw, recrtfctn_due_dt, last_modified_by, last_modified_dt, record_version, created_by, created_dt, archived_dt, tns_id, prsn_id, loc_status_cd, active_sw, pae_exp_dt, adj_id, override_adj_id, entity_id, recrtfctn_status_cd, reassessment_due_dt, pae_expiration_lifted_sw, loc_dcsn_dt, adj_dcsn_dt)
VALUES(1847912601, 'PAE200113846', '2024-11-05', 'CO', NULL, 'Y', 'N', 'N', 'CG1', 'DNF', '2024-11-04', NULL, NULL, NULL, 'CNV_ADJPDF_ADHOC', '2025-01-31 12:15:02.202', 2, 'PASRR_CV', '2025-01-13 00:00:00.000', NULL, NULL, 6000016806, NULL, 'Y', NULL, 100112189, NULL, 30045, NULL, '2024-10-29 12:06:26.000', 'N', '2024-11-03 14:05:00.000', NULL);
INSERT INTO perlss.adj_rqst
(id, pae_id, adj_due_dt, adj_status_cd, assigned_user_id, pdf_generated_sw, override_sw, apl_override_sw, enr_grp_cd, loc_dcsn_cd, pae_eff_dt, pae_end_dt, recrtfctn_waive_sw, recrtfctn_due_dt, last_modified_by, last_modified_dt, record_version, created_by, created_dt, archived_dt, tns_id, prsn_id, loc_status_cd, active_sw, pae_exp_dt, adj_id, override_adj_id, entity_id, recrtfctn_status_cd, reassessment_due_dt, pae_expiration_lifted_sw, loc_dcsn_dt, adj_dcsn_dt)
VALUES(1847912828, 'PAE200114073', '2024-12-26', 'CO', NULL, 'Y', 'N', 'N', 'CG1', 'NWE', '2024-12-23', NULL, NULL, NULL, 'CNV_ADJPDF_ADHOC', '2025-01-31 12:22:55.777', 2, 'PASRR_CV', '2025-01-13 00:00:00.000', NULL, NULL, 6000025750, NULL, 'Y', NULL, 100112416, NULL, 802, NULL, '2024-12-19 12:24:20.000', 'N', '2024-12-23 10:24:00.000', NULL);
INSERT INTO perlss.adj_rqst
(id, pae_id, adj_due_dt, adj_status_cd, assigned_user_id, pdf_generated_sw, override_sw, apl_override_sw, enr_grp_cd, loc_dcsn_cd, pae_eff_dt, pae_end_dt, recrtfctn_waive_sw, recrtfctn_due_dt, last_modified_by, last_modified_dt, record_version, created_by, created_dt, archived_dt, tns_id, prsn_id, loc_status_cd, active_sw, pae_exp_dt, adj_id, override_adj_id, entity_id, recrtfctn_status_cd, reassessment_due_dt, pae_expiration_lifted_sw, loc_dcsn_dt, adj_dcsn_dt)
VALUES(1847912079, 'PAE200113324', '2024-06-04', 'CO', NULL, 'Y', 'N', 'N', 'CG1', 'NSE', '2024-06-03', '2024-09-01', NULL, NULL, 'CNV_ADJPDF_ADHOC', '2025-01-31 12:07:48.470', 2, 'PASRR_CV', '2025-01-13 00:00:00.000', NULL, NULL, 6000048526, NULL, 'Y', NULL, 100111667, NULL, 9999, NULL, '2024-05-28 09:23:11.000', 'N', '2024-06-03 08:01:00.000', NULL);

--adj_dtls
INSERT INTO perlss.adj_dtls
(id, adj_id, trgt_popltn_phy_diagns_sw, trgt_popltn_qual_fun_sw, trgt_popltn_not_meet_sw, sis_assmnt_req_sw, sis_lvl_of_need_cd, "comments", last_modified_by, last_modified_dt, record_version, created_by, created_dt, archived_dt, tp_id_sw, tp_dd_sw, lon_chng_sw, erc_chng_sw, cea_approved_sw, cost_cap_excp_approved_amt, cost_cap_excp_eff_dt, review_dcsn_cd, total_assessed_acty_score, total_assessed_rn_acty_score, total_assessed_apl_acty_score, total_assessed_aud_acty_score, total_adj_skilled_srvcs_acuity_score, total_submitted_skilled_srvcs_acuity_score, total_adj_acuity_score, cic_completed_sw, lon_dcsn_cd, case_ratio_cd, temp_lon_sw, total_acuity_score, total_apl_acuity_score, total_audit_acuity_score)
VALUES(1848336126, 100112189, 'N', 'N', 'Y', 'N', NULL, NULL, 'CV-ACTY-SCORE', '2025-01-31 10:11:35.397', 2, 'PASRR_CV', '2025-01-13 00:00:00.000', NULL, NULL, NULL, 'N', 'N', NULL, NULL, NULL, NULL, 8, 4, NULL, NULL, 0, 3, 4, NULL, NULL, NULL, 'N', 4, 0, NULL);
INSERT INTO perlss.adj_dtls
(id, adj_id, trgt_popltn_phy_diagns_sw, trgt_popltn_qual_fun_sw, trgt_popltn_not_meet_sw, sis_assmnt_req_sw, sis_lvl_of_need_cd, "comments", last_modified_by, last_modified_dt, record_version, created_by, created_dt, archived_dt, tp_id_sw, tp_dd_sw, lon_chng_sw, erc_chng_sw, cea_approved_sw, cost_cap_excp_approved_amt, cost_cap_excp_eff_dt, review_dcsn_cd, total_assessed_acty_score, total_assessed_rn_acty_score, total_assessed_apl_acty_score, total_assessed_aud_acty_score, total_adj_skilled_srvcs_acuity_score, total_submitted_skilled_srvcs_acuity_score, total_adj_acuity_score, cic_completed_sw, lon_dcsn_cd, case_ratio_cd, temp_lon_sw, total_acuity_score, total_apl_acuity_score, total_audit_acuity_score)
VALUES(1848336353, 100112416, 'N', 'N', 'Y', 'N', NULL, NULL, 'CV-ACTY-SCORE', '2025-01-31 10:13:47.827', 4, 'PASRR_CV', '2025-01-13 00:00:00.000', NULL, NULL, NULL, 'N', 'N', NULL, NULL, NULL, NULL, 11, 9, NULL, NULL, 0, 0, 9, NULL, NULL, NULL, 'N', 9, 0, NULL);
INSERT INTO perlss.adj_dtls
(id, adj_id, trgt_popltn_phy_diagns_sw, trgt_popltn_qual_fun_sw, trgt_popltn_not_meet_sw, sis_assmnt_req_sw, sis_lvl_of_need_cd, "comments", last_modified_by, last_modified_dt, record_version, created_by, created_dt, archived_dt, tp_id_sw, tp_dd_sw, lon_chng_sw, erc_chng_sw, cea_approved_sw, cost_cap_excp_approved_amt, cost_cap_excp_eff_dt, review_dcsn_cd, total_assessed_acty_score, total_assessed_rn_acty_score, total_assessed_apl_acty_score, total_assessed_aud_acty_score, total_adj_skilled_srvcs_acuity_score, total_submitted_skilled_srvcs_acuity_score, total_adj_acuity_score, cic_completed_sw, lon_dcsn_cd, case_ratio_cd, temp_lon_sw, total_acuity_score, total_apl_acuity_score, total_audit_acuity_score)
VALUES(1848335604, 100111667, 'N', 'N', 'Y', 'N', NULL, NULL, 'CV-ACTY-SCORE', '2025-01-31 10:09:30.496', 4, 'PASRR_CV', '2025-01-13 00:00:00.000', NULL, NULL, NULL, 'N', 'N', NULL, NULL, NULL, NULL, 9, 3, NULL, NULL, 0, 0, 3, NULL, NULL, NULL, 'N', 3, 0, NULL);

--adj_functnl_assmnt
INSERT INTO perlss.adj_functnl_assmnt
(id, adj_id, functnl_measure_cd, sbmttr_rsp_cd, sbmttr_cap_need_rsp_cd, sbmttr_acuity_cd, sbmttr_acuity_score_num, rn_action_cd, rn_approval_cd, rn_denial_cd, rn_comment, rn_acuity_score_num, apl_approval_cd, apl_denial_cd, apl_comment, apl_acuity_score_num, audit_approval_cd, audit_denial_cd, audit_comment, audit_acuity_score_num, "comments", last_modified_by, last_modified_dt, record_version, created_by, created_dt, archived_dt)
VALUES(1848348740, 100112189, 'TRAN', 'US', NULL, 'US', NULL, 'A', 'US', NULL, NULL, 1, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'CV-ACTY-SCORE', '2025-01-30 12:06:55.687', 1, 'PASRR_CV', '2025-01-13 00:00:00.000', NULL);
INSERT INTO perlss.adj_functnl_assmnt
(id, adj_id, functnl_measure_cd, sbmttr_rsp_cd, sbmttr_cap_need_rsp_cd, sbmttr_acuity_cd, sbmttr_acuity_score_num, rn_action_cd, rn_approval_cd, rn_denial_cd, rn_comment, rn_acuity_score_num, apl_approval_cd, apl_denial_cd, apl_comment, apl_acuity_score_num, audit_approval_cd, audit_denial_cd, audit_comment, audit_acuity_score_num, "comments", last_modified_by, last_modified_dt, record_version, created_by, created_dt, archived_dt)
VALUES(1848348741, 100112189, 'MOBL', 'UN', NULL, 'UN', NULL, 'A', 'UN', NULL, NULL, 2, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'CV-ACTY-SCORE', '2025-01-30 12:06:55.691', 1, 'PASRR_CV', '2025-01-13 00:00:00.000', NULL);
INSERT INTO perlss.adj_functnl_assmnt
(id, adj_id, functnl_measure_cd, sbmttr_rsp_cd, sbmttr_cap_need_rsp_cd, sbmttr_acuity_cd, sbmttr_acuity_score_num, rn_action_cd, rn_approval_cd, rn_denial_cd, rn_comment, rn_acuity_score_num, apl_approval_cd, apl_denial_cd, apl_comment, apl_acuity_score_num, audit_approval_cd, audit_denial_cd, audit_comment, audit_acuity_score_num, "comments", last_modified_by, last_modified_dt, record_version, created_by, created_dt, archived_dt)
VALUES(1848348742, 100112189, 'MOBW', 'UN', NULL, 'UN', NULL, 'D', NULL, 'INS', NULL, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'CV-ACTY-SCORE', '2025-01-30 12:06:55.695', 1, 'PASRR_CV', '2025-01-13 00:00:00.000', NULL);
INSERT INTO perlss.adj_functnl_assmnt
(id, adj_id, functnl_measure_cd, sbmttr_rsp_cd, sbmttr_cap_need_rsp_cd, sbmttr_acuity_cd, sbmttr_acuity_score_num, rn_action_cd, rn_approval_cd, rn_denial_cd, rn_comment, rn_acuity_score_num, apl_approval_cd, apl_denial_cd, apl_comment, apl_acuity_score_num, audit_approval_cd, audit_denial_cd, audit_comment, audit_acuity_score_num, "comments", last_modified_by, last_modified_dt, record_version, created_by, created_dt, archived_dt)
VALUES(1848348743, 100112189, 'EATG', 'AL', NULL, 'AL', NULL, 'A', 'AL', NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'CV-ACTY-SCORE', '2025-01-30 12:06:55.699', 1, 'PASRR_CV', '2025-01-13 00:00:00.000', NULL);
INSERT INTO perlss.adj_functnl_assmnt
(id, adj_id, functnl_measure_cd, sbmttr_rsp_cd, sbmttr_cap_need_rsp_cd, sbmttr_acuity_cd, sbmttr_acuity_score_num, rn_action_cd, rn_approval_cd, rn_denial_cd, rn_comment, rn_acuity_score_num, apl_approval_cd, apl_denial_cd, apl_comment, apl_acuity_score_num, audit_approval_cd, audit_denial_cd, audit_comment, audit_acuity_score_num, "comments", last_modified_by, last_modified_dt, record_version, created_by, created_dt, archived_dt)
VALUES(1848348744, 100112189, 'TLTG', 'UN', NULL, 'UN', NULL, 'D', NULL, 'INS', NULL, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'CV-ACTY-SCORE', '2025-01-30 12:06:55.703', 1, 'PASRR_CV', '2025-01-13 00:00:00.000', NULL);
INSERT INTO perlss.adj_functnl_assmnt
(id, adj_id, functnl_measure_cd, sbmttr_rsp_cd, sbmttr_cap_need_rsp_cd, sbmttr_acuity_cd, sbmttr_acuity_score_num, rn_action_cd, rn_approval_cd, rn_denial_cd, rn_comment, rn_acuity_score_num, apl_approval_cd, apl_denial_cd, apl_comment, apl_acuity_score_num, audit_approval_cd, audit_denial_cd, audit_comment, audit_acuity_score_num, "comments", last_modified_by, last_modified_dt, record_version, created_by, created_dt, archived_dt)
VALUES(1848348745, 100112189, 'TLTI', 'NE', NULL, 'NE', NULL, 'D', NULL, 'INS', NULL, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'CV-ACTY-SCORE', '2025-01-30 12:06:55.707', 1, 'PASRR_CV', '2025-01-13 00:00:00.000', NULL);
INSERT INTO perlss.adj_functnl_assmnt
(id, adj_id, functnl_measure_cd, sbmttr_rsp_cd, sbmttr_cap_need_rsp_cd, sbmttr_acuity_cd, sbmttr_acuity_score_num, rn_action_cd, rn_approval_cd, rn_denial_cd, rn_comment, rn_acuity_score_num, apl_approval_cd, apl_denial_cd, apl_comment, apl_acuity_score_num, audit_approval_cd, audit_denial_cd, audit_comment, audit_acuity_score_num, "comments", last_modified_by, last_modified_dt, record_version, created_by, created_dt, archived_dt)
VALUES(1848348746, 100112189, 'TLTC', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'CV-ACTY-SCORE', '2025-01-30 12:06:55.711', 1, 'PASRR_CV', '2025-01-13 00:00:00.000', NULL);
INSERT INTO perlss.adj_functnl_assmnt
(id, adj_id, functnl_measure_cd, sbmttr_rsp_cd, sbmttr_cap_need_rsp_cd, sbmttr_acuity_cd, sbmttr_acuity_score_num, rn_action_cd, rn_approval_cd, rn_denial_cd, rn_comment, rn_acuity_score_num, apl_approval_cd, apl_denial_cd, apl_comment, apl_acuity_score_num, audit_approval_cd, audit_denial_cd, audit_comment, audit_acuity_score_num, "comments", last_modified_by, last_modified_dt, record_version, created_by, created_dt, archived_dt)
VALUES(1848348747, 100112189, 'ORNT', 'UN', NULL, 'UN', NULL, 'A', 'UN', NULL, NULL, 3, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'CV-ACTY-SCORE', '2025-01-30 12:06:55.714', 1, 'PASRR_CV', '2025-01-13 00:00:00.000', NULL);
INSERT INTO perlss.adj_functnl_assmnt
(id, adj_id, functnl_measure_cd, sbmttr_rsp_cd, sbmttr_cap_need_rsp_cd, sbmttr_acuity_cd, sbmttr_acuity_score_num, rn_action_cd, rn_approval_cd, rn_denial_cd, rn_comment, rn_acuity_score_num, apl_approval_cd, apl_denial_cd, apl_comment, apl_acuity_score_num, audit_approval_cd, audit_denial_cd, audit_comment, audit_acuity_score_num, "comments", last_modified_by, last_modified_dt, record_version, created_by, created_dt, archived_dt)
VALUES(1848348748, 100112189, 'ECOM', 'AL', NULL, 'AL', NULL, 'A', 'AL', NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'CV-ACTY-SCORE', '2025-01-30 12:06:55.718', 1, 'PASRR_CV', '2025-01-13 00:00:00.000', NULL);
INSERT INTO perlss.adj_functnl_assmnt
(id, adj_id, functnl_measure_cd, sbmttr_rsp_cd, sbmttr_cap_need_rsp_cd, sbmttr_acuity_cd, sbmttr_acuity_score_num, rn_action_cd, rn_approval_cd, rn_denial_cd, rn_comment, rn_acuity_score_num, apl_approval_cd, apl_denial_cd, apl_comment, apl_acuity_score_num, audit_approval_cd, audit_denial_cd, audit_comment, audit_acuity_score_num, "comments", last_modified_by, last_modified_dt, record_version, created_by, created_dt, archived_dt)
VALUES(1848348749, 100112189, 'RCOM', 'AL', NULL, 'AL', NULL, 'A', 'AL', NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'CV-ACTY-SCORE', '2025-01-30 12:06:55.722', 1, 'PASRR_CV', '2025-01-13 00:00:00.000', NULL);
INSERT INTO perlss.adj_functnl_assmnt
(id, adj_id, functnl_measure_cd, sbmttr_rsp_cd, sbmttr_cap_need_rsp_cd, sbmttr_acuity_cd, sbmttr_acuity_score_num, rn_action_cd, rn_approval_cd, rn_denial_cd, rn_comment, rn_acuity_score_num, apl_approval_cd, apl_denial_cd, apl_comment, apl_acuity_score_num, audit_approval_cd, audit_denial_cd, audit_comment, audit_acuity_score_num, "comments", last_modified_by, last_modified_dt, record_version, created_by, created_dt, archived_dt)
VALUES(1848348750, 100112189, 'MEDC', 'NE', NULL, 'NE', NULL, 'D', NULL, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'CV-ACTY-SCORE', '2025-01-30 12:06:55.727', 1, 'PASRR_CV', '2025-01-13 00:00:00.000', NULL);
INSERT INTO perlss.adj_functnl_assmnt
(id, adj_id, functnl_measure_cd, sbmttr_rsp_cd, sbmttr_cap_need_rsp_cd, sbmttr_acuity_cd, sbmttr_acuity_score_num, rn_action_cd, rn_approval_cd, rn_denial_cd, rn_comment, rn_acuity_score_num, apl_approval_cd, apl_denial_cd, apl_comment, apl_acuity_score_num, audit_approval_cd, audit_denial_cd, audit_comment, audit_acuity_score_num, "comments", last_modified_by, last_modified_dt, record_version, created_by, created_dt, archived_dt)
VALUES(1848348751, 100112189, 'BHVR', 'NE', NULL, 'NE', NULL, 'A', 'NE', NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'CV-ACTY-SCORE', '2025-01-30 12:06:55.732', 1, 'PASRR_CV', '2025-01-13 00:00:00.000', NULL);
INSERT INTO perlss.adj_functnl_assmnt
(id, adj_id, functnl_measure_cd, sbmttr_rsp_cd, sbmttr_cap_need_rsp_cd, sbmttr_acuity_cd, sbmttr_acuity_score_num, rn_action_cd, rn_approval_cd, rn_denial_cd, rn_comment, rn_acuity_score_num, apl_approval_cd, apl_denial_cd, apl_comment, apl_acuity_score_num, audit_approval_cd, audit_denial_cd, audit_comment, audit_acuity_score_num, "comments", last_modified_by, last_modified_dt, record_version, created_by, created_dt, archived_dt)
VALUES(1848351464, 100112416, 'TRAN', 'NE', NULL, 'NE', NULL, 'A', 'NE', NULL, NULL, 4, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'CV-ACTY-SCORE', '2025-01-30 12:08:38.826', 1, 'PASRR_CV', '2025-01-13 00:00:00.000', NULL);
INSERT INTO perlss.adj_functnl_assmnt
(id, adj_id, functnl_measure_cd, sbmttr_rsp_cd, sbmttr_cap_need_rsp_cd, sbmttr_acuity_cd, sbmttr_acuity_score_num, rn_action_cd, rn_approval_cd, rn_denial_cd, rn_comment, rn_acuity_score_num, apl_approval_cd, apl_denial_cd, apl_comment, apl_acuity_score_num, audit_approval_cd, audit_denial_cd, audit_comment, audit_acuity_score_num, "comments", last_modified_by, last_modified_dt, record_version, created_by, created_dt, archived_dt)
VALUES(1848351465, 100112416, 'MOBL', 'AL', NULL, 'AL', NULL, 'A', 'AL', NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'CV-ACTY-SCORE', '2025-01-30 12:08:38.830', 1, 'PASRR_CV', '2025-01-13 00:00:00.000', NULL);
INSERT INTO perlss.adj_functnl_assmnt
(id, adj_id, functnl_measure_cd, sbmttr_rsp_cd, sbmttr_cap_need_rsp_cd, sbmttr_acuity_cd, sbmttr_acuity_score_num, rn_action_cd, rn_approval_cd, rn_denial_cd, rn_comment, rn_acuity_score_num, apl_approval_cd, apl_denial_cd, apl_comment, apl_acuity_score_num, audit_approval_cd, audit_denial_cd, audit_comment, audit_acuity_score_num, "comments", last_modified_by, last_modified_dt, record_version, created_by, created_dt, archived_dt)
VALUES(1848351466, 100112416, 'MOBW', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'CV-ACTY-SCORE', '2025-01-30 12:08:38.834', 1, 'PASRR_CV', '2025-01-13 00:00:00.000', NULL);
INSERT INTO perlss.adj_functnl_assmnt
(id, adj_id, functnl_measure_cd, sbmttr_rsp_cd, sbmttr_cap_need_rsp_cd, sbmttr_acuity_cd, sbmttr_acuity_score_num, rn_action_cd, rn_approval_cd, rn_denial_cd, rn_comment, rn_acuity_score_num, apl_approval_cd, apl_denial_cd, apl_comment, apl_acuity_score_num, audit_approval_cd, audit_denial_cd, audit_comment, audit_acuity_score_num, "comments", last_modified_by, last_modified_dt, record_version, created_by, created_dt, archived_dt)
VALUES(1848351467, 100112416, 'EATG', 'NE', NULL, 'NE', NULL, 'D', NULL, 'INS', NULL, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'CV-ACTY-SCORE', '2025-01-30 12:08:38.839', 1, 'PASRR_CV', '2025-01-13 00:00:00.000', NULL);
INSERT INTO perlss.adj_functnl_assmnt
(id, adj_id, functnl_measure_cd, sbmttr_rsp_cd, sbmttr_cap_need_rsp_cd, sbmttr_acuity_cd, sbmttr_acuity_score_num, rn_action_cd, rn_approval_cd, rn_denial_cd, rn_comment, rn_acuity_score_num, apl_approval_cd, apl_denial_cd, apl_comment, apl_acuity_score_num, audit_approval_cd, audit_denial_cd, audit_comment, audit_acuity_score_num, "comments", last_modified_by, last_modified_dt, record_version, created_by, created_dt, archived_dt)
VALUES(1848351468, 100112416, 'TLTG', 'NE', NULL, 'NE', NULL, 'A', 'NE', NULL, NULL, 2, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'CV-ACTY-SCORE', '2025-01-30 12:08:38.843', 1, 'PASRR_CV', '2025-01-13 00:00:00.000', NULL);
INSERT INTO perlss.adj_functnl_assmnt
(id, adj_id, functnl_measure_cd, sbmttr_rsp_cd, sbmttr_cap_need_rsp_cd, sbmttr_acuity_cd, sbmttr_acuity_score_num, rn_action_cd, rn_approval_cd, rn_denial_cd, rn_comment, rn_acuity_score_num, apl_approval_cd, apl_denial_cd, apl_comment, apl_acuity_score_num, audit_approval_cd, audit_denial_cd, audit_comment, audit_acuity_score_num, "comments", last_modified_by, last_modified_dt, record_version, created_by, created_dt, archived_dt)
VALUES(1848351469, 100112416, 'TLTI', 'NE', NULL, 'NE', NULL, 'A', 'NE', NULL, NULL, 3, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'CV-ACTY-SCORE', '2025-01-30 12:08:38.847', 1, 'PASRR_CV', '2025-01-13 00:00:00.000', NULL);
INSERT INTO perlss.adj_functnl_assmnt
(id, adj_id, functnl_measure_cd, sbmttr_rsp_cd, sbmttr_cap_need_rsp_cd, sbmttr_acuity_cd, sbmttr_acuity_score_num, rn_action_cd, rn_approval_cd, rn_denial_cd, rn_comment, rn_acuity_score_num, apl_approval_cd, apl_denial_cd, apl_comment, apl_acuity_score_num, audit_approval_cd, audit_denial_cd, audit_comment, audit_acuity_score_num, "comments", last_modified_by, last_modified_dt, record_version, created_by, created_dt, archived_dt)
VALUES(1848351470, 100112416, 'TLTC', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'CV-ACTY-SCORE', '2025-01-30 12:08:38.852', 1, 'PASRR_CV', '2025-01-13 00:00:00.000', NULL);
INSERT INTO perlss.adj_functnl_assmnt
(id, adj_id, functnl_measure_cd, sbmttr_rsp_cd, sbmttr_cap_need_rsp_cd, sbmttr_acuity_cd, sbmttr_acuity_score_num, rn_action_cd, rn_approval_cd, rn_denial_cd, rn_comment, rn_acuity_score_num, apl_approval_cd, apl_denial_cd, apl_comment, apl_acuity_score_num, audit_approval_cd, audit_denial_cd, audit_comment, audit_acuity_score_num, "comments", last_modified_by, last_modified_dt, record_version, created_by, created_dt, archived_dt)
VALUES(1848351471, 100112416, 'ORNT', 'AL', NULL, 'AL', NULL, 'A', 'AL', NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'CV-ACTY-SCORE', '2025-01-30 12:08:38.856', 1, 'PASRR_CV', '2025-01-13 00:00:00.000', NULL);
INSERT INTO perlss.adj_functnl_assmnt
(id, adj_id, functnl_measure_cd, sbmttr_rsp_cd, sbmttr_cap_need_rsp_cd, sbmttr_acuity_cd, sbmttr_acuity_score_num, rn_action_cd, rn_approval_cd, rn_denial_cd, rn_comment, rn_acuity_score_num, apl_approval_cd, apl_denial_cd, apl_comment, apl_acuity_score_num, audit_approval_cd, audit_denial_cd, audit_comment, audit_acuity_score_num, "comments", last_modified_by, last_modified_dt, record_version, created_by, created_dt, archived_dt)
VALUES(1848351472, 100112416, 'ECOM', 'AL', NULL, 'AL', NULL, 'A', 'AL', NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'CV-ACTY-SCORE', '2025-01-30 12:08:38.860', 1, 'PASRR_CV', '2025-01-13 00:00:00.000', NULL);
INSERT INTO perlss.adj_functnl_assmnt
(id, adj_id, functnl_measure_cd, sbmttr_rsp_cd, sbmttr_cap_need_rsp_cd, sbmttr_acuity_cd, sbmttr_acuity_score_num, rn_action_cd, rn_approval_cd, rn_denial_cd, rn_comment, rn_acuity_score_num, apl_approval_cd, apl_denial_cd, apl_comment, apl_acuity_score_num, audit_approval_cd, audit_denial_cd, audit_comment, audit_acuity_score_num, "comments", last_modified_by, last_modified_dt, record_version, created_by, created_dt, archived_dt)
VALUES(1848351473, 100112416, 'RCOM', 'AL', NULL, 'AL', NULL, 'A', 'AL', NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'CV-ACTY-SCORE', '2025-01-30 12:08:38.864', 1, 'PASRR_CV', '2025-01-13 00:00:00.000', NULL);
INSERT INTO perlss.adj_functnl_assmnt
(id, adj_id, functnl_measure_cd, sbmttr_rsp_cd, sbmttr_cap_need_rsp_cd, sbmttr_acuity_cd, sbmttr_acuity_score_num, rn_action_cd, rn_approval_cd, rn_denial_cd, rn_comment, rn_acuity_score_num, apl_approval_cd, apl_denial_cd, apl_comment, apl_acuity_score_num, audit_approval_cd, audit_denial_cd, audit_comment, audit_acuity_score_num, "comments", last_modified_by, last_modified_dt, record_version, created_by, created_dt, archived_dt)
VALUES(1848351474, 100112416, 'MEDC', 'NE', NULL, 'NE', NULL, 'A', 'NE', NULL, NULL, 2, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'CV-ACTY-SCORE', '2025-01-30 12:08:38.868', 1, 'PASRR_CV', '2025-01-13 00:00:00.000', NULL);
INSERT INTO perlss.adj_functnl_assmnt
(id, adj_id, functnl_measure_cd, sbmttr_rsp_cd, sbmttr_cap_need_rsp_cd, sbmttr_acuity_cd, sbmttr_acuity_score_num, rn_action_cd, rn_approval_cd, rn_denial_cd, rn_comment, rn_acuity_score_num, apl_approval_cd, apl_denial_cd, apl_comment, apl_acuity_score_num, audit_approval_cd, audit_denial_cd, audit_comment, audit_acuity_score_num, "comments", last_modified_by, last_modified_dt, record_version, created_by, created_dt, archived_dt)
VALUES(1848351475, 100112416, 'BHVR', 'NE', NULL, 'NE', NULL, 'A', 'NE', NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'CV-ACTY-SCORE', '2025-01-30 12:08:38.872', 1, 'PASRR_CV', '2025-01-13 00:00:00.000', NULL);
INSERT INTO perlss.adj_functnl_assmnt
(id, adj_id, functnl_measure_cd, sbmttr_rsp_cd, sbmttr_cap_need_rsp_cd, sbmttr_acuity_cd, sbmttr_acuity_score_num, rn_action_cd, rn_approval_cd, rn_denial_cd, rn_comment, rn_acuity_score_num, apl_approval_cd, apl_denial_cd, apl_comment, apl_acuity_score_num, audit_approval_cd, audit_denial_cd, audit_comment, audit_acuity_score_num, "comments", last_modified_by, last_modified_dt, record_version, created_by, created_dt, archived_dt)
VALUES(1848342476, 100111667, 'TRAN', 'NE', NULL, 'NE', NULL, 'D', NULL, 'COT', NULL, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'CV-ACTY-SCORE', '2025-01-30 12:05:23.420', 1, 'PASRR_CV', '2025-01-13 00:00:00.000', NULL);
INSERT INTO perlss.adj_functnl_assmnt
(id, adj_id, functnl_measure_cd, sbmttr_rsp_cd, sbmttr_cap_need_rsp_cd, sbmttr_acuity_cd, sbmttr_acuity_score_num, rn_action_cd, rn_approval_cd, rn_denial_cd, rn_comment, rn_acuity_score_num, apl_approval_cd, apl_denial_cd, apl_comment, apl_acuity_score_num, audit_approval_cd, audit_denial_cd, audit_comment, audit_acuity_score_num, "comments", last_modified_by, last_modified_dt, record_version, created_by, created_dt, archived_dt)
VALUES(1848342477, 100111667, 'MOBL', 'NE', NULL, 'NE', NULL, 'A', 'NE', NULL, NULL, 3, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'CV-ACTY-SCORE', '2025-01-30 12:05:23.424', 1, 'PASRR_CV', '2025-01-13 00:00:00.000', NULL);
INSERT INTO perlss.adj_functnl_assmnt
(id, adj_id, functnl_measure_cd, sbmttr_rsp_cd, sbmttr_cap_need_rsp_cd, sbmttr_acuity_cd, sbmttr_acuity_score_num, rn_action_cd, rn_approval_cd, rn_denial_cd, rn_comment, rn_acuity_score_num, apl_approval_cd, apl_denial_cd, apl_comment, apl_acuity_score_num, audit_approval_cd, audit_denial_cd, audit_comment, audit_acuity_score_num, "comments", last_modified_by, last_modified_dt, record_version, created_by, created_dt, archived_dt)
VALUES(1848342478, 100111667, 'MOBW', 'NE', NULL, 'NE', NULL, 'D', NULL, 'COT', NULL, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'CV-ACTY-SCORE', '2025-01-30 12:05:23.429', 1, 'PASRR_CV', '2025-01-13 00:00:00.000', NULL);
INSERT INTO perlss.adj_functnl_assmnt
(id, adj_id, functnl_measure_cd, sbmttr_rsp_cd, sbmttr_cap_need_rsp_cd, sbmttr_acuity_cd, sbmttr_acuity_score_num, rn_action_cd, rn_approval_cd, rn_denial_cd, rn_comment, rn_acuity_score_num, apl_approval_cd, apl_denial_cd, apl_comment, apl_acuity_score_num, audit_approval_cd, audit_denial_cd, audit_comment, audit_acuity_score_num, "comments", last_modified_by, last_modified_dt, record_version, created_by, created_dt, archived_dt)
VALUES(1848342479, 100111667, 'EATG', 'US', NULL, 'US', NULL, 'D', NULL, 'COT', NULL, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'CV-ACTY-SCORE', '2025-01-30 12:05:23.433', 1, 'PASRR_CV', '2025-01-13 00:00:00.000', NULL);
INSERT INTO perlss.adj_functnl_assmnt
(id, adj_id, functnl_measure_cd, sbmttr_rsp_cd, sbmttr_cap_need_rsp_cd, sbmttr_acuity_cd, sbmttr_acuity_score_num, rn_action_cd, rn_approval_cd, rn_denial_cd, rn_comment, rn_acuity_score_num, apl_approval_cd, apl_denial_cd, apl_comment, apl_acuity_score_num, audit_approval_cd, audit_denial_cd, audit_comment, audit_acuity_score_num, "comments", last_modified_by, last_modified_dt, record_version, created_by, created_dt, archived_dt)
VALUES(1848342480, 100111667, 'TLTG', 'NE', NULL, 'NE', NULL, 'A', 'NE', NULL, NULL, 2, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'CV-ACTY-SCORE', '2025-01-30 12:05:23.436', 1, 'PASRR_CV', '2025-01-13 00:00:00.000', NULL);
INSERT INTO perlss.adj_functnl_assmnt
(id, adj_id, functnl_measure_cd, sbmttr_rsp_cd, sbmttr_cap_need_rsp_cd, sbmttr_acuity_cd, sbmttr_acuity_score_num, rn_action_cd, rn_approval_cd, rn_denial_cd, rn_comment, rn_acuity_score_num, apl_approval_cd, apl_denial_cd, apl_comment, apl_acuity_score_num, audit_approval_cd, audit_denial_cd, audit_comment, audit_acuity_score_num, "comments", last_modified_by, last_modified_dt, record_version, created_by, created_dt, archived_dt)
VALUES(1848342481, 100111667, 'TLTI', 'NE', NULL, 'NE', NULL, 'A', 'NE', NULL, NULL, 3, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'CV-ACTY-SCORE', '2025-01-30 12:05:23.440', 1, 'PASRR_CV', '2025-01-13 00:00:00.000', NULL);
INSERT INTO perlss.adj_functnl_assmnt
(id, adj_id, functnl_measure_cd, sbmttr_rsp_cd, sbmttr_cap_need_rsp_cd, sbmttr_acuity_cd, sbmttr_acuity_score_num, rn_action_cd, rn_approval_cd, rn_denial_cd, rn_comment, rn_acuity_score_num, apl_approval_cd, apl_denial_cd, apl_comment, apl_acuity_score_num, audit_approval_cd, audit_denial_cd, audit_comment, audit_acuity_score_num, "comments", last_modified_by, last_modified_dt, record_version, created_by, created_dt, archived_dt)
VALUES(1848342482, 100111667, 'TLTC', 'NE', NULL, 'NE', NULL, 'D', NULL, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'CV-ACTY-SCORE', '2025-01-30 12:05:23.444', 1, 'PASRR_CV', '2025-01-13 00:00:00.000', NULL);
INSERT INTO perlss.adj_functnl_assmnt
(id, adj_id, functnl_measure_cd, sbmttr_rsp_cd, sbmttr_cap_need_rsp_cd, sbmttr_acuity_cd, sbmttr_acuity_score_num, rn_action_cd, rn_approval_cd, rn_denial_cd, rn_comment, rn_acuity_score_num, apl_approval_cd, apl_denial_cd, apl_comment, apl_acuity_score_num, audit_approval_cd, audit_denial_cd, audit_comment, audit_acuity_score_num, "comments", last_modified_by, last_modified_dt, record_version, created_by, created_dt, archived_dt)
VALUES(1848342483, 100111667, 'ORNT', 'AL', NULL, 'AL', NULL, 'A', 'AL', NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'CV-ACTY-SCORE', '2025-01-30 12:05:23.448', 1, 'PASRR_CV', '2025-01-13 00:00:00.000', NULL);
INSERT INTO perlss.adj_functnl_assmnt
(id, adj_id, functnl_measure_cd, sbmttr_rsp_cd, sbmttr_cap_need_rsp_cd, sbmttr_acuity_cd, sbmttr_acuity_score_num, rn_action_cd, rn_approval_cd, rn_denial_cd, rn_comment, rn_acuity_score_num, apl_approval_cd, apl_denial_cd, apl_comment, apl_acuity_score_num, audit_approval_cd, audit_denial_cd, audit_comment, audit_acuity_score_num, "comments", last_modified_by, last_modified_dt, record_version, created_by, created_dt, archived_dt)
VALUES(1848342484, 100111667, 'ECOM', 'AL', NULL, 'AL', NULL, 'A', 'AL', NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'CV-ACTY-SCORE', '2025-01-30 12:05:23.452', 1, 'PASRR_CV', '2025-01-13 00:00:00.000', NULL);
INSERT INTO perlss.adj_functnl_assmnt
(id, adj_id, functnl_measure_cd, sbmttr_rsp_cd, sbmttr_cap_need_rsp_cd, sbmttr_acuity_cd, sbmttr_acuity_score_num, rn_action_cd, rn_approval_cd, rn_denial_cd, rn_comment, rn_acuity_score_num, apl_approval_cd, apl_denial_cd, apl_comment, apl_acuity_score_num, audit_approval_cd, audit_denial_cd, audit_comment, audit_acuity_score_num, "comments", last_modified_by, last_modified_dt, record_version, created_by, created_dt, archived_dt)
VALUES(1848342485, 100111667, 'RCOM', 'NE', NULL, 'NE', NULL, 'D', NULL, 'COT', NULL, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'CV-ACTY-SCORE', '2025-01-30 12:05:23.456', 1, 'PASRR_CV', '2025-01-13 00:00:00.000', NULL);
INSERT INTO perlss.adj_functnl_assmnt
(id, adj_id, functnl_measure_cd, sbmttr_rsp_cd, sbmttr_cap_need_rsp_cd, sbmttr_acuity_cd, sbmttr_acuity_score_num, rn_action_cd, rn_approval_cd, rn_denial_cd, rn_comment, rn_acuity_score_num, apl_approval_cd, apl_denial_cd, apl_comment, apl_acuity_score_num, audit_approval_cd, audit_denial_cd, audit_comment, audit_acuity_score_num, "comments", last_modified_by, last_modified_dt, record_version, created_by, created_dt, archived_dt)
VALUES(1848342486, 100111667, 'MEDC', 'NE', NULL, 'NE', NULL, 'D', NULL, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'CV-ACTY-SCORE', '2025-01-30 12:05:23.460', 1, 'PASRR_CV', '2025-01-13 00:00:00.000', NULL);
INSERT INTO perlss.adj_functnl_assmnt
(id, adj_id, functnl_measure_cd, sbmttr_rsp_cd, sbmttr_cap_need_rsp_cd, sbmttr_acuity_cd, sbmttr_acuity_score_num, rn_action_cd, rn_approval_cd, rn_denial_cd, rn_comment, rn_acuity_score_num, apl_approval_cd, apl_denial_cd, apl_comment, apl_acuity_score_num, audit_approval_cd, audit_denial_cd, audit_comment, audit_acuity_score_num, "comments", last_modified_by, last_modified_dt, record_version, created_by, created_dt, archived_dt)
VALUES(1848342487, 100111667, 'BHVR', 'NE', NULL, 'NE', NULL, 'A', 'NE', NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'CV-ACTY-SCORE', '2025-01-30 12:05:23.464', 1, 'PASRR_CV', '2025-01-13 00:00:00.000', NULL);

--adj_pasrr_outcome
INSERT INTO perlss.adj_pasrr_outcome
(id, adj_id, lvl1_submit_dt, payor_src_cd, lvl1_dcsn_cd, lvl1_dcsn_dt, lvl2_dcsn_cd, lvl2_eff_dt, lvl2_end_dt, created_dt, created_by, last_modified_by, last_modified_dt, record_version, archived_dt, pasrr_id, source_cd, type_cd, lvl1_eff_dt, lvl1_end_dt, lvl2_dcsn_dt, link_sw, episode_id)
VALUES(1847935418, 100112189, NULL, 'MD', NULL, NULL, 'DEN', '2024-11-04', NULL, '2025-01-13 00:00:00.000', 'PASRR_CV', NULL, NULL, 0, NULL, 'PSR100596083', 'CNV', 'T', NULL, NULL, '2024-11-04', 'Y', '829521');
INSERT INTO perlss.adj_pasrr_outcome
(id, adj_id, lvl1_submit_dt, payor_src_cd, lvl1_dcsn_cd, lvl1_dcsn_dt, lvl2_dcsn_cd, lvl2_eff_dt, lvl2_end_dt, created_dt, created_by, last_modified_by, last_modified_dt, record_version, archived_dt, pasrr_id, source_cd, type_cd, lvl1_eff_dt, lvl1_end_dt, lvl2_dcsn_dt, link_sw, episode_id)
VALUES(1847935645, 100112416, '2024-12-16', 'MD', 'REF', '2024-12-16', 'LTA', '2024-12-23', NULL, '2025-01-13 00:00:00.000', 'PASRR_CV', NULL, NULL, 0, NULL, 'PSR100596644', 'CNV', 'T', '2024-12-16', NULL, '2024-12-23', 'Y', '845573');
INSERT INTO perlss.adj_pasrr_outcome
(id, adj_id, lvl1_submit_dt, payor_src_cd, lvl1_dcsn_cd, lvl1_dcsn_dt, lvl2_dcsn_cd, lvl2_eff_dt, lvl2_end_dt, created_dt, created_by, last_modified_by, last_modified_dt, record_version, archived_dt, pasrr_id, source_cd, type_cd, lvl1_eff_dt, lvl1_end_dt, lvl2_dcsn_dt, link_sw, episode_id)
VALUES(1847934896, 100111667, '2024-05-23', 'MD', 'REF', '2024-05-23', 'STA', '2024-06-03', '2024-09-01', '2025-01-13 00:00:00.000', 'PASRR_CV', NULL, NULL, 0, NULL, 'PSR100597933', 'CNV', 'T', '2024-05-23', NULL, '2024-06-03', 'Y', '775479');


--adj_skilled_srvcs
INSERT INTO perlss.adj_skilled_srvcs
(id, adj_id, srvc_name_cd, rqst_eff_dt, rqst_end_dt, approved_eff_dt, approved_end_dt, acuity_score, adjctor_rsp_cd, tracheal_scrn_req_sw, "comments", created_dt, created_by, last_modified_by, last_modified_dt, record_version, archived_dt)
VALUES(1847931610, 100112189, 'OWC', '2024-10-10', '2024-11-08', NULL, NULL, 0, 'D', 'N', ' The documentation does not show wounds that are infected, dehisced, require a wound vac or the presence of 3 or more stage 3 or 4 decubitus wounds.  	  ', '2025-01-13 00:00:00.000', 'PASRR_CV', NULL, NULL, 0, NULL);
INSERT INTO perlss.adj_skilled_srvcs
(id, adj_id, srvc_name_cd, rqst_eff_dt, rqst_end_dt, approved_eff_dt, approved_end_dt, acuity_score, adjctor_rsp_cd, tracheal_scrn_req_sw, "comments", created_dt, created_by, last_modified_by, last_modified_dt, record_version, archived_dt)
VALUES(1847931611, 100112189, 'PHT', '2024-10-12', '2024-11-08', NULL, NULL, 0, 'D', 'N', 'There is no documentation provided of a physician s order specifying frequency greater than 5x/week, duration, or diagnosis for the requested therapy services. Please be advised: Skilled therapy services cannot be used for chronic conditions or generalize', '2025-01-13 00:00:00.000', 'PASRR_CV', NULL, NULL, 0, NULL);

--adj_safety_determn
INSERT INTO perlss.adj_safety_determn
(id, adj_id, ltss_safety_dcsn_cd, safety_assmnt_req_sw, "comments", created_dt, created_by, last_modified_by, last_modified_dt, record_version, archived_dt)
VALUES(1847936712, 100112189, 'CV', 'Y', 'Uploaded the  Safety doc from Maximus', '2025-01-13 00:00:00.000', 'PASRR_CV', NULL, NULL, 0, NULL);
INSERT INTO perlss.adj_safety_determn
(id, adj_id, ltss_safety_dcsn_cd, safety_assmnt_req_sw, "comments", created_dt, created_by, last_modified_by, last_modified_dt, record_version, archived_dt)
VALUES(1847936939, 100112416, 'CV', 'N', 'Uploaded the  Safety doc from Maximus', '2025-01-13 00:00:00.000', 'PASRR_CV', NULL, NULL, 0, NULL);
INSERT INTO perlss.adj_safety_determn
(id, adj_id, ltss_safety_dcsn_cd, safety_assmnt_req_sw, "comments", created_dt, created_by, last_modified_by, last_modified_dt, record_version, archived_dt)
VALUES(1847936190, 100111667, 'CV', 'Y', 'Uploaded the  Safety doc from Maximus', '2025-01-13 00:00:00.000', 'PASRR_CV', NULL, NULL, 0, NULL);

--adj_skilled_srvcs_info
INSERT INTO perlss.adj_skilled_srvcs_info
(id, adj_id, "comments", last_modified_by, last_modified_dt, record_version, created_by, created_dt, archived_dt)
VALUES(1847932830, 100112189, NULL, NULL, NULL, 0, 'PASRR_CV', '2025-01-13 00:00:00.000', NULL);
INSERT INTO perlss.adj_skilled_srvcs_info
(id, adj_id, "comments", last_modified_by, last_modified_dt, record_version, created_by, created_dt, archived_dt)
VALUES(1847933057, 100112416, NULL, NULL, NULL, 0, 'PASRR_CV', '2025-01-13 00:00:00.000', NULL);
INSERT INTO perlss.adj_skilled_srvcs_info
(id, adj_id, "comments", last_modified_by, last_modified_dt, record_version, created_by, created_dt, archived_dt)
VALUES(1847932308, 100111667, NULL, NULL, NULL, 0, 'PASRR_CV', '2025-01-13 00:00:00.000', NULL);

--adj_clrfcn_rsn
INSERT INTO perlss.adj_clrfcn_rsn
(id, created_dt, created_by, last_modified_by, last_modified_dt, record_version, archived_dt, rsn_flag_sw, rsn_cd, rsn_type_cd, adj_id, clrfcn_comment_txt)
VALUES(1847934124, '2025-01-13 00:00:00.000', 'PASRR_CV', NULL, NULL, 0, NULL, 'Y', 'NA', 'NA', 100112189, NULL);
INSERT INTO perlss.adj_clrfcn_rsn
(id, created_dt, created_by, last_modified_by, last_modified_dt, record_version, archived_dt, rsn_flag_sw, rsn_cd, rsn_type_cd, adj_id, clrfcn_comment_txt)
VALUES(1847934351, '2025-01-13 00:00:00.000', 'PASRR_CV', NULL, NULL, 0, NULL, 'Y', 'NA', 'NA', 100112416, NULL);
INSERT INTO perlss.adj_clrfcn_rsn
(id, created_dt, created_by, last_modified_by, last_modified_dt, record_version, archived_dt, rsn_flag_sw, rsn_cd, rsn_type_cd, adj_id, clrfcn_comment_txt)
VALUES(1847933602, '2025-01-13 00:00:00.000', 'PASRR_CV', NULL, NULL, 0, NULL, 'Y', 'NA', 'NA', 100111667, NULL);


INSERT INTO perlss.pasrr_rqst
(id, prsn_id, pasrr_id, episode_id, status_cd, source_cd, pae_id, type_cd, txn_id, rqst_sw, lvl1_outcome_cd, rqst_dt, lvl1_deter_dt, lvl1_eff_dt, lvl1_end_dt, lvl2_outcome_cd, lvl2_deter_dt, lvl2_eff_dt, lvl2_end_dt, expedited_sw, revsn_of_pasrr_id, submit_dt, due_dt, archived_dt, created_by, created_dt, last_modified_by, last_modified_dt, record_version, lookup_update_sw, nt_update_sw)
VALUES(1847855454, 6000016806, 'PSR100596084', '835570', 'CO', 'CNV', NULL, 'O', NULL, 'N', 'NEG', NULL, '2024-11-15', '2024-11-15', NULL, NULL, NULL, NULL, NULL, NULL, NULL, '2024-11-14', NULL, NULL, 'PASRR_CV', '2025-01-13 00:00:00.000', NULL, NULL, 0, 'Y', 'Y');
INSERT INTO perlss.pasrr_rqst
(id, prsn_id, pasrr_id, episode_id, status_cd, source_cd, pae_id, type_cd, txn_id, rqst_sw, lvl1_outcome_cd, rqst_dt, lvl1_deter_dt, lvl1_eff_dt, lvl1_end_dt, lvl2_outcome_cd, lvl2_deter_dt, lvl2_eff_dt, lvl2_end_dt, expedited_sw, revsn_of_pasrr_id, submit_dt, due_dt, archived_dt, created_by, created_dt, last_modified_by, last_modified_dt, record_version, lookup_update_sw, nt_update_sw)
VALUES(1847855448, 6000016806, 'PSR100596078', '751715', 'CO', 'CNV', NULL, 'O', NULL, 'N', 'NEG', NULL, '2024-03-14', '2024-03-14', NULL, NULL, NULL, NULL, NULL, NULL, NULL, '2024-03-14', NULL, NULL, 'PASRR_CV', '2025-01-13 00:00:00.000', NULL, NULL, 0, 'Y', 'Y');
INSERT INTO perlss.pasrr_rqst
(id, prsn_id, pasrr_id, episode_id, status_cd, source_cd, pae_id, type_cd, txn_id, rqst_sw, lvl1_outcome_cd, rqst_dt, lvl1_deter_dt, lvl1_eff_dt, lvl1_end_dt, lvl2_outcome_cd, lvl2_deter_dt, lvl2_eff_dt, lvl2_end_dt, expedited_sw, revsn_of_pasrr_id, submit_dt, due_dt, archived_dt, created_by, created_dt, last_modified_by, last_modified_dt, record_version, lookup_update_sw, nt_update_sw)
VALUES(1847855449, 6000016806, 'PSR100596079', '757284', 'CO', 'CNV', NULL, 'O', NULL, 'N', 'NEG', NULL, '2024-03-29', '2024-03-29', NULL, NULL, NULL, NULL, NULL, NULL, NULL, '2024-03-29', NULL, NULL, 'PASRR_CV', '2025-01-13 00:00:00.000', NULL, NULL, 0, 'Y', 'Y');
INSERT INTO perlss.pasrr_rqst
(id, prsn_id, pasrr_id, episode_id, status_cd, source_cd, pae_id, type_cd, txn_id, rqst_sw, lvl1_outcome_cd, rqst_dt, lvl1_deter_dt, lvl1_eff_dt, lvl1_end_dt, lvl2_outcome_cd, lvl2_deter_dt, lvl2_eff_dt, lvl2_end_dt, expedited_sw, revsn_of_pasrr_id, submit_dt, due_dt, archived_dt, created_by, created_dt, last_modified_by, last_modified_dt, record_version, lookup_update_sw, nt_update_sw)
VALUES(1847855450, 6000016806, 'PSR100596080', '760412', 'CO', 'CNV', NULL, 'O', NULL, 'N', 'NEG', NULL, '2024-04-09', '2024-04-09', NULL, NULL, NULL, NULL, NULL, NULL, NULL, '2024-04-09', NULL, NULL, 'PASRR_CV', '2025-01-13 00:00:00.000', NULL, NULL, 0, 'Y', 'Y');
INSERT INTO perlss.pasrr_rqst
(id, prsn_id, pasrr_id, episode_id, status_cd, source_cd, pae_id, type_cd, txn_id, rqst_sw, lvl1_outcome_cd, rqst_dt, lvl1_deter_dt, lvl1_eff_dt, lvl1_end_dt, lvl2_outcome_cd, lvl2_deter_dt, lvl2_eff_dt, lvl2_end_dt, expedited_sw, revsn_of_pasrr_id, submit_dt, due_dt, archived_dt, created_by, created_dt, last_modified_by, last_modified_dt, record_version, lookup_update_sw, nt_update_sw)
VALUES(1847856012, 6000025750, 'PSR100596642', '65751', 'CO', 'CNV', NULL, 'O', NULL, 'N', 'NEG', NULL, '2017-07-31', '2017-07-31', NULL, NULL, NULL, NULL, NULL, NULL, NULL, '2017-07-31', NULL, NULL, 'PASRR_CV', '2025-01-13 00:00:00.000', NULL, NULL, 0, 'Y', 'Y');
INSERT INTO perlss.pasrr_rqst
(id, prsn_id, pasrr_id, episode_id, status_cd, source_cd, pae_id, type_cd, txn_id, rqst_sw, lvl1_outcome_cd, rqst_dt, lvl1_deter_dt, lvl1_eff_dt, lvl1_end_dt, lvl2_outcome_cd, lvl2_deter_dt, lvl2_eff_dt, lvl2_end_dt, expedited_sw, revsn_of_pasrr_id, submit_dt, due_dt, archived_dt, created_by, created_dt, last_modified_by, last_modified_dt, record_version, lookup_update_sw, nt_update_sw)
VALUES(1847856013, 6000025750, 'PSR100596643', '74184', 'CO', 'CNV', NULL, 'O', NULL, 'N', 'NEG', NULL, '2017-09-01', '2017-09-01', NULL, NULL, NULL, NULL, NULL, NULL, NULL, '2017-09-01', NULL, NULL, 'PASRR_CV', '2025-01-13 00:00:00.000', NULL, NULL, 0, 'Y', 'Y');
INSERT INTO perlss.pasrr_rqst
(id, prsn_id, pasrr_id, episode_id, status_cd, source_cd, pae_id, type_cd, txn_id, rqst_sw, lvl1_outcome_cd, rqst_dt, lvl1_deter_dt, lvl1_eff_dt, lvl1_end_dt, lvl2_outcome_cd, lvl2_deter_dt, lvl2_eff_dt, lvl2_end_dt, expedited_sw, revsn_of_pasrr_id, submit_dt, due_dt, archived_dt, created_by, created_dt, last_modified_by, last_modified_dt, record_version, lookup_update_sw, nt_update_sw)
VALUES(1847857293, 6000048526, 'PSR100597923', '425989', 'CO', 'CNV', NULL, 'O', NULL, 'N', 'NEG', NULL, '2021-02-25', '2021-02-25', NULL, NULL, NULL, NULL, NULL, NULL, NULL, '2021-02-24', NULL, NULL, 'PASRR_CV', '2025-01-13 00:00:00.000', NULL, NULL, 0, 'Y', 'Y');





INSERT INTO perlss.pasrr_demo_dtls
(id, pasrr_id, last_name, middle_initial, first_name, dob_dt, ssn, gender_cd, archived_dt, created_by, created_dt, last_modified_by, last_modified_dt, record_version)
VALUES(1848018649, 'PSR100596084', 'test', 'A', 'tom', '1962-06-01', '309680618', 'M', NULL, 'PASRR_CV', '2025-01-13 00:00:00.000', NULL, NULL, 0);
INSERT INTO perlss.pasrr_demo_dtls
(id, pasrr_id, last_name, middle_initial, first_name, dob_dt, ssn, gender_cd, archived_dt, created_by, created_dt, last_modified_by, last_modified_dt, record_version)
VALUES(1848020712, 'PSR100596078', 'test', 'A', 'tom', '1962-06-01', '309680618', 'M', NULL, 'PASRR_CV', '2025-01-13 00:00:00.000', NULL, NULL, 0);
INSERT INTO perlss.pasrr_demo_dtls
(id, pasrr_id, last_name, middle_initial, first_name, dob_dt, ssn, gender_cd, archived_dt, created_by, created_dt, last_modified_by, last_modified_dt, record_version)
VALUES(1848017945, 'PSR100596079', 'test', 'A', 'tom', '1962-06-01', '309680618', 'M', NULL, 'PASRR_CV', '2025-01-13 00:00:00.000', NULL, NULL, 0);
INSERT INTO perlss.pasrr_demo_dtls
(id, pasrr_id, last_name, middle_initial, first_name, dob_dt, ssn, gender_cd, archived_dt, created_by, created_dt, last_modified_by, last_modified_dt, record_version)
VALUES(1848018580, 'PSR100596080', 'test', 'A', 'tom', '1962-06-01', '309680618', 'M', NULL, 'PASRR_CV', '2025-01-13 00:00:00.000', NULL, NULL, 0);
INSERT INTO perlss.pasrr_demo_dtls
(id, pasrr_id, last_name, middle_initial, first_name, dob_dt, ssn, gender_cd, archived_dt, created_by, created_dt, last_modified_by, last_modified_dt, record_version)
VALUES(1848018714, 'PSR100596642', 'Kohli', 'W', 'Virat', '1989-12-26', '351849313', 'M', NULL, 'PASRR_CV', '2025-01-13 00:00:00.000', NULL, NULL, 0);
INSERT INTO perlss.pasrr_demo_dtls
(id, pasrr_id, last_name, middle_initial, first_name, dob_dt, ssn, gender_cd, archived_dt, created_by, created_dt, last_modified_by, last_modified_dt, record_version)
VALUES(1848020855, 'PSR100596643', 'Kohli', 'W', 'Virat', '1989-12-26', '351849313', 'M', NULL, 'PASRR_CV', '2025-01-13 00:00:00.000', NULL, NULL, 0);
INSERT INTO perlss.pasrr_demo_dtls
(id, pasrr_id, last_name, middle_initial, first_name, dob_dt, ssn, gender_cd, archived_dt, created_by, created_dt, last_modified_by, last_modified_dt, record_version)
VALUES(1848017449, 'PSR100597923', 'sharma', 'C', 'rohit', '1999-10-13', '412878566', 'M', NULL, 'PASRR_CV', '2025-01-13 00:00:00.000', NULL, NULL, 0);



INSERT INTO perlss.pasrr_addr_dtl
(id, pasrr_id, first_name, middle_name, last_name, suffix, user_type_cd, addr_line_1, addr_line_2, city, state_cd, zip, zip_extsn, cnty_cd, current_location, current_location_facility, admtng_facility_name, archived_dt, created_by, created_dt, last_modified_by, last_modified_dt, record_version)
VALUES(1848007520, 'PSR100596084', '', NULL, '', NULL, 'APPL', '315 Adair St', NULL, 'Tullahoma', 'TN', '37388', NULL, 'COFF', 'Community setting/home', NULL, NULL, NULL, 'PASRR_CV', '2025-01-13 00:00:00.000', NULL, NULL, 0);
INSERT INTO perlss.pasrr_addr_dtl
(id, pasrr_id, first_name, middle_name, last_name, suffix, user_type_cd, addr_line_1, addr_line_2, city, state_cd, zip, zip_extsn, cnty_cd, current_location, current_location_facility, admtng_facility_name, archived_dt, created_by, created_dt, last_modified_by, last_modified_dt, record_version)
VALUES(1848007521, 'PSR100596084', '', NULL, '', NULL, 'CL', '315 Adair St', NULL, 'Tullahoma', 'TN', '37388', NULL, '', 'Community setting/home', NULL, NULL, NULL, 'PASRR_CV', '2025-01-13 00:00:00.000', NULL, NULL, 0);
INSERT INTO perlss.pasrr_addr_dtl
(id, pasrr_id, first_name, middle_name, last_name, suffix, user_type_cd, addr_line_1, addr_line_2, city, state_cd, zip, zip_extsn, cnty_cd, current_location, current_location_facility, admtng_facility_name, archived_dt, created_by, created_dt, last_modified_by, last_modified_dt, record_version)
VALUES(1848007508, 'PSR100596078', '', NULL, '', NULL, 'APPL', '113 East Moore', NULL, 'Tullahoma', 'TN', '37388', NULL, 'COFF', 'Medical Facility Medical Unit', 'Vanderbilt Tullahoma Harton', 'Manchester Center for Rehabilitation and Healing', NULL, 'PASRR_CV', '2025-01-13 00:00:00.000', NULL, NULL, 0);
INSERT INTO perlss.pasrr_addr_dtl
(id, pasrr_id, first_name, middle_name, last_name, suffix, user_type_cd, addr_line_1, addr_line_2, city, state_cd, zip, zip_extsn, cnty_cd, current_location, current_location_facility, admtng_facility_name, archived_dt, created_by, created_dt, last_modified_by, last_modified_dt, record_version)
VALUES(1848007509, 'PSR100596078', '', NULL, '', NULL, 'CL', '1801 North Jackson St.', NULL, 'TULLAHOMA', 'TN', '37388', NULL, '', 'Medical Facility Medical Unit', 'Vanderbilt Tullahoma Harton', 'Manchester Center for Rehabilitation and Healing', NULL, 'PASRR_CV', '2025-01-13 00:00:00.000', NULL, NULL, 0);
INSERT INTO perlss.pasrr_addr_dtl
(id, pasrr_id, first_name, middle_name, last_name, suffix, user_type_cd, addr_line_1, addr_line_2, city, state_cd, zip, zip_extsn, cnty_cd, current_location, current_location_facility, admtng_facility_name, archived_dt, created_by, created_dt, last_modified_by, last_modified_dt, record_version)
VALUES(1848007510, 'PSR100596079', '', NULL, '', NULL, 'APPL', '1113 East Moore St', NULL, 'Tullahoma', 'TN', '37388', NULL, 'COFF', 'Medical Facility Medical Unit', 'Vanderbilt Tullahoma Harton', 'Manchester Center for Rehabilitation and Healing', NULL, 'PASRR_CV', '2025-01-13 00:00:00.000', NULL, NULL, 0);
INSERT INTO perlss.pasrr_addr_dtl
(id, pasrr_id, first_name, middle_name, last_name, suffix, user_type_cd, addr_line_1, addr_line_2, city, state_cd, zip, zip_extsn, cnty_cd, current_location, current_location_facility, admtng_facility_name, archived_dt, created_by, created_dt, last_modified_by, last_modified_dt, record_version)
VALUES(1848007511, 'PSR100596079', '', NULL, '', NULL, 'CL', '1801 North Jackson St.', NULL, 'TULLAHOMA', 'TN', '37388', NULL, '', 'Medical Facility Medical Unit', 'Vanderbilt Tullahoma Harton', 'Manchester Center for Rehabilitation and Healing', NULL, 'PASRR_CV', '2025-01-13 00:00:00.000', NULL, NULL, 0);
INSERT INTO perlss.pasrr_addr_dtl
(id, pasrr_id, first_name, middle_name, last_name, suffix, user_type_cd, addr_line_1, addr_line_2, city, state_cd, zip, zip_extsn, cnty_cd, current_location, current_location_facility, admtng_facility_name, archived_dt, created_by, created_dt, last_modified_by, last_modified_dt, record_version)
VALUES(1848007512, 'PSR100596080', '', NULL, '', NULL, 'APPL', '395 Interstate Drive', NULL, 'Manchester', 'TN', '37355', NULL, 'COFF', 'Nursing Facility', 'Manchester Center for Rehabilitation and Healing', 'Manchester Center for Rehabilitation and Healing', NULL, 'PASRR_CV', '2025-01-13 00:00:00.000', NULL, NULL, 0);
INSERT INTO perlss.pasrr_addr_dtl
(id, pasrr_id, first_name, middle_name, last_name, suffix, user_type_cd, addr_line_1, addr_line_2, city, state_cd, zip, zip_extsn, cnty_cd, current_location, current_location_facility, admtng_facility_name, archived_dt, created_by, created_dt, last_modified_by, last_modified_dt, record_version)
VALUES(1848007513, 'PSR100596080', '', NULL, '', NULL, 'CL', '395 Interstate Dr', NULL, 'Manchester', 'TN', '37355', NULL, '', 'Nursing Facility', 'Manchester Center for Rehabilitation and Healing', 'Manchester Center for Rehabilitation and Healing', NULL, 'PASRR_CV', '2025-01-13 00:00:00.000', NULL, NULL, 0);
INSERT INTO perlss.pasrr_addr_dtl
(id, pasrr_id, first_name, middle_name, last_name, suffix, user_type_cd, addr_line_1, addr_line_2, city, state_cd, zip, zip_extsn, cnty_cd, current_location, current_location_facility, admtng_facility_name, archived_dt, created_by, created_dt, last_modified_by, last_modified_dt, record_version)
VALUES(1848008728, 'PSR100596642', '', NULL, '', NULL, 'APPL', '402 North Street', NULL, 'Nashville', 'TN', '37206', NULL, 'LINC', 'Medical Facility Medical Unit', 'Saint Thomas Hospital Midtown', NULL, NULL, 'PASRR_CV', '2025-01-13 00:00:00.000', NULL, NULL, 0);
INSERT INTO perlss.pasrr_addr_dtl
(id, pasrr_id, first_name, middle_name, last_name, suffix, user_type_cd, addr_line_1, addr_line_2, city, state_cd, zip, zip_extsn, cnty_cd, current_location, current_location_facility, admtng_facility_name, archived_dt, created_by, created_dt, last_modified_by, last_modified_dt, record_version)
VALUES(1848008729, 'PSR100596642', '', NULL, '', NULL, 'CL', '2000 Church Street', NULL, 'Nashville', 'TN', '37236', NULL, '', 'Medical Facility Medical Unit', 'Saint Thomas Hospital Midtown', NULL, NULL, 'PASRR_CV', '2025-01-13 00:00:00.000', NULL, NULL, 0);
INSERT INTO perlss.pasrr_addr_dtl
(id, pasrr_id, first_name, middle_name, last_name, suffix, user_type_cd, addr_line_1, addr_line_2, city, state_cd, zip, zip_extsn, cnty_cd, current_location, current_location_facility, admtng_facility_name, archived_dt, created_by, created_dt, last_modified_by, last_modified_dt, record_version)
VALUES(1848008730, 'PSR100596643', '', NULL, '', NULL, 'APPL', '402 N. 9th St.', NULL, 'Nashville', 'TN', '37206', NULL, 'LINC', 'Community setting/home', NULL, 'Elk River Health and Rehabilitation of Fayetteville', NULL, 'PASRR_CV', '2025-01-13 00:00:00.000', NULL, NULL, 0);
INSERT INTO perlss.pasrr_addr_dtl
(id, pasrr_id, first_name, middle_name, last_name, suffix, user_type_cd, addr_line_1, addr_line_2, city, state_cd, zip, zip_extsn, cnty_cd, current_location, current_location_facility, admtng_facility_name, archived_dt, created_by, created_dt, last_modified_by, last_modified_dt, record_version)
VALUES(1848008731, 'PSR100596643', '', NULL, '', NULL, 'CL', '402 N. 9th St', NULL, 'Nashville', 'TN', '37206', NULL, '', 'Community setting/home', NULL, 'Elk River Health and Rehabilitation of Fayetteville', NULL, 'PASRR_CV', '2025-01-13 00:00:00.000', NULL, NULL, 0);
INSERT INTO perlss.pasrr_addr_dtl
(id, pasrr_id, first_name, middle_name, last_name, suffix, user_type_cd, addr_line_1, addr_line_2, city, state_cd, zip, zip_extsn, cnty_cd, current_location, current_location_facility, admtng_facility_name, archived_dt, created_by, created_dt, last_modified_by, last_modified_dt, record_version)
VALUES(1848011501, 'PSR100597923', '', NULL, '', NULL, 'APPL', '7481 British Rd', NULL, 'Ooltewah', 'TN', '37363', NULL, 'MAUR', 'Medical Facility Medical Unit', 'Erlanger East Hospital', NULL, NULL, 'PASRR_CV', '2025-01-13 00:00:00.000', NULL, NULL, 0);
INSERT INTO perlss.pasrr_addr_dtl
(id, pasrr_id, first_name, middle_name, last_name, suffix, user_type_cd, addr_line_1, addr_line_2, city, state_cd, zip, zip_extsn, cnty_cd, current_location, current_location_facility, admtng_facility_name, archived_dt, created_by, created_dt, last_modified_by, last_modified_dt, record_version)
VALUES(1848011502, 'PSR100597923', '', NULL, '', NULL, 'CL', '1755 Gunbarrel Rd', NULL, 'Chattanooga', 'TN', '37421', NULL, '', 'Medical Facility Medical Unit', 'Erlanger East Hospital', NULL, NULL, 'PASRR_CV', '2025-01-13 00:00:00.000', NULL, NULL, 0);




INSERT INTO perlss.pasrr_outcome_dtls
(id, pasrr_id, payor_src_cd, hos_admit_dt, nf_admit_dt, review_type, prim_lang, ascendid, lvl1_letter_sent_dt, lvl1_letter_type_sent, lvl2_notice_type, lvl2_notice_sent_dt, lvl2_sent_to_state_dt, lvl2_assessment_dt, lvl2_specialized_services_dtr, lvl2_approved_str, lvl2_short_term_days, lvl2_pasrr_condition, lvl2_due_dt, archived_dt, created_by, created_dt, last_modified_by, last_modified_dt, record_version, passr_action_cd, short_stay_dt, pasrr_comment, assmnt_id, recon_of_assmnt_id)
VALUES(1847948810, 'PSR100596084', 'MD', NULL, NULL, 'Preadmission', 'English', '82377', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'PASRR_CV', '2025-01-13 00:00:00.000', NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL);
INSERT INTO perlss.pasrr_outcome_dtls
(id, pasrr_id, payor_src_cd, hos_admit_dt, nf_admit_dt, review_type, prim_lang, ascendid, lvl1_letter_sent_dt, lvl1_letter_type_sent, lvl2_notice_type, lvl2_notice_sent_dt, lvl2_sent_to_state_dt, lvl2_assessment_dt, lvl2_specialized_services_dtr, lvl2_approved_str, lvl2_short_term_days, lvl2_pasrr_condition, lvl2_due_dt, archived_dt, created_by, created_dt, last_modified_by, last_modified_dt, record_version, passr_action_cd, short_stay_dt, pasrr_comment, assmnt_id, recon_of_assmnt_id)
VALUES(1847947550, 'PSR100596078', 'MD', '2024-03-09', '2024-03-12', 'Preadmission', 'English', '82377', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'PASRR_CV', '2025-01-13 00:00:00.000', NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL);
INSERT INTO perlss.pasrr_outcome_dtls
(id, pasrr_id, payor_src_cd, hos_admit_dt, nf_admit_dt, review_type, prim_lang, ascendid, lvl1_letter_sent_dt, lvl1_letter_type_sent, lvl2_notice_type, lvl2_notice_sent_dt, lvl2_sent_to_state_dt, lvl2_assessment_dt, lvl2_specialized_services_dtr, lvl2_approved_str, lvl2_short_term_days, lvl2_pasrr_condition, lvl2_due_dt, archived_dt, created_by, created_dt, last_modified_by, last_modified_dt, record_version, passr_action_cd, short_stay_dt, pasrr_comment, assmnt_id, recon_of_assmnt_id)
VALUES(1847947621, 'PSR100596079', 'MD', '2024-03-28', '2024-04-01', 'Preadmission', 'English', '82377', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'PASRR_CV', '2025-01-13 00:00:00.000', NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL);
INSERT INTO perlss.pasrr_outcome_dtls
(id, pasrr_id, payor_src_cd, hos_admit_dt, nf_admit_dt, review_type, prim_lang, ascendid, lvl1_letter_sent_dt, lvl1_letter_type_sent, lvl2_notice_type, lvl2_notice_sent_dt, lvl2_sent_to_state_dt, lvl2_assessment_dt, lvl2_specialized_services_dtr, lvl2_approved_str, lvl2_short_term_days, lvl2_pasrr_condition, lvl2_due_dt, archived_dt, created_by, created_dt, last_modified_by, last_modified_dt, record_version, passr_action_cd, short_stay_dt, pasrr_comment, assmnt_id, recon_of_assmnt_id)
VALUES(1847947659, 'PSR100596080', 'MD', '2024-04-04', '2024-04-04', 'Preadmission', 'English', '82377', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'PASRR_CV', '2025-01-13 00:00:00.000', NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL);
INSERT INTO perlss.pasrr_outcome_dtls
(id, pasrr_id, payor_src_cd, hos_admit_dt, nf_admit_dt, review_type, prim_lang, ascendid, lvl1_letter_sent_dt, lvl1_letter_type_sent, lvl2_notice_type, lvl2_notice_sent_dt, lvl2_sent_to_state_dt, lvl2_assessment_dt, lvl2_specialized_services_dtr, lvl2_approved_str, lvl2_short_term_days, lvl2_pasrr_condition, lvl2_due_dt, archived_dt, created_by, created_dt, last_modified_by, last_modified_dt, record_version, passr_action_cd, short_stay_dt, pasrr_comment, assmnt_id, recon_of_assmnt_id)
VALUES(1847945179, 'PSR100596642', 'MD', '2017-07-26', '2017-07-31', 'Preadmission', 'English', '55422', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'PASRR_CV', '2025-01-13 00:00:00.000', NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL);
INSERT INTO perlss.pasrr_outcome_dtls
(id, pasrr_id, payor_src_cd, hos_admit_dt, nf_admit_dt, review_type, prim_lang, ascendid, lvl1_letter_sent_dt, lvl1_letter_type_sent, lvl2_notice_type, lvl2_notice_sent_dt, lvl2_sent_to_state_dt, lvl2_assessment_dt, lvl2_specialized_services_dtr, lvl2_approved_str, lvl2_short_term_days, lvl2_pasrr_condition, lvl2_due_dt, archived_dt, created_by, created_dt, last_modified_by, last_modified_dt, record_version, passr_action_cd, short_stay_dt, pasrr_comment, assmnt_id, recon_of_assmnt_id)
VALUES(1847948537, 'PSR100596643', 'MD', NULL, '2017-09-05', 'Preadmission', 'English', '55422', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'PASRR_CV', '2025-01-13 00:00:00.000', NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL);
INSERT INTO perlss.pasrr_outcome_dtls
(id, pasrr_id, payor_src_cd, hos_admit_dt, nf_admit_dt, review_type, prim_lang, ascendid, lvl1_letter_sent_dt, lvl1_letter_type_sent, lvl2_notice_type, lvl2_notice_sent_dt, lvl2_sent_to_state_dt, lvl2_assessment_dt, lvl2_specialized_services_dtr, lvl2_approved_str, lvl2_short_term_days, lvl2_pasrr_condition, lvl2_due_dt, archived_dt, created_by, created_dt, last_modified_by, last_modified_dt, record_version, passr_action_cd, short_stay_dt, pasrr_comment, assmnt_id, recon_of_assmnt_id)
VALUES(1847945900, 'PSR100597923', 'MD', '2021-02-20', NULL, 'Preadmission', 'English', '391120', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'PASRR_CV', '2025-01-13 00:00:00.000', NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL);


INSERT INTO perlss.pasrr_submtr_dtls
(id, pasrr_id, lvl1_submit_dt, lvl1_submtr_first_name, lvl1_submtr_last_name, lvl1_submitting_facility, lvl1_submitting_facility_address, lvl1_submitting_facility_city, lvl1_submitting_facility_state, lvl1_submitting_facility_zip, archived_dt, created_by, created_dt, last_modified_by, last_modified_dt, record_version)
VALUES(1847950350, 'PSR100596084', '2024-11-14', 'Katie', 'Stewart', 'BlueCare', '1 Cameron Hill', 'Chattanooga', 'TN', '37402', NULL, 'PASRR_CV', '2025-01-13 00:00:00.000', NULL, NULL, 0);
INSERT INTO perlss.pasrr_submtr_dtls
(id, pasrr_id, lvl1_submit_dt, lvl1_submtr_first_name, lvl1_submtr_last_name, lvl1_submitting_facility, lvl1_submitting_facility_address, lvl1_submitting_facility_city, lvl1_submitting_facility_state, lvl1_submitting_facility_zip, archived_dt, created_by, created_dt, last_modified_by, last_modified_dt, record_version)
VALUES(1847950346, 'PSR100596078', '2024-03-14', 'Paul', 'McGill', 'Vanderbilt Tullahoma Harton', '1801 North Jackson St.', 'Tullahoma', 'TN', '37388', NULL, 'PASRR_CV', '2025-01-13 00:00:00.000', NULL, NULL, 0);
INSERT INTO perlss.pasrr_submtr_dtls
(id, pasrr_id, lvl1_submit_dt, lvl1_submtr_first_name, lvl1_submtr_last_name, lvl1_submitting_facility, lvl1_submitting_facility_address, lvl1_submitting_facility_city, lvl1_submitting_facility_state, lvl1_submitting_facility_zip, archived_dt, created_by, created_dt, last_modified_by, last_modified_dt, record_version)
VALUES(1847950347, 'PSR100596079', '2024-03-29', 'Paul', 'McGill', 'Vanderbilt Tullahoma Harton', '1801 North Jackson St.', 'Tullahoma', 'TN', '37388', NULL, 'PASRR_CV', '2025-01-13 00:00:00.000', NULL, NULL, 0);
INSERT INTO perlss.pasrr_submtr_dtls
(id, pasrr_id, lvl1_submit_dt, lvl1_submtr_first_name, lvl1_submtr_last_name, lvl1_submitting_facility, lvl1_submitting_facility_address, lvl1_submitting_facility_city, lvl1_submitting_facility_state, lvl1_submitting_facility_zip, archived_dt, created_by, created_dt, last_modified_by, last_modified_dt, record_version)
VALUES(1847950348, 'PSR100596080', '2024-04-09', 'Cheryl', 'Loveless', 'Manchester Center for Rehabilitation and Healing', '395 Interstate Dr', 'Manchester', 'TN', '37355', NULL, 'PASRR_CV', '2025-01-13 00:00:00.000', NULL, NULL, 0);
INSERT INTO perlss.pasrr_submtr_dtls
(id, pasrr_id, lvl1_submit_dt, lvl1_submtr_first_name, lvl1_submtr_last_name, lvl1_submitting_facility, lvl1_submitting_facility_address, lvl1_submitting_facility_city, lvl1_submitting_facility_state, lvl1_submitting_facility_zip, archived_dt, created_by, created_dt, last_modified_by, last_modified_dt, record_version)
VALUES(1847950794, 'PSR100596642', '2017-07-31', 'Jessica', 'tom', 'Saint Thomas Hospital Midtown', '2000 Church Street', 'Nashville', 'TN', '37236', NULL, 'PASRR_CV', '2025-01-13 00:00:00.000', NULL, NULL, 0);
INSERT INTO perlss.pasrr_submtr_dtls
(id, pasrr_id, lvl1_submit_dt, lvl1_submtr_first_name, lvl1_submtr_last_name, lvl1_submitting_facility, lvl1_submitting_facility_address, lvl1_submitting_facility_city, lvl1_submitting_facility_state, lvl1_submitting_facility_zip, archived_dt, created_by, created_dt, last_modified_by, last_modified_dt, record_version)
VALUES(1847950795, 'PSR100596643', '2017-09-01', 'Alecia', 'Greer', 'Wellpoint', '22 Century Boulevard', 'Nashville', 'TN', '37214', NULL, 'PASRR_CV', '2025-01-13 00:00:00.000', NULL, NULL, 0);
INSERT INTO perlss.pasrr_submtr_dtls
(id, pasrr_id, lvl1_submit_dt, lvl1_submtr_first_name, lvl1_submtr_last_name, lvl1_submitting_facility, lvl1_submitting_facility_address, lvl1_submitting_facility_city, lvl1_submitting_facility_state, lvl1_submitting_facility_zip, archived_dt, created_by, created_dt, last_modified_by, last_modified_dt, record_version)
VALUES(1847951848, 'PSR100597923', '2021-02-24', 'Kim', 'Wright', 'Erlanger Medical Center', '975 E. Third St.', 'Chattanooga', 'TN', '37403', NULL, 'PASRR_CV', '2025-01-13 00:00:00.000', NULL, NULL, 0);

INSERT INTO perlss.com_comments
(id, ref_id, pae_id, apl_id, tns_id, chm_id, type_cd, "comments", entity_id, page_id, prsn_id, created_by, created_dt, last_modified_by, last_modified_dt, record_version, archived_dt, enr_id, erc_ref_id, erc_assmnt_id, episode_id)
VALUES(1848030485, NULL, 'PAE200113846', NULL, NULL, NULL, NULL, 'The documentation does not show wounds that are infected, dehisced, require a wound vac or the presence of 3 or more stage 3 or 4 decubitus wounds.  	', 30045, 'PPSSD', 6000016806, 'PASRR_CV', '2025-01-13 00:00:00.000', NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL);
INSERT INTO perlss.com_comments
(id, ref_id, pae_id, apl_id, tns_id, chm_id, type_cd, "comments", entity_id, page_id, prsn_id, created_by, created_dt, last_modified_by, last_modified_dt, record_version, archived_dt, enr_id, erc_ref_id, erc_assmnt_id, episode_id)
VALUES(1848030486, NULL, 'PAE200113846', NULL, NULL, NULL, NULL, 'There is no documentation provided of a physician s order specifying frequency greater than 5x/week, duration, or diagnosis for the requested therapy services. Please be advised: Skilled therapy services cannot be used for chronic conditions or generalized weakness.', 30045, 'PPSSD', 6000016806, 'PASRR_CV', '2025-01-13 00:00:00.000', NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL);


INSERT INTO perlss.com_notes
(id, pae_id, ref_id, apl_id, notes_type_cd, notes_comments, created_by, created_dt, last_modified_by, last_modified_dt, record_version, archived_dt, erc_ref_id, erc_assmnt_id, episode_id)
VALUES(1848027936, 'PAE200113846', NULL, NULL, 'GNR', 'Records converted on01/13/2025', 'PASRR_CV', '2025-01-13 00:00:00.000', NULL, NULL, 0, NULL, NULL, NULL, NULL);
INSERT INTO perlss.com_notes
(id, pae_id, ref_id, apl_id, notes_type_cd, notes_comments, created_by, created_dt, last_modified_by, last_modified_dt, record_version, archived_dt, erc_ref_id, erc_assmnt_id, episode_id)
VALUES(1848027698, 'PAE200114073', NULL, NULL, 'GNR', 'Records converted on01/13/2025', 'PASRR_CV', '2025-01-13 00:00:00.000', NULL, NULL, 0, NULL, NULL, NULL, NULL);
INSERT INTO perlss.com_notes
(id, pae_id, ref_id, apl_id, notes_type_cd, notes_comments, created_by, created_dt, last_modified_by, last_modified_dt, record_version, archived_dt, erc_ref_id, erc_assmnt_id, episode_id)
VALUES(1848027998, 'PAE200113324', NULL, NULL, 'GNR', 'Records converted on01/13/2025', 'PASRR_CV', '2025-01-13 00:00:00.000', NULL, NULL, 0, NULL, NULL, NULL, NULL);


INSERT INTO perlss.com_applcnt_access
(id, pae_id, ref_id, prsn_id, entity_cd, eff_begin_dt, eff_end_dt, active_sw, created_dt, last_modified_by, last_modified_dt, record_version, archived_dt, created_by, entity_type_cd, assigned_mco_sw, entity_id)
VALUES(1848087798, 'PAE200113846', NULL, 6000016806, '5', '2024-11-04', NULL, 'Y', '2025-01-28 16:59:00.733', NULL, NULL, 0, NULL, 'PASRR_CV', 'NF', NULL, 30045);
INSERT INTO perlss.com_applcnt_access
(id, pae_id, ref_id, prsn_id, entity_cd, eff_begin_dt, eff_end_dt, active_sw, created_dt, last_modified_by, last_modified_dt, record_version, archived_dt, created_by, entity_type_cd, assigned_mco_sw, entity_id)
VALUES(1848087709, 'PAE200114073', NULL, 6000025750, '4', '2024-12-23', NULL, 'Y', '2025-01-28 16:59:00.733', NULL, NULL, 0, NULL, 'PASRR_CV', 'MCO', NULL, 802);































select
nextval('perlss.hibernate_sequence') as ID,
* from (
select  
NULL	apl_id
,'OSD'	doc_type_cd
--, b.filename	file_name
, COALESCE (lower(azuredocumentid), b.filename)	file_name 
,ca.first_name	first_name
,null 	folder_name
,NULL	kb_fn_id
,NULL	last_modified_by
,NULL	last_modified_dt
,ca.last_name	last_name
,NULL	notice_type
,NULL	notice_type_cd
,r.pae_id	pae_id
,'N'	processed_flag
,ca.prsn_id	prsn_id
,NULL	ref_id
,'PASRR'	source_sys_nm
,NULL	tns_id
,'A' as CONVERSION_RUN_STATUS
from  legacy.pasrr_doc b    
join legacy.pasrr_base_member_pop  w  on b.reviewid::bigint  = w.maximus_reviewid::bigint
left join legacy.pasrr_blob a on b.attatchmentid =a.attachmentid
left join (select  *  from perlss.pasrr_rqst where  created_by='PASRR_CV') r    on r.episode_id::text = w.maximus_reviewid::text
left join perlss.com_applcnt ca on w.maximus_ssn=ca.ssn and active_sw='Y' and file_clearance_sw= 'Y'
)a;


update perlss.cnv_doc_dtls
set folder_name = '/perlss_caagent/stg/interfaces/TPAES/conv/pdfs/'
where created_by ='PASRR_CV';

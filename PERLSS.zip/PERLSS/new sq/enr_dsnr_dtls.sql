select 
nextval('perlss.hibernate_sequence') as ID,
 * from (
select distinct 
 enr.enr_status_cd enr_status_cd
,a.dte_last_update	dis_enr_dt
,Null	auth_dt
,enr.enr_id	enr_id
,enr.auth_status_cd as auth_status_cd
,'APP'	ltss_dscn_cd
,NULL	last_modified_by
,NULL	last_modified_dt
,NULL	auth_user_id
,'A'   CONVERSION_RUN_STATUS
,k.cde_type AS dis_enr_type_cd
,upper(trim(k.desc_disenroll_rsn)) dis_enr_rsn_cd
from legacy.pasrr_mmis_base_member_pop a 
join (select  * from legacy.wrk_pasrr_clients where  source_system_nm='MMIS' 
and valid_sw= 'Y' and 	xref_valid_sw='Y' and perlss_sw ='N') b  on  b.ssn=a.num_ssn and a.sak_recip::varchar(25)=b.sak_recip  and trim(a.num_pre_eval) =trim(b.mmis_pae_id)
join legacy.pasrr_tmed_base_member_pop tm on num_control_pkey::varchar(25) =trim(a.num_pre_eval)
join (select  *  from legacy.pasrr_pae_base_member_pop pae where step in ('1','2'))pae on pae.pasrr_review_id::varchar(25)=trim(tm.tmed_ascend_id)
left join (select  *  from perlss.pae_rqst where  created_by='PASRR_CV') p  on trim(legacy_id)=pae.pasrr_review_id::varchar(25)
left join (select * from perlss.enr_rqst where  created_by='PASRR_CV' and enr_status_cd ='DIS') enr on enr.pae_id = p.pae_id
left join (select a.*,b.cde_type,b.desc_disenroll_rsn from 
(select sak_recip,sak_pgm_elig,cde_disenroll_rsn,dte_last_update
from (select   ROW_NUMBER() OVER(PARTITION BY sak_recip
        ORDER BY dte_last_update DESC
    ) row_num, a.* from legacy.pasrr_mmis_t_re_disenroll_reasons a )a where  row_num=1 ) a
join legacy.pasrr_mmis_t_cde_disenroll_reasons b on b.CDE_DISENROLL_RSN=a.CDE_DISENROLL_RSN) k on a.sak_recip::varchar(25)=k.sak_recip::varchar(25) and a.SAK_PGM_ELIG::varchar(25) = k.SAK_PGM_ELIG::varchar(25)
where  enr.enr_id is not null
)a


SELECT WRK_XREF_CODES.TO_XREF_CD as TO_XREF_CD,
upper(Trim(WRK_XREF_CODES.FROM_XREF_DESC)) as FROM_XREF_DESC FROM legacy.WRK_XREF_CODES 
where 
WRK_XREF_CODES.SRC_SYS_ID='MMIS'
and WRK_XREF_CODES.REF_TBL_NM='DISENROLLMENT_REASON'
AND WRK_XREF_CODES.LEGACY_TBL_NM='T_CDE_DISENROLL_REASONS'
AND WRK_XREF_CODES.LEGACY_COL_NM='DESC_DISENROLL_RSN';

select * from legacy.pasrr_mmis_t_re_disenroll_reasons where sak_recip= '1758531'
select 
nextval('perlss.hibernate_sequence') as ID,
 * from (
select distinct 
  NULL as 	acuity_scr_2beh_sw
, NULL as 	acuity_scr_2toileting_sw
, NULL as 	acuity_scr_3mobility_trnsfr_sw
, NULL as 	acuity_scr_3orinet_sw
, NULL as 	acuity_scr_5_less_8_sw
, NULL as 	app_resdce_cd
, NULL as 	app_resdce_oth_txt
, NULL as	atstn_dt
, NULL as 	chng_phycl_behavrl_primary_care_sw
, NULL as 	chng_phycl_behavrl_sw
, NULL as 	choices_member_enrolled_sw
, NULL as 	cmpx_chrnc_sw
, NULL as 	credential
, NULL as 	credentials_cd
, NULL as 	dis_mala_comments
, NULL as 	do_believe_at_risk_sw
, NULL as 	do_believe_sw
, NULL as 	donot_believe_sw
, NULL as 	icap_score
, NULL as 	intel_dis_mala_index12_sw
, NULL as 	intlctl_disblty_sw
, NULL as 	last_modified_by
, NULL as 	last_modified_dt
, NULL as 	mco_determn_grp3_sw
, NULL as 	mco_determn_grp5_sw
, NULL as 	name_atstn
, NULL as 	no_criteria_met_grp3_sw
, NULL as 	no_criteria_met_grp5_sw
,r.pae_id 	pae_id
, NULL as 	post_acute_inptnt_sw
, Null as 	qualified_assessor_id
, NULL as 	qualified_assessor_name
, NULL as 	rcnt_discharge_sw
, NULL as 	rcnt_emrgnt_hospital_admsn_sw
, NULL as 	rcnt_fall_sw
, NULL as 	req_applcnt_sw
, NULL as 	resdce_unable_desc
, NULL as 	self_negli_sw
, Null as intlctl_disblty_icap_sw
, r.legacy_id
,'A' as CONVERSION_RUN_STATUS
from  legacy.wrk_pasrr_clients w   
join legacy.pasrr_events b on b.reviewid::bigint  = w.maximus_reviewid::bigint
left join legacy.pasrr_loc a on  b.eventid::text = a.eventid::text
left join (select  *  from perlss.pae_rqst where  created_by='PASRR_CV') r    on r.legacy_id::text = w.maximus_reviewid::text
where  w.source_system_nm = 'MAXIMUS' and a.SafetyFormRequest='False'
and valid_sw= 'Y' and 	xref_valid_sw='Y'   and perlss_sw ='N'
)a where pae_id is not null

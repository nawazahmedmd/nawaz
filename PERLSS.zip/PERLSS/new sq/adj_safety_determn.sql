select 
nextval('perlss.hibernate_sequence') as ID,
 * from (
select distinct 
r.adj_id 	adj_id
,'Uploaded the  Safety doc from Maximus'	comments
,NULL	last_modified_by
,NULL	last_modified_dt
,'CV' 	ltss_safety_dcsn_cd
,case when a.SafetyFormRequest='True' then 'Y' 
      when a.SafetyFormRequest='False' then 'N' end	safety_assmnt_req_sw
,'A' as CONVERSION_RUN_STATUS
--select count(1)
from legacy.pasrr_events b   
join legacy.wrk_pasrr_clients w on  b.reviewid::bigint  = w.maximus_reviewid::bigint
left join legacy.pasrr_loc a on  b.eventid::text = a.eventid::text
left join perlss.pae_rqst p on p.legacy_id::text = w.maximus_reviewid::text
left join perlss.adj_rqst r on r.pae_id = p.pae_id
where  w.source_system_nm = 'MAXIMUS' 
and valid_sw= 'Y' and 	xref_valid_sw='Y'
and r.created_by  = 'PASRR_CV'
and w.perlss_sw ='N'
)a 






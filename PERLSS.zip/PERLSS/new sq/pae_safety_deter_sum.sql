select 
nextval('perlss.hibernate_sequence') as ID,
 * from (
select distinct 
 'N'	hcbs_srvc_sw
,NULL	last_modified_by
,NULL	last_modified_dt
,case when a.SafetyFormRequest='True' then 'N' 
      when a.SafetyFormRequest='False' then 'Y' end 	nf_srvc_sw
,r.pae_id 	pae_id
,case when a.SafetyFormRequest='True' then 'Y' 
      when a.SafetyFormRequest='False' then 'N' end	req_safety_con_sw
,'N'	tenncare_qualified_assessor_sw
, r.legacy_id
,'A' as CONVERSION_RUN_STATUS
--select count(1)
from legacy.wrk_pasrr_clients w 
join legacy.pasrr_events b on b.reviewid::bigint  = w.maximus_reviewid::bigint
left join legacy.pasrr_loc a on  b.eventid::text = a.eventid::text
left join (select  *  from perlss.pae_rqst where  created_by='PASRR_CV') r    on r.legacy_id::text = w.maximus_reviewid::text
where  w.source_system_nm = 'MAXIMUS' 
and valid_sw= 'Y' and 	xref_valid_sw='Y'  and perlss_sw ='N'
)a where pae_id is not null

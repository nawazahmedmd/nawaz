select 
nextval('perlss.hibernate_sequence') as ID,
 * from (
select distinct 
  a.referraldate as start_dt
  ,null as 	end_dt
  ,null::timestamp as archived_dt
, 'SUB' as 	pae_action_cd
, r.pae_id 	pae_id
, '0' as record_version
, null as rqstextension_sw
,so.entity_id
,so.entity_name  as entity_name
,so.entity_type
,coalesce(so.user_id,'CV_282') as user_id
, 'A' as CONVERSION_RUN_STATUS
,null as  last_modified_by
,null as last_modified_dt
--select count(1)
from  legacy.wrk_pasrr_clients w 
join legacy.pasrr_events b on b.reviewid::bigint  = w.maximus_reviewid::bigint
join legacy.pasrr_pae_base_member_pop pop on w.maximus_reviewid = pop.pasrr_review_id and w.ssn = pop.ssn
left join legacy.pasrr_loc a on  b.eventid::text = a.eventid::text
left join legacy.pasrr_level_i l1 on  b.eventid =l1.eventid 
left join perlss.pae_rqst r on r.legacy_id::text = w.maximus_reviewid::text
left join (select distinct so.entity_id, entity_type,so.entity_name ,sp.user_id , first_name , last_name, a.level1submittingfacility 
			from perlss.sec_org_type sot 
			 join perlss.sec_organization so on so.entity_type_id = sot.entity_type_id 
			 join perlss.sec_user_organization suo on suo.entity_id = so.entity_id 
			 join perlss.sec_user_profile sp on sp.user_id = suo.user_id
			 join legacy.xref_subfacility_secorg a on a.perlss_entity_id= so.entity_id::text 
			 where sp.user_id not in ('TNT3002','TNT7234')) so 
			on upper(l1.level1submittingfacility)=upper(so.level1submittingfacility) 
			AND upper((trim(l1.level1submitterfirstname) || trim(l1.level1submitterlastname)))=upper((trim(so.first_name) ||trim(so.last_name)))
where  w.source_system_nm = 'MAXIMUS' 
and valid_sw= 'Y' and 	xref_valid_sw='Y'
and r.created_by  = 'PASRR_CV'
and w.perlss_sw ='N'
)a
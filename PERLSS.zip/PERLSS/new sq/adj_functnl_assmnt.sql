select distinct
r.adj_id adj_id
, 'TRAN' ADLTransfer
, 'MOBL' ADLWalking
, 'MOBW' ADLMobility
, 'EATG' ADLEating
, 'TLTG' ADLToileting
, 'TLTI' ADLIncontinentCare
, 'TLTC' ADLCatheterCare
, 'ORNT' ADLOrientation
, 'ECOM' ADLExpressive
, 'RCOM' ADLReceptive
, 'MEDC' ADLMedsAdmin
, 'BHVR' ADLBehavior
,trim(ADLTransferClinicianResponse) ADLTransferClinicianResponse
,trim(ADLWalkingClinicianResponse) ADLWalkingClinicianResponse
,trim(ADLMobilityClinicianResponse) ADLMobilityClinicianResponse
,trim(ADLEatingClinicianResponse) ADLEatingClinicianResponse
,trim(ADLToiletingClinicianResponse) ADLToiletingClinicianResponse
,trim(ADLIncontinentCareClinicianResponse) ADLIncontinentCareClinicianResponse
,trim(ADLCatheterCareClinicianResponse) ADLCatheterCareClinicianResponse
,trim(ADLOrientationClinicianResponse) ADLOrientationClinicianResponse
,trim(ADLExpressiveClinicianResponse) ADLExpressiveClinicianResponse
,trim(ADLReceptiveClinicianResponse) ADLReceptiveClinicianResponse
,trim(ADLMedsAdminClinicianResponse) ADLMedsAdminClinicianResponse
,trim(ADLBehaviorClinicianResponse) ADLBehaviorClinicianResponse
,trim(ADLTransferDenialReason) ADLTransferDenialReason
,trim(ADLWalkingDenialReason) ADLWalkingDenialReason
,trim(ADLMobilityDenialReason) ADLMobilityDenialReason
,trim(ADLEatingDenialReason) ADLEatingDenialReason
,trim(ADLToiletingDenialReason) ADLToiletingDenialReason
,trim(ADLIncontinentCareDenialReason) ADLIncontinentCareDenialReason
,trim(ADLCatheterCareDenialReason) ADLCatheterCareDenialReason
,trim(ADLOrientationDenialReason) ADLOrientationDenialReason
,trim(ADLExpressiveDenialReason) ADLExpressiveDenialReason
,trim(ADLReceptiveDenialReason) ADLReceptiveDenialReason
,trim(ADLMedsAdminDenialReason) ADLMedsAdminDenialReason
,trim(ADLBehaviorDenialReason) ADLBehaviorDenialReason
,trim(ADLTransfer) ADLTransfer_sbmtr_rsp
,trim(ADLWalking) ADLWalking_sbmtr_rsp
,trim(ADLMobility) ADLMobility_sbmtr_rsp
,trim(ADLEating) ADLEating_sbmtr_rsp
,trim(ADLToileting) ADLToileting_sbmtr_rsp
,trim(ADLIncontinentCare) ADLIncontinent_sbmtr_rsp
,trim(ADLCatheterCare) ADLCatheterCare_sbmtr_rsp
,trim(ADLOrientation) ADLOrientation_sbmtr_rsp
,trim(ADLExpressive) ADLExpressive_sbmtr_rsp
,trim(ADLReceptive) ADLReceptive_sbmtr_rsp
,trim(ADLMedsAdmin) ADLMedsAdmin_sbmtr_rsp
,trim(ADLBehavior) ADLBehavior_sbmtr_rsp
,trim(ADLTransferClinicianDetermination) ADLTransferClinicianDetermination
,trim(ADLWalkingClinicianDetermination) ADLWalkingClinicianDetermination
,trim(ADLMobilityClinicianDetermination) ADLMobilityClinicianDetermination
,trim(ADLEatingClinicianDetermination) ADLEatingClinicianDetermination
,trim(ADLToiletingClinicianDetermination) ADLToiletingClinicianDetermination
,trim(ADLIncontinentCareClinicianDetermination) ADLIncontinentCareClinicianDetermination
,trim(ADLCatheterCareClinicianDetermination) ADLCatheterCareClinicianDetermination
,trim(ADLOrientationClinicianDetermination) ADLOrientationClinicianDetermination
,trim(ADLExpressiveClinicianDetermination) ADLExpressiveClinicianDetermination
,trim(ADLReceptiveClinicianDetermination) ADLReceptiveClinicianDetermination
,trim(ADLMedsAdminClinicianDetermination) ADLMedsAdminClinicianDetermination
,trim(ADLBehaviorClinicianDetermination) ADLBehaviorClinicianDetermination
,trim(ADLTransferRationale) ADLTransferRationale
,trim(ADLWalkingRationale) ADLWalkingRationale
,trim(ADLMobilityRationale) ADLMobilityRationale
,trim(ADLEatingRationale) ADLEatingRationale
,trim(ADLToiletingRationale) ADLToiletingRationale
,trim(ADLIncontinentCareRationale) ADLIncontinentCareRationale
,trim(ADLCatheterCareRationale) ADLCatheterCareRationale
,trim(ADLOrientationRationale) ADLOrientationRationale
,trim(ADLExpressiveRationale) ADLExpressiveRationale
,trim(ADLReceptiveRationale) ADLReceptiveRationale
,trim(ADLMedsAdminRationale) ADLMedsAdminRationale
,trim(ADLBehaviorRationale) ADLBehaviorRationale
,a.Submittedacuityscore as Submittedacuityscore
--select count(1)
from legacy.pasrr_events b    
join legacy.wrk_pasrr_clients w on b.reviewid::bigint  = w.maximus_reviewid::bigint 
left join legacy.pasrr_loc a on b.eventid  = a.eventid
left join perlss.pae_rqst p on p.legacy_id::text = w.maximus_reviewid::text
left join perlss.adj_rqst r on r.pae_id = p.pae_id
where  w.source_system_nm = 'MAXIMUS' 
and valid_sw= 'Y' and 	xref_valid_sw='Y'
and r.created_by  = 'PASRR_CV'
and w.perlss_sw ='N';






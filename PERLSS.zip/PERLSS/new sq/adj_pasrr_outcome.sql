select 
nextval('perlss.hibernate_sequence') as ID,
 * from (
select distinct 
r.adj_id	adj_id
,NULL	last_modified_by
,NULL	last_modified_dt
,l1.Level1DeterminationDate lvl1_dcsn_dt
,l1.Level1SubmissionDate lvl1_submit_dt
,case when l2.Level2DeterminationEffectiveDate is not null then l2.Level2DeterminationEffectiveDate 
			else l2.Level2DeterminationDate end		lvl2_eff_dt
,l2.Level2DeterminationEndDate		lvl2_end_dt
,case when l1.Level1DeterminationEffectiveDate is not null then l1.Level1DeterminationEffectiveDate
			else l1.Level1DeterminationDate end		lvl1_eff_dt
,l1.Level1DeterminationEndDate		lvl1_end_dt
,l2.Level2DeterminationDate		lvl2_dcsn_dt
,'Y'	link_sw
,g.pasrr_id	pasrr_id
,g.source_cd	source_cd	
,g.type_cd	type_cd	
,g.episode_id episode_id
,'A' as CONVERSION_RUN_STATUS
,case when b.payersource = 'Medicaid Pending' then 'AP'
	  when b.payersource = 'Medicaid' then 'MD'
	  when b.payersource = 'PACE-Medicaid' then 'MD'
	  when b.payersource = 'PACE-Medicaid Pending' then 'AP' end	payor_src_cd
,trim(l1.level1outcome) level1outcome
,trim(l2.level2outcome) level2outcome
--select count(1)
from legacy.pasrr_events b   
join legacy.wrk_pasrr_clients w on  b.reviewid::bigint  = w.maximus_reviewid::bigint
left join legacy.pasrr_loc a on  b.eventid::text = a.eventid::text
left join legacy.pasrr_level_i l1 on  b.eventid =l1.eventid 
left join legacy.pasrr_level_ii l2 on  b.eventid =l2.eventid 
left join perlss.pae_rqst p on p.legacy_id::text = w.maximus_reviewid::text
left join perlss.adj_rqst r on r.pae_id = p.pae_id
left join perlss.pasrr_rqst g on g.pae_id = p.pae_id
where  w.source_system_nm = 'MAXIMUS' and l2.Level2DeterminationDate is not null
and valid_sw= 'Y' and 	xref_valid_sw='Y'
and r.created_by  = 'PASRR_CV' and p.created_by = 'PASRR_CV'
and w.perlss_sw ='N'
)a;




REF	Refer for Level II
NEG	Negative
CV	Converted


case when level1outcome ='No Level II Condition-Level I Negative' then 'NEG'
when level1outcome ='Cancelled/ Withdrawn' then 'Cancelled/ Withdrawn'
when level1outcome ='Refer for Level II-Level I Positive' then 'REF'
when level1outcome ='30 day Respite Categorical-Level I Positive->	Categorical - Respite
when level1outcome ='Refer to Level II-No LOC->	Refer for Level II
when level1outcome ='180 day Terminal Categorical-Level I Positive->	Categorical - Terminal Illness
when level1outcome ='Primary Dementia and ID/RC	->  Primary Dementia and ID/RC
when level1outcome ='30 day Hospital Exemption-Level I Positive-> 	Categorical - Exempted Hospital Discharge
when level1outcome ='Severe Illness Categorical-Level I Positive->	Exemption - Severe Physical Illness
when level1outcome ='Dementia Exempt-Level I 	-> Exemption - Dementia
when level1outcome ='60 day Convalescence Categorical-Level I Positive->	Categorical - Convalescent Care
when level1outcome ='Refer For Level II DBR->	'REF'
when level1outcome ='No Status Change	-> No Status Change
when level1outcome ='Hold for LOC-Level II needed->	'REF'
when level1outcome ='Terminal Categorical-Level I Positive->	Categorical - Terminal Illness
when level1outcome ='7 day Provisional Delirium Categorical-Level I Positive->	Categorical - Exempted Hospital Discharge
when level1outcome ='7 day Provisional Emergency Categorical-Level I Positive->	Categorical - Exempted Hospital Discharge'	lvl1_dcsn_cd




LTA	Long Term Approval (LT)
STA	Short Term Approval (ST)
HAL	Halted Outcome (Ruled Out)
DEN	Denied
CAN	Cancelled / Withdrawn
	
case when l2.level2outcome='Cancelled' then 'CAN'
when l2.level2outcome='Denial' then 'DEN'
when l2.level2outcome='Specialized Services Denial' then 'DEN'
when l2.level2outcome='Long-term Approval'	then 'LTA'
when l2.level2outcome='Long-term Approved Reconsideration' THEN 'LTA'
when l2.level2outcome='Ruled Out'	THEN 'HAL'
when l2.level2outcome='Short-term Approval'	then 'STA'
when l2.level2outcome='Short-term Approved Reconsideration' THEN 'STA'
when l2.level2outcome='Long Term Approval/Community Setting Recommended' THEN 'LTA' END 	lvl2_dcsn_cd

























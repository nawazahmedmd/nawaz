insert into perlss.enr_rqst ( id, enr_id , auth_id ,auth_status_cd, prsn_id, pae_id , auth_dt, enr_status_cd , enr_grp_cd, enr_denial_rsn_cd, created_by, created_dt, active_sw, record_version )
select 
nextval('perlss."hibernate_sequence"') id,
nextval('perlss."enr_rqst_0sq"') enr_id,
null as  auth_id,  --updated as per Sai inputs
'PAU' auth_status_cd,
prsn_id,
pae_id,
null as auth_dt,  --updated as per Sai inputs
enr_status_cd,
enr_grp_cd,
enr_denial_rsn_cd,
'PASRR_CV' as created_by,
created_dt ,
'Y' as active_sw, 0 as record_version
from (select c.Prsn_id, c.pae_id as pae_id, ar.pae_eff_dt , 
'NEE' as enr_status_cd, 
ar.enr_grp_cd , null as enr_denial_rsn_cd, ar.created_dt  from
perlss.cnv_task c 
inner join perlss.adj_rqst ar on c.pae_id = ar.pae_id 
--inner join perlss.tmg_task_master ttm on C.task_master_id = ttm.task_master_id 
where   c.created_by  = 'PASRR_CV' and c.task_master_id in (58,61)
and not exists (select 1 from perlss.enr_rqst t where ar.prsn_id = t.prsn_id and ar.pae_id = t.pae_id)) a
;  --106


--MOP insert to ENR
insert into perlss.enr_rqst ( id, enr_id , auth_id ,auth_status_cd, prsn_id, pae_id , auth_dt, enr_status_cd , enr_grp_cd, enr_denial_rsn_cd, created_by, created_dt, active_sw, record_version )
select 
nextval('perlss."hibernate_sequence"') id,
nextval('perlss."enr_rqst_0sq"') enr_id,
null as  auth_id,  --updated as per Sai inputs
'PAU' auth_status_cd,
prsn_id,
pae_id,
null as auth_dt,   --updated as per Sai inputs
enr_status_cd,
enr_grp_cd,
enr_denial_rsn_cd,
'PASRR_CV' as created_by,
created_dt ,
'Y' as active_sw , 0 as record_version
from (
select c.Prsn_id, c.pae_id as pae_id, ar.pae_eff_dt , 
'MOP' as enr_status_cd, 
ar.enr_grp_cd , null as enr_denial_rsn_cd, ar.created_dt  from
perlss.cnv_task c inner join perlss.adj_rqst ar on c.pae_id = ar.pae_id  
inner join perlss.tmg_task_master ttm on C.task_master_id = ttm.task_master_id 
where  c.created_by  = 'PASRR_CV' and c.task_master_id = '74'
and not exists (select 1 from perlss.enr_rqst t where ar.prsn_id = t.prsn_id and ar.pae_id = t.pae_id)
)a ;--19



--PFE Insert to ENR
insert into perlss.enr_rqst ( id, enr_id , auth_id ,auth_status_cd, prsn_id, pae_id , auth_dt, enr_status_cd , enr_grp_cd, enr_denial_rsn_cd, created_by, created_dt, active_sw, record_version ) --6315
select 
nextval('perlss."hibernate_sequence"') id,
nextval('perlss."enr_rqst_0sq"') enr_id,
null as  auth_id, --updated as per Sai inputs
'PAU' auth_status_cd,
prsn_id,
pae_id,
null as auth_dt,  --updated as per Sai inputs  
enr_status_cd,
enr_grp_cd,
enr_denial_rsn_cd,
'PASRR_CV' as created_by,
created_dt ,
'Y' as active_sw,
0 as record_version
from (select c.Prsn_id, c.pae_id as pae_id, ar.pae_eff_dt , 
'PFE' as enr_status_cd, 
ar.enr_grp_cd , null as enr_denial_rsn_cd, ar.created_dt  from
perlss.cnv_task c inner join perlss.adj_rqst ar on c.pae_id = ar.pae_id  
inner join perlss.tmg_task_master ttm on C.task_master_id = ttm.task_master_id 
where c.created_by  = 'PASRR_CV' and c.task_master_id = '8'
and not exists (select 1 from perlss.enr_rqst t where ar.prsn_id = t.prsn_id and ar.pae_id = t.pae_id)) A;--106


--NEE udpate
UPDATE perlss.tmg_task  SET enr_id = (SELECT distinct enr_rqst.enr_id
                                  FROM perlss.enr_rqst
                                  WHERE tmg_task.pae_id = enr_rqst.pae_id and enr_status_cd = 'NEE'
                                  and enr_rqst.created_by = 'PASRR_CV')
WHERE tmg_task.module_cd = 'ENR' and enr_id is null
AND EXISTS (SELECT enr_rqst.pae_id
            FROM perlss.enr_rqst 
            WHERE perlss.tmg_task.pae_id = enr_rqst.pae_id and enr_status_cd = 'NEE' and enr_rqst.created_by = 'PASRR_CV');--101

--MOP update           
UPDATE perlss.tmg_task   SET enr_id = (SELECT distinct enr_rqst.enr_id
                                  FROM perlss.enr_rqst
                                  WHERE tmg_task.pae_id = enr_rqst.pae_id and enr_status_cd = 'MOP'
                                  and enr_rqst.created_by = 'PASRR_CV')
WHERE enr_id is null and task_dtl_desc = 'Enter MOPD'
AND EXISTS (SELECT enr_rqst.pae_id
            FROM perlss.enr_rqst
            WHERE perlss.tmg_task.pae_id = enr_rqst.pae_id and enr_status_cd = 'MOP' and enr_rqst.created_by = 'PASRR_CV');--19
           
--PFE update      
 UPDATE perlss.tmg_task   SET enr_id = (SELECT distinct enr_rqst.enr_id
FROM perlss.enr_rqst
WHERE tmg_task.pae_id = enr_rqst.pae_id and enr_status_cd = 'PFE' and enr_rqst.created_by = 'PASRR_CV')
WHERE tmg_task.module_cd = 'ENR' and enr_id is null
AND EXISTS (SELECT enr_rqst.pae_id
            FROM perlss.enr_rqst
            WHERE perlss.tmg_task.pae_id = enr_rqst.pae_id and enr_status_cd = 'PFE' and enr_rqst.created_by = 'PASRR_CV');--106
			
			
--MOP insert to recertification
insert into perlss.enr_rqst ( id, enr_id , auth_id ,auth_status_cd, prsn_id, pae_id , auth_dt, enr_status_cd , enr_grp_cd, enr_denial_rsn_cd, created_by, created_dt, active_sw, record_version )
select 
nextval('perlss."hibernate_sequence"') id,
nextval('perlss."enr_rqst_0sq"') enr_id,
null as  auth_id,  --updated as per Sai inputs
'PAU' auth_status_cd,
prsn_id,
pae_id,
null as auth_dt,   --updated as per Sai inputs
enr_status_cd,
enr_grp_cd,
enr_denial_rsn_cd,
'PASRR_CV' as created_by,
created_dt ,
'Y' as active_sw , 0 as record_version
from (
select c.Prsn_id, c.pae_id as pae_id, ar.pae_eff_dt , 
'MOP' as enr_status_cd, 
ar.enr_grp_cd , null as enr_denial_rsn_cd, ar.created_dt  from
perlss.cnv_task c inner join perlss.adj_rqst ar on c.pae_id = ar.pae_id  
inner join perlss.tmg_task_master ttm on C.task_master_id = ttm.task_master_id 
where  c.created_by  = 'PASRR_CV' and c.task_master_id = '181'
and not exists (select 1 from perlss.enr_rqst t where ar.prsn_id = t.prsn_id and ar.pae_id = t.pae_id)
)a;--1


UPDATE perlss.tmg_task   SET enr_id = (SELECT distinct enr_rqst.enr_id
                                  FROM perlss.enr_rqst
                                  WHERE tmg_task.pae_id = enr_rqst.pae_id and enr_status_cd = 'MOP'
                                  and enr_rqst.created_by = 'PASRR_CV')
WHERE enr_id is null and task_dtl_desc = 'Complete CHOICES Group 1 Recertification'
AND EXISTS (SELECT enr_rqst.pae_id
            FROM perlss.enr_rqst
            WHERE perlss.tmg_task.pae_id = enr_rqst.pae_id and enr_status_cd = 'MOP' and enr_rqst.created_by = 'PASRR_CV');--1
			



insert into perlss.enr_rqst ( id, enr_id , auth_id ,auth_status_cd, prsn_id, pae_id , auth_dt, enr_status_cd , enr_grp_cd, enr_denial_rsn_cd, created_by, created_dt, active_sw, record_version )
select 
nextval('perlss."hibernate_sequence"') id,
nextval('perlss."enr_rqst_0sq"') enr_id,
null as  auth_id,  
'PAU' auth_status_cd,
prsn_id,
pae_id,
null as auth_dt,  
enr_status_cd,
enr_grp_cd,
case when denial_rsn = 'Not Medicaid Eligible' then 'INE' 
	 when denial_rsn = 'Eligible for Medicaid only - asset transfer penalty for NF vendor' then 'ELI' 
	 when denial_rsn = 'Deny TP' then 'TAR' else null end enr_denial_rsn_cd,
'PASRR_CV' as created_by,
created_dt ,
'Y' as active_sw, 0 as record_version
from (select b.Prsn_id, b.pae_id as pae_id, ar.pae_eff_dt , 
'DEN' as enr_status_cd, 
ar.enr_grp_cd , ar.created_dt , d.preenrollment_enrollmentdenialreason ,
d.enrollment_enrollmentdenialreason ,tpreview_decision,
case when d.preenrollment_enrollmentdenialreason  is not null then d.preenrollment_enrollmentdenialreason
when d.preenrollment_enrollmentdenialreason is null and d.enrollment_enrollmentdenialreason is not null 
then d.enrollment_enrollmentdenialreason else tpreview_decision end denial_rsn
from perlss.pae_rqst b  
join perlss.adj_rqst ar on b.pae_id = ar.pae_id  
join legacy.pasrr_pae_base_member_pop a on a.pasrr_review_id::text =b.legacy_id
join legacy.tmed_xml_extract_cv_qlf_no_rec d on a.tmed_num_control_pkey::text = d.num_control::text 
where  step='4'and b.created_by  = 'PASRR_CV'
and not exists (select 1 from perlss.enr_rqst t where ar.prsn_id = t.prsn_id and ar.pae_id = t.pae_id)
)a
where denial_rsn not in ('Withdrawn by NF','Withdrawn by MCO');--46 records
           



 
select pr.id,currentlocationfacility,referralfacility,legacy_id,xss.perlss_entity_id as entity_id, sot.entity_type 
from perlss.pae_rqst pr  join (select currentlocationfacility,referralfacility,reviewid 
from legacy.pasrr_events pe   
 join legacy.pasrr_level_i l1 on pe.eventid= l1.eventid 
 join legacy.pasrr_loc  pli on pe.eventid=pli.eventid)x  		  on x.reviewid::text=trim(pr.legacy_id)
 join legacy.xref_subfacility_secorg xss
on xss.level1submittingfacility=referralfacility 
		  left join perlss.sec_organization so on so.entity_id::text = xss.perlss_entity_id::text 
		  left join perlss.sec_org_type sot on so.entity_type_id = sot.entity_type_id  
		  where pr.created_by ='PASRR_CV' and pr.entity_id = '9999' and xss.perlss_entity_id is not null
		  
with sq as ( 
select pr.id,currentlocationfacility,referralfacility,legacy_id,xss.perlss_entity_id as entity_id, sot.entity_type 
from perlss.pae_rqst pr  join (select currentlocationfacility,referralfacility,reviewid 
from legacy.pasrr_events pe    
 join legacy.pasrr_loc  pli on pe.eventid=pli.eventid)x  		  on x.reviewid::text=pr.legacy_id::text
 join legacy.xref_subfacility_secorg xss on xss.level1submittingfacility=referralfacility 
left join perlss.sec_organization so on so.entity_id::text = xss.perlss_entity_id::text 
		  left join perlss.sec_org_type sot on so.entity_type_id = sot.entity_type_id  
		  where pr.created_by ='PASRR_CV' and pr.entity_id = '9999' and xss.perlss_entity_id is not null) 
		  update perlss.pae_rqst p 
		  set entity_id = sq.entity_id::int , entity_type=sq.entity_type , last_modified_by = 'PASRR_CV'
		  from sq where sq.id = p.id and p.created_by = 'PASRR_CV';   



 with sq as ( select pr.id,currentlocationfacility,referralfacility, legacy_id,xsd.perlss_entity_id as entity_id,
 sot.entity_type, so.entity_name 
 from perlss.pae_rqst pr
  join (select currentlocationfacility,referralfacility,reviewid from legacy.pasrr_events pe       
  join legacy.pasrr_loc  pli on pe.eventid=pli.eventid)x             on x.reviewid::text=pr.legacy_id ::text
  join legacy.xref_subfacility_secorg xsd on xsd.level1submittingfacility=currentlocationfacility 
 left join perlss.sec_organization so on so.entity_id::text = xsd.perlss_entity_id::text 
 left join perlss.sec_org_type sot on so.entity_type_id = sot.entity_type_id  
 where pr.created_by ='PASRR_CV' and pr.entity_id = '9999' and xsd.perlss_entity_id is not null) 
 update perlss.pae_rqst p set entity_id = sq.entity_id::int , entity_type=sq.entity_type , last_modified_by = 'PASRR_CV'
 from sq where sq.id = p.id and p.created_by = 'PASRR_CV';
 
 
 
 
 with sq as ( 
select pr.legacy_id,currentlocationfacility,referralfacility,xss.perlss_entity_id as entity_id, sot.entity_type 
from legacy.pae_rqst_test_0224 pr  join (select currentlocationfacility,referralfacility,reviewid 
from legacy.pasrr_events pe    
 join legacy.pasrr_loc  pli on pe.eventid=pli.eventid)x  		  on x.reviewid::text=pr.legacy_id::text
 join legacy.xref_subfacility_secorg xss on xss.level1submittingfacility=referralfacility 
left join perlss.sec_organization so on so.entity_id::text = xss.perlss_entity_id::text 
		  left join perlss.sec_org_type sot on so.entity_type_id = sot.entity_type_id  
		  where  pr.entity_id = '9999' and xss.perlss_entity_id is not null) 
		  update legacy.pae_rqst_test_0224 p 
		  set entity_id = sq.entity_id::int , entity_type=sq.entity_type , last_modified_by = 'PASRR_CV'
		  from sq where sq.legacy_id = p.legacy_id;   

select * from legacy.pae_rqst_test_0224 where entity_id = '9999'

 with sq as ( select pr.legacy_id,currentlocationfacility,referralfacility,xsd.perlss_entity_id as entity_id,
 sot.entity_type, so.entity_name 
 from legacy.pae_rqst_test_0224 pr
  join (select currentlocationfacility,referralfacility,reviewid from legacy.pasrr_events pe       
  join legacy.pasrr_loc  pli on pe.eventid=pli.eventid)x             on x.reviewid::text=pr.legacy_id ::text
  join legacy.xref_subfacility_secorg xsd on xsd.level1submittingfacility=currentlocationfacility 
 left join perlss.sec_organization so on so.entity_id::text = xsd.perlss_entity_id::text 
 left join perlss.sec_org_type sot on so.entity_type_id = sot.entity_type_id  
 where pr.entity_id = '9999' and xsd.perlss_entity_id is not null) 
 update legacy.pae_rqst_test_0224 p set entity_id = sq.entity_id::int , entity_type=sq.entity_type , last_modified_by = 'PASRR_CV'
 from sq where sq.legacy_id = p.legacy_id;
--Review New PASRR PAE task
--An Approved PASRR Level II record is received in PERLSS and is Converted;
--Individual is known to PERLSS and enrolled in an LTSS program then Review new PASRR PAE task will be created
INSERT INTO perlss.cnv_task
(id, task_master_id, prsn_id, pae_id, apl_id, assigned_user_id, due_dt,
role_id, entity_id, prirty_cd, ref_id, task_dtl_desc, last_modified_by,
last_modified_dt, record_version, created_by, created_dt, archived_dt, processed_flag)
select nextval('perlss.hibernate_sequence'), a.task_master_id , a.prsn_id, a.pae_id, NULL, NULL, due_dt,
NULL, NULL, 'LO', NULL, 'Review New PASRR PAE', NULL, 
NULL, 0, a.created_by, a.created_dt, null,'N'  
from (
select distinct 198 as task_master_id  ,p.pae_id , p.prsn_id,p.created_by, p.created_dt,
legacy.fn_add_business_days(to_date(to_char(p.created_dt, 'yyyy-mm-dd'), 'yyyy-mm-dd'),14) due_dt from 
perlss.pae_rqst p 
join legacy.pasrr_pae_base_member_pop pop on pop.pasrr_review_id::text  = p.legacy_id
where p.created_by = 'PASRR_CV' and pop.step in ('3','5','5a') and p.status_cd='AA' 
 and exists(select 1 from perlss.enr_rqst e where e.prsn_id = p.prsn_id 
 and e.enr_status_cd= 'ENR' and created_by <> 'PASRR_CV' and e.enr_grp_cd <> 'CG3'
 and enr_id in  ( 
      select
            max(enr_id)
      from
            perlss.enr_rqst where created_by <> 'PASRR_CV'
      and (hstry_sw = 'N'
            or hstry_sw is null)
      and active_sw = 'Y'
      group by
            pae_id,
            prsn_id))
and not exists(
select 1
from
perlss.tmg_task,
perlss.Tmg_Doc,
perlss.tmg_task_master
where
tmg_task.input_Id = Tmg_Doc.input_Id 
and Tmg_Doc.task_Master_Id = tmg_task_master.task_Master_Id
and tmg_task_master.task_Master_Id in (198)
and tmg_task.pae_id = p.pae_id)
and not exists( select 1 from perlss.cnv_task c where  p.prsn_id = c.prsn_id and p.pae_id = c.pae_id))a;


--1. Target population null then create Target Population task
INSERT INTO perlss.cnv_task
(id, task_master_id, prsn_id, pae_id, apl_id, assigned_user_id, due_dt,
role_id, entity_id, prirty_cd, ref_id, task_dtl_desc, last_modified_by,
last_modified_dt, record_version, created_by, created_dt, archived_dt, processed_flag)
select nextval('perlss.hibernate_sequence'), a.task_master_id , a.prsn_id, a.pae_id, NULL, NULL, due_dt,
NULL, NULL, 'LO', NULL, 'Add Target Population to PASRR PAE', NULL, NULL, 0, a.created_by, a.created_dt, null,'N'  
from (
select distinct 201 as task_master_id, a.prsn_id, a.pae_id,a.created_by , a.created_dt,
legacy.fn_add_business_days(to_date(to_char(a.created_dt, 'yyyy-mm-dd'), 'yyyy-mm-dd'),4) due_dt FROM
perlss.pae_rqst p 
join  perlss.adj_rqst a on p.pae_id = a.pae_id and p.prsn_id = a.prsn_id
join legacy.pasrr_pae_base_member_pop pop on pop.pasrr_review_id::text  = p.legacy_id
join perlss.adj_dtls aa on aa.adj_id = a.adj_id
join perlss.com_applcnt d on p.prsn_id = d.prsn_id
where p.created_by = 'PASRR_CV' and a.created_by = 'PASRR_CV' and pop.step in ('3','5','5a') 
and a.loc_dcsn_cd in  ('DNF','DWE') and p.status_cd ='AA' and aa.trgt_popltn_not_meet_sw is null 
and not exists(
select 1
from
perlss.tmg_task,
perlss.Tmg_Doc,
perlss.tmg_task_master
where
tmg_task.input_Id = Tmg_Doc.input_Id 
and Tmg_Doc.task_Master_Id = tmg_task_master.task_Master_Id
and tmg_task_master.task_Master_Id in('201') 
and tmg_task.pae_id = a.pae_id)
and not exists(select 1 from perlss.cnv_task c where  a.prsn_id = c.prsn_id and a.pae_id = c.pae_id))a;


--2. if target population is Met and group 3 interest is null create Group 3 interest task
INSERT INTO perlss.cnv_task
(id, task_master_id, prsn_id, pae_id, apl_id, assigned_user_id, due_dt,
role_id, entity_id, prirty_cd, ref_id, task_dtl_desc, last_modified_by,
last_modified_dt, record_version, created_by, created_dt, archived_dt, processed_flag)
select nextval('perlss.hibernate_sequence'), a.task_master_id , a.prsn_id, a.pae_id, NULL, NULL, due_dt,
NULL, NULL, 'LO', NULL, 'Add Group 3 Interest Details', NULL, NULL, 0, a.created_by, a.created_dt, null,'N'  
from (
select distinct 73 as task_master_id  ,p.pae_id , p.prsn_id,a.created_by, a.created_dt,
legacy.fn_add_business_days(to_date(to_char(a.created_dt, 'yyyy-mm-dd'), 'yyyy-mm-dd'),4) due_dt from 
perlss.pae_rqst p 
join  perlss.adj_rqst a on p.pae_id = a.pae_id and p.prsn_id = a.prsn_id
join perlss.adj_dtls aa on aa.adj_id = a.adj_id
join legacy.pasrr_pae_base_member_pop pop on pop.pasrr_review_id::text  = p.legacy_id
where p.created_by = 'PASRR_CV' and a.created_by = 'PASRR_CV' and pop.step in ('3','5','5a') 
and a.loc_dcsn_cd in  ('DNF','DWE') and   p.grp3_intrst_sw is null and  p.status_cd='AA' and aa.trgt_popltn_not_meet_sw = 'N'
and not exists(
select 1
from
perlss.tmg_task,
perlss.Tmg_Doc,
perlss.tmg_task_master
where
tmg_task.input_Id = Tmg_Doc.input_Id
and Tmg_Doc.task_Master_Id = tmg_task_master.task_Master_Id
and tmg_task_master.task_Master_Id in (73)
and tmg_task.pae_id = a.pae_id)
and not exists( select 1 from perlss.cnv_task c where  a.prsn_id = c.prsn_id and a.pae_id = c.pae_id))a;



--4.Actual discharge date not null check fin eligibility and create  PFE or NEE enrollment task-PFE
INSERT INTO perlss.cnv_task
(id, task_master_id, prsn_id, pae_id, apl_id, assigned_user_id, due_dt,
role_id, entity_id, prirty_cd, ref_id, task_dtl_desc, last_modified_by,
last_modified_dt, record_version, created_by, created_dt, archived_dt, processed_flag)
select nextval('perlss.hibernate_sequence'), a.task_master_id , a.prsn_id, a.pae_id, NULL, NULL, due_dt,
NULL, NULL, 'LO', NULL, 'Pending Financial Eligibility Determination', NULL, 
NULL, 0, a.created_by, a.created_dt, null,'N'  
from (
select distinct 8 as task_master_id  ,p.pae_id , p.prsn_id,a.created_by, a.created_dt,
a.pae_eff_dt::date,
legacy.fn_add_business_days(to_date(to_char(a.created_dt, 'yyyy-mm-dd'), 'yyyy-mm-dd'),4) due_dt from  
perlss.pae_rqst p 
join  perlss.adj_rqst a on p.pae_id = a.pae_id and p.prsn_id = a.prsn_id
join  perlss.com_applcnt ca on ca.prsn_id = p.prsn_id and  ca.active_sw='Y' and file_clearance_sw ='Y'
join legacy.pasrr_pae_base_member_pop pop on pop.pasrr_review_id::text  = p.legacy_id
where p.created_by = 'PASRR_CV' and a.created_by = 'PASRR_CV' and p.status_cd='AA'  
and p.actual_discharge_dt  is not null and pop.step in ('3','5','5a')
and not exists (select ssn from (select case when length(ssn)= 8 then '0'||ssn 
when length(ssn) = 7 then '00'||ssn::text else ssn end as ssn 
from legacy.fe_check where coe_id  in ('W01','L02','L01','W02','L03','L04', 'SSI')
and (eligibility_end_dt is null or eligibility_end_dt > current_date)) fc where fc.ssn = ca.ssn)
and not exists(
select 1
from
perlss.tmg_task,
perlss.Tmg_Doc,
perlss.tmg_task_master
where
tmg_task.input_Id = Tmg_Doc.input_Id 
and Tmg_Doc.task_Master_Id = tmg_task_master.task_Master_Id
and tmg_task_master.task_Master_Id in (8)
and module_cd = 'ENR'
and tmg_task.pae_id = a.pae_id)
and not exists( select 1 from perlss.cnv_task c where  a.prsn_id = c.prsn_id and a.pae_id = c.pae_id))a;

--4.Actual discharge date not null check fin eligibility and create  PFE or NEE enrollment task
INSERT INTO perlss.cnv_task
(id, task_master_id, prsn_id, pae_id, apl_id, assigned_user_id, due_dt,
role_id, entity_id, prirty_cd, ref_id, task_dtl_desc, last_modified_by,
last_modified_dt, record_version, created_by, created_dt, archived_dt, processed_flag)
select nextval('perlss.hibernate_sequence'), a.task_master_id , a.prsn_id, a.pae_id, NULL, NULL, due_dt,
NULL, NULL, 'LO', NULL, 'Complete New Enrollment - CHOICES Group 3', NULL, 
NULL, 0, a.created_by, a.created_dt, null,'N'  
from (
select distinct 61 as task_master_id  ,p.pae_id , p.prsn_id,a.created_by, a.created_dt,
a.pae_eff_dt::date,fc.eligibility_beg_dt::date,
legacy.fn_add_business_days(to_date(to_char(a.created_dt, 'yyyy-mm-dd'), 'yyyy-mm-dd'),4) due_dt from  
perlss.pae_rqst p 
join  perlss.adj_rqst a on p.pae_id = a.pae_id and p.prsn_id = a.prsn_id
join  perlss.com_applcnt ca on ca.prsn_id = p.prsn_id and  ca.active_sw='Y' and file_clearance_sw ='Y'
join legacy.pasrr_pae_base_member_pop pop on pop.pasrr_review_id::text  = p.legacy_id
join legacy.fe_check fc on case when length(fc.ssn)= 8 then '0'||fc.ssn when length(fc.ssn) = 7 then '00'||fc.ssn::text else fc.ssn end= ca.ssn 
where p.created_by = 'PASRR_CV' and a.created_by = 'PASRR_CV' and p.status_cd='AA'  
and p.actual_discharge_dt  is not null and pop.step in ('3','5','5a')  and fc.coe_id  in ('W01','L02','L01','W02','L03','L04', 'SSI')
 and  (fc.eligibility_end_dt is null or fc.eligibility_end_dt > current_date)
and not exists(
select 1
from
perlss.tmg_task,
perlss.Tmg_Doc,
perlss.tmg_task_master
where
tmg_task.input_Id = Tmg_Doc.input_Id 
and Tmg_Doc.task_Master_Id = tmg_task_master.task_Master_Id
and tmg_task_master.task_Master_Id in (61)
and module_cd = 'ENR'
and tmg_task.pae_id = a.pae_id)
and not exists( select 1 from perlss.cnv_task c where  a.prsn_id = c.prsn_id and a.pae_id = c.pae_id))a;


--5.Actual discharge date  null and Anticipated discharge date not null  , check FE and if FE eligible create ENR
INSERT INTO perlss.cnv_task
(id, task_master_id, prsn_id, pae_id, apl_id, assigned_user_id, due_dt,
role_id, entity_id, prirty_cd, ref_id, task_dtl_desc, last_modified_by,
last_modified_dt, record_version, created_by, created_dt, archived_dt, processed_flag)
select nextval('perlss.hibernate_sequence'), a.task_master_id , a.prsn_id, a.pae_id, NULL, NULL, due_dt,
NULL, NULL, 'LO', NULL, 'Complete New Enrollment - CHOICES Group 3', NULL, 
NULL, 0, a.created_by, a.created_dt, null,'N'  
from (
select distinct 61 as task_master_id  ,p.pae_id , p.prsn_id,a.created_by, a.created_dt,
a.pae_eff_dt::date,fc.eligibility_beg_dt::date,
legacy.fn_add_business_days(to_date(to_char(a.created_dt, 'yyyy-mm-dd'), 'yyyy-mm-dd'),4) due_dt from  
perlss.pae_rqst p 
join  perlss.adj_rqst a on p.pae_id = a.pae_id and p.prsn_id = a.prsn_id
join  perlss.pae_lvng_arrgmnt lvg on p.pae_id = lvg.pae_id 
join  perlss.com_applcnt ca on ca.prsn_id = p.prsn_id and  ca.active_sw='Y' and file_clearance_sw ='Y'
join legacy.pasrr_pae_base_member_pop pop on pop.pasrr_review_id::text  = p.legacy_id
join legacy.fe_check fc on case when length(fc.ssn)= 8 then '0'||fc.ssn when length(fc.ssn) = 7 then '00'||fc.ssn::text else fc.ssn end= ca.ssn 
where p.created_by = 'PASRR_CV' and a.created_by = 'PASRR_CV' and p.status_cd='AA'  
and p.actual_discharge_dt  is null  and lvg.anticipated_discharge_dt is not null and  pop.step in ('3','5','5a')
and  fc.coe_id  in ('W01','L02','L01','W02','L03','L04', 'SSI')
 and  (fc.eligibility_end_dt is null or fc.eligibility_end_dt > current_date)
--and a.pae_eff_dt::date - fc.eligibility_beg_dt::date<90
and not exists(
select 1
from
perlss.tmg_task,
perlss.Tmg_Doc,
perlss.tmg_task_master
where
tmg_task.input_Id = Tmg_Doc.input_Id 
and Tmg_Doc.task_Master_Id = tmg_task_master.task_Master_Id
and tmg_task_master.task_Master_Id in (61)
and module_cd = 'ENR'
and tmg_task.pae_id = a.pae_id)
and not exists( select 1 from perlss.cnv_task c where  a.prsn_id = c.prsn_id and a.pae_id = c.pae_id))a;


--6. if current living arrangement not  SNF or NFC , PFE or NEE task based on fin eligibility
--PFE
INSERT INTO perlss.cnv_task
(id, task_master_id, prsn_id, pae_id, apl_id, assigned_user_id, due_dt,
role_id, entity_id, prirty_cd, ref_id, task_dtl_desc, last_modified_by,
last_modified_dt, record_version, created_by, created_dt, archived_dt, processed_flag)
select nextval('perlss.hibernate_sequence'), a.task_master_id , a.prsn_id, a.pae_id, NULL, NULL, due_dt,
NULL, NULL, 'LO', NULL, 'Pending Financial Eligibility Determination', NULL, 
NULL, 0, a.created_by, a.created_dt, null,'N'  
from (
select distinct 8 as task_master_id,p.pae_id , p.prsn_id,p.created_by, p.created_dt,
legacy.fn_add_business_days(to_date(to_char(p.created_dt, 'yyyy-mm-dd'), 'yyyy-mm-dd'),4) due_dt from
 perlss.pae_rqst p 
join  perlss.pae_lvng_arrgmnt lvg on p.pae_id = lvg.pae_id 
join  perlss.com_applcnt ca on ca.prsn_id = p.prsn_id and  ca.active_sw='Y' and file_clearance_sw ='Y'
join legacy.pasrr_pae_base_member_pop pop on pop.pasrr_review_id::text  = p.legacy_id
where p.created_by = 'PASRR_CV' and lvg.created_by = 'PASRR_CV' and pop.step in ('3','5','5a') 
and lvg.curr_lvng_arrgmnt_cd not in  ('NFC','SNF') and p.status_cd= 'AA' 
and not exists (select ssn from (select case when length(ssn)= 8 then '0'||ssn 
when length(ssn) = 7 then '00'||ssn::text else ssn end as ssn from legacy.fe_check 
where coe_id  in ('W01','L02','L01','W02','L03','L04', 'SSI')
and (eligibility_end_dt is null or eligibility_end_dt > current_date)) fc where fc.ssn = ca.ssn)
and not exists(
select 1
from
perlss.tmg_task,
perlss.Tmg_Doc,
perlss.tmg_task_master
where
tmg_task.input_Id = Tmg_Doc.input_Id
and Tmg_Doc.task_Master_Id = tmg_task_master.task_Master_Id
and tmg_task_master.task_Master_Id in (8)
and tmg_task.pae_id = p.pae_id)
and not exists( select 1 from perlss.cnv_task c where  p.prsn_id = c.prsn_id and p.pae_id = c.pae_id))a;

--NEE
INSERT INTO perlss.cnv_task
(id, task_master_id, prsn_id, pae_id, apl_id, assigned_user_id, due_dt,
role_id, entity_id, prirty_cd, ref_id, task_dtl_desc, last_modified_by,
last_modified_dt, record_version, created_by, created_dt, archived_dt, processed_flag)
select nextval('perlss.hibernate_sequence'), a.task_master_id , a.prsn_id, a.pae_id, NULL, NULL, due_dt,
NULL, NULL, 'LO', NULL, 'Complete New Enrollment - CHOICES Group 3', NULL, 
NULL, 0, a.created_by, a.created_dt, null,'N'  
from (
select distinct 61 as task_master_id,p.pae_id , p.prsn_id,p.created_by, p.created_dt,
legacy.fn_add_business_days(to_date(to_char(p.created_dt, 'yyyy-mm-dd'), 'yyyy-mm-dd'),4) due_dt from
 perlss.pae_rqst p 
join  perlss.pae_lvng_arrgmnt lvg on p.pae_id = lvg.pae_id 
join legacy.pasrr_pae_base_member_pop pop on pop.pasrr_review_id::text  = p.legacy_id
join  perlss.com_applcnt ca on ca.prsn_id = p.prsn_id and  ca.active_sw='Y' and file_clearance_sw ='Y'
join legacy.fe_check fc on case when length(fc.ssn)= 8 then '0'||fc.ssn when length(fc.ssn) = 7 then '00'||fc.ssn::text else fc.ssn end= ca.ssn 
where p.created_by = 'PASRR_CV' and lvg.created_by = 'PASRR_CV' and pop.step in ('3','5','5a') 
and lvg.curr_lvng_arrgmnt_cd not in  ('NFC','SNF') and p.status_cd= 'AA' 
and  fc.coe_id  in ('W01','L02','L01','W02','L03','L04', 'SSI')
 and  (fc.eligibility_end_dt is null or fc.eligibility_end_dt > current_date)
and not exists(
select 1
from
perlss.tmg_task,
perlss.Tmg_Doc,
perlss.tmg_task_master
where
tmg_task.input_Id = Tmg_Doc.input_Id
and Tmg_Doc.task_Master_Id = tmg_task_master.task_Master_Id
and tmg_task_master.task_Master_Id in (61)
and tmg_task.pae_id = p.pae_id)
and not exists( select 1 from perlss.cnv_task c where  p.prsn_id = c.prsn_id and p.pae_id = c.pae_id))a;


update perlss.cnv_task c
set pasrr_id = d.pasrr_id from  
					(select distinct pae_id ,pasrr_id,prsn_id 
					from perlss.pasrr_rqst where  created_by = 'PASRR_CV' and last_modified_by is null) d 
where d.pae_id = c.pae_id and d.prsn_id =c.prsn_id
and c.pasrr_id is null and c.created_by = 'PASRR_CV';

update perlss.cnv_task c
set created_dt = current_date
where c.created_by = 'PASRR_CV';


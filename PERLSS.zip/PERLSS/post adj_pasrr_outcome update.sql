/*select  * from perlss.pasrr_rqst  
where last_modified_by like 'PASRR_U%'
except
select distinct pae_id from perlss.adj_rqst  
where adj_id in (select adj_id from perlss.adj_pasrr_outcome where last_modified_by = 'PASRR_CV');

create table legacy.adj_pasrr_outcome_analysis as
select * from perlss.adj_pasrr_outcome apo 

select * from perlss.adj_rqst 
where pae_id in ('PAE200057091','PAE200055153','PAE200048256','PAE200050548','PAE200111860');

select * from perlss.adj_pasrr_outcome where adj_id in 
(select adj_id from perlss.adj_rqst 
where pae_id in ('PAE200057091','PAE200055153','PAE200048256','PAE200050548','PAE200111860'));

select * from perlss.adj_pasrr_outcome where adj_id in 
(select adj_id from perlss.adj_rqst 
where pae_id in ('PAE200057091','PAE200055153','PAE200048256','PAE200050548','PAE200111860'));

with sq as (
select  a.pasrr_id ,a.episode_id, a.pae_id, b.prsn_id , o.adj_id, o.id from perlss.pasrr_rqst a 
join perlss.pae_rqst b on a.pae_id = b.pae_id
join perlss.com_applcnt ca on ca.prsn_id = b.prsn_id 
join perlss.adj_rqst d  on d.pae_id = b.pae_id and d.active_sw='Y'
join perlss.adj_pasrr_outcome o on o.adj_id = d.adj_id
where a.created_by ='PASRR_CV' and a.last_modified_by like 'PASRR_U%' and o.pasrr_id is null)
update perlss.adj_pasrr_outcome p
set pasrr_id = sq.pasrr_id ,episode_id = sq.episode_id, last_modified_by='PASRR_CV'
from sq where sq.id = p.id and p.created_by <> 'PASRR_CV';


select * from legacy.adj_pasrr_outcome_analysis where last_modified_by = 'PASRR_CV' and adj_id = 100049207;

select  a.pasrr_id ,a.episode_id, a.pae_id, b.prsn_id  from perlss.pasrr_rqst a 
join perlss.pae_rqst b on a.pae_id = b.pae_id
join perlss.com_applcnt ca on ca.prsn_id = b.prsn_id
join perlss.adj_rqst d  on d.pae_id = b.pae_id
where adj_id = '100049207'



select * from perlss.cnv_doc_dtls cdd where created_by = 'PASRR_CV' and file_name like 'idd%'

*/


with sq as (
select  a.pasrr_id ,a.episode_id, a.lvl1_eff_dt,a.source_cd, a.type_cd,a.lvl1_end_dt,
a.pae_id, b.prsn_id , o.adj_id, o.id, a.lvl2_deter_dt from perlss.pasrr_rqst a 
join perlss.pae_rqst b on a.pae_id = b.pae_id
join perlss.com_applcnt ca on ca.prsn_id = b.prsn_id 
join perlss.adj_rqst d  on d.pae_id = b.pae_id and d.active_sw='Y'
join perlss.adj_pasrr_outcome o on o.adj_id = d.adj_id
where a.created_by ='PASRR_CV' and a.last_modified_by like 'PASRR_U%')
update perlss.adj_pasrr_outcome p
set pasrr_id = sq.pasrr_id ,
episode_id = sq.episode_id, 
last_modified_by='PASRR_CV', 
lvl1_eff_dt = sq.lvl1_eff_dt  ,
lvl2_dcsn_dt = sq.lvl2_deter_dt, 
source_cd= sq.source_cd,
type_cd= sq.type_cd,
lvl1_end_dt= sq.lvl1_end_dt,
link_sw='Y'
from sq where sq.adj_id = p.adj_id and p.created_by <> 'PASRR_CV' and p.lvl1_dcsn_cd is not null;

with sq as (
select  a.pasrr_id ,a.episode_id, a.lvl1_eff_dt,a.source_cd, a.type_cd,a.lvl1_end_dt,a.lvl2_deter_dt,
a.pae_id, b.prsn_id , o.adj_id, o.id from perlss.pasrr_rqst a 
join perlss.pae_rqst b on a.pae_id = b.pae_id
join perlss.com_applcnt ca on ca.prsn_id = b.prsn_id 
join perlss.adj_rqst d  on d.pae_id = b.pae_id and d.active_sw='Y'
join perlss.adj_pasrr_outcome o on o.adj_id = d.adj_id
where a.created_by ='PASRR_CV' and a.last_modified_by like 'PASRR_U%')
update perlss.adj_pasrr_outcome p
set pasrr_id = sq.pasrr_id ,
episode_id = sq.episode_id, 
lvl1_eff_dt = sq.lvl1_eff_dt  ,
lvl1_end_dt= sq.lvl1_end_dt,
last_modified_by='PASRR_CV', 
lvl2_dcsn_dt = sq.lvl2_deter_dt  , 
source_cd= sq.source_cd,
type_cd= sq.type_cd,
link_sw='Y'
from sq where sq.adj_id = p.adj_id and p.created_by <> 'PASRR_CV' and p.lvl2_dcsn_cd is not null;
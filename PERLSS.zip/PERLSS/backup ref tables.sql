CREATE TABLE legacy.ref_rqst_kb_04052023					AS SELECT * FROM PERLSS.ref_rqst				;
CREATE TABLE legacy.ref_app_addr_dtl_kb_04052023            AS SELECT * FROM PERLSS.ref_app_addr_dtl        ;
CREATE TABLE legacy.ref_app_cntct_dtl_kb_04052023           AS SELECT * FROM PERLSS.ref_app_cntct_dtl       ;
CREATE TABLE legacy.ref_applcnt_dtls_kb_04052023            AS SELECT * FROM PERLSS.ref_applcnt_dtls        ;
CREATE TABLE legacy.ref_living_arrngmt_kb_04052023          AS SELECT * FROM PERLSS.ref_living_arrngmt      ;
CREATE TABLE legacy.kb_referral_closure_kb_04052023         AS SELECT * FROM PERLSS.kb_referral_closure     ;


GRANT ALL ON TABLE Legacy.ref_rqst_kb_04052023 TO ro_perlss;
GRANT ALL ON TABLE Legacy.ref_rqst_kb_04052023 TO rw_perlss;

GRANT ALL ON TABLE Legacy.ref_app_addr_dtl_kb_04052023 TO ro_perlss;
GRANT ALL ON TABLE Legacy.ref_app_addr_dtl_kb_04052023 TO rw_perlss;

GRANT ALL ON TABLE Legacy.ref_app_cntct_dtl_kb_04052023 TO ro_perlss;
GRANT ALL ON TABLE Legacy.ref_app_cntct_dtl_kb_04052023 TO rw_perlss;

GRANT ALL ON TABLE Legacy.ref_applcnt_dtls_kb_04052023 TO ro_perlss;
GRANT ALL ON TABLE Legacy.ref_applcnt_dtls_kb_04052023 TO rw_perlss;

GRANT ALL ON TABLE Legacy.ref_living_arrngmt_kb_04052023 TO ro_perlss;
GRANT ALL ON TABLE Legacy.ref_living_arrngmt_kb_04052023 TO rw_perlss;

GRANT ALL ON TABLE Legacy.kb_referral_closure_kb_04052023 TO ro_perlss;
GRANT ALL ON TABLE Legacy.kb_referral_closure_kb_04052023 TO rw_perlss;

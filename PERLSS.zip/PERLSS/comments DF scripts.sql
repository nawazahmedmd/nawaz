select * from (select distinct af.id,af.record_version,af.adj_id, a.legacy_comments, length(a.legacy_comments) as legacy_length, a.leg_functnl_measure_cd,
length(af.comments) perlss_length,af.comments perlss_comments ,af.functnl_measure_cd
--select count(1)
from legacy.pasrr_events b    
join legacy.wrk_pasrr_clients w on b.reviewid::bigint  = w.maximus_reviewid::bigint 
 join (select eventid, 'TRAN' leg_functnl_measure_cd ,trim(ADLTransferRationale) as legacy_comments from legacy.pasrr_loc
union 
select eventid, 'MOBL' leg_functnl_measure_cd ,trim(ADLWalkingRationale) as legacy_comments from legacy.pasrr_loc
union 
select eventid, 'MOBW' leg_functnl_measure_cd ,trim(ADLMobilityRationale) as legacy_comments from legacy.pasrr_loc
union 
select eventid, 'EATG' leg_functnl_measure_cd ,trim(ADLEatingRationale) as legacy_comments from legacy.pasrr_loc
union 
select eventid, 'TLTG' leg_functnl_measure_cd ,trim(ADLToiletingRationale) as legacy_comments from legacy.pasrr_loc
union 
select eventid, 'TLTI' leg_functnl_measure_cd ,trim(ADLIncontinentCareRationale) as legacy_comments from legacy.pasrr_loc
union 
select eventid, 'TLTC' leg_functnl_measure_cd ,trim(ADLCatheterCareRationale) as legacy_comments from legacy.pasrr_loc
union 
select eventid, 'ORNT' leg_functnl_measure_cd ,trim(ADLOrientationRationale) as legacy_comments from legacy.pasrr_loc
union 
select eventid, 'ECOM' leg_functnl_measure_cd ,trim(ADLExpressiveRationale) as legacy_comments from legacy.pasrr_loc
union 
select eventid, 'RCOM' leg_functnl_measure_cd ,trim(ADLReceptiveRationale) as legacy_comments from legacy.pasrr_loc
union 
select eventid, 'MEDC' leg_functnl_measure_cd ,trim(ADLMedsAdminRationale) as legacy_comments from legacy.pasrr_loc
union 
select eventid, 'BHVR' leg_functnl_measure_cd ,trim(ADLBehaviorRationale) as legacy_comments from legacy.pasrr_loc) a on b.eventid  = a.eventid
 join perlss.pae_rqst p on p.legacy_id::text = w.maximus_reviewid::text
 join perlss.adj_rqst r on r.pae_id = p.pae_id
 join perlss.adj_functnl_assmnt af on af.adj_id = r.adj_id and af.functnl_measure_cd = a.leg_functnl_measure_cd
where  w.source_system_nm = 'MAXIMUS' and valid_sw= 'Y' and 	xref_valid_sw='Y'
and r.created_by  = 'PASRR_CV' and w.perlss_sw ='N' and af.created_by='PASRR_CV') a where legacy_length is not null 
and legacy_length <> perlss_length;--49



select * from (select distinct af.id,af.record_version, af.adj_id, a.legacy_comments, length(a.legacy_comments)  as legacy_length, a.leg_srvc_name_cd,
length(af.comments) perlss_length,af.comments perlss_comments,af.srvc_name_cd
--select count(1)
from legacy.pasrr_events b    
join legacy.wrk_pasrr_clients w on b.reviewid::bigint  = w.maximus_reviewid::bigint 
 join (
select eventid, 'WCS' leg_srvc_name_cd ,WoundCareDecubitusrationale   as legacy_comments from legacy.pasrr_loc
union 
select eventid, 'OWC' leg_srvc_name_cd ,WoundCareOtherrationale   as legacy_comments from legacy.pasrr_loc
union 
select eventid, 'ISS' leg_srvc_name_cd ,InjectionsInsulinrationale   as legacy_comments from legacy.pasrr_loc
union 
select eventid, 'IOT' leg_srvc_name_cd ,InjectionsOtherrationale   as legacy_comments from legacy.pasrr_loc
union 
select eventid, 'INT' leg_srvc_name_cd ,IntravenousFluidsrationale   as legacy_comments from legacy.pasrr_loc
union 
select eventid, 'ISP' leg_srvc_name_cd ,IsolationPrecautionsrationale   as legacy_comments from legacy.pasrr_loc
union 
select eventid, 'OCT' leg_srvc_name_cd ,OccupationalTherapyrationale   as legacy_comments from legacy.pasrr_loc
union 
select eventid, 'PHT' leg_srvc_name_cd ,PhysicalTherapyrationale   as legacy_comments from legacy.pasrr_loc
union 
select eventid, 'TCO' leg_srvc_name_cd ,CatheterOstomyrationale   as legacy_comments from legacy.pasrr_loc
union 
select eventid, 'TSI' leg_srvc_name_cd ,SelfInjectionrationale   as legacy_comments from legacy.pasrr_loc
union 
select eventid, 'TPN' leg_srvc_name_cd ,ParenteralNutritionrationale   as legacy_comments from legacy.pasrr_loc
union 
select eventid, 'TFE' leg_srvc_name_cd ,TubeFeedingrationale   as legacy_comments from legacy.pasrr_loc
union 
select eventid, 'PED' leg_srvc_name_cd ,PeritonealDialysisrationale   as legacy_comments from legacy.pasrr_loc
union 
select eventid, 'PCA' leg_srvc_name_cd ,PCAPumprationale   as legacy_comments from legacy.pasrr_loc
union 
select eventid, 'TRS' leg_srvc_name_cd ,Tracheostomyrationale   as legacy_comments from legacy.pasrr_loc) a on b.eventid  = a.eventid
 join perlss.pae_rqst p on p.legacy_id::text = w.maximus_reviewid::text
 join perlss.adj_rqst r on r.pae_id = p.pae_id
 join perlss.adj_skilled_srvcs af on af.adj_id = r.adj_id and af.srvc_name_cd = a.leg_srvc_name_cd
where  w.source_system_nm = 'MAXIMUS' and valid_sw= 'Y' and 	xref_valid_sw='Y'
and r.created_by  = 'PASRR_CV' and w.perlss_sw ='N' ) a where legacy_length is not null 
and legacy_length <> perlss_length;-77


select * from (select distinct af.id,af.record_version,p.episode_id ,af.pasrr_id, a.legacy_comments, length(a.legacy_comments) as legacy_length, a.leg_functnl_measure_cd,
length(af.comments) perlss_length,af.comments perlss_comments ,af.functnl_measure_cd
--select count(1)
from legacy.pasrr_events b    
 join (select eventid, 'TRAN' leg_functnl_measure_cd ,trim(ADLTransferRationale) as legacy_comments from legacy.pasrr_loc
union 
select eventid, 'MOBL' leg_functnl_measure_cd ,trim(ADLWalkingRationale) as legacy_comments from legacy.pasrr_loc
union 
select eventid, 'MOBW' leg_functnl_measure_cd ,trim(ADLMobilityRationale) as legacy_comments from legacy.pasrr_loc
union 
select eventid, 'EATG' leg_functnl_measure_cd ,trim(ADLEatingRationale) as legacy_comments from legacy.pasrr_loc
union 
select eventid, 'TLTG' leg_functnl_measure_cd ,trim(ADLToiletingRationale) as legacy_comments from legacy.pasrr_loc
union 
select eventid, 'TLTI' leg_functnl_measure_cd ,trim(ADLIncontinentCareRationale) as legacy_comments from legacy.pasrr_loc
union 
select eventid, 'TLTC' leg_functnl_measure_cd ,trim(ADLCatheterCareRationale) as legacy_comments from legacy.pasrr_loc
union 
select eventid, 'ORNT' leg_functnl_measure_cd ,trim(ADLOrientationRationale) as legacy_comments from legacy.pasrr_loc
union 
select eventid, 'ECOM' leg_functnl_measure_cd ,trim(ADLExpressiveRationale) as legacy_comments from legacy.pasrr_loc
union 
select eventid, 'RCOM' leg_functnl_measure_cd ,trim(ADLReceptiveRationale) as legacy_comments from legacy.pasrr_loc
union 
select eventid, 'MEDC' leg_functnl_measure_cd ,trim(ADLMedsAdminRationale) as legacy_comments from legacy.pasrr_loc
union 
select eventid, 'BHVR' leg_functnl_measure_cd ,trim(ADLBehaviorRationale) as legacy_comments from legacy.pasrr_loc) a on b.eventid  = a.eventid
 join perlss.pasrr_rqst p on p.episode_id::text = b.reviewid::text
 join perlss.pasrr_functnl_assmnt af on af.pasrr_id = p.pasrr_id and af.functnl_measure_cd = a.leg_functnl_measure_cd
where  p.created_by  = 'PASRR_CV' and af.created_by='PASRR_CV') a where legacy_length is not null 
and legacy_length <> perlss_length; --4685
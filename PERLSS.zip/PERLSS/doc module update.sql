with sq as (
select distinct b.upload_dt  ,b.attachment_type , b.prsn_id , c.pasrr_id 
from perlss.int_pasrr_doc_sync_stg b 
join  perlss.doc_module_mapping a on a.doc_type = b.attachment_type   and a.prsn_id =b.prsn_id 
join perlss.pasrr_rqst c on c.pasrr_id = a.pasrr_id  and a.prsn_id = c.prsn_id and c.episode_id::text = b.review_id::text
where a.created_by = 'IN-RCPSRRDOCSYNC-DLY' and B.last_modified_by = 'IN-RCPSRRDOCSYNC-DLY') 
update perlss.doc_module_mapping p
set created_dt = sq.upload_dt
from sq where sq.attachment_type = p.doc_type 
and sq.pasrr_id =p.pasrr_id and sq.prsn_id = p.prsn_id
and p.created_by = 'IN-RCPSRRDOCSYNC-DLY';
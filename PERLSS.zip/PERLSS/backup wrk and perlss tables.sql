select * into legacy.pasrr_pae_base_member_pop_bkp_20250221_dryrun5 from legacy.pasrr_pae_base_member_pop;
select * into legacy.pasrr_mmis_base_member_pop_bkp_20250221_dryrun5 from legacy.pasrr_mmis_base_member_pop;
select * into legacy.pasrr_tmed_base_member_pop_bkp_20250221_dryrun5 from legacy.pasrr_tmed_base_member_pop;
select * into legacy.pasrr_base_member_pop_bkp_20250221_dryrun5 from legacy.pasrr_base_member_pop;
select * into legacy.pasrr_mdm_inputfile_generation_bkp_20250221_dryrun5 from legacy.pasrr_mdm_inputfile_generation;
select * into legacy.wrk_pasrr_clients_bkp_20250221_dryrun5 from legacy.wrk_pasrr_clients;
select * into legacy.pasrr_wrk_error_log_bkp_20250221_dryrun5 from legacy.pasrr_wrk_error_log;
select * into legacy.pasrr_pae_base_member_pop_fload_bkp_20250221_dryrun5 from legacy.pasrr_pae_base_member_pop_fload;

create table legacy.cnv_task_bkp_20250221_dryrun5 as select *  from perlss.cnv_task; 
create table legacy.tmg_task_bkp_20250221_dryrun5 as select *  from perlss.tmg_task; 


create table legacy.com_comments_bkp_20250221_dryrun5 as select *  from perlss.com_comments; 
create table legacy.com_notes_bkp_20250221_dryrun5 as select *  from perlss.com_notes; 
create table legacy.com_work_flow_analytics_bkp_20250221_dryrun5 as select *  from perlss.com_work_flow_analytics; 
create table legacy.com_applcnt_access_bkp_20250221_dryrun5 as select *  from perlss.com_applcnt_access; 
create table legacy.cnv_doc_dtls_bkp_20250221_dryrun5 as select *  from perlss.cnv_doc_dtls   ; 
create table legacy.int_pasrr_doc_sync_stg_bkp_20250221_dryrun5 as select *  from perlss.int_pasrr_doc_sync_stg;
create table legacy.com_applcnt_bkp_20250221_dryrun5 as select *  from perlss.com_applcnt; 


create table legacy.enr_bnft_bkp_20250221_dryrun5 as select *  from perlss.enr_bnft ;
create table legacy.enr_dsnr_dtls_bkp_20250221_dryrun5     as select *  from perlss.enr_dsnr_dtls ;
create table legacy.enr_patient_lblty_dtls_bkp_20250221_dryrun5     as select *  from perlss.enr_patient_lblty_dtls ; 
create table legacy.enr_financial_elig_bkp_20250221_dryrun5 as select *  from perlss.enr_financial_elig  ;
create table legacy.enr_dtls_bkp_20250221_dryrun5 as select *  from perlss.enr_dtls ;
create table legacy.enr_rqst_bkp_20250221_dryrun5 as select *  from perlss.enr_rqst ;

create table legacy.pasrr_demo_dtls_bkp_20250221_dryrun5 as select *  from perlss.pasrr_demo_dtls  ;
create table legacy.pasrr_addr_dtl_bkp_20250221_dryrun5 as select *  from perlss.pasrr_addr_dtl  ;
create table legacy.pasrr_skilled_srvcs_bkp_20250221_dryrun5 as select *  from perlss.pasrr_skilled_srvcs  ;
create table legacy.pasrr_loc_dtls_bkp_20250221_dryrun5     as select *  from perlss.pasrr_loc_dtls ;
create table legacy.pasrr_outcome_dtls_bkp_20250221_dryrun5 as select *  from perlss.pasrr_outcome_dtls ; 
create table legacy.pasrr_functnl_assmnt_bkp_20250221_dryrun5 as select *  from perlss.pasrr_functnl_assmnt ; 
create table legacy.pasrr_submtr_dtls_bkp_20250221_dryrun5 as select *  from perlss.pasrr_submtr_dtls ;
create table legacy.pasrr_rqst_bkp_20250221_dryrun5 as select *  from perlss.pasrr_rqst ;



create table legacy.adj_clrfcn_rsn_bkp_20250221_dryrun5     as select *  from perlss.adj_clrfcn_rsn    ; 
create table legacy.adj_functnl_assmnt_bkp_20250221_dryrun5     as select *  from perlss.adj_functnl_assmnt   ; 
create table legacy.adj_safety_determn_bkp_20250221_dryrun5     as select *  from perlss.adj_safety_determn; 
create table legacy.adj_pasrr_outcome_bkp_20250221_dryrun5     as select *  from perlss.adj_pasrr_outcome; 
create table legacy.adj_skilled_srvcs_info_bkp_20250221_dryrun5     as select *  from perlss.adj_skilled_srvcs_info; 
create table legacy.adj_skilled_srvcs_bkp_20250221_dryrun5     as select *  from perlss.adj_skilled_srvcs; 
create table legacy.adj_dtls_bkp_20250221_dryrun5     as select *  from perlss.adj_dtls   ; 
create table legacy.adj_rqst_bkp_20250221_dryrun5     as select *  from perlss.adj_rqst; 

create table legacy.pae_lvng_arrgmnt_bkp_20250221_dryrun5 as select * from perlss.pae_lvng_arrgmnt;
create table legacy.pae_doc_summary_bkp_20250221_dryrun5 as select * from perlss.pae_doc_summary pds ;
create table legacy.pae_sis_assessment_bkp_20250221_dryrun5     as select *  from perlss.pae_sis_assessment ;
create table legacy.pae_certify_of_assmnt_bkp_20250221_dryrun5     as select *  from perlss.pae_certify_of_assmnt ;
create table legacy.pae_action_bkp_20250221_dryrun5     as select *  from perlss.pae_action ;
create table legacy.pae_flow_sequence_bkp_20250221_dryrun5     as select *  from perlss.pae_flow_sequence ;
create table legacy.pae_chrnc_med_diagns_bkp_20250221_dryrun5     as select *  from perlss.pae_chrnc_med_diagns ;
create table legacy.pae_driver_flow_bkp_20250221_dryrun5     as select *  from perlss.pae_driver_flow ;
create table legacy.pae_med_diagns_dtls_bkp_20250221_dryrun5     as select *  from perlss.pae_med_diagns_dtls ; 
create table legacy.pae_medical_diagnosis_bkp_20250221_dryrun5     as select *  from perlss.pae_medical_diagnosis ;
create table legacy.pae_program_selection_bkp_20250221_dryrun5     as select *  from perlss.pae_program_selection ;
create table legacy.pae_skilled_srvc_summary_bkp_20250221_dryrun5     as select *  from perlss.pae_skilled_srvc_summary ;

create table legacy.pae_activities_behavrl_dtl_bkp_20250221_dryrun5     as select *  from perlss.pae_activities_behavrl_dtl ; 
create table legacy.pae_activities_lvng_bkp_20250221_dryrun5     as select *  from perlss.pae_activities_lvng ; 
create table legacy.pae_app_addr_dtl_bkp_20250221_dryrun5     as select *  from perlss.pae_app_addr_dtl    ; 
create table legacy.pae_app_cntct_dtl_bkp_20250221_dryrun5     as select *  from perlss.pae_app_cntct_dtl   ; 
create table legacy.pae_respiratory_care_bkp_20250221_dryrun5     as select *  from perlss.pae_respiratory_care; 
create table legacy.pae_safety_deter_form_bkp_20250221_dryrun5     as select *  from perlss.pae_safety_deter_form; 
create table legacy.pae_safety_deter_sum_bkp_20250221_dryrun5     as select *  from perlss.pae_safety_deter_sum; 
create table legacy.pae_skilled_srvc_dtl_bkp_20250221_dryrun5     as select *  from perlss.pae_skilled_srvc_dtl; 

create table legacy.pae_submission_bkp_20250221_dryrun5     as select *  from perlss.pae_submission; 
create table legacy.pae_rqst_bkp_20250221_dryrun5     as select *   from perlss.pae_rqst;
select * from perlss.pae_activities_behavrl_dtl pabd 
where created_by='CV_11';

select COUNT(1), PAE_ID from perlss.pae_activities_behavrl_dtl
where created_by= 'CV_11'
group by PAE_ID
having COUNT(1)>1;

select * from  perlss.pae_activities_behavrl_dtl where pae_id = 'PAE200074413';

select * from perlss.pae_activities_behavrl_dtl a
where created_by = 'CV_11'
and not exists(select 1 from perlss.pae_activities_lvng b where b.id = a.pae_activities_lvng_id);
select 
nextval('perlss.hibernate_sequence') as ID,
 * from (
with temptb as(
select distinct 
'Conversion'	beh_intrvntn
,'Conversion'	beh_type
,NULL	last_modified_by
,NULL	last_modified_dt
,r.pae_id as	pae_id
,'A' as CONVERSION_RUN_STATUS
,lv.id as pae_activities_lvng_id
from  perlss.pae_rqst r
join perlss.pae_activities_lvng lv on lv.pae_id = r.pae_id
join legacy.wrk_pasrr_clients w on r.legacy_id::text = w.maximus_reviewid::text --and w.perlss_indv_id = r.prsn_id 
where  w.source_system_nm = 'MAXIMUS' 
and valid_sw= 'Y' and 	xref_valid_sw='Y' 
and r.created_by  = 'CV_'|| (select CNV_RUN_NUM from legacy.wrk_conversion_run where cnv_run_status = 'A')
)
select distinct * from temptb 
)a

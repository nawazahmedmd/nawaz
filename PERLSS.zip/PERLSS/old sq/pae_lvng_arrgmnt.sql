select 
nextval('perlss.hibernate_sequence') as ID,
 * from (
with temptb as(
select distinct 
upper(trim(l1.Level1SubmittingFacilityAddress))		addr_line_1
,upper(trim(l1.Level1SubmittingFacilityAddress))		addr_line_2
,b.NFAdmitDate	admsn_dt
,NULL  	anticipated_discharge_dt
,NULL   anticipated_release_dt
,upper(trim(l1.Level1SubmittingFacilityCity))	city
,NULL  	cnty_cd
,'NFC'	curr_lvng_arrgmnt_cd
,'NES'	expctd_discharge_cd
,NULL  	extsn
,NULL  	incarceration_dt
,NULL   intlctl_disable_sw
,NULL  	last_modified_by
,NULL  	last_modified_dt
,NULL   long_term_care_sw
,NULL  	lvng_arrgmnt_desc
,NULL   mental_hlth_sw
,NULL   none_sw
,cmp.org_id	nursing_facility_name_cd
,cmp.org_id	org_id
,cmp.org_id	org_loc_id
,NULL	othr_facility_name
,r.pae_id pae_id
,NULL  	ph_num
,NULL   phychiatric_hosp_sw
,NULL  	phycl_disable_sw
,cmp.provider_id	provider_id
,NULL   	sch_outside_sw
,NULL   	special_sch_sw
,upper(trim(l1.Level1SubmittingFacilityState))	state_cd
,upper(trim(l1.Level1SubmittingFacilityZip))		zip
, r.legacy_id
,'A' as CONVERSION_RUN_STATUS
from  perlss.pae_rqst r
join legacy.wrk_pasrr_clients w on r.legacy_id::text = w.maximus_reviewid::text 
join legacy.pasrr_events b on b.reviewid::bigint  = w.maximus_reviewid::bigint
left join legacy.pasrr_level_i l1 on  b.eventid::text = l1.eventid::text
left join perlss.com_provider_master cmp 
     on upper((trim(b.currentlocationfacility)))=upper((trim(cmp.provider_name)))
where  w.source_system_nm = 'MAXIMUS' and valid_sw= 'Y' and 	xref_valid_sw='Y'
and r.created_by  = 'CV_'|| (select CNV_RUN_NUM from legacy.wrk_conversion_run where cnv_run_status = 'A')
)
select distinct * from temptb 
)a;
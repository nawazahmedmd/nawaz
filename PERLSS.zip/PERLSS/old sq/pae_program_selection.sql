select 
nextval('perlss.hibernate_sequence') as ID,
 * from (
with temptb as(
select distinct 
Null	actual_discharge_dt
,'N'	choices_grp_3_sw
,NULL	last_modified_by
,NULL	last_modified_dt
,r.pae_id pae_id
,coalesce(r.pae_rqst_dt   , '2022-09-17') as program_rqst_dt
, r.program_cd	program_type_cd
, r.legacy_id
,'A' as CONVERSION_RUN_STATUS
from  perlss.pae_rqst r
join legacy.wrk_pasrr_clients w on r.legacy_id::text = w.maximus_reviewid::text --and w.perlss_indv_id = r.prsn_id 
where  w.source_system_nm = 'MAXIMUS' 
and valid_sw= 'Y' and 	xref_valid_sw='Y' 
and r.created_by  = 'CV_'|| (select CNV_RUN_NUM from legacy.wrk_conversion_run where cnv_run_status = 'A')
)
select distinct * from temptb 
)a;
select * from perlss.pae_program_selection pabd 
where created_by='CV_11';

select COUNT(1), PAE_ID from perlss.pae_program_selection
group by PAE_ID
having COUNT(1)>1;--0

select * from perlss.pae_program_selection a
where created_by = 'CV_11'
and not exists(select 1 from perlss.pae_rqst b where b.pae_id = a.pae_id);--0

select * from perlss.pae_program_selection a
where created_by = 'CV_11'
and exists(select 1 from perlss.pae_rqst b where b.pae_id = a.pae_id);--should be above count

select * from PERLSS.PAE_RQST where LEGACY_ID = '736851';

select * from perlss.pae_program_selection pal  where created_by ='CV_11'
and pae_id = 'PAE200125425';

select * from legacy.pasrr_loc where eventid in 
(select eventid from legacy.pasrr_events where reviewid::text in 
(select legacy_id::text from perlss.pae_rqst where pae_id = 'PAE200125425')) 
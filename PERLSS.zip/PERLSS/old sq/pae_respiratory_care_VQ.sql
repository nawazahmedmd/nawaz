select * from perlss.pae_respiratory_care prc  
where created_by='CV_11';

select COUNT(1), PAE_ID from perlss.pae_respiratory_care
group by PAE_ID
having COUNT(1)>1;--0

select * from perlss.pae_respiratory_care a
where created_by = 'CV_11'
and not exists(select 1 from perlss.pae_rqst b where b.pae_id = a.pae_id);--0

select * from perlss.pae_respiratory_care a
where created_by = 'CV_11'
and  exists(select 1 from perlss.pae_rqst b where b.pae_id = a.pae_id);--0

select * from perlss.pae_respiratory_care a
where created_by = 'CV_11' and tracheal_req_start_dt is null and chrnc_req_start_dt is null;

select chronicventilatorservices , trachealsuctioning  from legacy.pasrr_loc where eventid in 
(select eventid from legacy.pasrr_events where reviewid::text in 
(select legacy_id::text from perlss.pae_rqst where pae_id in  ('PAE200103426','PAE200103427'))); 

select * from perlss.pae_respiratory_care a
where created_by = 'CV_11' and tracheal_req_start_dt is not null;--30 days

select  trachealsuctioning , trachealsuctioningclinicaldetermination ,
trachealsuctioningrationale ,chronicventilatorservices 
from legacy.pasrr_loc where eventid in 
(select eventid from legacy.pasrr_events where reviewid::text in 
(select legacy_id::text from perlss.pae_rqst where pae_id in  ('PAE200104304'))); 

select * from perlss.pae_respiratory_care a
where created_by = 'CV_11' and chrnc_req_start_dt  is not null;--30 days

select  chronicventilatorservices , ventilatorclinicaldetermination , ventilatorrationale 
from legacy.pasrr_loc where eventid in 
(select eventid from legacy.pasrr_events where reviewid::text in 
(select legacy_id::text from perlss.pae_rqst where pae_id in  ('PAE200104012')));
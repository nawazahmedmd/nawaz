select distinct dsnt_need_srvcs_sw from perlss.pae_skilled_srvc_summary
where need_skilled_srvcs_sw  = 'N' and need_respiratory_care_sw = 'N' 
--and dsnt_need_srvcs_sw = 'N'
and created_by not like 'CV%';--always Y

select distinct dsnt_need_srvcs_sw from perlss.pae_skilled_srvc_summary
where need_skilled_srvcs_sw  = 'Y' and need_respiratory_care_sw = 'Y' 
--and dsnt_need_srvcs_sw = 'N'
and created_by not like 'CV%';--always N

select distinct dsnt_need_srvcs_sw from perlss.pae_skilled_srvc_summary
where need_skilled_srvcs_sw  = 'Y' and need_respiratory_care_sw = 'N' 
--and dsnt_need_srvcs_sw = 'N'
and created_by not like 'CV%';--always N

select distinct dsnt_need_srvcs_sw from perlss.pae_skilled_srvc_summary
where need_skilled_srvcs_sw  = 'N' and need_respiratory_care_sw = 'Y' 
--and dsnt_need_srvcs_sw = 'N'
and created_by not like 'CV%';--always Y



select distinct dsnt_need_srvcs_sw from perlss.pae_skilled_srvc_summary
where need_skilled_srvcs_sw  = 'N' and need_respiratory_care_sw = 'N' 
--and dsnt_need_srvcs_sw = 'N'
and created_by = 'CV_11';--always Y

select distinct dsnt_need_srvcs_sw from perlss.pae_skilled_srvc_summary
where need_skilled_srvcs_sw  = 'Y' and need_respiratory_care_sw = 'Y' 
--and dsnt_need_srvcs_sw = 'N'
and created_by = 'CV_11';--always N

select distinct dsnt_need_srvcs_sw from perlss.pae_skilled_srvc_summary
where need_skilled_srvcs_sw  = 'Y' and need_respiratory_care_sw = 'N' 
--and dsnt_need_srvcs_sw = 'N'
and created_by = 'CV_11';--always N

select distinct dsnt_need_srvcs_sw from perlss.pae_skilled_srvc_summary
where need_skilled_srvcs_sw  = 'N' and need_respiratory_care_sw = 'Y' 
--and dsnt_need_srvcs_sw = 'N'
and created_by = 'CV_11';--always Y

select count(distinct pae_id) from PERLSS.pae_skilled_srvc_dtl where created_by = 'CV_11';--769

select * from PERLSS.pae_skilled_srvc_summary a 
where created_by = 'CV_11' and  need_skilled_srvcs_sw = 'Y';--769


select * from PERLSS.pae_respiratory_care prc where created_by = 'CV_11'
and tracheal_req_start_dt is not null;--7

select * from PERLSS.pae_respiratory_care prc where created_by = 'CV_11'
and chrnc_req_start_dt  is not null;--18

select * from PERLSS.pae_skilled_srvc_summary a 
where created_by = 'CV_11' and  need_skilled_srvcs_sw = 'N'
and exists(select 1 from perlss.pae_skilled_srvc_dtl b where a.pae_id = b.pae_id and created_by = 'CV_11');--0 
--SHould be zero

select * from PERLSS.pae_skilled_srvc_summary psss 
where created_by = 'CV_11' and  need_respiratory_care_sw  = 'Y';--25

select * from PERLSS.pae_skilled_srvc_dtl pssd  where pae_id in ('PAE200103427','PAE200103428');

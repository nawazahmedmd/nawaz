select 
nextval('perlss.hibernate_sequence') as ID,
concat('PAE',nextval('perlss.pae_rqst_0sq')) as PAE_ID,
 * from (
with temptb as(
select distinct 
 NULL as 	abandon_parta_sw
,NULL as 	actual_discharge_dt
,'N'	assigned_grp_submit_sw
,case when l2.Level2DeterminationEffectiveDate is not null then l2.Level2DeterminationEffectiveDate 
			else l2.Level2DeterminationDate end  as	begin_dt
,NULL as 	chm_id
,NULL as 	closure_attestation_sw
,NULL as 	closure_rsn_cd
,NULL as 	closure_rsn_desc
,NULL as 	due_dt
,NULL as 	enroll_in_mfp_sw
,NULL as 	grand_region_cd
,NULL as 	grp3_intrst_sw
,NULL as 	last_modified_by
,NULL as 	last_modified_dt
,b.ReviewID	legacy_id
,NULL as 	mode_cd
,b.NFAdmitDate as	mopd_dt
,'N'	new_prsn_sw
,a.ReferralDate as	pae_rqst_dt
,'TMD'	pae_type_cd
,'Y'	pdf_generated_sw
,'CG1'	program_cd
--,perlss_indv_id from wrk_ltss_clients	prsn_id
, ca.prsn_id as    prsn_id
,NULL as 	reassessment_due_dt
,NULL as 	recrtfctn_due_dt
,NULL as 	ref_id
,NULL as 	rqstd_enr_grp_cd
,NULL as 	ssi_applcatn_status_cd
,NULL as 	submitted_enr_grp_cd
,NULL as 	tmed_id
,NULL as 	tns_id
,Null as	user_id--same as Phase1
,'A' as CONVERSION_RUN_STATUS
, upper(l1.level1submittingfacility) as level1submittingfacility
,so.entity_id
,so.entity_name  as entity_name
,sot.entity_type
,trim(adj.perlss_pae_status) as final_pae_status
,trim(b.payersource) payersource
,trim(l1.level1outcome) level1outcome
,trim(l2.level2outcome) level2outcome
,trim(l2.level2noticetype) level2noticetype	
,trim(a.locoutcome) locoutcome
,trim(a.safetyformoutcome) safetyformoutcome 
,trim(a.functionaldeficitidentified) functionaldeficitidentified
from legacy.wrk_pasrr_clients w
join legacy.pasrr_events b on w.maximus_reviewid = b.reviewid  
join perlss.com_applcnt ca on ca.ssn::text = w.ssn::text --and ca.prsn_id = w.perlss_indv_id--enable once we get indv id's
join legacy.pasrr_pae_base_member_pop pop on w.maximus_reviewid = pop.pasrr_review_id and w.ssn = pop.ssn
left join legacy.pasrr_level_i l1 on  b.eventid =l1.eventid 
left join legacy.pasrr_level_ii l2 on  b.eventid =l2.eventid 
left join legacy.pasrr_loc  a on  a.eventid =b.eventid 
left join perlss.sec_organization so on upper(l1.level1submittingfacility)=upper(so.entity_name)
left join perlss.sec_org_type sot on so.entity_type_id=sot.entity_type_id
left join perlss.sec_user_organization suo on suo.entity_id = so.entity_id
left join legacy.wrk_pasrr_pae_status_adj_dcsn adj on (coalesce (trim(upper(b.payersource)),'[NULL]')=coalesce (trim(upper(adj.payersource)),'[NULL]')	and
														coalesce (trim(upper(l1.level1outcome)),'[NULL]')=coalesce (trim(upper(adj.level1outcome)),'[NULL]')	and
														coalesce (trim(upper(l2.level2outcome)),'[NULL]')=coalesce (trim(upper(adj.level2outcome)),'[NULL]')	and
														coalesce (trim(upper(l2.level2noticetype)),'[NULL]')	=coalesce (trim(upper(adj.level2noticetype)),'[NULL]')and
														coalesce (trim(upper(replace(a.locoutcome,' ','')	)),'[NULL]')=coalesce (trim(upper(replace(adj.locoutcome,' ','')	)),'[NULL]')and
														coalesce (trim(upper(a.safetyformoutcome)),'[NULL]')=coalesce (trim(upper(adj.safetyformoutcome)),'[NULL]')and
														coalesce (trim(upper(a.functionaldeficitidentified)),'[NULL]')=coalesce (trim(upper(adj.functionaldeficitidentified)),'[NULL]'))
where  w.source_system_nm = 'MAXIMUS'
and valid_sw= 'Y' and 	xref_valid_sw='Y'
and l2.Level2DeterminationDate is not null
)
select distinct * from temptb 
)a




















update perlss.pae_rqst c
set entity_type = d.entity_type
from (select distinct b.entity_type , a.entity_id  from perlss.sec_organization a
join perlss.sec_org_type b on a.entity_type_id = b.entity_type_id) d
where c.entity_id = d.entity_id and c.entity_type is null
and created_by  = 'CV_'|| (select CNV_RUN_NUM from legacy.wrk_conversion_run where cnv_run_status = 'A');

select
 entity_id ,
 upper(entity_name) as enity_name
  from perlss.sec_organization so



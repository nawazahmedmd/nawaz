select 
nextval('perlss.hibernate_sequence') as ID,
 * from (
with temptb as(
select distinct 
'USAD'	addr_format_cd
,upper(trim(b.IndividualAddress1))	addr_line_1
,upper(trim(b.IndividualAddress2))	addr_line_2
,'MA'	addr_type_cd
,upper(trim(b.IndividualCity))	city
,case when upper(trim(b.IndividualState))<> 'TN' then '999' else upper(trim(b.IndividualCounty)) end  cnty_cd
,NULL	last_modified_by
,NULL	last_modified_dt
,'Y'	mail_addr_sw
,NULL	military_po_cd
,NULL	military_state_cd
,r.pae_id  	pae_id
,upper(trim(b.IndividualState))	state_cd
,'APPL'	user_type_cd
,NULL	validated_addr_cd
,trim(b.IndividualZip)	zip
,NULL	zip_extsn
,'A' as CONVERSION_RUN_STATUS
, NULL as delete_sw
from perlss.pae_rqst r
join legacy.wrk_pasrr_clients w on r.legacy_id::text = w.maximus_reviewid::text  
join legacy.pasrr_events b on b.reviewid::bigint  = w.maximus_reviewid::bigint
where  w.source_system_nm = 'MAXIMUS' 
and valid_sw= 'Y' and 	xref_valid_sw='Y' 
and r.created_by  = 'CV_'|| (select CNV_RUN_NUM from legacy.wrk_conversion_run where cnv_run_status = 'A')
union 
select distinct 
'USAD'	addr_format_cd
,upper(trim(b.IndividualAddress1))	addr_line_1
,upper(trim(b.IndividualAddress2))	addr_line_2
,'PA'	addr_type_cd
,upper(trim(b.IndividualCity))	city
,case when upper(trim(b.IndividualState))<> 'TN' then '999' else upper(trim(b.IndividualCounty)) end  cnty_cd
,NULL	last_modified_by
,NULL	last_modified_dt
,'Y'	mail_addr_sw
,NULL	military_po_cd
,NULL	military_state_cd
,r.pae_id  	pae_id
,upper(trim(b.IndividualState))	state_cd
,'APPL'	user_type_cd
,NULL	validated_addr_cd
,trim(b.IndividualZip)	zip
,NULL	zip_extsn
,'A' as CONVERSION_RUN_STATUS
,NULL as delete_sw
--select count(1)
from perlss.pae_rqst r
join legacy.wrk_pasrr_clients w on r.legacy_id::text = w.maximus_reviewid::text  
join legacy.pasrr_events b on b.reviewid::bigint  = w.maximus_reviewid::bigint  
where  w.source_system_nm = 'MAXIMUS' 
and valid_sw= 'Y' and 	xref_valid_sw='Y' 
and r.created_by  = 'CV_'|| (select CNV_RUN_NUM from legacy.wrk_conversion_run where cnv_run_status = 'A')
)
select distinct * from temptb 
)a;


:LKP.SHORTCUT_TO_LKP_WRK_XREF_CODES('TPAES', 'ECF_STAGING', 'COUNTYUS_STATE', 'COUNTY', UPPER(LTRIM(RTRIM(APPLICANT_TNC_COUNTY))))
:LKP.SHORTCUT_TO_LKP_WRK_XREF_CODES('TPAES', 'ECF_STAGING', 'US_STATE', 'STATE', UPPER(LTRIM(RTRIM(MAILING_ADR_STATE))))

iif(isnull(ltrim(rtrim(i_CNTY_CD))) or  ltrim(rtrim(i_CNTY_CD))='',:LKP.SHORTCUT_TO_LKP_WRK_XREF_CODES('TPAES', 'ECF_STAGING', 'ZIP-COUNTY', 'COUNTY',ltrim(rtrim(upper(i_ADR_ZIP_CODE)))),ltrim(rtrim(i_CNTY_CD)))

SELECT WRK_XREF_CODES.TO_XREF_CD AS TO_XREF_CD
 , WRK_XREF_CODES.SRC_SYS_ID AS SRC_SYS_ID
 , WRK_XREF_CODES.LEGACY_TBL_NM AS LEGACY_TBL_NM
 , WRK_XREF_CODES.LEGACY_COL_NM AS LEGACY_COL_NM
 , WRK_XREF_CODES.REF_TBL_NM AS REF_TBL_NM
 , UPPER(LTRIM(RTRIM(WRK_XREF_CODES.FROM_XREF_CD))) AS FROM_XREF_CD FROM legacy.WRK_XREF_CODES
 
 select * from perlss.pae_app_addr_dtl paad 
 county 
 
 SRC_SYS_ID = in_SRC_SYS_ID 
 AND LEGACY_TBL_NM = in_LEGACY_TBL_NM 
 AND LEGACY_COL_NM = in_LEGACY_COL_NM 
 AND REF_TBL_NM = in_REF_TBL_NM 
 AND FROM_XREF_CD = in_FROM_XREF_CD


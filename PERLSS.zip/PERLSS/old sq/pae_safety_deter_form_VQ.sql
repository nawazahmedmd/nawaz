--pae_safety_deter_form;
select * from perlss.pae_safety_deter_form psdf 
where created_by='CV_11';

select COUNT(1), PAE_ID from perlss.pae_safety_deter_form psdf 
group by PAE_ID
having COUNT(1)>1;--0

select * from perlss.pae_safety_deter_form
where pae_id not in (select pae_id from perlss.pae_rqst); --0

select * from perlss.pae_safety_deter_form a
where created_by = 'CV_11'
and not exists(select 1 from perlss.pae_rqst b where b.pae_id = a.pae_id);--0

select * from perlss.pae_safety_deter_form a
where created_by = 'CV_11'
and exists(select 1 from perlss.pae_rqst b where b.pae_id = a.pae_id);
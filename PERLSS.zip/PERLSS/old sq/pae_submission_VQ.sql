select * from perlss.pae_submission
where created_by='CV_11';

select COUNT(1), PAE_ID from perlss.pae_submission psdf 
group by PAE_ID
having COUNT(1)>1;--0

select * from perlss.pae_rqst where pae_id in (
select * from perlss.pae_submission ps where pae_id = 'PAE200115932');

select * from perlss.sec_user_profile sup where user_id in ('DCV5690','TNT7991'); --both have same user id 

select * from perlss.pae_submission a
where created_by = 'CV_11'
and not exists(select 1 from perlss.pae_rqst b where b.pae_id = a.pae_id);--0

select * from perlss.pae_submission a
where created_by = 'CV_11'
and exists(select 1 from perlss.pae_rqst b where b.pae_id = a.pae_id);--should be above count


select * from perlss.pae_submission a
where created_by = 'CV_11'
and submit_dt is null; 

select referraldate  from legacy.pasrr_loc where eventid in 
(select eventid from legacy.pasrr_events where reviewid::text in 
(select legacy_id::text from perlss.pae_rqst where pae_id = 'PAE200112406'));--2017-02-03 13:48:00.000

select pae_rqst_dt  from perlss.pae_rqst where pae_id = 'PAE200112406';--2017-02-03 13:48:00.000

select submit_dt from perlss.pae_submission ps  where pae_id = 'PAE200112406';--2017-02-03 13:48:00.000


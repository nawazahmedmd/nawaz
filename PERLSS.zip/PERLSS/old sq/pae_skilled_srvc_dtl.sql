select 
nextval('perlss.hibernate_sequence') as ID,
 * from (
with temptb as(
select distinct 
NULL	last_modified_by
,NULL	last_modified_dt
,r.pae_id pae_id
,'CG1'	program_cd
,WoundCareDecubitusEndDate 		rqstd_end_dt
,WoundCareDecubitusStartDate	rqstd_start_dt
,'WCS'	section_type_cd
, r.legacy_id
,'A' as CONVERSION_RUN_STATUS
--select count(1)
from perlss.pae_rqst r
join legacy.wrk_pasrr_clients w on r.legacy_id::text = w.maximus_reviewid::text --and w.perlss_indv_id = r.prsn_id 
join legacy.pasrr_events b on b.reviewid::bigint  = w.maximus_reviewid::bigint
join legacy.pasrr_loc a on  b.eventid::text = a.eventid::text
where  w.source_system_nm = 'MAXIMUS' 
and valid_sw= 'Y' and 	xref_valid_sw='Y'
and WoundCareDecubitus= 'True' and WoundCareDecubitusStartDate is not null
and r.created_by  = 'CV_'|| (select CNV_RUN_NUM from legacy.wrk_conversion_run where cnv_run_status = 'A')
union 
select distinct 
NULL	last_modified_by
,NULL	last_modified_dt
,r.pae_id pae_id
,'CG1'	program_cd
,WoundCareOtherEndDate		rqstd_end_dt
,WoundCareOtherStartDate	rqstd_start_dt
,'OWC'	section_type_cd
, r.legacy_id
,'A' as CONVERSION_RUN_STATUS
--select count(1)
from perlss.pae_rqst r
join legacy.wrk_pasrr_clients w on r.legacy_id::text = w.maximus_reviewid::text --and w.perlss_indv_id = r.prsn_id 
join legacy.pasrr_events b on b.reviewid::bigint  = w.maximus_reviewid::bigint
join legacy.pasrr_loc a on  b.eventid::text = a.eventid::text
where  w.source_system_nm = 'MAXIMUS' 
and valid_sw= 'Y' and 	xref_valid_sw='Y'
and WoundCareOther= 'True' and  WoundCareOtherStartDate is not null
and r.created_by  = 'CV_'|| (select CNV_RUN_NUM from legacy.wrk_conversion_run where cnv_run_status = 'A')
union 
select distinct 
NULL	last_modified_by
,NULL	last_modified_dt
,r.pae_id pae_id
,'CG1'	program_cd
,InjectionsInsulinEndDate		rqstd_end_dt
,InjectionsInsulinStartDate	    rqstd_start_dt
,'ISS'	section_type_cd
, r.legacy_id
,'A' as CONVERSION_RUN_STATUS
--select count(1)
from perlss.pae_rqst r
join legacy.wrk_pasrr_clients w on r.legacy_id::text = w.maximus_reviewid::text --and w.perlss_indv_id = r.prsn_id 
join legacy.pasrr_events b on b.reviewid::bigint  = w.maximus_reviewid::bigint
join legacy.pasrr_loc a on  b.eventid::text = a.eventid::text
where  w.source_system_nm = 'MAXIMUS' 
and valid_sw= 'Y' and 	xref_valid_sw='Y'
and InjectionsInsulin = 'True' and  InjectionsInsulinStartDate is not null
and r.created_by  = 'CV_'|| (select CNV_RUN_NUM from legacy.wrk_conversion_run where cnv_run_status = 'A')
union 
select distinct 
NULL	last_modified_by
,NULL	last_modified_dt
,r.pae_id pae_id
,'CG1'	program_cd
,InjectionsOtherEndDate		rqstd_end_dt
,InjectionsOtherStartDate	rqstd_start_dt
,'IOT'	section_type_cd
, r.legacy_id
,'A' as CONVERSION_RUN_STATUS
--select count(1)
from perlss.pae_rqst r
join legacy.wrk_pasrr_clients w on r.legacy_id::text = w.maximus_reviewid::text --and w.perlss_indv_id = r.prsn_id 
join legacy.pasrr_events b on b.reviewid::bigint  = w.maximus_reviewid::bigint
join legacy.pasrr_loc a on  b.eventid::text = a.eventid::text
where  w.source_system_nm = 'MAXIMUS' 
and valid_sw= 'Y' and 	xref_valid_sw='Y'
and InjectionsOther           = 'True' and  InjectionsOtherStartDate is not null
and r.created_by  = 'CV_'|| (select CNV_RUN_NUM from legacy.wrk_conversion_run where cnv_run_status = 'A')
union 
select distinct 
NULL	last_modified_by
,NULL	last_modified_dt
,r.pae_id pae_id
,'CG1'	program_cd
,IntravenousFluidsEndDate		rqstd_end_dt
,IntravenousFluidsStartDate 	rqstd_start_dt
,'INT'	section_type_cd
, r.legacy_id
,'A' as CONVERSION_RUN_STATUS
--select count(1)
from perlss.pae_rqst r
join legacy.wrk_pasrr_clients w on r.legacy_id::text = w.maximus_reviewid::text --and w.perlss_indv_id = r.prsn_id 
join legacy.pasrr_events b on b.reviewid::bigint  = w.maximus_reviewid::bigint
join legacy.pasrr_loc a on  b.eventid::text = a.eventid::text
where  w.source_system_nm = 'MAXIMUS' 
and valid_sw= 'Y' and 	xref_valid_sw='Y'
and IntravenousFluids         = 'True' and  IntravenousFluidsStartDate is not null
and r.created_by  = 'CV_'|| (select CNV_RUN_NUM from legacy.wrk_conversion_run where cnv_run_status = 'A')
union 
select distinct 
NULL	last_modified_by
,NULL	last_modified_dt
,r.pae_id pae_id
,'CG1'	program_cd
,IsolationPrecautionsEndDate		rqstd_end_dt
,IsolationPrecautionsStartDate	rqstd_start_dt
,'ISP'	section_type_cd
, r.legacy_id
,'A' as CONVERSION_RUN_STATUS
--select count(1)
from perlss.pae_rqst r
join legacy.wrk_pasrr_clients w on r.legacy_id::text = w.maximus_reviewid::text --and w.perlss_indv_id = r.prsn_id 
join legacy.pasrr_events b on b.reviewid::bigint  = w.maximus_reviewid::bigint
join legacy.pasrr_loc a on  b.eventid::text = a.eventid::text
where  w.source_system_nm = 'MAXIMUS' 
and valid_sw= 'Y' and 	xref_valid_sw='Y'
and IsolationPrecautions      = 'True' and  IsolationPrecautionsStartDate is not null
and r.created_by  = 'CV_'|| (select CNV_RUN_NUM from legacy.wrk_conversion_run where cnv_run_status = 'A')
union 
select distinct 
NULL	last_modified_by
,NULL	last_modified_dt
,r.pae_id pae_id
,'CG1'	program_cd
,OccupationalTherapyEndDate		rqstd_end_dt
,OccupationalTherapyStartDate	rqstd_start_dt
,'OCT'	section_type_cd
, r.legacy_id
,'A' as CONVERSION_RUN_STATUS
--select count(1)
from perlss.pae_rqst r
join legacy.wrk_pasrr_clients w on r.legacy_id::text = w.maximus_reviewid::text --and w.perlss_indv_id = r.prsn_id 
join legacy.pasrr_events b on b.reviewid::bigint  = w.maximus_reviewid::bigint
join legacy.pasrr_loc a on  b.eventid::text = a.eventid::text
where  w.source_system_nm = 'MAXIMUS' 
and valid_sw= 'Y' and 	xref_valid_sw='Y'
and OccupationalTherapy       = 'True' and OccupationalTherapyStartDate is not null
and r.created_by  = 'CV_'|| (select CNV_RUN_NUM from legacy.wrk_conversion_run where cnv_run_status = 'A')
union 
select distinct 
NULL	last_modified_by
,NULL	last_modified_dt
,r.pae_id pae_id
,'CG1'	program_cd
,PhysicalTherapyEndDate		rqstd_end_dt
,PhysicalTherapyStartDate	rqstd_start_dt
,'PHT'	section_type_cd
, r.legacy_id
,'A' as CONVERSION_RUN_STATUS
--select count(1)
from perlss.pae_rqst r
join legacy.wrk_pasrr_clients w on r.legacy_id::text = w.maximus_reviewid::text --and w.perlss_indv_id = r.prsn_id 
join legacy.pasrr_events b on b.reviewid::bigint  = w.maximus_reviewid::bigint
join legacy.pasrr_loc a on  b.eventid::text = a.eventid::text
where  w.source_system_nm = 'MAXIMUS' 
and valid_sw= 'Y' and 	xref_valid_sw='Y'
and PhysicalTherapy          = 'True' and PhysicalTherapyStartDate is not null
and r.created_by  = 'CV_'|| (select CNV_RUN_NUM from legacy.wrk_conversion_run where cnv_run_status = 'A')
union 
select distinct 
NULL	last_modified_by
,NULL	last_modified_dt
,r.pae_id pae_id
,'CG1'	program_cd
,CatheterOstomyEndDate	rqstd_end_dt
,CatheterOstomyStartDate	rqstd_start_dt
,'TCO'	section_type_cd
, r.legacy_id
,'A' as CONVERSION_RUN_STATUS
--select count(1)
from perlss.pae_rqst r
join legacy.wrk_pasrr_clients w on r.legacy_id::text = w.maximus_reviewid::text --and w.perlss_indv_id = r.prsn_id 
join legacy.pasrr_events b on b.reviewid::bigint  = w.maximus_reviewid::bigint
join legacy.pasrr_loc a on  b.eventid::text = a.eventid::text
where  w.source_system_nm = 'MAXIMUS' 
and valid_sw= 'Y' and 	xref_valid_sw='Y'
and CatheterOstomy            = 'True' and CatheterOstomyStartDate is not null
and r.created_by  = 'CV_'|| (select CNV_RUN_NUM from legacy.wrk_conversion_run where cnv_run_status = 'A')
union 
select distinct 
NULL	last_modified_by
,NULL	last_modified_dt
,r.pae_id pae_id
,'CG1'	program_cd
,SelfInjectionEndDate		rqstd_end_dt
,SelfInjectionStartDate	    rqstd_start_dt
,'TSI'	section_type_cd
, r.legacy_id
,'A' as CONVERSION_RUN_STATUS
--select count(1)
from perlss.pae_rqst r
join legacy.wrk_pasrr_clients w on r.legacy_id::text = w.maximus_reviewid::text --and w.perlss_indv_id = r.prsn_id 
join legacy.pasrr_events b on b.reviewid::bigint  = w.maximus_reviewid::bigint
join legacy.pasrr_loc a on  b.eventid::text = a.eventid::text
where  w.source_system_nm = 'MAXIMUS' 
and valid_sw= 'Y' and 	xref_valid_sw='Y'
and SelfInjection             = 'True' and  SelfInjectionStartDate is not null
and r.created_by  = 'CV_'|| (select CNV_RUN_NUM from legacy.wrk_conversion_run where cnv_run_status = 'A')
union 
select distinct 
NULL	last_modified_by
,NULL	last_modified_dt
,r.pae_id pae_id
,'CG1'	program_cd
,ParenteralNutritionEndDate		rqstd_end_dt
,ParenteralNutritionStartDate	rqstd_start_dt
,'TPN'	section_type_cd
, r.legacy_id
,'A' as CONVERSION_RUN_STATUS
--select count(1)
from perlss.pae_rqst r
join legacy.wrk_pasrr_clients w on r.legacy_id::text = w.maximus_reviewid::text --and w.perlss_indv_id = r.prsn_id 
join legacy.pasrr_events b on b.reviewid::bigint  = w.maximus_reviewid::bigint
join legacy.pasrr_loc a on  b.eventid::text = a.eventid::text
where  w.source_system_nm = 'MAXIMUS' 
and valid_sw= 'Y' and 	xref_valid_sw='Y'
and ParenteralNutrition       = 'True' and  ParenteralNutritionStartDate is not null
and r.created_by  = 'CV_'|| (select CNV_RUN_NUM from legacy.wrk_conversion_run where cnv_run_status = 'A')
union 
select distinct 
NULL	last_modified_by
,NULL	last_modified_dt
,r.pae_id pae_id
,'CG1'	program_cd
,TubeFeedingEndDate		rqstd_end_dt
,TubeFeedingStartDate	rqstd_start_dt
,'TFE'	section_type_cd
, r.legacy_id
,'A' as CONVERSION_RUN_STATUS
--select count(1)
from perlss.pae_rqst r
join legacy.wrk_pasrr_clients w on r.legacy_id::text = w.maximus_reviewid::text --and w.perlss_indv_id = r.prsn_id 
join legacy.pasrr_events b on b.reviewid::bigint  = w.maximus_reviewid::bigint
join legacy.pasrr_loc a on  b.eventid::text = a.eventid::text
where  w.source_system_nm = 'MAXIMUS' 
and valid_sw= 'Y' and 	xref_valid_sw='Y'
and TubeFeeding               = 'True' and TubeFeedingStartDate is not null
and r.created_by  = 'CV_'|| (select CNV_RUN_NUM from legacy.wrk_conversion_run where cnv_run_status = 'A')
union 
select distinct 
NULL	last_modified_by
,NULL	last_modified_dt
,r.pae_id pae_id
,'CG1'	program_cd
,PeritonealDialysisEndDate		rqstd_end_dt
,PeritonealDialysisStartDate	rqstd_start_dt
,'PED'	section_type_cd
, r.legacy_id
,'A' as CONVERSION_RUN_STATUS
--select count(1)
from perlss.pae_rqst r
join legacy.wrk_pasrr_clients w on r.legacy_id::text = w.maximus_reviewid::text --and w.perlss_indv_id = r.prsn_id 
join legacy.pasrr_events b on b.reviewid::bigint  = w.maximus_reviewid::bigint
join legacy.pasrr_loc a on  b.eventid::text = a.eventid::text
where  w.source_system_nm = 'MAXIMUS' 
and valid_sw= 'Y' and 	xref_valid_sw='Y'
and PeritonealDialysis        = 'True' and PeritonealDialysisStartDate is not null
and r.created_by  = 'CV_'|| (select CNV_RUN_NUM from legacy.wrk_conversion_run where cnv_run_status = 'A')
union 
select distinct 
NULL	last_modified_by
,NULL	last_modified_dt
,r.pae_id pae_id
,'CG1'	program_cd
,PCAPumpEndDate		rqstd_end_dt
,PCAPumpStartDate	rqstd_start_dt
,'PCA'	section_type_cd
, r.legacy_id
,'A' as CONVERSION_RUN_STATUS
--select count(1)
from perlss.pae_rqst r
join legacy.wrk_pasrr_clients w on r.legacy_id::text = w.maximus_reviewid::text --and w.perlss_indv_id = r.prsn_id 
join legacy.pasrr_events b on b.reviewid::bigint  = w.maximus_reviewid::bigint
join legacy.pasrr_loc a on  b.eventid::text = a.eventid::text
where  w.source_system_nm = 'MAXIMUS' 
and valid_sw= 'Y' and 	xref_valid_sw='Y'
and PCAPump = 'True' and PCAPumpStartDate is not null
and r.created_by  = 'CV_'|| (select CNV_RUN_NUM from legacy.wrk_conversion_run where cnv_run_status = 'A')
union 
select distinct 
NULL	last_modified_by
,NULL	last_modified_dt
,r.pae_id pae_id
,'CG1'	program_cd
,TracheostomyEndDate		rqstd_end_dt
,TracheostomyStartDate	rqstd_start_dt
,'TRS'	section_type_cd
, r.legacy_id
,'A' as CONVERSION_RUN_STATUS
--select count(1)
from perlss.pae_rqst r
join legacy.wrk_pasrr_clients w on r.legacy_id::text = w.maximus_reviewid::text --and w.perlss_indv_id = r.prsn_id 
join legacy.pasrr_events b on b.reviewid::bigint  = w.maximus_reviewid::bigint
join legacy.pasrr_loc a on  b.eventid::text = a.eventid::text
where  w.source_system_nm = 'MAXIMUS' 
and valid_sw= 'Y' and 	xref_valid_sw='Y'
and Tracheostomy  = 'True' and TracheostomyStartDate is not null
and r.created_by  = 'CV_'|| (select CNV_RUN_NUM from legacy.wrk_conversion_run where cnv_run_status = 'A')
)
select distinct * from temptb 
)a;




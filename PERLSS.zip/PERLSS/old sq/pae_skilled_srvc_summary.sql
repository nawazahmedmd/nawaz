select 
nextval('perlss.hibernate_sequence') as ID,
 * from (
with temptb as(
select distinct a.* ,
case when (a.need_skilled_srvcs_sw = 'Y' or a.need_respiratory_care_sw = 'Y') then 'N' else 'Y'  end as dsnt_need_srvcs_sw
from (select  
NULL	last_modified_by
,NULL	last_modified_dt
, Case when (a.ChronicVentilatorServices='True' and ventilatorclinicaldetermination = 'Approved'
        OR TrachealSuctioning='True' and trachealsuctioningclinicaldetermination = 'Approved' ) then 'Y' else 'N' end	need_respiratory_care_sw
,CASE WHEN (WoundCareDecubitus= 'True' and WoundCareDecubitusStartDate is not null OR
		   WoundCareOther= 'True' and WoundCareOtherStartDate is not null OR 
		   InjectionsInsulin = 'True' and InjectionsInsulinStartDate is not null OR
		   InjectionsOther           = 'True' and InjectionsOtherStartDate is not null OR
		   IntravenousFluids         = 'True' and IntravenousFluidsStartDate is not null OR
		   IsolationPrecautions      = 'True' and IsolationPrecautionsstartdate is not null OR
		   OccupationalTherapy       = 'True' and OccupationalTherapyStartDate is not null OR
		   PhysicalTherapy          = 'True' and PhysicalTherapyStartDate is not null OR
		   CatheterOstomy            = 'True' and CatheterOstomyStartDate is not null OR
		   SelfInjection             = 'True' and SelfInjectionStartDate is not null OR
		   ParenteralNutrition       = 'True' and ParenteralNutritionStartDate is not null OR
		   TubeFeeding               = 'True' and TubeFeedingStartDate is not null OR
		   PeritonealDialysis        = 'True' and PeritonealDialysisStartDate is not null OR
		   PCAPump                   = 'True' and PCAPumpStartDate is not null OR
		   Tracheostomy              = 'True' and TracheostomyStartDate is not null)
		   then 'Y' else 'N' end	need_skilled_srvcs_sw
,r.pae_id	pae_id
, NULL	total_submitted_skilled_srvcs_acuity_score
, r.legacy_id
,'A' as CONVERSION_RUN_STATUS
--select count(1)
from perlss.pae_rqst r
join legacy.wrk_pasrr_clients w on r.legacy_id::text = w.maximus_reviewid::text --and w.perlss_indv_id = r.prsn_id 
join legacy.pasrr_events b on b.reviewid::bigint  = w.maximus_reviewid::bigint
join legacy.pasrr_loc a on  b.eventid::text = a.eventid::text
where  w.source_system_nm = 'MAXIMUS' 
and valid_sw= 'Y' and 	xref_valid_sw='Y'
and r.created_by  = 'CV_'|| (select CNV_RUN_NUM from legacy.wrk_conversion_run where cnv_run_status = 'A'))a
)
select distinct * from temptb 
)a

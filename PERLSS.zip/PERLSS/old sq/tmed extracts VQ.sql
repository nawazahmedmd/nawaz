select distinct t.num_control_pkey,t.first_name,t.last_name,t.middle_name,t.gender,t.ssn tmed_ssn,t.dob,
t.num_phone,t.streetaddress1,t.streetaddress2,t.city,t.
state,t.zipcode,r.status,r.submission_date,r.srv_requested_cd,r.project_type_cd,r.sub_req_type_cd,
r.screener_id,r.ascend_id tmed_ascend_id,r.assigned_mco,r.process_id
from legacy.tmed_recepient_details t
join legacy.tmed_all_submissions r on t.num_control_pkey = r.num_control_pkey 
join 
(select distinct d.ssn,e.ReviewID from  legacy.pasrr_events e 
JOIN legacy.pasrr_demographics d ON e.individualid::text = d.individualid::text
      where e.payersource in ('Medicaid','Medicaid Pending','PACE-Medicaid','PACE-Medicaid Pending')) maxi 
      on maxi.ssn::text = t.ssn::text 
      and maxi.ReviewID::bigint = r.ascend_id::bigint               
and  exists(select 1 from  (select num_ssn,dte_effective,dte_end,c.cde_source ,num_pre_eval 
from legacy.pasrr_mmis_t_re_base b 
join legacy.pasrr_mmis_t_re_loc c  on  c.sak_recip=b.sak_recip 
         )mmis where    trim(maxi.ssn)=trim(mmis.num_ssn) 
		 and  trim(mmis.num_pre_eval)=trim(t.num_control_pkey::char(25))
     );
	 
select count(1) from legacy.tmed_recepient_details trd 
where ssn in (select ssn from legacy.pasrr_demographics);--611942

select count(1) from legacy.pasrr_demographics a
where not exists (select 1 from legacy.tmed_recepient_details b where a.ssn = b.ssn);--78074

select count(1) from legacy.tmed_recepient_details  a
where not exists (select 1 from legacy.pasrr_demographics b where a.ssn = b.ssn);--933

select count(1) from legacy.pasrr_demographics a
where not exists (select 1 from legacy.tmed_all_submissions  b
where cast(a.ascendid as varchar)  = (b.ascend_id));--13396

select * from legacy.tmed_all_submissions b
where not exists (select 1 from legacy.pasrr_demographics a
where cast(a.ascendid as varchar)  = (b.ascend_id));--362791
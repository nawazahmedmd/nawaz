select 
nextval('perlss.hibernate_sequence') as ID,
 * from (
with temptb as(
select distinct 
NULL	cea_determn_cd
,'N'	cea_sw
,NULL	certificate_dt
,NULL	comments
,NULL	last_modified_by
,NULL	last_modified_dt
,r.pae_id as	pae_id
,'N'	pae_recrtfctn_ack_sw
,NULL	pae_recrtfctn_sw
,'N'	revised_pae_sw
,coalesce(sup.user_id,'CV_402') as	signature
,a.ReferralDate	submit_dt
,'OTH'	who_submitting_cd
, r.legacy_id
,'A' as CONVERSION_RUN_STATUS
--select count(1)
from perlss.pae_rqst r
join legacy.wrk_pasrr_clients w on r.legacy_id::text = w.maximus_reviewid::text --and w.perlss_indv_id = r.prsn_id 
join legacy.pasrr_events b on b.reviewid::bigint  = w.maximus_reviewid::bigint
left join legacy.pasrr_level_i l1 on  b.eventid =l1.eventid 
left join legacy.pasrr_loc  a on  a.eventid =b.eventid 
left join perlss.sec_user_profile sup 
     on upper((trim(l1.level1submitterfirstname) || trim(l1.level1submitterlastname)))=upper((trim(sup.first_name) ||trim(sup.last_name)))
where  w.source_system_nm = 'MAXIMUS' 
and valid_sw= 'Y' and 	xref_valid_sw='Y'
and r.created_by  = 'CV_'|| (select CNV_RUN_NUM from legacy.wrk_conversion_run where cnv_run_status = 'A')
)
select distinct * from temptb 
)a

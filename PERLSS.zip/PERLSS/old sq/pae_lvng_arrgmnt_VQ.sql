select * from perlss.pae_lvng_arrgmnt pabd 
where created_by='CV_11';

select COUNT(1), PAE_ID from perlss.pae_lvng_arrgmnt pds 
where created_by ='CV_11'
group by PAE_ID
having COUNT(1)>1;--0

select * from perlss.pae_lvng_arrgmnt a
where created_by = 'CV_11'
and not exists(select 1 from perlss.pae_rqst b where b.pae_id = a.pae_id);--0

select * from perlss.pae_lvng_arrgmnt a
where created_by = 'CV_11'
and exists(select 1 from perlss.pae_rqst b where b.pae_id = a.pae_id);--should be above count

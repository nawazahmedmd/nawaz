--pae_rqst

select * from perlss.pae_rqst
where created_by='CV_11';

select COUNT(1), PAE_ID from perlss.pae_rqst 
group by PAE_ID
having COUNT(1)>1;--0

select referraldate   from legacy.pasrr_loc where eventid in 
(select eventid from legacy.pasrr_events where reviewid::text in 
(select legacy_id::text from perlss.pae_rqst where pae_id = 'PAE200112406'));--2017-02-03 13:48:00.000

select nfadmitdate  from legacy.pasrr_events where reviewid::text in 
(select legacy_id::text from perlss.pae_rqst where pae_id = 'PAE200112406');--2017-02-15

select pae_rqst_dt, mopd_dt  from perlss.pae_rqst where pae_id = 'PAE200112406';--2017-02-03 13:48:00.000
--2017-02-15 00:00:00.000

select distinct entity_id  from perlss.pae_rqst where CREATED_BY = 'CV_11' and entity_id is not null;
select distinct entity from perlss.pae_rqst where CREATED_BY = 'CV_11' and entity_type is not null;

9514,12098

select *   from legacy.pasrr_level_i pli  where eventid in 
(select eventid from legacy.pasrr_events where reviewid::text in 
(select legacy_id::text from perlss.pae_rqst where pae_id in  ('PAE200112403','PAE200112404')));

select payersource,level1outcome , locoutcome , level2outcome , safetyformoutcome ,level2noticetype
from
legacy.pasrr_demographics d 
join legacy.pasrr_events b on d.individualid = b.individualid
left join legacy.pasrr_level_i l1 on  b.eventid =l1.eventid 
left join legacy.pasrr_level_ii l2 on  b.eventid =l2.eventid 
left join legacy.pasrr_loc  a on  a.eventid =b.eventid 
where reviewid::text
in (select LEGACY_ID::TEXT from PERLSS.PAE_RQST where PAE_ID in ('PAE200135877','PAE200135980'));--AP

select * from perlss.pae_rqst  
where created_by ='CV_11' and PAE_ID in ('PAE200135877','PAE200135980');


select * from legacy.wrk_pasrr_pae_status_adj_dcsn where locoutcome ='Approved'
and level1outcome = 'Refer for Level II-Level I Positive' and payersource = 'Medicaid'
and safetyformoutcome = 'NF LOC through Safety without end date' and 
level2outcome = 'Long-term Approval' and level2noticetype= 'Approved SS'; --AP

select * from legacy.wrk_pasrr_pae_status_adj_dcsn where locoutcome ='Approved'
 and payersource = 'Medicaid' and 
level2outcome = 'Long-term Approved Reconsideration' and level2noticetype= 'Approved SS'; --AP

select * from perlss.sec_organization so;

select * from perlss.sec_org_type

select * from perlss.sec_user_organization suo 
join perlss.sec_user_profile sup on suo.user_id = sup.user_id
join perlss.sec_organization so on so.entity_id = suo.entity_id 


select * from perlss.sec_user_profile sup where user_id in ('DCV5690','TNT7991'); --both have same user id 

select distinct entity_id  from perlss.pae_action where created_by = 'CV_11'





--pae_safety_deter_form;
select * from perlss.pae_safety_deter_form psdf 
where created_by='CV_11';

select COUNT(1), PAE_ID from perlss.pae_safety_deter_form psdf 
group by PAE_ID
having COUNT(1)>1;--0

select * from perlss.pae_safety_deter_form
where pae_id not in (select pae_id from perlss.pae_rqst); --0





--pae_safety_deter_sum
select * from perlss.pae_safety_deter_sum 
where created_by='CV_11';

select COUNT(1), PAE_ID from perlss.pae_safety_deter_SUM
group by PAE_ID
having COUNT(1)>1;--0

select * from perlss.pae_safety_deter_sum
where pae_id not in (select pae_id from perlss.pae_rqst); --0




--pae_activities_lvng
select * from perlss.pae_activities_lvng pabd 
where created_by='CV_11';

select COUNT(1), PAE_ID from perlss.pae_activities_lvng
group by PAE_ID
having COUNT(1)>1;--0

select * from perlss.pae_activities_lvng a
where created_by = 'CV_11'
and not exists(select 1 from perlss.pae_rqst b where b.pae_id = a.pae_id);--0

select * from perlss.pae_activities_lvng a
where created_by = 'CV_11'
and exists(select 1 from perlss.pae_rqst b where b.pae_id = a.pae_id);--should be above count

select * from PERLSS.PAE_RQST where LEGACY_ID = '736851';

select * from perlss.pae_activities_lvng pal  where created_by ='CV_11'
and pae_id = 'PAE200104986';

select * from legacy.pasrr_loc where eventid in 
(select eventid from legacy.pasrr_events where reviewid::text in 
(select legacy_id::text from perlss.pae_rqst where pae_id = 'PAE200104986')) 





--pae_skilled_srvc_dtl
select * from perlss.pae_skilled_srvc_dtl pabd 
where created_by='CV_11';

select * from perlss.pae_skilled_srvc_dtl a
where created_by = 'CV_11'
and not exists(select 1 from perlss.pae_rqst b where b.pae_id = a.pae_id);--0

select * from perlss.pae_skilled_srvc_dtl a
where created_by = 'CV_11'
and exists(select 1 from perlss.pae_rqst b where b.pae_id = a.pae_id);--should be above count

select * from PERLSS.PAE_RQST where LEGACY_ID = '736851';


select * from perlss.pae_skilled_srvc_dtl pssd where created_by ='CV_11'
and pae_id = 'PAE200104986';

select * from legacy.pasrr_loc where eventid in 
(select eventid from legacy.pasrr_events where reviewid::text in 
(select legacy_id::text from perlss.pae_rqst where pae_id = 'PAE200104986')) 






--pae_activities_behavrl_dtl
select * from perlss.pae_activities_behavrl_dtl pabd 
where created_by='CV_11';

select COUNT(1), PAE_ID from perlss.pae_activities_behavrl_dtl
where created_by= 'CV_11'
group by PAE_ID
having COUNT(1)>1;

select * from  perlss.pae_activities_behavrl_dtl where pae_id = 'PAE200074413';

select * from perlss.pae_activities_behavrl_dtl a
where created_by = 'CV_11'
and not exists(select 1 from perlss.pae_activities_lvng b where b.id = a.pae_activities_lvng_id);


--pae_skilled_srvc_summary
select * from perlss.pae_skilled_srvc_summary
where need_skilled_srvcs_sw  = 'N' and need_respiratory_care_sw = 'N' and dsnt_need_srvcs_sw = 'Y'
and created_by not like 'CV%';

select * from perlss.adj_skilled_srvcs ass  where adj_id ='100093615'
where created_by not  like 'CV%' and 
srvc_name_cd  in ('SMT', 'CVS')
order by 2;

select * from PERLSS.pae_skilled_srvc_dtl pssd  where pae_id in ('PAE200091282','PAE200091857');

select * from PERLSS.pae_respiratory_care prc where created_by not  like 'CV%'
where pae_id in ('PAE200017148','PAE200095116');

select adj_id  from perlss.adj_rqst where pae_id  in ( 'PAE200091857','PAE200091857');

select * from PERLSS.pae_skilled_srvc_summary pssd  where pae_id = 'PAE200071753';

select * from perlss.adj_skilled_srvcs ass 
where  created_by not like 'CV%' and adj_id = '100074152';


--pae_submission
select * from perlss.pae_submission
where created_by='CV_11';

select COUNT(1), PAE_ID from perlss.pae_submission psdf 
group by PAE_ID
having COUNT(1)>1;--0

select * from perlss.pae_rqst where pae_id in (
select * from perlss.pae_submission ps where pae_id = 'PAE200115932');

select * from perlss.sec_user_profile sup where user_id in ('DCV5690','TNT7991'); --both have same user id 

select * from perlss.pae_submission a
where created_by = 'CV_11'
and not exists(select 1 from perlss.pae_rqst b where b.pae_id = a.pae_id);--0

select * from perlss.pae_submission a
where created_by = 'CV_11'
and exists(select 1 from perlss.pae_rqst b where b.pae_id = a.pae_id);--should be above count


select * from perlss.pae_submission a
where created_by = 'CV_11'
and submit_dt is null; 

select referraldate  from legacy.pasrr_loc where eventid in 
(select eventid from legacy.pasrr_events where reviewid::text in 
(select legacy_id::text from perlss.pae_rqst where pae_id = 'PAE200112406'));--2017-02-03 13:48:00.000

select pae_rqst_dt  from perlss.pae_rqst where pae_id = 'PAE200112406';--2017-02-03 13:48:00.000

select submit_dt from perlss.pae_submission ps  where pae_id = 'PAE200112406';--2017-02-03 13:48:00.000








select distinct upper(level1submitterfirstname) || upper(level1submitterlastname)
from  legacy.pasrr_events b 
join legacy.pasrr_level_i l1 on  b.eventid =l1.eventid   where b.payersource ilike 'Medicaid'
and level1submitterfirstname is not null
except
select distinct upper(first_name)|| upper(last_name) from perlss.sec_user_profile

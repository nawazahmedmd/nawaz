select 
nextval('perlss.hibernate_sequence') as ID,
 * from (
with temptb as(
select distinct 
 'N'	hcbs_srvc_sw
,NULL	last_modified_by
,NULL	last_modified_dt
,'N' 	nf_srvc_sw
,r.pae_id 	pae_id
,'Y' 	req_safety_con_sw
,'N'	tenncare_qualified_assessor_sw
, r.legacy_id
,'A' as CONVERSION_RUN_STATUS
--select count(1)
from perlss.pae_rqst r
join legacy.wrk_pasrr_clients w on r.legacy_id::text = w.maximus_reviewid::text --and w.perlss_indv_id = r.prsn_id 
join legacy.pasrr_events b on b.reviewid::bigint  = w.maximus_reviewid::bigint
join legacy.pasrr_loc a on  b.eventid::text = a.eventid::text
where  w.source_system_nm = 'MAXIMUS' 
and valid_sw= 'Y' and 	xref_valid_sw='Y'
and r.created_by  = 'CV_'|| (select CNV_RUN_NUM from legacy.wrk_conversion_run where cnv_run_status = 'A')
)
select distinct * from temptb 
)a


--pae_app_addr_dtl


select * from perlss.pae_app_addr_dtl pabd 
where created_by='CV_11';

select COUNT(1), PAE_ID from perlss.pae_app_addr_dtl
where created_by='CV_11'
group by PAE_ID
having COUNT(1)>2;--0

select * from perlss.pae_app_addr_dtl a
where created_by = 'CV_11'
and not exists(select 1 from perlss.pae_rqst b where b.pae_id = a.pae_id);--0

select * from perlss.pae_app_addr_dtl a
where created_by = 'CV_11'
and exists(select 1 from perlss.pae_rqst b where b.pae_id = a.pae_id);


select *
from perlss.pae_rqst r
join legacy.wrk_pasrr_clients w on r.legacy_id::text = w.maximus_reviewid::text --and w.perlss_indv_id = r.prsn_id 
join legacy.pasrr_events b on b.reviewid::bigint  = w.maximus_reviewid::bigint
where  w.source_system_nm = 'MAXIMUS' 
and valid_sw= 'Y' and 	xref_valid_sw='Y'
and w.maximus_reviewid in (262594 ,485408)

and r.created_by  = 'CV_'|| (select CNV_RUN_NUM from legacy.wrk_conversion_run where cnv_run_status = 'A')
and b.individualid in (select individualid from (
select ssn, individualid, hospitaladmitdate, count(distinct upper(individualaddress1)) from (
select wpc.ssn, pe.individualid, hospitaladmitdate,individualaddress1,
rank() over(partition by pe.individualid order by hospitaladmitdate desc) as rnk
--select *
from legacy.wrk_pasrr_clients wpc 
left join legacy.pasrr_demographics pd on wpc.ssn = pd.ssn  
left join legacy.pasrr_events pe on pe.individualid = pd.individualid where pe.payersource ilike '%Medicaid%') a 
where rnk = 1
GROUP by ssn, individualid, hospitaladmitdate 
having count(distinct upper(individualaddress1)) > 1) a );

select *  from legacy.pasrr_events pe where --reviewid = '262594'
individualid= '4A3F3C8E-E914-43FA-AE30-B30A2D3C8D40';

select * from perlss.pae_rqst where created_by = 'CV_11' and  legacy_id::text
in (select reviewid::text from legacy.pasrr_events pe where --reviewid = '262594'
individualid= '4A3F3C8E-E914-43FA-AE30-B30A2D3C8D40');

select * from legacy.pasrr_events where reviewid in (262594 ,485408);


select * from legacy.wrk_pasrr_clients where maximus_reviewid in (262594 ,485408)

select * from perlss.pae_app_addr_dtl paad where addr_line_1 like '%46720%'


select * from legacy.wrk_pasrr_clients  where maximus_reviewid in 
(select *  from legacy.pasrr_events pe 
where payersource like '%Medicaid%' and
individualid='9F855B29-FC74-4893-AE40-5F14AC5E392A');

 
select * from perlss.pae_app_addr_dtl where pae_id in (
select pae_id from perlss.pae_rqst where created_by = 'CV_11' and legacy_id in ('262594' ,'485408'));

select *  from legacy.pasrr_events pe where reviewid::text
in (select LEGACY_ID::TEXT from PERLSS.PAE_RQST where PAE_ID in (
select PAE_ID from perlss.pae_app_addr_dtl   
where created_by ='CV_11' and PAE_ID in ('PAE200135877','PAE200135980')));--59 C0UNTY

select * from perlss.pae_app_addr_dtl   
where created_by ='CV_11' and PAE_ID in ('PAE200135877','PAE200135980');

select * from LEGACY.WRK_PASRR_XREF_CODES where FROM_XREF_CD = 'MEIGS';









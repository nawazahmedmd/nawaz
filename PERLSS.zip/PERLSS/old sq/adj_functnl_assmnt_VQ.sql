select *  from perlss.adj_functnl_assmnt afa 
where created_by =  'CV_11';

select * from perlss.com_comments cc 

select count(1), adj_id  from perlss.adj_functnl_assmnt afa 
where created_by =  'CV_11'
group by adj_id
having count(1)>12;--0

select count(1), adj_id  from perlss.adj_functnl_assmnt afa 
where created_by =  'CV_11'
group by adj_id
having count(1)<12;--0

select * from perlss.adj_rqst where adj_id = '100105232';

select legacy_id  from perlss.pae_rqst where pae_id = 'PAE200107499';--762510

select * from perlss.adj_functnl_assmnt where adj_id = '100105232';

select 
ADLTransferClinicianResponse
,ADLWalkingClinicianResponse
,ADLMobilityClinicianResponse
,ADLEatingClinicianResponse
,ADLEatingClinicianResponse
,ADLToiletingClinicianResponse
,ADLIncontinentCareClinicianResponse
,ADLCatheterCareClinicianResponse
,ADLOrientationClinicianResponse
,ADLExpressiveClinicianResponse
,ADLReceptiveClinicianResponse
,ADLMedsAdminClinicianResponse
,ADLBehaviorClinicianResponse
from legacy.pasrr_loc pl 
where eventid in (select eventid from legacy.pasrr_events where reviewid = '762510');


select 
ADLTransferClinicianDetermination
,ADLWalkingClinicianDetermination
,ADLMobilityClinicianDetermination
,ADLEatingClinicianDetermination
,ADLToiletingClinicianDetermination
,ADLIncontinentCareClinicianDetermination
,ADLCatheterCareClinicianDetermination
,ADLOrientationClinicianDetermination
,ADLExpressiveClinicianDetermination
,ADLReceptiveClinicianDetermination
,ADLMedsAdminClinicianDetermination
,ADLBehaviorClinicianDetermination
from legacy.pasrr_loc pl 
where eventid in (select eventid from legacy.pasrr_events where reviewid = '762510');



 




select count(1), task_master_id , task_dtl_desc  from perlss.cnv_task where created_by ='PASRR_CV'
group by task_master_id , task_dtl_desc;


select distinct passr_pi__nursingfacilitynpinumber,tmed_num_control_pkey ,pasrr_review_id, c.pae_id, lv.provider_id
from  legacy.pasrr_pae_base_member_pop b 
join perlss.pae_rqst c on c.legacy_id::text = b.pasrr_review_id::text
left join perlss.pae_lvng_arrgmnt LV on c.pae_id = lv.pae_id
left join legacy.tmed_xml_extract_cv_qlf_no_rec a on a.num_control::text = b.tmed_num_control_pkey ::text
where c.created_by ='PASRR_CV'
and passr_pi__nursingfacilitynpinumber is not  null
;

update perlss.pae_lvng_arrgmnt a
set provider_id = '1235516097'
where a.created_by = 'PASRR_CV' and a.pae_id = 'PAE200113043' and a.provider_id is null;

select * from perlss.pae_lvng_arrgmnt where created_by = 'PASRR_CV' and provider_id is not null;


select count(1), task_master_id , task_dtl_desc  from perlss.cnv_task ct 
where created_by = 'PASRR_CV'
group by task_master_id , task_dtl_desc 



select distinct loc_dcsn_cd from perlss.adj_rqst where created_by ='PASRR_CV'
NWE

select pae_id from perlss.pae_rqst where created_by = 'PASRR_CV' and legacy_id ::text in (
select maximus_reviewid::text  from legacy.pasrr_pae_base_member_pop a
join legacy.wrk_pasrr_clients b on a.pasrr_review_id::text = b.maximus_reviewid::text
where perlss_sw= 'N' and valid_sw ='Y' and xref_valid_sw ='Y'
and step in ('3','5','5a'))
except
select pae_id from perlss.cnv_task where created_by = 'PASRR_CV' and task_master_id <> 180;

select * from perlss.adj_dtls where adj_id in (
select adj_id from perlss.adj_rqst 
where pae_id in ('PAE200113224','PAE200112820','PAE200112538','PAE200112225'));

select a.pae_id , b.adj_id , fe.ssn, a.grp3_intrst_sw , c.trgt_popltn_not_meet_sw,b.enr_grp_cd ,A.mopd_dt ,
--a.actual_discharge_dt ,bb.anticipated_discharge_dt,curr_lvng_arrgmnt_cd,
pae_eff_dt,eligibility_beg_dt, a.status_cd
from perlss.pae_rqst a
join perlss.adj_rqst b on a.pae_id = b.pae_id
join perlss.pae_lvng_arrgmnt bb on a.pae_id = bb.pae_id
join perlss.adj_dtls c on b.adj_id = c.adj_id
join perlss.com_applcnt d on d.prsn_id = a.prsn_id 
left join legacy.fe_check fe on fe.ssn = d.ssn
where a.pae_id in ('PAE200113224','PAE200112820','PAE200112538','PAE200112225');

select * from perlss.adj_rqst 
where pae_id in ('PAE200113224','PAE200112820','PAE200112538','PAE200112225');

select * from perlss.pae_rqst p 
join legacy.pasrr_pae_base_member_pop pop on pop.pasrr_review_id::text  = p.legacy_id
where p.created_by = 'PASRR_CV' and pop.step in ('3','5','5a') and p.status_cd='AP'
 and exists(select 1 from perlss.enr_rqst e where e.prsn_id = p.prsn_id 
 and e.enr_status_cd= 'ENR' and created_by <> 'PASRR_CV' and e.enr_grp_cd <> 'CG1'
 and p.pae_id  in ('PAE200113224','PAE200112820','PAE200112538','PAE200112225')
 and enr_id in  ( 
      select
            max(enr_id)
      from
            perlss.enr_rqst where created_by <> 'PASRR_CV'
      and (hstry_sw = 'N'
            or hstry_sw is null)
      and active_sw = 'Y'
      group by
            pae_id,
            prsn_id))
            
   select distinct 8 as task_master_id  ,p.pae_id , p.prsn_id,a.created_by, a.created_dt,
a.pae_eff_dt::date,
legacy.fn_add_business_days(to_date(to_char(a.created_dt, 'yyyy-mm-dd'), 'yyyy-mm-dd'),14) due_dt from  
perlss.pae_rqst p 
join  perlss.adj_rqst a on p.pae_id = a.pae_id and p.prsn_id = a.prsn_id
join  perlss.com_applcnt ca on ca.prsn_id = p.prsn_id and  ca.active_sw='Y' and file_clearance_sw ='Y'
join legacy.pasrr_pae_base_member_pop pop on pop.pasrr_review_id::text  = p.legacy_id
where p.created_by = 'PASRR_CV' and a.created_by = 'PASRR_CV' and p.status_cd='AP'  and pop.step in ('3','5','5a')
and not exists (select ssn from (select case when length(ssn)= 8 then '0'||ssn 
when length(ssn) = 7 then '00'||ssn::text else ssn end as ssn from legacy.fe_check) fc where fc.ssn = ca.ssn)
and p.pae_id = 'PAE200113224'

select * from legacy.fe_check where ssn in (
select ssn from perlss.com_applcnt ca 
where prsn_id in (6000021508,
3812500236,
6000100612,
3812500329));







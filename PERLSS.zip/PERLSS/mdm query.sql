select distinct 
 12345 LTSS_CLIENT_SEQ_ID               
,'PASRR' AS SOURCE_SYSTEM_NM                  
,a.ssn LEGACY_CLIENT_ID                  
,a.lastname NAM_LAST                          
,a.firstname NAM_FIRST                         
,a.middleinitial NAM_MID                           
,a.ssn NUM_SSN                           
,a.dob DTE_BIRTH                         
,a.gender CDE_SEX                           
,b.individualaddress1 MAILING_ADR_STREET_1              
,b.individualaddress2 MAILING_ADR_STREET_2             
,b.individualcity MAILING_ADR_CITY                 
,b.individualstate MAILING_ADR_STATE                
,b.individualzip MAILING_ADR_ZIP_CODE              
,null as MAILING_ADR_ZIP_CODE_4            
,Null as PHONE_NR                         
,b.individualaddress1 PHY_ADR_STREET_1                 
,b.individualaddress2 PHY_ADR_STREET_2                  
,b.individualcity PHY_ADR_CITY                     
,b.individualstate PHY_ADR_STATE                    
,b.individualzip PHY_ADR_ZIP_CODE                  
,null as PHY_ADR_ZIP_CODE_4                
,null as ALT_PHONE_NR                     
,now() CREATE_DT                                           
,b.individualcounty MAILING_CNTY_CD                  
,null as PHY_CNTY_CD        
FROM legacy.pasrr_demographics a 
join legacy.pasrr_events b on a.individualid=b.individualid


												              

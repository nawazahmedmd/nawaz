create table legacy.pae_med_digans_dtls_bkp as
select * from perlss.pae_med_diagns_dtls where created_by = 'PASRR_CV';


select othr_med_diagns, id  from perlss.pae_med_diagns_dtls pmdd
where othr_med_diagns ~ '[^\x20-\x7E,\t,\,-]' 
and  created_by = 'PASRR_CV';



update perlss.pae_med_diagns_dtls
set othr_med_diagns = replace(othr_med_diagns,'Չ','')
where id in (1833643125,1833643153,1833643234,1833644490);

update perlss.pae_med_diagns_dtls
set othr_med_diagns = replace(othr_med_diagns,'Ӣehavior disorderԬ','behaviour disorder')
where id in (1833643247);

update perlss.pae_med_diagns_dtls
set othr_med_diagns = replace(othr_med_diagns,'nҴ','not')
where id in (1833643288);

update perlss.pae_med_diagns_dtls
set othr_med_diagns = replace(othr_med_diagns,'','')
where id in (1833643673);

update perlss.pae_med_diagns_dtls
set othr_med_diagns = replace(othr_med_diagns,'ҳ','')
where id in (1833643449);

update perlss.pae_med_diagns_dtls
set othr_med_diagns = replace(othr_med_diagns,'','')
where id in (1833643592);

update perlss.pae_med_diagns_dtls
set othr_med_diagns = replace(othr_med_diagns,'֠(p','(p')
where id in (1833643688);

update perlss.pae_med_diagns_dtls
set othr_med_diagns = replace(othr_med_diagns,'頳','')
where id in (1833644061);

update perlss.pae_med_diagns_dtls
set othr_med_diagns = replace(othr_med_diagns,'HLD, 1РAV block','HLD, 1PAV block')
where id in (1833644003);

update perlss.pae_med_diagns_dtls
set othr_med_diagns = replace(othr_med_diagns,'weaknessַeakness resolved','weakness resolved')
where id in (1833643959);

update perlss.pae_med_diagns_dtls
set othr_med_diagns = 
replace(replace(othr_med_diagns,'                 Diagnostics:                                                   ',' '),
'Temp:  [97.4 І (36.3 Ѓ)-98 І (36.7 Ѓ)] 97.5 І (36.4 Ѓ)','Temp : 97.4(36.3) , 98(36.7), 97.5(36.4)')
where id in (1833643141);


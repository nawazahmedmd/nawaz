--------------------------------------------------------
--  DDL for Function F_GET_CONV_DATE
--------------------------------------------------------

  CREATE OR REPLACE EDITIONABLE FUNCTION "IE_CNV_WRK"."F_GET_CONV_DATE" 
RETURN DATE 
IS l_Conv_DATE DATE;

BEGIN
SELECT  DATA_CONVERSION_DATE INTO l_Conv_DATE 
FROM CONV_ADMIN.DCM_DATA_CONVERSION_HEADER
WHERE DATA_CONVERSION_HEADER_ID = F_GET_HDR_ID;
RETURN l_Conv_DATE ;

END ;

/
--------------------------------------------------------
--  DDL for Function F_GET_CONV_FIRST_DATE
--------------------------------------------------------

  CREATE OR REPLACE EDITIONABLE FUNCTION "IE_CNV_WRK"."F_GET_CONV_FIRST_DATE" 
RETURN DATE
IS l_Conv_DATE DATE; l_Conv_first_DATE DATE;
BEGIN
SELECT  F_GET_CONV_DATE INTO l_Conv_DATE  FROM DUAL;
SELECT TRUNC(l_Conv_DATE,'MM') INTO l_Conv_first_DATE  FROM DUAL;
RETURN l_Conv_first_DATE;
END; 

/
--------------------------------------------------------
--  DDL for Function F_GET_CONV_USER
--------------------------------------------------------

  CREATE OR REPLACE EDITIONABLE FUNCTION "IE_CNV_WRK"."F_GET_CONV_USER" 
RETURN VARCHAR2
IS  l_Conv_USER VARCHAR2(100);
BEGIN

SELECT  'CONVERSION_USER_' || cast(F_GET_HDR_ID as varchar2(3)) 
INTO l_Conv_USER  FROM DUAL;

RETURN l_Conv_USER;

END;

/
--------------------------------------------------------
--  DDL for Function F_GET_CREATE_DATE
--------------------------------------------------------

  CREATE OR REPLACE EDITIONABLE FUNCTION "IE_CNV_WRK"."F_GET_CREATE_DATE" 
RETURN timestamp
IS l_DATE timestamp;
BEGIN

SELECT  CURRENT_timestamp INTO l_DATE FROM DUAL;

RETURN l_DATE; 

END; 

/
--------------------------------------------------------
--  DDL for Function F_GET_EXTRACT_DATE
--------------------------------------------------------

  CREATE OR REPLACE EDITIONABLE FUNCTION "IE_CNV_WRK"."F_GET_EXTRACT_DATE" 
RETURN DATE 
IS l_Conv_DATE DATE;
BEGIN

SELECT DATA_EXTRACT_DATE INTO l_Conv_DATE FROM CONV_ADMIN.DCM_DATA_CONVERSION_HEADER 
WHERE DATA_CONVERSION_HEADER_ID = F_GET_HDR_ID;

RETURN l_Conv_DATE;

END;

/
--------------------------------------------------------
--  DDL for Function F_GET_HDR_ID
--------------------------------------------------------

  CREATE OR REPLACE EDITIONABLE FUNCTION "IE_CNV_WRK"."F_GET_HDR_ID" 
RETURN NUMBER 
IS l_hdr_ID NUMBER ;
BEGIN

SELECT   MAX(DATA_CONVERSION_HEADER_ID) into l_Hdr_ID
FROM CONV_ADMIN.DCM_DATA_CONVERSION_HEADER
Where CONVERSION_TYPE NOT like '%INTERIM';


RETURN l_hdr_ID ;

END;

/
--------------------------------------------------------
--  DDL for Function F_GET_REFERENCE_DATA
--------------------------------------------------------

  CREATE OR REPLACE EDITIONABLE FUNCTION "IE_CNV_WRK"."F_GET_REFERENCE_DATA" (Legacy_Table IN VARCHAR2, LEG_CODE IN VARCHAR2,REFERENCE_TABLE IN VARCHAR2)
RETURN VARCHAR2
IS l_NEXTGEN_Reference_Code VARCHAR2(200);

BEGIN

SELECT LTRIM(RTRIM(NEXTGEN_CODE)) INTO l_NEXTGEN_Reference_Code 
FROM STAGE.leg_nextgen_ref_table
WHERE LEGACY_TABLE_CODE = LTRIM(RTRIM(Legacy_Table)) 
AND LEGACY_CODE= LTRIM(RTRIM(LEG_CODE))--CANNOT USE SAME NAME AS TABLE COLUMN NAME
AND NEXTGEN_REFERENCE_TABLE_NAME = LTRIM(RTRIM(REFERENCE_TABLE))
and rownum=1;

RETURN l_NEXTGEN_Reference_Code;

END;

/
--------------------------------------------------------
--  DDL for Function F_GET_REFERENCE_DATA_TLCS
--------------------------------------------------------

  CREATE OR REPLACE EDITIONABLE FUNCTION "IE_CNV_WRK"."F_GET_REFERENCE_DATA_TLCS" (Legacy_Table IN VARCHAR2, LEG_CODE IN VARCHAR2,REFERENCE_TABLE IN VARCHAR2)
RETURN VARCHAR2
IS l_ELIC_Reference_Code VARCHAR2(200);

BEGIN

SELECT LTRIM(RTRIM(ELIC_CODE)) INTO l_ELIC_Reference_Code 
FROM STAGE.LEG_NEXTGEN_REF_TABLE_TLCS
WHERE LEGACY_TABLE_CODE = LTRIM(RTRIM(Legacy_Table)) 
AND LEGACY_CODE= LTRIM(RTRIM(LEG_CODE))--CANNOT USE SAME NAME AS TABLE COLUMN NAME
AND ELIC_REFERENCE_TABLE_NAME = LTRIM(RTRIM(REFERENCE_TABLE))
and rownum=1;

RETURN l_ELIC_Reference_Code;

END;

/

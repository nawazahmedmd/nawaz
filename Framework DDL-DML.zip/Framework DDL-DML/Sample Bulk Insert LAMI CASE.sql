
--delete from preland.lami_case where case_cid like 'LAMI%'
TRUNCATE TABLE PRELAND.TEMP_GROUP2_SEQ

BULK INSERT PRELAND.VW_TEMP_GROUP2_SEQ FROM  '\\s-CMDB-SNTN03\CNV\PILOT\LAMI_case.txt'  WITH
        (
        CODEPAGE = 'ACP',
        FIRSTROW = 1,
        FIELDTERMINATOR = 'tab',
        ROWTERMINATOR = '0x0a',
             --KEEPIDENTITY,
        KEEPNULLS
        )

		--
TRUNCATE TABLE PRELAND.LAMI_CASE
--SET IDENTITY_INSERT PRELAND.LAMI_CASE OFF;
INSERT INTO PRELAND.LAMI_CASE
SELECT 
SUBSTRING(File_Text,          1,          9),
SUBSTRING(File_Text,         10,          9),
SUBSTRING(File_Text,         19,          3),
SUBSTRING(File_Text,         22,          9),
SUBSTRING(File_Text,         31,          7),
SUBSTRING(File_Text,         38,          3),
SUBSTRING(File_Text,         41,          2),
SUBSTRING(File_Text,         43,          2),
SUBSTRING(File_Text,         45,         10),
SUBSTRING(File_Text,         55,         10),
SUBSTRING(File_Text,         65,          8),
SUBSTRING(File_Text,         73,          8),
SUBSTRING(File_Text,         81,          9),
SUBSTRING(File_Text,         90,          9),
SUBSTRING(File_Text,         99,         12),
SUBSTRING(File_Text,        111,          1),
SUBSTRING(File_Text,        112,          3),
SUBSTRING(File_Text,        115,          2),
SUBSTRING(File_Text,        117,          1),
SUBSTRING(File_Text,        118,          1),
SUBSTRING(File_Text,        119,          1),
SUBSTRING(File_Text,        120,          2),
SUBSTRING(File_Text,        122,          9),
SUBSTRING(File_Text,        131,         12),
SUBSTRING(File_Text,        143,          1),
SUBSTRING(File_Text,        144,          3),
SUBSTRING(File_Text,        147,         10),
SUBSTRING(File_Text,        157,          1),
SUBSTRING(File_Text,        158,         25),
SUBSTRING(File_Text,        183,         25),
SUBSTRING(File_Text,        208,         20),
SUBSTRING(File_Text,        228,          2),
SUBSTRING(File_Text,        230,          9),
SUBSTRING(File_Text,        239,          1),
SUBSTRING(File_Text,        240,          1),
SUBSTRING(File_Text,        241,         25),
SUBSTRING(File_Text,        266,         25),
SUBSTRING(File_Text,        291,         20),
SUBSTRING(File_Text,        311,          2),
SUBSTRING(File_Text,        313,          9),
SUBSTRING(File_Text,        322,          1),
SUBSTRING(File_Text,        323,          1),
SUBSTRING(File_Text,        324,         25),
SUBSTRING(File_Text,        349,         25),
SUBSTRING(File_Text,        374,         20),
SUBSTRING(File_Text,        394,          2),
SUBSTRING(File_Text,        396,          9),
SUBSTRING(File_Text,        405,          1),
SUBSTRING(File_Text,        406,         15),
SUBSTRING(File_Text,        421,          8),
SUBSTRING(File_Text,        429,         11),
SUBSTRING(File_Text,        440,          8),
SUBSTRING(File_Text,        448,          1),
SUBSTRING(File_Text,        449,          1),
SUBSTRING(File_Text,        450,         16),
SUBSTRING(File_Text,        466,          8),
SUBSTRING(File_Text,        474,          1),
SUBSTRING(File_Text,        475,          1),
SUBSTRING(File_Text,        476,          1),
SUBSTRING(File_Text,        477,          8),
SUBSTRING(File_Text,        485,          1),
SUBSTRING(File_Text,        486,          8),
SUBSTRING(File_Text,        494,         35),
SUBSTRING(File_Text,        529,          1)
FROM PRELAND.TEMP_GROUP2_SEQ






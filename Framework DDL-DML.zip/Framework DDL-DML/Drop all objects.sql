USE IE_IE_CNV_INTERIM_TEST_SCRIPT
Go



DECLARE @l_loop INT, @l_Max INT, @l_Object VARCHAR(200)
DECLARE @l_SQL VARCHAR(MAX)

DECLARE @Table Table(SEq_ID INT Identity(1,1), ObjectName VARCHAR(200))

Declare @l_type VARCHAR(100) 


DECLARE @l_ObjectName VARCHAR(200)

SET NOCOUNT ON 
SET @l_type = 'Tables'
--SET @l_type = 'Views'
--SET @l_type = 'Procedures'
--SET @l_type = 'Functions'
--SET @l_type = 'Sequences'
--SET @l_type = 'ALL'

--Drop all table
IF @l_type = 'Tables' or @l_type = 'ALL'
BEGIN
  --Get data
  INSERT INTO @Table
  --SElect @l_Max = Count(1) , @l_loop =1
  SELECT TABLE_SCHEMA + '.' + TABLE_NAME
  from INFORMATION_SCHEMA.TABLES
  Where TABLE_TYPE = 'BASE TABLE'
  SElect @l_Max = Count(1) , @l_loop =1 from @table

  Print 'Total tables to be deleted: ' + Cast(@l_Max as varchar)
  While @l_loop <= @l_Max
  BEGIN
     SELECT  @l_SQL = 'DROP TABLE IE_IE_CNV_INTERIM_TEST_SCRIPT.' + '' + ObjectName + ''+ ';' from @Table Where Seq_ID = @l_loop
     --PRINT @l_SQL
     EXEC (@l_SQL)

	 SET @l_loop = @l_loop + 1
	 END 
  END --tables
  Print 'Total tables deleted: ' + Cast(@l_loop-1 as varchar)

--Drop all views  
IF @l_type = 'Views' or @l_type = 'ALL'
BEGIN
  --Get data
  INSERT INTO @Table
  --SElect @l_Max = Count(1) , @l_loop =1
  SELECT TABLE_SCHEMA + '.' + TABLE_NAME
  from INFORMATION_SCHEMA.TABLES
  Where TABLE_TYPE != 'VIEW'
  SElect @l_Max = Count(1) , @l_loop =1 from @table

  While @l_loop <= @l_Max
  BEGIN
     SELECT  @l_SQL = 'DROP VIEW IE_IE_CNV_INTERIM_TEST_SCRIPT.' + '' + ObjectName + ''+ ';' from @Table Where Seq_ID = @l_loop
     PRINT @l_SQL
     --EXEC (@l_SQL)

	 SET @l_loop = @l_loop + 1
  END 
END --tables

--Drop all Sequences
IF @l_type = 'Sequences' or @l_type = 'ALL'
BEGIN
  --Get data
  INSERT INTO @Table
  --SElect @l_Max = Count(1) , @l_loop =1
  SELECT SEQUENCE_SCHEMA + '.' + SEQUENCE_NAME  FROM INFORMATION_SCHEMA.SEQUENCES
  SElect @l_Max = Count(1) , @l_loop =1 from @table

  While @l_loop <= @l_Max
  BEGIN
     SELECT  @l_SQL = 'DROP SEQUENCE IE_IE_CNV_INTERIM_TEST_SCRIPT.' + '' + ObjectName + ''+ ';' from @Table Where Seq_ID = @l_loop
     PRINT @l_SQL
     --EXEC (@l_SQL)

	 SET @l_loop = @l_loop + 1
  END 
END --Sequences


--Drop all functions
IF @l_type = 'functions' or @l_type = 'ALL'
BEGIN
  --Get data
  INSERT INTO @Table
  --SElect @l_Max = Count(1) , @l_loop =1
  SELECT Schema_NAME([schema_id])  + '.'  + Name  FROM sys.objects WHERE type in (N'FN', N'IF', N'TF', N'FS', N'FT')
  SElect @l_Max = Count(1) , @l_loop =1 from @table

  While @l_loop <= @l_Max
  BEGIN
     SELECT  @l_SQL = 'DROP FUNCTION IE_IE_CNV_INTERIM_TEST_SCRIPT.' + '' + ObjectName + ''+ ';' from @Table Where Seq_ID = @l_loop
     PRINT @l_SQL
     --EXEC (@l_SQL)

	 SET @l_loop = @l_loop + 1
  END 
END --function

  
  --Drop all functions
IF @l_type = 'Procedures' or @l_type = 'ALL'
BEGIN
  --Get data
  INSERT INTO @Table
  --SElect @l_Max = Count(1) , @l_loop =1
  SELECT Schema_NAME([schema_id])  + '.'  + Name  FROM sys.objects WHERE type in (N'P', N'PC')
  SElect @l_Max = Count(1) , @l_loop =1 from @table

  While @l_loop <= @l_Max
  BEGIN
     SELECT  @l_SQL = 'DROP PROCEDURE IE_IE_CNV_INTERIM_TEST_SCRIPT.' + '' + ObjectName + ''+ ';' from @Table Where Seq_ID = @l_loop
     PRINT @l_SQL
     --EXEC (@l_SQL)

	 SET @l_loop = @l_loop + 1
  END 
END --Procedure
  /*


--Verify
SElect 'Tables', TABLE_SCHEMA + '.' + TABLE_NAME from INFORMATION_SCHEMA.TABLES
UNION
SELECT 'SEQUENCES', SEQUENCE_SCHEMA + '.' + SEQUENCE_NAME  FROM INFORMATION_SCHEMA.SEQUENCES
UNION 
SELECT 'Functions', Schema_NAME([schema_id]) +  '.'  + Name   
FROM sys.objects WHERE type  in (N'FN', N'IF', N'TF', N'FS', N'FT')

UNION 
SELECT 'Procs', Schema_NAME([schema_id])  + '.'  + Name   FROM sys.objects WHERE type in (N'P', N'PC')



*/
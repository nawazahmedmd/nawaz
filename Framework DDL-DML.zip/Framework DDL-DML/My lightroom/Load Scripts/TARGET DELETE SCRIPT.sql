--17
--BEGIN TRan
begin try
declare @user varchar(100)  = 'CONVERSION_USER_475' --dbo.F_GET_CONV_USER() 
--rollback
--3352258
--18
DELETE FROM dbo.LG_MEM_SUMM WHERE CREATE_USER_ID = @User
DELETE FROM dbo.LG_BEN_SUMM WHERE CREATE_USER_ID = @User
DELETE FROM dbo.LG_MEM_DTL WHERE CREATE_USER_ID = @User

--DELETE FROM dbo.DC_SELF_EMP_BUS_REC_B WHERE CREATE_USER_ID = 'CONVERSION_USER_289'
--17
DELETE FROM dbo.CO_NOD_REASON_HISTORY WHERE CREATE_USER_ID = @User
DELETE FROM dbo.DC_CASE_NOTES_DELETION WHERE CREATE_USER_ID = @User
DELETE FROM dbo.DC_CASE_NOTES WHERE CREATE_USER_ID = @User
DELETE FROM dbo.CO_REQUEST_HISTORY_DETAIL WHERE CREATE_USER_ID = @User
DELETE FROM dbo.CO_REQUEST_HISTORY WHERE CREATE_USER_ID = @User


--commit
--16
DELETE FROM dbo.CR_FINDING_DETAILS WHERE CREATE_USER_ID = @User
DELETE FROM dbo.CR_SAMPLE_CASE_FINDINGS WHERE CREATE_USER_ID = @User
DELETE FROM dbo.TM_TASK_DETAILS WHERE CREATE_USER_ID = @User

DELETE FROM dbo.SAMPLE_PROGRAM_CRITERIA WHERE CREATE_USER_ID = @User
DELETE FROM dbo.SAMPLE_CASES WHERE CREATE_USER_ID = @User


DELETE FROM dbo.SAMPLE_CRITERIA   WHERE CREATE_USER_ID = @User


--14
DELETE FROM 	dbo.HE_OUTCOME_DETAILS                      WHERE CREATE_USER_ID = @User
DELETE FROM 	dbo.HE_DISMISSAL_DETAILS                    WHERE CREATE_USER_ID = @User
DELETE FROM 	dbo.HE_CASE_PARTICIPANTS_INFO               WHERE CREATE_USER_ID = @User
DELETE B FROM dbo.HE_CASE_PARTICIPANTS_INFO_B  B            where exists (select 1 from dbo.HE_CASE_PARTICIPANTS_INFO A where CREATE_USER_ID = @User  AND A.PARTICIPANT_ID = B.PARTICIPANT_ID)
DELETE FROM 	dbo.HE_APPEAL_PROGRAM                       WHERE CREATE_USER_ID = @User
DELETE B FROM dbo.HE_APPEAL_PROGRAM_B  B                   where exists (select 1 from Dbo.HE_APPEAL_PROGRAM A where CREATE_USER_ID = @User  AND A.APPEAL_ID = B.APPEAL_ID)
DELETE FROM 	dbo.HE_APPEAL                               WHERE CREATE_USER_ID = @User
DELETE B FROM dbo.HE_APPEAL_B  B                            where exists (select 1 from Dbo.HE_APPEAL A where CREATE_USER_ID = @User  AND A.CASE_NUM = B.CASE_NUM)


--13

DELETE FROM dbo.CNV_CASE_CROSS_REF                         WHERE CREATE_USER_ID = @User
DELETE FROM dbo.DC_INDV_PROFILE                            WHERE CREATE_USER_ID = @User
DELETE FROM dbo.DC_CASE_PROFILE                            WHERE CREATE_USER_ID = @User
DELETE FROM dbo.AR_APP_ADDR								 WHERE CREATE_USER_ID = @User
--COMMIT
--15 and 12A


DELETE FROM dbo.in_lwc_dq_periods                        WHERE CREATE_USER_ID = @USER
DELETE FROM dbo.in_lwc_weekly_bnft_per                   WHERE CREATE_USER_ID = @USER
DELETE FROM dbo.in_lwc_employer_wages                    WHERE CREATE_USER_ID = @USER
DELETE FROM dbo.in_lwc_employer                          WHERE CREATE_USER_ID = @USER
DELETE FROM dbo.in_lwc_claimant_dtls                     WHERE CREATE_USER_ID = @USER
DELETE FROM dbo.in_wrk_num_hist_inc                      WHERE CREATE_USER_ID = @USER
DELETE FROM dbo.in_wrk_num_cur_inc                       WHERE CREATE_USER_ID = @USER
DELETE FROM dbo.in_wrk_num_inc_ver_request               WHERE CREATE_USER_ID = @USER
DELETE FROM dbo.in_wrk_num_employment_info               WHERE CREATE_USER_ID = @USER
DELETE FROM dbo.in_wrk_num_response                      WHERE CREATE_USER_ID = @USER
DELETE FROM dbo.in_wrk_num_request                       WHERE CREATE_USER_ID = @USER
DELETE FROM dbo.in_caps_service_history                  WHERE CREATE_USER_ID = @USER
DELETE FROM dbo.in_caps_provider_payments                WHERE CREATE_USER_ID = @USER
DELETE FROM dbo.in_caps_provider_inq                     WHERE CREATE_USER_ID = @USER
DELETE FROM dbo.in_tips_provider_inq                     WHERE CREATE_USER_ID = @USER
DELETE FROM dbo.in_edrs_search_locality_contacts         WHERE CREATE_USER_ID = @USER
DELETE FROM dbo.in_edrs_response                         WHERE CREATE_USER_ID = @USER
DELETE FROM dbo.in_edrs_request                          WHERE CREATE_USER_ID = @USER
DELETE FROM dbo.in_solq_mbc                              WHERE CREATE_USER_ID = @USER
DELETE FROM dbo.in_solq_phist                            WHERE CREATE_USER_ID = @USER
DELETE FROM dbo.IN_SOLQ_UIRECORD                         WHERE CREATE_USER_ID = @USER
DELETE FROM dbo.IN_SOLQ_XREF                             WHERE CREATE_USER_ID = @USER
DELETE FROM dbo.in_solq                                  WHERE CREATE_USER_ID = @USER
DELETE FROM dbo.IN_NAC_WS_REQUEST                        WHERE CREATE_USER_ID = @USER
DELETE FROM dbo.IN_NAC_RECORD                            WHERE CREATE_USER_ID = @USER
DELETE FROM dbo.IN_NAC_MATCH_INNER_HIST                  WHERE CREATE_USER_ID = @USER
DELETE FROM dbo.IN_NAC_ELIGIBILITY                       WHERE CREATE_USER_ID = @USER
DELETE FROM dbo.IN_NAC_ADDRESS                           WHERE CREATE_USER_ID = @USER
DELETE FROM dbo.IN_NAC_CASE                              WHERE CREATE_USER_ID = @USER
DELETE FROM dbo.IN_NAC_WS_RESPONSE                       WHERE CREATE_USER_ID = @USER
DELETE FROM dbo.IN_SSA_EMP_HIST                          WHERE CREATE_USER_ID = @USER
DELETE FROM dbo.IN_SSA_PRISONER_MATCH                    WHERE CREATE_USER_ID = @USER
DELETE FROM dbo.IN_SSA_PRISONER_FACILITY                 WHERE CREATE_USER_ID = @USER
DELETE FROM dbo.IN_LASES_LEZ_GRFN_SUMMARY                WHERE CREATE_USER_ID = @USER
DELETE FROM dbo.IN_LASES_LEZ_CS_MBR                      WHERE CREATE_USER_ID = @USER
DELETE FROM dbo.IN_LASES_LEZ_INQ                         WHERE CREATE_USER_ID = @USER
DELETE FROM dbo.IN_PARIS_VET_OUTPUT                      WHERE CREATE_USER_ID = @USER
DELETE FROM dbo.IN_PARIS_FED_OUTPUT                      WHERE CREATE_USER_ID = @USER
DELETE FROM dbo.IN_PARIS_INSTATE_OUTPUT                  WHERE CREATE_USER_ID = @USER
DELETE FROM dbo.IN_FILE_STATUS                           WHERE CREATE_USER_ID = @USER
DELETE FROM dbo.IN_CLEARANCE_DETAILS                     WHERE CREATE_USER_ID = @USER
DELETE FROM dbo.IN_CLEARANCE                             WHERE CREATE_USER_ID = @USER

DELETE FROM dbo.IN_TANF_CHILD_RPT                            WHERE CREATE_USER_ID = @User
DELETE FROM dbo.IN_TANF_ADULT_RPT                            WHERE CREATE_USER_ID = @User
DELETE FROM dbo.IN_TANF_FAMILY_RPT                          WHERE CREATE_USER_ID = @User
DELETE FROM dbo.IN_TANF_CHILD                               WHERE CREATE_USER_ID = @User
DELETE FROM dbo.IN_TANF_ADULT                               WHERE CREATE_USER_ID = @User
DELETE FROM dbo.IN_TANF_FAMILY                              WHERE CREATE_USER_ID = @User
DELETE FROM dbo.IN_TANF_CLOSE_REC_STG_CHILD                 WHERE CREATE_USER_ID = @User
DELETE FROM dbo.IN_TANF_CLOSE_REC_STG                       WHERE CREATE_USER_ID = @User
DELETE FROM dbo.IN_TANF_ACTIVE_AD_STG                       WHERE CREATE_USER_ID = @User
DELETE FROM dbo.IN_TANF_ACTIVE_STG                          WHERE CREATE_USER_ID = @User
DELETE FROM dbo.IN_TANF_ACTIVE_CH_STG                       WHERE CREATE_USER_ID = @User

--12


DELETE FROM dbo.IN_SDX                                      WHERE CREATE_USER_ID = @User
DELETE FROM dbo.IN_RCV_DEATH_MATCH                          WHERE CREATE_USER_ID = @User
DELETE FROM dbo.IN_LWC_WEEKLY_BNFT_PER                      WHERE CREATE_USER_ID = @User
DELETE FROM dbo.IN_LWC_EMPLOYER_WAGES                       WHERE CREATE_USER_ID = @User
DELETE FROM dbo.IN_LWC_EMPLOYER                             WHERE CREATE_USER_ID = @User
DELETE FROM dbo.IN_LWC_DQ_PERIODS                           WHERE CREATE_USER_ID = @User
DELETE FROM dbo.IN_LWC_CLAIMANT_DTLS                        WHERE CREATE_USER_ID = @User
DELETE FROM dbo.IN_FED_SERVICE_AUDIT_LOG                    WHERE CREATE_USER_ID = @User
DELETE FROM dbo.IN_DOC_RCV                                  WHERE CREATE_USER_ID = @User


--11
DELETE FROM dbo.DC_ABSENT_PARENT_ADDITIONAL_DETAILS        WHERE CREATE_USER_ID = @User
DELETE FROM dbo.DC_CHILDREN_LINK                           WHERE CREATE_USER_ID = @User
DELETE FROM dbo.DC_ABSENT_PARENT_RACE                      WHERE CREATE_USER_ID = @User
DELETE FROM dbo.DC_ABSENT_PARENT_SUPPORT                   WHERE CREATE_USER_ID = @User
DELETE FROM dbo.DC_ABSENT_PARENT_ADDRESSES                 WHERE CREATE_USER_ID = @User
DELETE FROM dbo.DC_ABSENT_PARENT_ALIAS                     WHERE CREATE_USER_ID = @User
DELETE FROM dbo.DC_ABSENT_PARENT_EMPL_DTLS                 WHERE CREATE_USER_ID = @User
DELETE FROM dbo.DC_ABSENT_PARENTS                          WHERE CREATE_USER_ID = @User


--10
DELETE FROM dbo.MO_EMPLOYEE_CASES                          WHERE CREATE_USER_ID = @User
DELETE FROM dbo.MO_EMPLOYEE_APPS                           WHERE CREATE_USER_ID = @User
DELETE FROM dbo.AR_PHN_DETAILS                             WHERE CREATE_USER_ID = @User
DELETE FROM dbo.AR_EMAIL_DETAILS                           WHERE CREATE_USER_ID = @User
DELETE FROM dbo.AR_APPLICATION_FOR_AID                     WHERE CREATE_USER_ID = @User
DELETE FROM dbo.AR_APP_PROGRAM_INDV                        WHERE CREATE_USER_ID = @User
DELETE FROM dbo.AR_APP_PROGRAM                             WHERE CREATE_USER_ID = @User
DELETE FROM dbo.AR_APP_INDV                                WHERE CREATE_USER_ID = @User
DELETE FROM dbo.AR_APP_ADDR                                WHERE CREATE_USER_ID = @User

--9
DELETE FROM dbo.TC_EXTENDED_BNFT_DETAILS                    WHERE CREATE_USER_ID = @User
DELETE FROM dbo.TC_TRANSACTIONS                            WHERE CREATE_USER_ID = @User
DELETE FROM dbo.TC_CLOCK_DETAILS                           WHERE CREATE_USER_ID = @User

--8
--DELETE B FROM dbo.WC_ACTIVITY_ASSIGNMENT_B B		where exists (select 1 from Dbo.WC_ACTIVITY_ASSIGNMENT A where A.CREATE_USER_ID = @User  AND A.INDV_ID = B.INDV_ID and a.ACTIVITY_ASSIGNMENT_SEQ_NUM = b.ACTIVITY_ASSIGNMENT_SEQ_NUM )
--DELETE B FROM dbo.WC_EMPLOYMENT_HISTORY_B B			where exists (select 1 from Dbo.WC_EMPLOYMENT_HISTORY A where A.CREATE_USER_ID = @User AND A.INDV_ID = B.INDV_ID ) VENKATA TOLD NOT REQ 1/30
DELETE B FROM dbo.WC_EMPLOYMENT_INFO_B B			where exists (select 1 from Dbo.WC_EMPLOYMENT_INFO A where A.CREATE_USER_ID = @User  AND A.INDV_ID = B.INDV_ID )
--DELETE B FROM dbo.WC_FAMILY_CMPOSITN_DETLS_B B		where exists (select 1 from Dbo.WC_FAMILY_CMPOSITN_DETLS A where A.CREATE_USER_ID = @User AND A.INDV_ID = B.INDV_ID )
--DELETE B FROM dbo.WC_FAMILY_COMPOSITION_INFO_B B	where exists (select 1 from Dbo.WC_FAMILY_COMPOSITION_INFO A where A.CREATE_USER_ID = @User  AND A.INDV_ID = B.INDV_ID )
--DELETE B FROM dbo.WC_FINANCIAL_EDU_INFO_B B			where exists (select 1 from Dbo.dc_indv A where A.CREATE_USER_ID = @User AND   A.INDV_ID = B.INDV_ID )
DELETE B FROM dbo.WC_MEDICAL_INFO_B B				where exists (select 1 from Dbo.WC_MEDICAL_INFO A where A.CREATE_USER_ID = @User  AND A.INDV_ID = B.INDV_ID )
DELETE B FROM dbo.WC_REFERRAL_STATUS_TRACKER b     WHERE CREATE_USER_ID = @User
DELETE FROM dbo.WC_PAYMENT_DETAILS                         WHERE CREATE_USER_ID = @User
DELETE FROM dbo.WC_MEDICAL_INFO                            WHERE CREATE_USER_ID = @User
DELETE FROM dbo.WC_INDV_PF_MONTHS                          WHERE CREATE_USER_ID = @User
DELETE FROM dbo.PARENTING_SKILLS                         WHERE CREATE_USER_ID = @User
DELETE FROM dbo.WC_INDV_PAY                                WHERE CREATE_USER_ID = @User
DELETE FROM dbo.WC_INDV_AVL_SUPP_BAL                       WHERE CREATE_USER_ID = @User
DELETE FROM dbo.WC_EMPLOYMENT_INFO                         WHERE CREATE_USER_ID = @User
DELETE FROM dbo.IN_ISIS_PAY_DETAILS_STG                    WHERE CREATE_USER_ID = @User 
DELETE FROM dbo.WC_EXCUSED_ABSENCES							 WHERE CREATE_USER_ID = @User 
DELETE FROM dbo.WC_JOB_SEARCH_READINESS                     WHERE CREATE_USER_ID = @User  
DELETE FROM dbo.IN_ISIS_PAY_DETAILS_STG                    WHERE CREATE_USER_ID = @User
DELETE FROM dbo.WC_FED_HOLIDAY_HRS                         WHERE CREATE_USER_ID = @User
DELETE FROM dbo.WC_EMPLOYMENT_PART_HRS                     WHERE CREATE_USER_ID = @User
DELETE FROM dbo.WC_RECON_PART_HRS                          WHERE CREATE_USER_ID = @User
DELETE FROM dbo.WC_FINANCIAL_EDU_INFO                      WHERE CREATE_USER_ID = @User
DELETE B FROM dbo.WC_FINANCIAL_EDU_INFO_B B			where exists (select 1 from Dbo.dc_indv A where A.CREATE_USER_ID = @User AND   A.INDV_ID = B.INDV_ID )
DELETE FROM dbo.WC_FAMILY_COMPOSITION_INFO                 WHERE CREATE_USER_ID = @User
DELETE B FROM dbo.WC_FAMILY_COMPOSITION_INFO_B B	where exists (select 1 from Dbo.dc_indv A where A.CREATE_USER_ID = @User  AND A.INDV_ID = B.INDV_ID )
DELETE FROM dbo.WC_FAMILY_CMPOSITN_DETLS                   WHERE CREATE_USER_ID = @User
--DELETE B FROM dbo.WC_FAMILY_CMPOSITN_DETLS_B B				where exists (select 1 from Dbo.dc_indv A where A.CREATE_USER_ID = @User AND A.INDV_ID = B.INDV_ID )
DELETE FROM dbo.WC_EMP_PLAN                                WHERE CREATE_USER_ID = @User
DELETE FROM dbo.WC_ASSIGNMENT                              WHERE CREATE_USER_ID = @User
DELETE FROM dbo.WC_ACTIVITY_ASSIGNMENT                     WHERE CREATE_USER_ID = @User
DELETE B FROM dbo.WC_ACTIVITY_ASSIGNMENT_B B				where exists (select 1 from Dbo.dc_indv A where A.CREATE_USER_ID = @User  AND A.INDV_ID = B.INDV_ID)-- and a.ACTIVITY_ASSIGNMENT_SEQ_NUM = b.ACTIVITY_ASSIGNMENT_SEQ_NUM )
DELETE FROM dbo.DC_WORC_REFERRAL                           WHERE CREATE_USER_ID = @User 

--7
DELETE B FROM dbo.BV_CLAIM_B B  where exists (select 1 from Dbo.BV_CLAIM A where A.CREATE_USER_ID = @User AND A.CLAIM_ID = B.CLAIM_ID )
--commit

DELETE FROM dbo.BV_OVERPAYMENT_BENFT_SUMMARY			  WHERE CREATE_USER_ID = @User
DELETE FROM dbo.BV_OVERPAY_RSC_EXP                        WHERE CREATE_USER_ID = @User
DELETE FROM dbo.BV_OVERPAY_INCM_BUDGET                    WHERE CREATE_USER_ID = @User
DELETE FROM dbo.BV_OVERPAY_INCLD_INDV                     WHERE CREATE_USER_ID = @User
DELETE FROM dbo.BV_OVERPAY_INC                            WHERE CREATE_USER_ID = @User
DELETE FROM dbo.BV_OVERPAY_FORM_STG                       WHERE CREATE_USER_ID = @User
DELETE FROM dbo.BV_OVERPAY_DISCREET_INDV                  WHERE CREATE_USER_ID = @User
DELETE FROM dbo.BV_OVERPAY_CLAIM_STG                      WHERE CREATE_USER_ID = @User
DELETE FROM dbo.BV_DISCREPANCY                            WHERE CREATE_USER_ID = @User
DELETE FROM dbo.BV_CLAIM_RECOVERY                         WHERE CREATE_USER_ID = @User
DELETE FROM dbo.BV_CLAIM_FORM_DTLS                        WHERE CREATE_USER_ID = @User
DELETE FROM dbo.BV_CLAIM_LIABLE_INDV                      WHERE CREATE_USER_ID = @User
DELETE FROM dbo.BV_CLAIM                                  WHERE CREATE_USER_ID = @User
DELETE FROM dbo.BV_CLAIM_HEADER                           WHERE CREATE_USER_ID = @User


--6
DELETE FROM dbo.BI_SSI_REFUND_DETAILS                     WHERE CREATE_USER_ID = @User
DELETE FROM dbo.BI_SSI_MANUAL_CHECK_DETAILS               WHERE CREATE_USER_ID = @User
DELETE FROM dbo.BI_RAS_EXPUNGE_DETAIL                     WHERE CREATE_USER_ID = @User
DELETE FROM dbo.BI_TANF_DETAIL                            WHERE CREATE_USER_ID = @User
DELETE FROM dbo.BI_SUPP_SERVICE_DETAIL                    WHERE CREATE_USER_ID = @User
DELETE FROM dbo.BI_FS_DETAIL                            WHERE CREATE_USER_ID = @User
DELETE FROM dbo.BI_PAYEE_DETAIL                          WHERE CREATE_USER_ID = @User

--4

DELETE FROM dbo.DC_LIQUID_RESOURCES                      WHERE CREATE_USER_ID = @User
DELETE B  FROM dbo.DC_LIQUID_RESOURCES_B B  where exists (select 1 from Dbo.DC_RESOURCES A where A.CREATE_USER_ID = @User AND  A.INDV_ID = B.INDV_ID and a.RESOURCE_SEQ_NUM = b.SEQUENCE_NUM)
DELETE FROM dbo.DC_RESOURCES                             WHERE CREATE_USER_ID = @User

--3
DELETE B FROM [DC_SUPPORT_DED_PAYMENTS] B        where CREATE_USER_ID = @User
DELETE FROM dbo.DC_SUPPORT_DEDUCTIONS                    WHERE CREATE_USER_ID = @User
DELETE B FROM dbo.DC_SUPPORT_DEDUCTIONS_B   B        where exists (select 1 from Dbo.DC_INDV A where A.CREATE_USER_ID = @User AND B.INDV_ID = A.INDV_ID)
DELETE FROM dbo.DC_SHELTER_DEDUCTIONS                    WHERE CREATE_USER_ID = @User
DELETE B FROM dbo.DC_SHELTER_DEDUCTIONS_B   B        where exists (select 1 from Dbo.DC_INDV A where A.CREATE_USER_ID = @User AND B.INDV_ID = A.INDV_ID)
DELETE FROM dbo.DC_MEDICAL_DEDUCTIONS                    WHERE CREATE_USER_ID = @User
DELETE B FROM dbo.DC_MEDICAL_DEDUCTIONS_B   B        where exists (select 1 from Dbo.DC_INDV A where A.CREATE_USER_ID = @User AND B.INDV_ID = A.INDV_ID)
DELETE FROM dbo.DC_DEPEND_CARE_DEDUCTIONS                WHERE CREATE_USER_ID = @User
DELETE B FROM dbo.DC_DEPEND_CARE_DEDUCTIONS_B   B        where exists (select 1 from Dbo.DC_INDV A where A.CREATE_USER_ID = @User AND B.INDV_ID = A.INDV_ID)
DELETE B FROM dbo.DC_UTILITY_DEDUCTIONS B  where CREATE_USER_ID = @User
DELETE B FROM dbo.DC_UTILITY_DEDUCTIONS_B B  where exists (select 1 from Dbo.DC_CASES A where A.CREATE_USER_ID = @User AND A.CASE_NUM  = b.CASE_NUM )

--2
DELETE FROM dbo.DC_SELF_EMP_BUS_REC  WHERE CREATE_USER_ID = @User
DELETE FROM dbo.DC_SELF_EMP_SCHEDULE_C                  WHERE CREATE_USER_ID = @User
DELETE B FROM dbo.DC_SELF_EMP_BUS_REC_B B  where exists (select 1 from Dbo.DC_INDV A where A.CREATE_USER_ID = @User AND  A.INDV_ID = B.INDV_ID )
DELETE B FROM dbo.DC_SELF_EMP_SCHEDULE_C_B B  where exists (select 1 from Dbo.DC_INDV A where A.CREATE_USER_ID = @User AND A.INDV_ID = B.INDV_ID )


DELETE FROM dbo.DC_UNEARNED_PAY_EXPENSES                WHERE CREATE_USER_ID = @User

DELETE FROM dbo.DC_EMPLOYMENT_BUDGET                    WHERE CREATE_USER_ID = @User
DELETE FROM dbo.DC_UNEARNED_INCOME_BUDGET               WHERE CREATE_USER_ID = @User
DELETE FROM dbo.DC_UNEARNED_INCOME                      WHERE CREATE_USER_ID = @User
DELETE FROM dbo.DC_SELF_EMP_PAY_EXPENSES                WHERE CREATE_USER_ID = @User
DELETE FROM dbo.DC_SELF_EMP_INCOME_BUDGET               WHERE CREATE_USER_ID = @User
DELETE FROM dbo.DC_SELF_EMP_INCOME                      WHERE CREATE_USER_ID = @User
DELETE FROM dbo.DC_EMPLOYMENT                           WHERE CREATE_USER_ID = @User
DELETE FROM dbo.DC_EMP_PAYMENT_EXPENSES                 WHERE CREATE_USER_ID = @User
DELETE B FROM dbo.DC_UNEARNED_INCOME_B B  where exists (select 1 from Dbo.DC_INDV A where A.CREATE_USER_ID = @User  AND A.INDV_ID = B.INDV_ID )
DELETE B FROM dbo.DC_SELF_EMP_INCOME_B B  where exists (select 1 from Dbo.DC_INDV A where A.CREATE_USER_ID = @User AND  A.INDV_ID = B.INDV_ID )
DELETE B FROM dbo.DC_EMPLOYMENT_B B  where exists (select 1 from Dbo.DC_INDV A where A.CREATE_USER_ID = @User AND A.INDV_ID = B.INDV_ID )

--1E
DELETE FROM dbo.ED_STEP_FAMILY_INDVS						WHERE CREATE_USER_ID = @User
DELETE FROM dbo.ED_MASS_CHANGE_TRIGGER						WHERE CREATE_USER_ID = @User
DELETE FROM dbo.CV_ED_MCI_EDG_INDIVIDUAL                WHERE CREATE_USER_ID = @User
DELETE B FROM dbo.ED_INDV_ELIGIBILITY   B               where exists (select 1 from Dbo.ED_ELIGIBILITY A where A.CREATE_USER_ID = @User AND B.CASE_NUM = A.CASE_NUM  AND B.EDG_TRACE_ID = A.EDG_TRACE_ID)
DELETE B FROM dbo.ED_ELIG_NOTICE_REASONS  B             where exists (select 1 from Dbo.ED_ELIGIBILITY A where A.CREATE_USER_ID = @User AND B.CASE_NUM = A.CASE_NUM  AND B.EDG_TRACE_ID = A.EDG_TRACE_ID)
DELETE FROM dbo.ED_ELIGIBILITY                          WHERE CREATE_USER_ID = @User
DELETE FROM dbo.ED_DC_INDV_DISQ_PENALTIES               WHERE CREATE_USER_ID = @User
DELETE B FROM dbo.ED_DC_INDV_DISQ_PENALTIES_B B  where exists (select 1 from Dbo.DC_INDV A where A.CREATE_USER_ID = @User AND A.INDV_ID = B.INDV_ID )
DELETE FROM dbo.ED_CASE_RECERT_DATES                    WHERE CREATE_USER_ID = @User
--DELETE B FROM dbo.ED_CASE_RECERT_DATES_B B  where exists (select 1 from Dbo.ED_CASE_RECERT_DATES A where A.CREATE_USER_ID = @User AND A.CASE_NUM  = b.CASE_NUM )--AND A.EDG_NUM = B.EDG_NUM )
DELETE B FROM dbo.ED_CASE_RECERT_DATES_B B  where exists (select 1 from Dbo.ED_EDG_NUM_ALLOTMENT a where A.CREATE_USER_ID = @User AND A.CASE_NUM  = b.CASE_NUM )--AND A.EDG_NUM = B.EDG_NUM )
DELETE FROM dbo.ED_EDG_NUM_ALLOTMENT                    WHERE CREATE_USER_ID = @User

--1C

DELETE FROM dbo.DC_PREGNANCIES                          WHERE CREATE_USER_ID = @User
DELETE B FROM dbo.DC_PREGNANCIES_B B  where exists (select 1 from Dbo.DC_INDV A where A.CREATE_USER_ID = @User AND A.INDV_ID = B.INDV_ID )
DELETE FROM dbo.DC_INDV_ABAWD                           WHERE CREATE_USER_ID = @User
DELETE B FROM dbo.DC_INDV_ABAWD_B B  where exists (select 1 from Dbo.DC_INDV A where A.CREATE_USER_ID = @User AND  A.INDV_ID = B.INDV_ID )
DELETE FROM dbo.DC_IMMUNIZATIONS                        WHERE CREATE_USER_ID = @User
DELETE B FROM dbo.DC_IMMUNIZATIONS_B B  where exists (select 1 from Dbo.DC_INDV A where A.CREATE_USER_ID = @User AND  A.INDV_ID = B.INDV_ID )
DELETE FROM dbo.DC_EDUCATION                            WHERE CREATE_USER_ID = @User
DELETE B FROM dbo.DC_EDUCATION_B B  where exists (select 1 from Dbo.DC_INDV A where A.CREATE_USER_ID = @User AND  A.INDV_ID = B.INDV_ID )
DELETE FROM dbo.DC_DISABILITY                           WHERE CREATE_USER_ID = @User
DELETE B FROM dbo.DC_DISABILITY_B B  where exists (select 1 from Dbo.DC_INDV A where A.CREATE_USER_ID = @User AND  A.INDV_ID = B.INDV_ID )


--1B


DELETE FROM dbo.DC_EMAIL_XREF                      WHERE CREATE_USER_ID = @User

DELETE FROM dbo.DC_INDIVIDUAL_ALIEN                     WHERE CREATE_USER_ID = @User
DELETE B FROM dbo.DC_INDIVIDUAL_ALIEN_B B  where exists (select 1 from Dbo.DC_INDV A where A.CREATE_USER_ID = @User AND A.INDV_ID = B.INDV_ID )
DELETE FROM dbo.DC_EMAIL_DETAILS                        WHERE CREATE_USER_ID = @User
DELETE FROM dbo.DC_AUTH_REP                             WHERE CREATE_USER_ID = @User
DELETE B FROM dbo.DC_AUTH_REP_B B  where exists (select 1 from Dbo.DC_CASES A where A.CREATE_USER_ID = @User AND A.CASE_NUM  = b.CASE_NUM  )
--COMMIT
--1A
DELETE FROM dbo.DC_FLYER_INFO                            WHERE CREATE_USER_ID = @User
DELETE FROM dbo.DC_FLYER_INFO    WHERE CREATE_USER_ID = @User
DELETE FROM dbo.DC_PHN_XREF                             WHERE CREATE_USER_ID = @User
DELETE FROM dbo.DC_INDV_NONCOMP_DET                     WHERE CREATE_USER_ID = @User
DELETE B FROM dbo.DC_INDV_NONCOMP_DET_B B  where exists (select 1 from Dbo.DC_INDV A where A.CREATE_USER_ID = @User  AND A.INDV_ID = B.INDV_ID )
DELETE FROM dbo.DC_CASE_HOUSEHOLD_SITUATION             WHERE CREATE_USER_ID = @User
DELETE FROM dbo.DC_RELATIONSHIPS                        WHERE CREATE_USER_ID = @User
DELETE B FROM dbo.DC_RELATIONSHIPS_B B  where exists (select 1 from Dbo.DC_indv A where A.CREATE_USER_ID = @User  AND A.INDV_ID = B.INDV_ID )
DELETE B FROM dbo.DC_RELATIONSHIPS_B B  where exists (select 1 from Dbo.DC_indv A where A.CREATE_USER_ID = @User  AND A.INDV_ID = B.REF_INDV_ID )
DELETE FROM dbo.DC_PHN_DETAILS                          WHERE CREATE_USER_ID = @User
DELETE FROM dbo.DC_INDV_SECONDARY_RACE                  WHERE CREATE_USER_ID = @User
--begin tran
DELETE FROM dbo.DC_INDV_LIVING_ARNGMNTS                 WHERE CREATE_USER_ID = @User
DELETE B FROM dbo.DC_INDV_LIVING_ARNGMNTS_B B  where exists (select 1 from Dbo.DC_INDV_LIVING_ARNGMNTS A where A.CREATE_USER_ID = @User AND A.INDV_ID = B.INDV_ID and a.EFF_BEGIN_DT = b.EFF_BEGIN_DT)
DELETE B FROM dbo.DC_INDV_LIVING_ARNGMNTS_B B  where exists (select 1 from Dbo.DC_INDV A where A.CREATE_USER_ID = @User AND A.INDV_ID = B.INDV_ID )
DELETE FROM dbo.DC_INDV_HH_STATUS                       WHERE CREATE_USER_ID = @User
DELETE B FROM dbo.DC_INDV_HH_STATUS_B  B				where exists (select 1 from Dbo.DC_INDV A where A.CREATE_USER_ID = @User AND  B.INDV_ID = A.INDV_ID)
DELETE B FROM dbo.DC_INDV_HH_STATUS_B  B				where exists (select 1 from Dbo.DC_CASES A where A.CREATE_USER_ID = @User AND  B.CASE_NUM = A.CASE_NUM)
DELETE FROM dbo.DC_HEAD_OF_HOUSEHOLD                    WHERE CREATE_USER_ID = @User
DELETE FROM dbo.DC_DEMOGRAPHICS                         WHERE CREATE_USER_ID = @User
DELETE B FROM dbo.DC_DEMOGRAPHICS_B  B					where exists (select 1 from Dbo.DC_INDV A where A.CREATE_USER_ID = @User AND  B.INDV_ID = A.INDV_ID)
DELETE FROM dbo.DC_CASE_ADDRESSES                       WHERE CREATE_USER_ID = @User
DELETE B FROM dbo.DC_CASE_ADDRESSES_B  B                where exists (select 1 from Dbo.DC_CASES A where A.CREATE_USER_ID = @User AND B.CASE_NUM = A.CASE_NUM  )
DELETE FROM dbo.DC_CASE_PROGRAM_INDV                    WHERE CREATE_USER_ID = @User
DELETE B FROM dbo.DC_CASE_PROGRAM_INDV_B  B             where exists (select 1 from Dbo.DC_CASES A where A.CREATE_USER_ID = @User AND B.CASE_NUM = A.CASE_NUM  )
DELETE FROM dbo.DC_CASE_PROGRAM                         WHERE CREATE_USER_ID = @User
DELETE FROM dbo.DC_CASE_INDIVIDUAL                      WHERE CREATE_USER_ID = @User
DELETE B FROM dbo.DC_CASE_INDIVIDUAL_B  B             	where exists (select 1 from Dbo.DC_CASEs A where A.CREATE_USER_ID = @User AND B.CASE_NUM = A.CASE_NUM  )
DELETE B FROM dbo.DC_CASE_PROGRAM_B  B             		where exists (select 1 from Dbo.DC_CASEs A where A.CREATE_USER_ID = @User AND B.CASE_NUM = A.CASE_NUM )
DELETE FROM dbo.DC_INDV                                 WHERE CREATE_USER_ID = @User
DELETE FROM dbo.DC_CASES                                WHERE CREATE_USER_ID = @User





--rollback
--commit
END TRY
BEGIN CATCH

SELECT ERROR_MESSAGE()  
--rollback
END CATCH

/*
DELETE A
--SELECT *
FROM dbo.DC_CASE_PROGRAM_INDV_B A 
WHERE EXISTS(SELECT 1 FROM PRELAND.LAMI_CASE_PGM_MEM B where A.INDV_ID = B.CPM_PID and A.CASE_NUM = B.CPM_CID AND PROG_CD = dbo.F_GET_CASE_PROGRAM_PROG_CD(CPM_PGM_TYPE))
 A.EFF_BEGIN_DT = B.EFF_BEGIN_DT AND b.CREATE_USER_ID = 'CONVERSION_USER_429')

DELETE FROM dbo.IN_SOLQ_PHIST

DELETE A 
--SELECT * 
FROM dbo.DC_CASE_PROGRAM_INDV A WHERE CREATE_USER_ID = 'CONVERSION_44453' AND CREATE_DT LIKE  '2020-03-05%'


DELETE B 
--select *
FROM dbo.DC_CASE_PROGRAM_INDV_B B  where exists (select * from Dbo.dc_cases A 
where A.CREATE_USER_ID IN  ('CONVERSION_USER_475') AND  A.case_num = B.case_num )
554079, 1668559, UP, P0, 1 29571, 3076724

SELECT * FROM dbo.DC_CASE_PROGRAM_INDV WHERE CASE_NUM = 554079 AND INDV_ID = 1668559

DELETE A FROM dbo.DC_CASE_PROGRAM_INDV A WHERE CASE_NUM = 29571 AND INDV_ID = 3076724
DELETE A  FROM dbo.DC_CASE_PROGRAM_INDV_B  A WHERE CASE_NUM = 29571 AND INDV_ID = 3076724

*/

--SELECT DISTINCT CREATE_USER_ID FROM dbo.DC_CASE_ADDRESSES_B

--

-- DELETE A FROM Dbo.DC_SELF_EMP_BUS_REC A where A.CREATE_USER_ID = 'CONVERSION_USER_340'




--DELETE A FROM Dbo.DC_SELF_EMP_BUS_REC_B A where INDV_ID IN (1194073,2037718,2297868)

--select * from DBO.DC_INDV_LIVING_ARNGMNTS_B WHERE INDV_ID  = 3352258

--DELETE A FROM DC_INDV_LIVING_ARNGMNTS_B WHERE 

--select * from stage.DC_INDV_LIVING_ARNGMNTS WHERE INDV_ID = 3352258


--USE ie_ie_Cnv
Go

/*
--Checks

--SELECT * from CONV_ADMIN.DCM_LEGACY_MASTER_FILES
--SELECT * from CONV_ADMIN.DCM_LEGACY_EXTRACT_DETAIL Where [DATA_CONVERSION_HEADER_ID] = 17

UPDATE A 
  SET LSD_DATA_EXTRACT_DATE = NULL,
   TIME_TAKE_FOR_EXTRACT = NULL,
  LSD_DATA_EXTRACT_COUNT = NULL,
  FILE_STATUS = NULL
FROM CONV_ADMIN.DCM_LEGACY_EXTRACT_DETAIL A
  WHERE DATA_CONVERSION_HEADER_ID = dbo.F_GET_HDR_ID()

  Conversion failed when converting the varchar value '58CAROLYN' to data type int.
*/

if exists (select * FROM sYS.procedures wHERE nAME = 'PR_EXTRACT_LAMI_GROUP1_FILES')
drop proc PR_EXTRACT_LAMI_GROUP1_FILES;
gO
cREATE PROC dbo.PR_EXTRACT_LAMI_GROUP1_FILES
AS

/*

Created By: Venkata Nemani
Created date: Nov 2nd 2017
File Name: 001_PR_EXTRACT_LAMI_GROUP1_FILES.sql
Purpose: SP to extract data from legacy extract file to the LSD Group1 tables 

 

1. LAMI_ASSET_RESOURCES
2. LAMI_EXPENSES
3. LAMI_INCOME_EARNED
4. LAMI_INCOME_SPECIAL
5. LAMI_INCOME_UNEARNED
6. LAMI_LIMIT_AFDC
7. LAMI_LIMIT_FS
8. LAMI_MEMBER
9. LAMI_SANCTIONS
10. LAMI_MEMBER_SANCTIONS

 

 
IF NOT EXISTS (SELECT 1 FROM INFORMATION_SCHEMA.TABLES WHERE TABLE_NAME = 'TEMP_GROUP1_SEQ' AND TABLE_SCHEMA = 'PRELAND')
CREATE TABLE PRELAND.TEMP_GROUP1_SEQ ( SEQ_ID INT IDENTITY(1,1) PRIMARY KEY , File_Text VARCHAR(8000));

IF NOT EXISTS (SELECT 1 FROM INFORMATION_SCHEMA.TABLES WHERE TABLE_NAME = 'VW_TEMP_GROUP1_SEQ' AND TABLE_SCHEMA = 'PRELAND')
CREATE VIEW PRELAND.VW_TEMP_GROUP1_SEQ AS SELECT File_Text FROM PRELAND.TEMP_GROUP1_SEQ;


*/

 

BEGIN --PROC
BEGIN TRY

 

SET Nocount ON

DECLARE @l_SQL NVARCHAR(MAX), @l_Table_count INT
DECLARE @l_Update_Flag VARCHAR(1) = 'Y'
DECLARE @l_cnt INT, @l_time_Taken INT
DECLARE @l_START_Time DATETIME, @l_END_Time DATETIME
DECLARE @l_File_Path VARCHAR(1000)
DECLARE @SQL_BULK VARCHAR(MAX)
DECLARE @l_File_Text VARCHAR(MAX)
DECLARE @l_Header VARCHAR(100)
DECLARE @l_footer VARCHAR(200)
DECLARE @l_Hdr_ID INT
DECLARE @l_First INT, @l_Last INT
DECLARE @l_From_SEQ INT = 2, @l_to_Seq INT, @l_Incremental INT = 500000
DECLARE @l_Loop INT, @l_Max INT 
DECLARE @l_File_Name VARCHAR(1000)
DECLARE @l_tablename VARCHAR(1000)
DECLARE @t_Files TABLE(LEGACY_ID int identity(1,1), LEGACY_FILE_NAME VARCHAR(200), LEGACY_FILE_PATH VARCHAR(1000), Legacy_Table_Name Varchar(200))
DECLARE @l_MAX2 INt
DECLARE @l_Level INt = 10
DECLARE @l_CONVERSION_TYPE VARCHAR(10)
 --UPDATE CONV_ADMIN.DCM_DATA_CONVERSION_HEADER SET CONVERSION_TYPE = 'STATE' WHERE DATA_CONVERSION_HEADER_ID = 2


--Get Header 

SELECT @l_Hdr_ID = dbo.F_GET_HDR_ID()
print 'Data Loading from Legacy Files to PRELAND for Group1 (9 files) for Header : ' + STR(@l_Hdr_ID)

--Get  CONVERSION_TYPE
SELECT @l_CONVERSION_TYPE = CONVERSION_TYPE  from CONV_ADMIN.DCM_DATA_CONVERSION_HEADER WHERE DATA_CONVERSION_HEADER_ID = @l_Hdr_ID
--IF @l_CONVERSION_TYPE = 'PILOT' SET  @l_CONVERSION_TYPE = 'PILOT'
Print @l_CONVERSION_TYPE

--Reset extract details incase of rerun
SET @l_Level = 15
If @l_Update_Flag = 'Y'
UPDATE A 
  SET LSD_DATA_EXTRACT_DATE = NULL,
   TIME_TAKE_FOR_EXTRACT = NULL,
  LSD_DATA_EXTRACT_COUNT = NULL,
  FILE_STATUS = NULL
  , LEGACY_FILE_DATA_HEADER = NULL, LEGACY_FILE_DATA_FOOTER = NULL, LEGACY_FILE_DATA_COUNT = Null
FROM CONV_ADMIN.DCM_LEGACY_EXTRACT_DETAIL A
  WHERE DATA_CONVERSION_HEADER_ID = @l_Hdr_ID
AND LEGACY_FILE_GROUP = 'GROUP1'
--AND A.LEGACY_FILE_NAME = 'LAMI_LIMIT_FS'



SET @l_Level =20

 

--Get all Files
INSERT INTO @t_Files
SELECT  A.LEGACY_FILE_NAME,  LEGACY_FILE_PATH, Legacy_Table_Name
from CONV_ADMIN.DCM_LEGACY_EXTRACT_DETAIL  A
JOIN CONV_ADMIN.DCM_LEGACY_MASTER_FILES  B on A.LEGACY_FILE_NAME = b.LEGACY_FILE_NAME
Where DATA_CONVERSION_HEADER_ID = @l_Hdr_ID
AND A.LEGACY_FILE_GROUP = 'GROUP1'
--AND A.LEGACY_FILE_NAME = 'LAMI_LIMIT_FS'

SELECT @l_Loop = 1, @l_Max = @@ROWCOUNT

--While  Loop for Files
WHILE @l_Loop <= @l_Max
BEGIN


SET @l_START_Time = Getdate()
SET @l_Level =30

 

--Get File name and path
SELECT @l_File_Name =LEGACY_FILE_NAME,  @l_File_Path = LEGACY_FILE_PATH, @l_tablename = Legacy_Table_Name, @l_MAX2 =0, @l_Table_count =0
FROM @t_Files 
WHERE LEGACY_ID = @l_Loop
Print 'Processing file for : '+ @l_File_Name

 
 /*
IF RIGHT(@l_File_Path,1) != '\'   SET @l_File_Path = @l_File_Path + '\'
SEt @l_File_Path = @l_File_Path + @l_File_Name

IF RIGHT(@l_File_Path,4) != '.txt'  SET @l_File_Path = @l_File_Path + '.txt'

If @l_File_Name = 'LAMI_ASSET_RESOURCES' SET @l_File_Path  = '\\s-CMDB-SNTN03\CNV\LAMI_RESOURCES.txt'


*/

  SET @l_File_Path = CASE 
     WHEN LEFT(@l_File_Name,4) = 'LAMI' THEN '\\s-CMDB-SNTN03\CNV\STATE\LAMI_' + REPLACE(SUBSTRING(@l_File_Name,6,100), '_', '')+ '.Txt'
	-- WHEN LEFT(@l_File_Name,3) = 'JAS' THEN '\\s-CMDB-SNTN03\CNV\' + @l_CONVERSION_TYPE + '\JAS_' + REPLACE(SUBSTRING(@l_File_Name,7,100), '_', '')+ '.Txt'
	 END 

  
  IF @l_File_Name = 'LAMI_ASSET_RESOURCES' 
  SET @l_File_Path =  '\\s-CMDB-SNTN03\CNV\STATE\LAMI_RESOURCES' + '.Txt'
 --Print @l_File_Path 
  SET @l_Level =40

 --IF @l_File_Name IN (  'LAMI_INCOME_EARNED', 'LAMI_INCOME_SPECIAL', 'LAMI_INCOME_UNEARNED', '')
 -- SET @l_File_Path =  '\\s-CMDB-SNTN03\CNV\' + @l_CONVERSION_TYPE + '\' + @l_File_Name +  + '.Txt'


--Verify file exists
IF dbo.fn_FileExists (@l_File_Path) = 0
BEGIN
  Print 'File not exists : ' + @l_File_Path
  IF @l_Update_Flag = 'Y'
    UPDATE CONV_ADMIN.DCM_LEGACY_EXTRACT_DETAIL 
	 SET FILE_STATUS = 'FILE_NOT_FOUND'
	  WHERE DATA_CONVERSION_HEADER_ID = @l_Hdr_ID
	   AND LEGACY_FILE_GROUP = 'GROUP1'
	    AND LEGACY_FILE_NAME = @l_File_Name

  Goto NextRec

END

SET @l_Level =50

--Get Table Count
IF  @l_File_Name = 'LAMI_ASSET_RESOURCES' TRUNCATE TABLE PRELAND.LAMI_ASSET_RESOURCES;
IF  @l_File_Name = 'LAMI_EXPENSES' TRUNCATE TABLE PRELAND.LAMI_EXPENSES;
IF  @l_File_Name = 'LAMI_INCOME_EARNED' TRUNCATE TABLE PRELAND.LAMI_INCOME_EARNED;
IF  @l_File_Name = 'LAMI_INCOME_SPECIAL' TRUNCATE TABLE PRELAND.LAMI_INCOME_SPECIAL;
IF  @l_File_Name = 'LAMI_INCOME_UNEARNED' TRUNCATE TABLE PRELAND.LAMI_INCOME_UNEARNED;
IF  @l_File_Name = 'LAMI_LIMIT_AFDC' TRUNCATE TABLE PRELAND.LAMI_LIMIT_AFDC;
IF  @l_File_Name = 'LAMI_LIMIT_FS' TRUNCATE TABLE PRELAND.LAMI_LIMIT_FS;
IF  @l_File_Name = 'LAMI_MEMBER' TRUNCATE TABLE PRELAND.LAMI_MEMBER;
IF  @l_File_Name = 'LAMI_SANCTIONS' TRUNCATE TABLE PRELAND.LAMI_SANCTIONS;
IF  @l_File_Name = 'LAMI_MEMBER_SANCTIONS' TRUNCATE TABLE PRELAND.LAMI_MEMBER_SANCTIONS;

--TRUNCATE TABLE PRELAND.TEMP_GROUP1;
TRUNCATE TABLE PRELAND.TEMP_GROUP1_SEQ;


SET @l_Level =60
--Set bulk load script

SET @SQL_BULK = 'BULK INSERT PRELAND.VW_TEMP_GROUP1_SEQ FROM ''' + @l_File_Path + ''' WITH
        (
        CODEPAGE = ''ACP'',
        FIRSTROW = 1,
        FIELDTERMINATOR = ''tab'',
        ROWTERMINATOR = ''0x0a'',
             --KEEPIDENTITY,
        KEEPNULLS
        )'

--Exec script to populate data into BULK_LOAD

EXEC (@SQL_BULK)
SET @l_Level =70

  SELECT @l_MAX2 = Count(1) from PRELAND.TEMP_GROUP1_SEQ
  Print 'Total Records in PRELAND.TEMP_GROUP1_SEQ: '  + STR(@l_MAX2)

IF @l_MAX2= 0 
 BEGIN
   Print 'No records in the file'
    IF @l_Update_Flag = 'Y'
  UPDATE CONV_ADMIN.DCM_LEGACY_EXTRACT_DETAIL 
  SET FILE_STATUS = 'FILE_HAS_NO_RECORDS'
  WHERE DATA_CONVERSION_HEADER_ID = @l_Hdr_ID
  AND LEGACY_FILE_GROUP = 'GROUP1'
  AND LEGACY_FILE_NAME = @l_File_Name
   goto NEXTREC
 END 

SET @l_Level =72

SELECT @l_Last = MAX(SEQ_ID), @l_First =1 from PRELAND.TEMP_GROUP1_SEQ;

 

--Get Header
SELECT @l_Header = File_Text FROM PRELAND.TEMP_GROUP1_SEQ WHERE Seq_ID = @l_First;
--Get Footer
SELECT @l_footer = File_Text FROM PRELAND.TEMP_GROUP1_SEQ WHERE Seq_ID = @l_Last;

SET @l_Level =75

 
 IF @l_Update_Flag = 'Y'
UPDATE CONV_ADMIN.DCM_LEGACY_EXTRACT_DETAIL 
  SET LEGACY_FILE_DATA_HEADER = substring(@l_Header,1,93),
      LEGACY_FILE_DATA_FOOTER = substring(@l_footer,1,26) 
	  , LEGACY_FILE_DATA_COUNT = cast(SUBSTRING(@l_footer,17,9) as int)
  WHERE DATA_CONVERSION_HEADER_ID = @l_Hdr_ID
  AND LEGACY_FILE_GROUP = 'GROUP1'
  AND LEGACY_FILE_NAME = @l_File_Name


SET @l_Level =76

 

--Delete hdr and footer data
DELETE from PRELAND.TEMP_GROUP1_SEQ Where Seq_ID IN (1,@l_Last);

--Select * from PRELAND.TEMP_GROUP1_SEQ

 

SET @l_Level =77
SELECT @l_From_SEQ = 1, @l_to_Seq = @l_Incremental

--Perform while loop to load data into LSD table for each 100K records

WHILE @l_From_SEQ <= @l_MAX2
BEGIN

SET @l_Level =90
--PRINT 'Processing Data from: ' + STR(@l_From_SEQ) + '  To: ' + STR(@l_to_Seq)

--1.LAMI_ASSET_RESOURCES
IF @l_File_Name = 'LAMI_ASSET_RESOURCES'
BEGIN

 
SET @l_tablename = 'PRELAND.LAMI_ASSET_RESOURCES'
SET @l_Level =100

 

--Insert data
INSERT INTO PRELAND.LAMI_ASSET_RESOURCES
SELECT
SUBSTRING(File_Text,          1,          3),
SUBSTRING(File_Text,          4,          9),
SUBSTRING(File_Text,         13,          2),
SUBSTRING(File_Text,         15,         11),
SUBSTRING(File_Text,         26,          2),
SUBSTRING(File_Text,         28,          1),
SUBSTRING(File_Text,         29,          9),
SUBSTRING(File_Text,         38,          3),
SUBSTRING(File_Text,         41,          8),
SUBSTRING(File_Text,         49,          8),
SUBSTRING(File_Text,         57,          8),
SUBSTRING(File_Text,         65,         15),
SUBSTRING(File_Text,         80,          8),
SUBSTRING(File_Text,         88,          8)
FROM PRELAND.TEMP_GROUP1_SEQ
WHERE SEQ_ID >= @l_From_SEQ AND SEQ_ID <= @l_to_Seq

 

END --1

 

 

 

--2.LAMI_EXPENSES

IF @l_File_Name = 'LAMI_EXPENSES'
BEGIN


SET @l_tablename = 'PRELAND.LAMI_EXPENSES'
SET @l_Level =110

 
--Insert data
INSERT INTO PRELAND.LAMI_EXPENSES
SELECT
SUBSTRING(File_Text,          1,          1),
SUBSTRING(File_Text,          2,          8),
SUBSTRING(File_Text,         10,         11),
SUBSTRING(File_Text,         21,          4),
SUBSTRING(File_Text,         25,          9),
SUBSTRING(File_Text,         34,          1),
SUBSTRING(File_Text,         35,          2),
SUBSTRING(File_Text,         37,          8),
SUBSTRING(File_Text,         45,          2),
SUBSTRING(File_Text,         47,          2),
SUBSTRING(File_Text,         49,          3),
SUBSTRING(File_Text,         52,         15),
SUBSTRING(File_Text,         67,          8),
SUBSTRING(File_Text,         75,          8),
SUBSTRING(File_Text,         83,          8),
SUBSTRING(File_Text,         91,          1)
FROM PRELAND.TEMP_GROUP1_SEQ
WHERE SEQ_ID >= @l_From_SEQ AND SEQ_ID <= @l_to_Seq

END --2

 

 

--3. LAMI_INCOME_EARNED
IF @l_File_Name = 'LAMI_INCOME_EARNED'
BEGIN

SET @l_tablename = 'PRELAND.LAMI_INCOME_EARNED'
SET @l_Level =120

 

--Insert data
INSERT INTO PRELAND.LAMI_INCOME_EARNED
SELECT
SUBSTRING(File_Text,          1,          9),
SUBSTRING(File_Text,         10,          4),
SUBSTRING(File_Text,         14,          2),
SUBSTRING(File_Text,         16,          1),
SUBSTRING(File_Text,         17,          3),
SUBSTRING(File_Text,         20,          8),
SUBSTRING(File_Text,         28,          8),
SUBSTRING(File_Text,         36,          1),
SUBSTRING(File_Text,         37,          8),
SUBSTRING(File_Text,         45,          3),
SUBSTRING(File_Text,         48,          2),
SUBSTRING(File_Text,         50,         11),
SUBSTRING(File_Text,         61,          4),
SUBSTRING(File_Text,         65,         11),
SUBSTRING(File_Text,         76,          4),
SUBSTRING(File_Text,         80,         11),
SUBSTRING(File_Text,         91,          4),
SUBSTRING(File_Text,         95,         11),
SUBSTRING(File_Text,        106,          4),
SUBSTRING(File_Text,        110,         11),
SUBSTRING(File_Text,        121,          4),
SUBSTRING(File_Text,        125,         11),
SUBSTRING(File_Text,        136,          4),
SUBSTRING(File_Text,        140,         11),
SUBSTRING(File_Text,        151,          4),
SUBSTRING(File_Text,        155,         11),
SUBSTRING(File_Text,        166,          4),
SUBSTRING(File_Text,        170,         11),
SUBSTRING(File_Text,        181,          4),
SUBSTRING(File_Text,        185,         11),
SUBSTRING(File_Text,        196,          4),
SUBSTRING(File_Text,        200,         15),
SUBSTRING(File_Text,        215,          8),
SUBSTRING(File_Text,        223,          8),
SUBSTRING(File_Text,        231,         31)
FROM PRELAND.TEMP_GROUP1_SEQ
WHERE SEQ_ID >= @l_From_SEQ AND SEQ_ID <= @l_to_Seq

 

END --3

 

 

--4. LAMI_INCOME_SPECIAL

IF @l_File_Name = 'LAMI_INCOME_SPECIAL'
BEGIN

SET @l_tablename = 'PRELAND.LAMI_INCOME_SPECIAL'

SET @l_Level =130
--Insert data
INSERT INTO PRELAND.LAMI_INCOME_SPECIAL
SELECT
SUBSTRING(File_Text,          1,          9),
SUBSTRING(File_Text,         10,         11),
SUBSTRING(File_Text,         21,          4),
SUBSTRING(File_Text,         25,          4),
SUBSTRING(File_Text,         29,          2),
SUBSTRING(File_Text,         31,         11),
SUBSTRING(File_Text,         42,          2),
SUBSTRING(File_Text,         44,          8),
SUBSTRING(File_Text,         52,          8),
SUBSTRING(File_Text,         60,          1),
SUBSTRING(File_Text,         61,          8),
SUBSTRING(File_Text,         69,          3),
SUBSTRING(File_Text,         72,         15),
SUBSTRING(File_Text,         87,          8),
SUBSTRING(File_Text,         95,          8)
FROM PRELAND.TEMP_GROUP1_SEQ
WHERE SEQ_ID >= @l_From_SEQ AND SEQ_ID <= @l_to_Seq

 

END --4


--5.LAMI_INCOME_UNEARNED

IF @l_File_Name = 'LAMI_INCOME_UNEARNED'
BEGIN

SET @l_tablename = 'PRELAND.LAMI_INCOME_UNEARNED'
SET @l_Level =140

--Insert data
INSERT INTO PRELAND.LAMI_INCOME_UNEARNED
SELECT
SUBSTRING(File_Text,          1,          9),
SUBSTRING(File_Text,         10,          4),
SUBSTRING(File_Text,         14,          2),
SUBSTRING(File_Text,         16,          8),
SUBSTRING(File_Text,         24,          8),
SUBSTRING(File_Text,         32,          1),
SUBSTRING(File_Text,         33,          8),
SUBSTRING(File_Text,         41,          3),
SUBSTRING(File_Text,         44,          2),
SUBSTRING(File_Text,         46,         11),
SUBSTRING(File_Text,         57,         11),
SUBSTRING(File_Text,         68,         11),
SUBSTRING(File_Text,         79,         11),
SUBSTRING(File_Text,         90,         11),
SUBSTRING(File_Text,        101,         11),
SUBSTRING(File_Text,        112,         11),
SUBSTRING(File_Text,        123,         11),
SUBSTRING(File_Text,        134,         11),
SUBSTRING(File_Text,        145,         11),
SUBSTRING(File_Text,        156,         15),
SUBSTRING(File_Text,        171,          8),
SUBSTRING(File_Text,        179,          8)
FROM PRELAND.TEMP_GROUP1_SEQ
WHERE SEQ_ID >= @l_From_SEQ AND SEQ_ID <= @l_to_Seq

END --5

 

 

 

 

--6. LAMI_LIMIT_AFDC

IF @l_File_Name = 'LAMI_LIMIT_AFDC'
BEGIN

SET @l_tablename = 'PRELAND.LAMI_LIMIT_AFDC'
SET @l_Level =150

--Insert data
INSERT INTO PRELAND.LAMI_LIMIT_AFDC
SELECT
SUBSTRING(File_Text,          1,          9),
SUBSTRING(File_Text,         10,          2),
SUBSTRING(File_Text,         12,          8),
SUBSTRING(File_Text,         20,          8),
SUBSTRING(File_Text,         28,          1),
SUBSTRING(File_Text,         29,          8),
SUBSTRING(File_Text,         37,         15),
SUBSTRING(File_Text,         52,          1),
SUBSTRING(File_Text,         53,          2),
SUBSTRING(File_Text,         55,          2),
SUBSTRING(File_Text,         57,          1)
FROM PRELAND.TEMP_GROUP1_SEQ
WHERE SEQ_ID >= @l_From_SEQ AND SEQ_ID <= @l_to_Seq

END --6

 
--7. LAMI_LIMIT_FS

IF @l_File_Name = 'LAMI_LIMIT_FS'
BEGIN
SET @l_tablename = 'PRELAND.LAMI_LIMIT_FS'

SET @l_Level =160
--Insert data
INSERT INTO PRELAND.LAMI_LIMIT_FS
SELECT
SUBSTRING(File_Text,          1,          9),
SUBSTRING(File_Text,         10,          8),
SUBSTRING(File_Text,         18,          8),
SUBSTRING(File_Text,         26,          2),
SUBSTRING(File_Text,         28,          2),
SUBSTRING(File_Text,         30,          2),
SUBSTRING(File_Text,         32,          8),
SUBSTRING(File_Text,         40,         15),
SUBSTRING(File_Text,         55,          1)
FROM PRELAND.TEMP_GROUP1_SEQ
WHERE SEQ_ID >= @l_From_SEQ AND SEQ_ID <= @l_to_Seq

 

END --7

 

 

 

 

--8. LAMI_MEMBER

IF @l_File_Name = 'LAMI_MEMBER'
BEGIN

SET @l_tablename = 'PRELAND.LAMI_MEMBER'
SET @l_Level =170

 

--Insert data
INSERT INTO PRELAND.LAMI_MEMBER
SELECT
SUBSTRING(File_Text,          1,          1),
SUBSTRING(File_Text,          2,          1),
SUBSTRING(File_Text,          3,          2),
SUBSTRING(File_Text,          5,          8),
SUBSTRING(File_Text,         13,          2),
SUBSTRING(File_Text,         15,          8),
SUBSTRING(File_Text,         23,          2),
SUBSTRING(File_Text,         25,          1),
SUBSTRING(File_Text,         26,          2),
SUBSTRING(File_Text,         28,          2),
SUBSTRING(File_Text,         30,          2),
SUBSTRING(File_Text,         32,          8),
SUBSTRING(File_Text,         40,          2),
SUBSTRING(File_Text,         42,          2),
SUBSTRING(File_Text,         44,          1),
SUBSTRING(File_Text,         45,          8),
SUBSTRING(File_Text,         53,          8),
SUBSTRING(File_Text,         61,          1),
SUBSTRING(File_Text,         62,          9),
SUBSTRING(File_Text,         71,         12),
SUBSTRING(File_Text,         83,          1),
SUBSTRING(File_Text,         84,          9),
SUBSTRING(File_Text,         93,          3),
SUBSTRING(File_Text,         96,         12),
SUBSTRING(File_Text,        108,          2),
SUBSTRING(File_Text,        110,          2),
SUBSTRING(File_Text,        112,          9),
SUBSTRING(File_Text,        121,          6),
SUBSTRING(File_Text,        127,          1),
SUBSTRING(File_Text,        128,          2),
SUBSTRING(File_Text,        130,          1),
SUBSTRING(File_Text,        131,          2),
SUBSTRING(File_Text,        133,          9),
SUBSTRING(File_Text,        142,          2),
SUBSTRING(File_Text,        144,          3),
SUBSTRING(File_Text,        147,          1),
SUBSTRING(File_Text,        148,          1),
SUBSTRING(File_Text,        149,          1),
SUBSTRING(File_Text,        150,          9),
SUBSTRING(File_Text,        159,          8),
SUBSTRING(File_Text,        167,          2),
SUBSTRING(File_Text,        169,          2),
SUBSTRING(File_Text,        171,          2),
SUBSTRING(File_Text,        173,          1),
SUBSTRING(File_Text,        174,          8),
SUBSTRING(File_Text,        182,          8),
SUBSTRING(File_Text,        190,          9),
SUBSTRING(File_Text,        199,         12),
SUBSTRING(File_Text,        211,          1),
SUBSTRING(File_Text,        212,          9),
SUBSTRING(File_Text,        221,          9),
SUBSTRING(File_Text,        230,         15),
SUBSTRING(File_Text,        245,          8),
SUBSTRING(File_Text,        253,          1),
SUBSTRING(File_Text,        254,          2),
SUBSTRING(File_Text,        256,          1),
SUBSTRING(File_Text,        257,          1),
SUBSTRING(File_Text,        258,          2),
SUBSTRING(File_Text,        260,          1),
SUBSTRING(File_Text,        261,          1),
SUBSTRING(File_Text,        262,          8),
SUBSTRING(File_Text,        270,          1),
SUBSTRING(File_Text,        271,          1),
SUBSTRING(File_Text,        272,          6),
SUBSTRING(File_Text,        278,          3),
SUBSTRING(File_Text,        281,          2),
SUBSTRING(File_Text,        283,          2),
SUBSTRING(File_Text,        285,          1),
SUBSTRING(File_Text,        286,          8),
SUBSTRING(File_Text,        294,          8),
SUBSTRING(File_Text,        302,          1),
SUBSTRING(File_Text,        303,          8),
SUBSTRING(File_Text,        311,          8),
SUBSTRING(File_Text,        319,          8),
SUBSTRING(File_Text,        327,          8),
SUBSTRING(File_Text,        335,          8)
FROM PRELAND.TEMP_GROUP1_SEQ
WHERE SEQ_ID >= @l_From_SEQ AND SEQ_ID <= @l_to_Seq

 

END --8

 

 

 

 
--9.LAMI_SANCTIONS
IF @l_File_Name = 'LAMI_MEMBER_SANCTIONS'
BEGIN

SET @l_tablename = 'PRELAND.LAMI_MEMBER_SANCTIONS'
SET @l_Level =190

 

--Insert data
INSERT INTO PRELAND.LAMI_MEMBER_SANCTIONS
SELECT
SUBSTRING(File_Text,          1,          9),
SUBSTRING(File_Text,         10,          9),
SUBSTRING(File_Text,         19,          9),
SUBSTRING(File_Text,         28,         12),
SUBSTRING(File_Text,         40,          1),
SUBSTRING(File_Text,         41,          3),
SUBSTRING(File_Text,         44,          8),
SUBSTRING(File_Text,         52,          8),
SUBSTRING(File_Text,         60,         15),
SUBSTRING(File_Text,         75,          8),
SUBSTRING(File_Text,         83,          2),
SUBSTRING(File_Text,         85,          4),
SUBSTRING(File_Text,         89,          9),
SUBSTRING(File_Text,         98,          8),
SUBSTRING(File_Text,        106,          8),
SUBSTRING(File_Text,        114,          8),
SUBSTRING(File_Text,        122,          3),
SUBSTRING(File_Text,        125,          4),
SUBSTRING(File_Text,        129,          8),
SUBSTRING(File_Text,        137,          1),
SUBSTRING(File_Text,        138,          8),
SUBSTRING(File_Text,        146,          8),
SUBSTRING(File_Text,        154,          3),
SUBSTRING(File_Text,        157,         15),
SUBSTRING(File_Text,        172,          8),
SUBSTRING(File_Text,        180,          2),
SUBSTRING(File_Text,        182,          3),
SUBSTRING(File_Text,        185,          1),
SUBSTRING(File_Text,        186,          8),
SUBSTRING(File_Text,        194,          8)
FROM PRELAND.TEMP_GROUP1_SEQ
WHERE SEQ_ID >= @l_From_SEQ AND SEQ_ID <= @l_to_Seq


END --8



--9.LAMI_SANCTIONS
IF @l_File_Name = 'LAMI_SANCTIONS'
BEGIN

SET @l_tablename = 'PRELAND.LAMI_SANCTIONS'
SET @l_Level =190

 

--Insert data
INSERT INTO PRELAND.LAMI_SANCTIONS
SELECT
SUBSTRING(File_Text,          1,          4),
SUBSTRING(File_Text,          5,          9),
SUBSTRING(File_Text,         14,          8),
SUBSTRING(File_Text,         22,          8),
SUBSTRING(File_Text,         30,          8),
SUBSTRING(File_Text,         38,          3),
SUBSTRING(File_Text,         41,          4),
SUBSTRING(File_Text,         45,          8),
SUBSTRING(File_Text,         53,          1),
SUBSTRING(File_Text,         54,          8),
SUBSTRING(File_Text,         62,          8),
SUBSTRING(File_Text,         70,          3),
SUBSTRING(File_Text,         73,         15),
SUBSTRING(File_Text,         88,          8),
SUBSTRING(File_Text,         96,          2),
SUBSTRING(File_Text,         98,          3),
SUBSTRING(File_Text,        101,          1),
SUBSTRING(File_Text,        102,          8),
SUBSTRING(File_Text,        110,          8)
FROM PRELAND.TEMP_GROUP1_SEQ
WHERE SEQ_ID >= @l_From_SEQ AND SEQ_ID <= @l_to_Seq


END --9

--Get Next set of records
SELECT @l_From_SEQ = @l_To_SEQ +1 , @l_To_SEQ = @l_to_SEQ + @l_Incremental

 

END --While loop to loadPrint


 

--Get Table Count
set @l_SQL = N'select @cnt = count(*) from ' + @l_tablename;
exec sp_executesql @l_SQL, N'@cnt int output', @cnt = @l_Table_count output;
 
SET @l_Level =295

 

SET @l_END_Time = Getdate()

 

 

SET @l_time_Taken = DATEDIFF(ss, @l_START_Time, @l_END_Time)
 Print 'Total Records loaded: ' + isnull(STR(@l_Table_count),0) + ' and Time taken: ' + STR(@l_time_Taken)

 

SET @l_Level =200

 

If @l_Update_Flag = 'Y'
UPDATE CONV_ADMIN.DCM_LEGACY_EXTRACT_DETAIL 
  SET LSD_DATA_EXTRACT_DATE = getdate(), 
     TIME_TAKE_FOR_EXTRACT = @l_time_Taken,
  LSD_DATA_EXTRACT_COUNT = @l_Table_count ,
    FILE_STATUS = 'FILE_EXTRACT_SUCCESS'
  WHERE DATA_CONVERSION_HEADER_ID = @l_Hdr_ID
  AND LEGACY_FILE_GROUP = 'GROUP1'
  AND LEGACY_FILE_NAME = @l_File_Name

 

SET @l_Level =210

 

NextRec:

SET @l_Loop = @l_Loop +1

END --While loop for file

 

END TRY

 

BEGIN CATCH
DECLARE @l_Msg VARCHAR(2000) = ERROR_MESSAGE() 
SELECT  
    ERROR_NUMBER() AS ErrorNumber  
    ,ERROR_SEVERITY() AS ErrorSeverity  
    ,ERROR_STATE() AS ErrorState  
    ,ERROR_PROCEDURE() AS ErrorProcedure  
    ,ERROR_LINE() AS ErrorLine  
    ,@l_Msg, --ERROR_MESSAGE() AS ErrorMessage, 
	@l_Level

RAISERROR(@l_Msg, 18,1)
END CATCH




END --PROC

Go




 

 /*


 
 SELECT LEGACY_FILE_NAME, LSD_DATA_EXTRACT_COUNT, LEGACY_FILE_DATA_COUNT
FROM  CONV_ADMIN.DCM_LEGACY_EXTRACT_DETAIL  A
  WHERE DATA_CONVERSION_HEADER_ID = 12
  AND LEGACY_FILE_GROUP = 'Group1'


EXEC PR_EXTRACT_LAMI_GROUP1_FILES


SELECT LEGACY_FILE_GROUP, Count(1)
FROM  CONV_ADMIN.DCM_LEGACY_EXTRACT_DETAIL  A
  WHERE DATA_CONVERSION_HEADER_ID = 2
GROUP BY LEGACY_FILE_GROUP
Order By cast(Substring(LEGACY_FILE_GROUP,6,2) as INT)




SELECT LEGACY_FILE_GROUP, LEGACY_FILE_NAME, LEGACY_TABLE_NAME,	LEGACY_FILE_PATH
FROM  CONV_ADMIN.DCM_LEGACY_MASTER_FILES  A
--GROUP BY LEGACY_FILE_GROUP
Order By cast(Substring(LEGACY_FILE_GROUP,6,2) as INT)

UPDATE  A
SET LEGACY_TABLE_NAME = REPLACE(LEGACY_TABLE_NAME, 'LAND.', '')
--SELECT LSD_TABLE_NAME, LSD_DATA_EXTRACT_DATE, LSD_DATA_EXTRACT_COUNT, TIME_TAKE_FOR_EXTRACT, FILE_STATUS
FROM  CONV_ADMIN.DCM_LEGACY_MASTER_FILES  A
  WHERE Left(LEGACY_TABLE_NAME,5)= 'LAND.'


DELETE A
--SELECT LSD_TABLE_NAME, LSD_DATA_EXTRACT_DATE, LSD_DATA_EXTRACT_COUNT, TIME_TAKE_FOR_EXTRACT, FILE_STATUS
FROM  CONV_ADMIN.DCM_LEGACY_EXTRACT_DETAIL  A
  WHERE DATA_CONVERSION_HEADER_ID = 2
  AND LEGACY_FILE_GROUP = 'GROUP7'

 
SELECT LSD_TABLE_NAME, LSD_DATA_EXTRACT_DATE, LSD_DATA_EXTRACT_COUNT, TIME_TAKE_FOR_EXTRACT, FILE_STATUS
FROM  CONV_ADMIN.DCM_LEGACY_EXTRACT_DETAIL 
  WHERE DATA_CONVERSION_HEADER_ID = 26
  AND LEGACY_FILE_GROUP = 'GROUP1'

 --Stats on 11/21 took 10:30

*/

